---
name: escalation_tracking
display_name: Enhanced Escalation Intelligence with Semantic Detection & Multi-Table Analysis
description: Comprehensive escalation analysis using Qwen 0.6B semantic embeddings, 3-level topic classification, sentiment journey tracking, and multi-table intelligence. Detects escalations through dual detection methods and provides complete escalation customer experience analytics. Use for "escalation analysis", "buyback intelligence", "legal threat tracking", "management escalation patterns".
signals:
  - escalation analysis
  - escalation intelligence
  - escalation tracking
  - buyback analysis
  - legal threat detection
  - management escalation
  - lemon law tracking
  - customer escalation experience
  - escalation sentiment analysis
  - escalation conversation analysis
  - escalation topic classification
  - escalation transcript analysis
  - comprehensive escalation analytics
  - escalation business intelligence
  - escalation process improvement
requires:
  - date range for temporal analysis
  - flag query (what type of escalation to analyze)
capabilities:
  - Dual escalation detection using Qwen/Qwen3-Embedding-0.6B semantic embeddings AND 3-level topic classification
  - Complete call content analysis including summaries AND full transcripts from call_table
  - Multi-table intelligence combining 8+ Ford data sources for comprehensive escalation context
  - Customer sentiment journey tracking from call start to end for escalation experience measurement
  - Vehicle-escalation correlation using apple-to-apple matching via models table
  - Parts availability intelligence for identifying supply chain issues driving escalations
  - Agent team and case classification analysis for operational escalation handling insights
  - Business intelligence with actionable recommendations for escalation process improvement
  - No hardcoded values - all detection based on user query and data-driven analysis
not_good_for: General vehicle issues (use keyword_search), non-escalation analysis (use flag_examples), simple counts (use flag_counts)
---

# Enhanced Escalation Intelligence with Semantic Detection & Multi-Table Analysis

## What this does
Provides comprehensive escalation analysis using dual detection methods (semantic embeddings + topic classification) with complete multi-table intelligence. Analyzes escalation customer conversations including full transcripts, sentiment journeys, and business context to deliver actionable escalation process insights.

## Production Features
- **Dual Detection Methods**: Combines Qwen 0.6B semantic search with 3-level topic classification for maximum escalation detection coverage
- **Complete Call Content**: Analyzes both call summaries AND full transcripts from call_table for comprehensive conversation understanding
- **Multi-Table Intelligence**: Integrates 8+ Ford data sources including sentiments, vehicles, parts, cases, and agent teams
- **Sentiment Journey Analysis**: Tracks customer and agent sentiment from call start to end during escalation interactions
- **Vehicle-Escalation Correlation**: Apple-to-apple vehicle matching with detailed escalation mention analysis
- **Parts Availability Intelligence**: Identifies supply chain issues and customer frustration driving escalations
- **Business Classification Integration**: Correlates with case metadata and agent team performance
- **User-Query Driven**: No hardcoded values - searches for exactly what user specifies in flag parameter

## How to run it

```bash
python .claude/skills/escalation_tracking/scripts/escalation_tracking.py --from 2026-01-01 --to 2026-01-31 --flag "escalation"
```

## Enhanced Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--from` | Yes | — | Start date YYYY-MM-DD for temporal analysis |
| `--to` | Yes | — | End date YYYY-MM-DD for temporal analysis |
| `--flag` | Yes | — | Escalation query to search (e.g., "buyback", "legal threat", "management escalation") |
| `--vehicle` | No | all | Filter by specific vehicle (partial match) |
| `--similarity-threshold` | No | 0.4 | Minimum similarity score for semantic matching (0.0-1.0) |
| `--limit` | No | 100 | Number of detailed examples to return (100 or 1000) |

## Example Usage

```bash
# Basic escalation analysis
python escalation_tracking.py --from 2026-01-01 --to 2026-01-31 --flag "escalation"

# Buyback request analysis  
python escalation_tracking.py --from 2026-01-01 --to 2026-01-31 --flag "buyback"

# Legal threat tracking
python escalation_tracking.py --from 2026-01-01 --to 2026-01-31 --flag "legal threat"

# Management escalation patterns
python escalation_tracking.py --from 2026-01-01 --to 2026-01-31 --flag "management escalation"

# Lemon law analysis
python escalation_tracking.py --from 2026-01-01 --to 2026-01-31 --flag "lemon law"

# Vehicle-specific escalation analysis
python escalation_tracking.py --from 2026-01-01 --to 2026-01-31 --flag "escalation" --vehicle "F-150"

# High-precision semantic analysis
python escalation_tracking.py --from 2026-01-01 --to 2026-01-31 --flag "BBB complaint" --similarity-threshold 0.6

# Large-scale escalation intelligence
python escalation_tracking.py --from 2026-01-01 --to 2026-01-31 --flag "escalation" --limit 1000

# Safety escalation analysis
python escalation_tracking.py --from 2026-01-01 --to 2026-01-31 --flag "safety concern" --vehicle "Explorer"

# NHTSA complaint tracking
python escalation_tracking.py --from 2026-01-01 --to 2026-01-31 --flag "NHTSA complaint"
```

## Enhanced Output Format

```json
{
  "flag": "escalation",
  "semantic_query_used": "escalation",
  "parameters": {
    "search_method": "semantic_embeddings_plus_topics",
    "embedding_model": "Qwen/Qwen3-Embedding-0.6B",
    "similarity_threshold": 0.4,
    "topic_levels_analyzed": 3,
    "date_range": {"from": "2026-01-01", "to": "2026-01-31"},
    "vehicle_filter": "F-150"
  },
  "detection_summary": {
    "total_matches": 1456,
    "semantic_matches": 1034,
    "topic_matches": 422,
    "analyzed_examples": 100,
    "detection_methods": {
      "Semantic Detection": 73,
      "Topic Classification": 27
    }
  },
  "sentiment_analysis": {
    "avg_customer_sentiment": -0.67,
    "total_calls_analyzed": 1456
  },
  "topic_classification": [
    {
      "topic_hierarchy": "Customer Escalation Request > Management Contact Request > Seeking higher authority assistance",
      "call_count": 523
    },
    {
      "topic_hierarchy": "Legal Process Inquiry > Buyback Request Process > Lemon law consultation",
      "call_count": 312
    }
  ],
  "vehicle_analysis": [
    {
      "vehicle": "F-150",
      "call_count": 456
    },
    {
      "vehicle": "Explorer", 
      "call_count": 287
    }
  ],
  "examples": [
    {
      "call_id": "825961407234",
      "call_date": "2026-01-15",
      "call_summary_preview": "Customer demanding buyback for repeated transmission issues, threatening legal action...",
      "call_transcript": "Customer: I want my money back for this lemon. I've had it with Ford and I'm calling my lawyer if this isn't resolved today...",
      "vehicle_model": "F-150",
      "model_year": "2024",
      "agent_team": "MPH-CRC_Escalation_1",
      "case_level1": "Escalation",
      "topic_broad": "Customer Escalation Request",
      "topic_mid": "Legal Process Inquiry", 
      "topic_specific": "Buyback request with legal threat",
      "parts_concern": "Transmission Issue",
      "customer_sentiment": -0.89,
      "agent_sentiment": 0.12,
      "sentiment_gap": -1.01,
      "customer_start_sentiment": -0.85,
      "customer_end_sentiment": -0.93,
      "customer_sentiment_change": -0.08,
      "complexity_score": 0.94,
      "number_of_transfers": 1,
      "handle_time_minutes": 12.45,
      "detection_method": "Semantic Detection"
    }
  ],
  "data_sources": [
    "sentiments (customer/agent sentiment journey)",
    "call_data (core call information)",
    "embedding_table (Qwen 0.6B semantic search)",
    "call_table (transcripts and agent teams)",
    "models (vehicle correlation)",
    "parts_unfiltered (component analysis)",
    "topic_detail (3-level topic hierarchy)",
    "case_metadata (business classification)"
  ]
}
```

## Advanced Analytics Features

### Dual Detection Intelligence
- **Semantic Embeddings**: Qwen 0.6B model identifies escalation content beyond exact keyword matching
- **3-Level Topic Classification**: Searches topic_level1, topic_level2, topic_level3 for comprehensive coverage
- **Combined Detection**: Union of both methods ensures maximum escalation conversation identification
- **User-Query Driven**: Searches for exactly what user specifies - no hardcoded patterns

### Complete Call Content Analysis  
- **Call Summaries**: Quick overview from embedding table summaries
- **Full Transcripts**: Complete customer-agent conversations from call_table
- **Conversation Context**: Understand why customers are escalating and how
- **Agent Response Analysis**: Evaluate how agents handle escalation inquiries

### Multi-Dimensional Escalation Intelligence
- **Sentiment Journey**: Track customer emotion from call start to end during escalation interactions
- **Vehicle Correlation**: Apple-to-apple vehicle matching for accurate escalation-to-vehicle analysis
- **Parts Intelligence**: Component correlation and supply chain issue identification driving escalations
- **Business Context**: Case classification and agent team performance analysis

### Operational Intelligence
- **Detection Method Effectiveness**: Compare semantic vs topic classification performance
- **Agent Team Analysis**: Identify which teams handle escalations most effectively
- **Complexity Scoring**: Understand operational burden of different escalation types
- **Process Improvement**: Identify patterns in customer escalation and resolution

## Key Use Cases

### Comprehensive Escalation Experience Analysis
- **"Complete customer experience with F-150 buyback requests"** - Full conversation analysis with sentiment tracking
- **"How do customers really feel about our escalation handling?"** - Sentiment journey and transcript analysis
- **"What are customers actually saying about legal threats?"** - Full conversation context analysis

### Escalation Process Intelligence
- **"Which escalation conversations are most complex?"** - Complexity and transfer analysis
- **"How effective are our escalation specialist teams?"** - Agent team performance evaluation
- **"What topics dominate escalation conversations?"** - 3-level topic hierarchy analysis

### Business Intelligence & Improvement
- **"Identify patterns in customer escalation triggers"** - Sentiment decline analysis during calls
- **"Parts availability impact on escalation rates"** - Supply chain correlation with escalations
- **"Escalation communication effectiveness measurement"** - Detection method and resolution analysis

### Risk Management & Legal Intelligence
- **"Customer legal threat patterns and severity"** - Legal risk assessment
- **"Buyback request escalation tracking"** - Financial risk monitoring  
- **"Customer understanding of escalation processes"** - Conversation content and complexity analysis

## Business Value
Enhanced escalation_tracking provides strategic escalation intelligence for:
- **Customer Experience Optimization**: Complete escalation conversation analysis for process improvement
- **Risk Management**: Comprehensive tracking of legal threats, buyback requests, and regulatory risks
- **Operational Excellence**: Agent team performance and escalation handling process optimization
- **Financial Intelligence**: Early identification of potential costly escalation patterns
- **Business Strategy**: Data-driven escalation prevention and resolution improvement based on actual conversations

## Technical Features

### Advanced Semantic + Topic Engine
- **Dual Detection**: Qwen/Qwen3-Embedding-0.6B embeddings PLUS 3-level topic classification
- **Complete Coverage**: Semantic understanding combined with structured topic categorization
- **User-Query Driven**: Searches for exactly what user specifies with no hardcoded limitations
- **Processing**: Batch-based embedding analysis with comprehensive topic correlation

### Multi-Table Architecture  
- **8+ Data Sources**: Complete integration across Ford data ecosystem
- **Complete Call Content**: Both summaries AND full transcripts for comprehensive analysis
- **Sentiment Intelligence**: Customer journey tracking from call start to completion
- **Business Correlation**: Case classification, agent teams, vehicle matching, and parts correlation

### Production-Ready Features
- **Flexible Limits**: Support for 100 or 1000 examples based on analysis needs
- **Vehicle Filtering**: Focus analysis on specific vehicle models
- **Similarity Tuning**: Adjustable semantic similarity thresholds for precision control
- **Comprehensive Logging**: Detailed progress tracking and diagnostics

## Error Handling
Robust error handling with comprehensive logging, graceful degradation, and detailed diagnostics for maximum reliability in production escalation monitoring and analysis environments.