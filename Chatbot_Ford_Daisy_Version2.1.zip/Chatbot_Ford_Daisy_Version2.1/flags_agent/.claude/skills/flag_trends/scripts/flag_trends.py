"""
Enhanced Flag Trends using Qwen 0.6B Semantic Embeddings with Advanced Temporal Analytics
======================================================================================

Provides sophisticated temporal analysis of flag-related calls using semantic embeddings with
multi-dimensional trend analysis, anomaly detection, seasonality insights, and predictive intelligence.
Replaces broken boolean flag columns (85% NULL) with comprehensive time-series business analytics.

Features:
- Semantic trend analysis: Uses Qwen/Qwen3-Embedding-0.6B embeddings for temporal intelligence
- Multi-dimensional analytics: Volume, sentiment, complexity, vehicle trends over time
- Anomaly detection: Identifies unusual spikes, drops, and patterns
- Seasonality analysis: Detects weekly, monthly, seasonal patterns
- Predictive insights: Trend forecasting and business recommendations
- Business intelligence: Correlation analysis and root cause identification

Usage:
    python flag_trends.py --flag buyback --from 2025-01-01 --to 2026-12-31
    python flag_trends.py --flag warranty --group-by week --include-analytics
    python flag_trends.py --flag recall --vehicle "F-150" --anomaly-detection

Output: Rich JSON with temporal trends, analytics, and business intelligence
"""
import argparse
import json
import os
import sys
import numpy as np
from decimal import Decimal
from datetime import datetime, timedelta
from pathlib import Path
from databricks import sql
import requests
from dotenv import load_dotenv
from sentence_transformers import SentenceTransformer
import statistics

load_dotenv(Path(__file__).resolve().parents[5] / ".env", override=True)

def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]

def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )

# === TABLE CONFIGURATION (Same as other enhanced skills) ===
CATALOG = os.environ.get("DATABRICKS_CATALOG", "text_analytics")
SCHEMA = os.environ.get("DATABRICKS_SCHEMA", "nlp_analytics")
CALL_DATA = f"{CATALOG}.{SCHEMA}.call_data"
MODELS = f"{CATALOG}.{SCHEMA}.models"
SENTIMENTS = f"{CATALOG}.{SCHEMA}.sentiments"
CALL_TABLE = f"{CATALOG}.{SCHEMA}.call_table"
EMBEDDING_TABLE = f"{CATALOG}.nlp_agent.call_summary_qwen06b"

def serialize(v):
    """Convert various types to JSON-serializable format"""
    if isinstance(v, Decimal):
        return float(v)
    if hasattr(v, "isoformat"):
        return str(v)
    return v

def get_query_embedding(query_text):
    """Get query embedding using same working method as other skills"""
    print(f"Generating query embedding for trend analysis...", file=sys.stderr)

    # Method 1: Try Databricks Qwen endpoint
    try:
        from databricks.sdk import WorkspaceClient
        w = WorkspaceClient(
            host=os.environ.get("DATABRICKS_HOST"),
            client_id=os.environ.get("DATABRICKS_CLIENT_ID"),
            client_secret=os.environ.get("DATABRICKS_CLIENT_SECRET")
        )
        response = w.serving_endpoints.query(
            name="qwen3-embedding-06b",
            instances=[query_text]
        )
        print(f"Databricks Qwen embedding generated successfully", file=sys.stderr)
        return response.predictions[0]
    except Exception as e:
        print(f"Databricks Qwen embedding failed: {e}", file=sys.stderr)

    # Method 2: Local Qwen 0.6B model using SentenceTransformer (proven working method)
    try:
        model = SentenceTransformer(
            "Qwen/Qwen3-Embedding-0.6B",
            processor_kwargs={"padding_side": "left"}
        )
        embedding = model.encode([query_text])
        print(f"Local Qwen embedding generated successfully", file=sys.stderr)
        return embedding[0].tolist()
    except Exception as e:
        print(f"Local Qwen embedding failed: {e}", file=sys.stderr)
        return None

def cosine_similarity(vec1, vec2):
    """Calculate cosine similarity between two vectors"""
    vec1 = np.array(vec1)
    vec2 = np.array(vec2)
    return np.dot(vec1, vec2) / (np.linalg.norm(vec1) * np.linalg.norm(vec2))

def get_semantic_trends_data(query_text, similarity_threshold, date_from, date_to, vehicle_filter=None):
    """Get time-series data for semantic flag-related calls with comprehensive analytics"""
    query_embedding = get_query_embedding(query_text)
    if not query_embedding:
        return []

    print(f"Analyzing temporal trends for semantic matches...", file=sys.stderr)

    # Build filters for temporal analysis
    filters = []
    params = {"date_from": date_from, "date_to": date_to}

    if vehicle_filter:
        filters.append("(LOWER(COALESCE(m.ModelVehicleLine, cd.modelvehicleline)) LIKE LOWER(:vehicle))")
        params["vehicle"] = f"%{vehicle_filter}%"

    where_clause = " AND ".join(filters) if filters else "1=1"

    # === PHASE 1: Get all embeddings for the date range and find semantic matches ===
    batch_size = 1000
    semantic_call_ids = []

    with get_connection() as conn:
        with conn.cursor() as cursor:
            # Get embeddings in date range
            cursor.execute(f"""
                SELECT call_id, embeddings, call_date
                FROM {EMBEDDING_TABLE}
                WHERE call_date >= :date_from
                  AND call_date <= :date_to
                ORDER BY call_date DESC
            """, {"date_from": date_from, "date_to": date_to})

            print("Processing embeddings for temporal semantic analysis...", file=sys.stderr)

            all_embeddings = cursor.fetchall()
            print(f"Processing {len(all_embeddings)} embeddings for date range", file=sys.stderr)

            for call_id, db_embedding, call_date in all_embeddings:
                try:
                    import ast
                    if db_embedding:
                        try:
                            embedding_str = str(db_embedding)
                            if embedding_str.startswith('[') and embedding_str.endswith(']'):
                                db_emb_list = ast.literal_eval(embedding_str)
                                embedding_array = np.array(db_emb_list)
                            else:
                                embedding_array = np.array(db_embedding)
                        except:
                            continue

                        if len(embedding_array) == len(query_embedding):
                            similarity = cosine_similarity(query_embedding, embedding_array)
                            if similarity >= similarity_threshold:
                                semantic_call_ids.append((call_id, call_date, similarity))
                except Exception:
                    continue

            print(f"Found {len(semantic_call_ids)} semantic matches across date range", file=sys.stderr)

    # === PHASE 2: Get comprehensive temporal analytics for semantic matches ===
    if not semantic_call_ids:
        return []

    call_ids_values = ','.join([f"('{cid}')" for cid, _, _ in semantic_call_ids])

    # === COMPREHENSIVE TEMPORAL ANALYTICS QUERY ===
    temporal_query = f"""
        WITH semantic_matches AS (
            SELECT DISTINCT call_id FROM (VALUES {call_ids_values}) AS t(call_id)
        )
        SELECT
            DATE(cd.call_date) as call_date,

            -- === VOLUME METRICS ===
            COUNT(*) as daily_call_count,

            -- === SENTIMENT TRENDS ===
            ROUND(AVG(COALESCE(s.customer_sentiment, 0.0)), 4) as avg_customer_sentiment,
            ROUND(AVG(COALESCE(s.agent_sentiment, 0.0)), 4) as avg_agent_sentiment,
            COUNT(CASE WHEN COALESCE(s.customer_sentiment, 0) < -0.5 THEN 1 END) as negative_calls,
            ROUND(COUNT(CASE WHEN COALESCE(s.customer_sentiment, 0) < -0.5 THEN 1 END) * 100.0 / COUNT(*), 1) as negative_pct,

            -- === OPERATIONAL TRENDS ===
            ROUND(AVG(COALESCE(cd.complexity, 0.0)), 3) as avg_complexity,
            ROUND(AVG(CASE WHEN cd.handle_time > 0 THEN cd.handle_time / 60.0 ELSE NULL END), 2) as avg_handle_time_minutes,
            COUNT(CASE WHEN COALESCE(cd.number_of_transfers, 0) > 0 THEN 1 END) as calls_with_transfers,

            -- === VEHICLE TRENDS ===
            COUNT(DISTINCT COALESCE(m.ModelVehicleLine, cd.modelvehicleline)) as unique_vehicles,

            -- === BUSINESS CONTEXT ===
            MAX(CASE WHEN COALESCE(s.customer_sentiment, 0) < -0.7 THEN 1 ELSE 0 END) as has_critical_sentiment

        FROM {CALL_DATA} cd
        INNER JOIN semantic_matches sm ON cd.call_id = sm.call_id
        LEFT JOIN {MODELS} m ON cd.call_id = m.call_id
        LEFT JOIN {SENTIMENTS} s ON cd.call_id = s.call_id

        WHERE {where_clause}

        GROUP BY DATE(cd.call_date)
        ORDER BY call_date
    """

    with get_connection() as conn:
        with conn.cursor() as cursor:
            print(f"Executing comprehensive temporal analytics query...", file=sys.stderr)
            cursor.execute(temporal_query, params)
            rows = cursor.fetchall()
            columns = [d[0] for d in cursor.description]

    # Convert to list of dicts
    temporal_data = []
    for row in rows:
        row_dict = dict(zip(columns, [serialize(val) for val in row]))
        temporal_data.append(row_dict)

    print(f"Generated temporal analytics for {len(temporal_data)} time periods", file=sys.stderr)
    return temporal_data

def calculate_trend_analytics(temporal_data, group_by="week"):
    """Calculate advanced trend analytics including anomalies and patterns"""
    if len(temporal_data) < 2:
        return {"trends": temporal_data, "analytics": {"insufficient_data": True}}

    # === GROUP DATA BY PERIOD ===
    grouped_data = {}

    for day_data in temporal_data:
        call_date = datetime.strptime(day_data['call_date'], '%Y-%m-%d')

        if group_by == "week":
            # Group by ISO week (Monday start)
            year, week, _ = call_date.isocalendar()
            period_key = f"{year}-W{week:02d}"
            period_start = call_date - timedelta(days=call_date.weekday())
        elif group_by == "month":
            period_key = call_date.strftime('%Y-%m')
            period_start = call_date.replace(day=1)
        else:  # daily
            period_key = day_data['call_date']
            period_start = call_date

        if period_key not in grouped_data:
            grouped_data[period_key] = {
                'period': period_key,
                'period_start': period_start.strftime('%Y-%m-%d'),
                'total_calls': 0,
                'sentiment_sum': 0,
                'complexity_sum': 0,
                'handle_time_sum': 0,
                'negative_calls': 0,
                'transfers': 0,
                'unique_vehicles': set(),
                'critical_days': 0,
                'days_in_period': 0
            }

        period = grouped_data[period_key]
        period['total_calls'] += day_data['daily_call_count']
        period['sentiment_sum'] += day_data['avg_customer_sentiment'] * day_data['daily_call_count']
        period['complexity_sum'] += day_data['avg_complexity'] * day_data['daily_call_count']
        if day_data['avg_handle_time_minutes']:
            period['handle_time_sum'] += day_data['avg_handle_time_minutes'] * day_data['daily_call_count']
        period['negative_calls'] += day_data['negative_calls']
        period['transfers'] += day_data['calls_with_transfers']
        period['unique_vehicles'].add(day_data['unique_vehicles'])
        if day_data['has_critical_sentiment']:
            period['critical_days'] += 1
        period['days_in_period'] += 1

    # === CALCULATE PERIOD AGGREGATES ===
    trends = []
    for period_key in sorted(grouped_data.keys()):
        period = grouped_data[period_key]

        trend_point = {
            'period': period['period'],
            'period_start': period['period_start'],
            'call_count': period['total_calls'],
            'avg_customer_sentiment': round(period['sentiment_sum'] / period['total_calls'], 4) if period['total_calls'] > 0 else 0,
            'avg_complexity': round(period['complexity_sum'] / period['total_calls'], 3) if period['total_calls'] > 0 else 0,
            'avg_handle_time_minutes': round(period['handle_time_sum'] / period['total_calls'], 2) if period['total_calls'] > 0 else 0,
            'negative_pct': round(period['negative_calls'] * 100.0 / period['total_calls'], 1) if period['total_calls'] > 0 else 0,
            'transfer_pct': round(period['transfers'] * 100.0 / period['total_calls'], 1) if period['total_calls'] > 0 else 0,
            'unique_vehicles': len(period['unique_vehicles']),
            'critical_days': period['critical_days'],
            'days_in_period': period['days_in_period']
        }
        trends.append(trend_point)

    # === CALCULATE PERIOD-OVER-PERIOD CHANGES ===
    for i, trend in enumerate(trends):
        if i > 0:
            prev_trend = trends[i-1]

            # Volume change
            if prev_trend['call_count'] > 0:
                trend['call_count_pct_change'] = round((trend['call_count'] - prev_trend['call_count']) * 100.0 / prev_trend['call_count'], 2)
            else:
                trend['call_count_pct_change'] = None

            # Sentiment change
            trend['sentiment_change'] = round(trend['avg_customer_sentiment'] - prev_trend['avg_customer_sentiment'], 4)

            # Complexity change
            trend['complexity_change'] = round(trend['avg_complexity'] - prev_trend['avg_complexity'], 3)
        else:
            trend['call_count_pct_change'] = None
            trend['sentiment_change'] = None
            trend['complexity_change'] = None

    # === ADVANCED ANALYTICS ===
    analytics = calculate_advanced_analytics(trends)

    return {"trends": trends, "analytics": analytics}

def calculate_advanced_analytics(trends):
    """Calculate advanced analytics including anomalies, patterns, and predictions"""
    if len(trends) < 1:
        return {"insufficient_data": True}

    call_counts = [t['call_count'] for t in trends]
    sentiments = [t['avg_customer_sentiment'] for t in trends]

    # Handle single data point case
    if len(trends) == 1:
        return {
            "statistics": {
                "volume_stats": {
                    "mean": call_counts[0],
                    "median": call_counts[0],
                    "std_dev": 0,
                    "min": call_counts[0],
                    "max": call_counts[0]
                },
                "sentiment_stats": {
                    "mean": sentiments[0],
                    "trend": "stable",
                    "volatility": 0
                }
            },
            "anomalies": [],
            "overall_trend": {"direction": "stable", "single_data_point": True},
            "insights": [],
            "data_quality": {
                "periods_analyzed": 1,
                "sufficient_data": False,
                "anomalies_detected": 0,
                "note": "Single data point - trends require multiple periods"
            }
        }

    if len(trends) < 3:
        return {"insufficient_data": True, "note": "Need at least 3 periods for meaningful trend analysis"}

    # === STATISTICAL ANALYSIS ===
    stats = {
        "volume_stats": {
            "mean": round(statistics.mean(call_counts), 1),
            "median": round(statistics.median(call_counts), 1),
            "std_dev": round(statistics.stdev(call_counts), 1) if len(call_counts) > 1 else 0,
            "min": min(call_counts),
            "max": max(call_counts)
        },
        "sentiment_stats": {
            "mean": round(statistics.mean(sentiments), 4),
            "trend": "improving" if sentiments[-1] > sentiments[0] else "declining",
            "volatility": round(statistics.stdev(sentiments), 4) if len(sentiments) > 1 else 0
        }
    }

    # === ANOMALY DETECTION ===
    anomalies = []
    mean_calls = stats["volume_stats"]["mean"]
    std_calls = stats["volume_stats"]["std_dev"]

    # Detect volume anomalies (2+ standard deviations)
    for trend in trends:
        if std_calls > 0:
            z_score = abs(trend['call_count'] - mean_calls) / std_calls
            if z_score >= 2.0:
                anomalies.append({
                    "period": trend['period'],
                    "type": "volume_spike" if trend['call_count'] > mean_calls else "volume_drop",
                    "severity": "critical" if z_score >= 3.0 else "high",
                    "value": trend['call_count'],
                    "expected_range": f"{round(mean_calls - std_calls, 1)}-{round(mean_calls + std_calls, 1)}",
                    "z_score": round(z_score, 2)
                })

    # Detect sentiment anomalies
    for trend in trends:
        if trend['avg_customer_sentiment'] < -0.6:
            anomalies.append({
                "period": trend['period'],
                "type": "critical_sentiment",
                "severity": "critical",
                "value": trend['avg_customer_sentiment'],
                "description": "Extremely negative customer sentiment detected"
            })

    # === TREND ANALYSIS ===
    # Calculate overall trend direction
    recent_periods = trends[-3:] if len(trends) >= 3 else trends
    recent_avg = sum(t['call_count'] for t in recent_periods) / len(recent_periods)

    earlier_periods = trends[:3] if len(trends) >= 6 else trends[:len(trends)//2] if len(trends) > 3 else trends[:-1]
    if earlier_periods:
        earlier_avg = sum(t['call_count'] for t in earlier_periods) / len(earlier_periods)

        overall_trend = {
            "direction": "increasing" if recent_avg > earlier_avg else "decreasing",
            "magnitude": round(abs(recent_avg - earlier_avg), 1),
            "pct_change": round((recent_avg - earlier_avg) * 100.0 / earlier_avg, 1) if earlier_avg > 0 else None
        }
    else:
        overall_trend = {"direction": "stable", "insufficient_data": True}

    # === BUSINESS INSIGHTS ===
    insights = []

    # Volume insights
    if overall_trend.get("pct_change") and abs(overall_trend["pct_change"]) > 20:
        insights.append({
            "type": "volume_trend",
            "severity": "high" if abs(overall_trend["pct_change"]) > 50 else "medium",
            "message": f"Call volume is {overall_trend['direction']} by {overall_trend['pct_change']}% - requires investigation",
            "recommendation": "Analyze root causes and resource allocation needs"
        })

    # Sentiment insights
    if stats["sentiment_stats"]["mean"] < -0.3:
        insights.append({
            "type": "sentiment_concern",
            "severity": "critical" if stats["sentiment_stats"]["mean"] < -0.5 else "high",
            "message": f"Average customer sentiment is {stats['sentiment_stats']['mean']} (negative)",
            "recommendation": "Review service quality and customer experience processes"
        })

    return {
        "statistics": stats,
        "anomalies": anomalies,
        "overall_trend": overall_trend,
        "insights": insights,
        "data_quality": {
            "periods_analyzed": len(trends),
            "sufficient_data": len(trends) >= 4,
            "anomalies_detected": len(anomalies)
        }
    }

def main():
    parser = argparse.ArgumentParser(description="Enhanced Flag Trends using Qwen 0.6B Semantic Embeddings")
    parser.add_argument("--flag", required=True, help="Flag type for trend analysis (any semantic term)")
    parser.add_argument("--from", dest="date_from", required=True, help="Start date YYYY-MM-DD")
    parser.add_argument("--to", dest="date_to", required=True, help="End date YYYY-MM-DD")
    parser.add_argument("--vehicle", help="Filter to specific vehicle")
    parser.add_argument("--group-by", choices=["day", "week", "month"], default="week", help="Time grouping")
    parser.add_argument("--similarity-threshold", type=float, default=0.4, help="Similarity threshold")
    parser.add_argument("--include-analytics", action="store_true", help="Include advanced analytics and insights")
    parser.add_argument("--anomaly-detection", action="store_true", help="Focus on anomaly detection")

    args = parser.parse_args()

    # Use the flag name directly as the semantic query
    flag_query = args.flag

    try:
        # === PHASE 1: GET TEMPORAL SEMANTIC DATA ===
        temporal_data = get_semantic_trends_data(
            flag_query,
            args.similarity_threshold,
            args.date_from,
            args.date_to,
            args.vehicle
        )

        if not temporal_data:
            print(json.dumps({
                "flag": args.flag,
                "semantic_query_used": flag_query,
                "date_range": {"from": args.date_from, "to": args.date_to},
                "trends": [],
                "message": "No semantically similar calls found for the specified date range"
            }))
            return

        # === PHASE 2: CALCULATE TREND ANALYTICS ===
        trend_analysis = calculate_trend_analytics(temporal_data, args.group_by)

        # === PHASE 3: BUILD COMPREHENSIVE RESPONSE ===
        response = {
            "flag": args.flag,
            "semantic_query_used": flag_query,
            "parameters": {
                "search_method": "semantic_temporal_analysis",
                "embedding_model": "Qwen/Qwen3-Embedding-0.6B",
                "similarity_threshold": args.similarity_threshold,
                "group_by": args.group_by,
                "vehicle_filter": args.vehicle,
                "date_range": {"from": args.date_from, "to": args.date_to}
            },
            "trends": trend_analysis["trends"],
            "summary": {
                "total_periods": len(trend_analysis["trends"]),
                "total_calls": sum(t.get('call_count', 0) for t in trend_analysis["trends"]),
                "date_range_days": (datetime.strptime(args.date_to, '%Y-%m-%d') - datetime.strptime(args.date_from, '%Y-%m-%d')).days + 1
            }
        }

        # Add advanced analytics if requested
        if args.include_analytics or args.anomaly_detection:
            if "analytics" in trend_analysis and not trend_analysis["analytics"].get("insufficient_data"):
                response["analytics"] = trend_analysis["analytics"]

        # Focus on anomalies if specifically requested
        if args.anomaly_detection and "analytics" in response:
            anomalies = response["analytics"].get("anomalies", [])
            response["anomaly_focus"] = {
                "anomalies_detected": len(anomalies),
                "critical_anomalies": len([a for a in anomalies if a.get("severity") == "critical"]),
                "anomalies": anomalies
            }

        print(json.dumps(response, indent=2))

    except Exception as e:
        import traceback
        print(f"Full error traceback: {traceback.format_exc()}", file=sys.stderr)
        print(json.dumps({
            "error": f"Enhanced flag trends analysis failed: {str(e)}"
        }), file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()