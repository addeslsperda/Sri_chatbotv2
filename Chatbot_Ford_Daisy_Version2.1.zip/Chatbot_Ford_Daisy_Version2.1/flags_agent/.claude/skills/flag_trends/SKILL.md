---
name: flag_trends
display_name: Enhanced Flag Trends with Advanced Temporal Analytics
description: Provides sophisticated temporal analysis of flag-related calls using Qwen 0.6B semantic embeddings with multi-dimensional trend analysis, anomaly detection, seasonality insights, and predictive intelligence. Replaces broken boolean flag columns (85% NULL) with comprehensive time-series business analytics. Use for "are buybacks increasing over time", "warranty sentiment trends", "recall volume anomalies", "seasonal patterns in financial assistance calls".
signals:
  - trending
  - buyback trend
  - warranty trend
  - recall trend
  - increasing
  - decreasing
  - flag over time
  - week over week
  - month over month
  - anomaly detection
  - seasonal patterns
  - sentiment trends
  - volume spikes
  - trend analysis
  - temporal patterns
  - business intelligence trends
requires:
  - a flag name (used as semantic search query)
  - a date range for temporal analysis
capabilities:
  - Semantic temporal analysis using Qwen/Qwen3-Embedding-0.6B embeddings for intelligent flag detection over time
  - Multi-dimensional trend analysis: volume, sentiment, complexity, operational metrics, and vehicle trends
  - Advanced anomaly detection with statistical analysis and z-score calculations
  - Seasonality and pattern recognition for business cycle understanding
  - Predictive trend insights with period-over-period change analysis
  - Business intelligence with root cause correlation and actionable recommendations
  - Pure embedding approach - no hardcoded keyword mappings needed
not_good_for: Single point-in-time snapshots (use flag_counts), detailed call examples (use flag_examples), simple counts without temporal context
---

# Enhanced Flag Trends with Advanced Temporal Analytics

## What this does
Provides sophisticated temporal analysis of flag-related calls using semantic embeddings with comprehensive time-series analytics. Uses Qwen 0.6B embeddings to identify flag-related calls over time, then performs multi-dimensional trend analysis including volume patterns, sentiment evolution, complexity trends, anomaly detection, and predictive business intelligence.

## Production Features
- **Semantic temporal analysis**: Uses Databricks Qwen/Qwen3-Embedding-0.6B embeddings for intelligent flag detection across time periods
- **Multi-dimensional trends**: Volume, sentiment, complexity, handle time, transfer rates, and vehicle diversity over time
- **Advanced anomaly detection**: Statistical analysis with z-score calculations to identify unusual spikes, drops, and patterns
- **Business intelligence**: Correlation analysis, trend forecasting, and actionable recommendations
- **Flexible time grouping**: Daily, weekly, or monthly aggregation with period-over-period change analysis
- **Predictive insights**: Trend direction analysis and business impact assessment

## How to run it

```bash
python .claude/skills/flag_trends/scripts/flag_trends.py --flag buyback --from 2025-01-01 --to 2026-12-31 --include-analytics
```

## Enhanced Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--flag` | Yes | — | Flag type for trend analysis (any semantic term: buyback, warranty, recall, etc.) |
| `--from` | Yes | — | Start date YYYY-MM-DD for temporal analysis |
| `--to` | Yes | — | End date YYYY-MM-DD for temporal analysis |
| `--group-by` | No | week | Time grouping: day, week, or month |
| `--vehicle` | No | all | Filter to specific vehicle (partial match) |
| `--similarity-threshold` | No | 0.4 | Minimum similarity score for semantic matching (0.0-1.0) |
| `--include-analytics` | No | false | Include advanced analytics, anomaly detection, and business insights |
| `--anomaly-detection` | No | false | Focus on anomaly detection and pattern analysis |

## Example Usage

```bash
# Comprehensive buyback trend analysis with business intelligence
python flag_trends.py --flag buyback --from 2025-01-01 --to 2026-12-31 --include-analytics

# Weekly warranty trends with anomaly detection
python flag_trends.py --flag warranty --from 2025-06-01 --to 2026-12-31 --group-by week --anomaly-detection

# Vehicle-specific recall trends with monthly grouping
python flag_trends.py --flag recall --vehicle "F-150" --from 2025-01-01 --to 2026-12-31 --group-by month --include-analytics

# Daily sentiment trends for financial assistance calls
python flag_trends.py --flag "financial assistance" --from 2026-09-01 --to 2026-09-30 --group-by day --include-analytics

# High-precision semantic search for legal action trends
python flag_trends.py --flag "legal action" --similarity-threshold 0.6 --from 2025-01-01 --to 2026-12-31 --anomaly-detection

# Any semantic term works (no predefined list needed)
python flag_trends.py --flag "parts delay" --from 2025-01-01 --to 2026-12-31 --include-analytics
```

## Enhanced Output Format

```json
{
  "flag": "buyback",
  "semantic_query_used": "buyback",
  "parameters": {
    "search_method": "semantic_temporal_analysis",
    "embedding_model": "Qwen/Qwen3-Embedding-0.6B",
    "similarity_threshold": 0.4,
    "group_by": "week",
    "vehicle_filter": null,
    "date_range": {"from": "2025-01-01", "to": "2026-12-31"}
  },
  "trends": [
    {
      "period": "2025-W01",
      "period_start": "2025-01-06",
      "call_count": 45,
      "call_count_pct_change": null,
      "avg_customer_sentiment": -0.3245,
      "sentiment_change": null,
      "avg_complexity": 5.2,
      "complexity_change": null,
      "avg_handle_time_minutes": 12.8,
      "negative_pct": 38.2,
      "transfer_pct": 15.6,
      "unique_vehicles": 8,
      "critical_days": 2
    },
    {
      "period": "2025-W02",
      "period_start": "2025-01-13", 
      "call_count": 67,
      "call_count_pct_change": 48.89,
      "avg_customer_sentiment": -0.4123,
      "sentiment_change": -0.0878,
      "avg_complexity": 6.1,
      "complexity_change": 0.9,
      "avg_handle_time_minutes": 15.2,
      "negative_pct": 52.1,
      "transfer_pct": 22.4,
      "unique_vehicles": 12,
      "critical_days": 4
    }
  ],
  "summary": {
    "total_periods": 52,
    "total_calls": 2847,
    "date_range_days": 365
  },
  "analytics": {
    "statistics": {
      "volume_stats": {
        "mean": 54.8,
        "median": 51.0,
        "std_dev": 18.3,
        "min": 23,
        "max": 98
      },
      "sentiment_stats": {
        "mean": -0.3567,
        "trend": "declining",
        "volatility": 0.1234
      }
    },
    "anomalies": [
      {
        "period": "2025-W15",
        "type": "volume_spike",
        "severity": "critical",
        "value": 98,
        "expected_range": "36.5-73.1",
        "z_score": 2.36
      }
    ],
    "overall_trend": {
      "direction": "increasing",
      "magnitude": 12.4,
      "pct_change": 28.7
    },
    "insights": [
      {
        "type": "volume_trend",
        "severity": "high",
        "message": "Call volume is increasing by 28.7% - requires investigation",
        "recommendation": "Analyze root causes and resource allocation needs"
      }
    ]
  }
}
```

## Advanced Analytics Features

### Statistical Analysis
- **Volume Statistics**: Mean, median, standard deviation, min/max analysis for trend baseline
- **Sentiment Analysis**: Trend direction, volatility assessment, and sentiment evolution patterns
- **Operational Metrics**: Handle time trends, complexity evolution, transfer rate analysis

### Anomaly Detection
- **Volume Anomalies**: Statistical outliers using z-score analysis (2+ standard deviations)
- **Sentiment Anomalies**: Critical sentiment drops below -0.6 threshold
- **Operational Anomalies**: Unusual complexity spikes or handle time increases
- **Severity Classification**: Critical (3+ std dev) vs High (2+ std dev) anomalies

### Business Intelligence
- **Trend Direction**: Increasing, decreasing, or stable patterns with magnitude analysis
- **Period-over-Period**: Week-over-week, month-over-month percentage changes
- **Seasonal Patterns**: Identification of recurring business cycle patterns
- **Predictive Insights**: Trend forecasting and business impact assessment

## Key Use Cases

### Regulatory & Compliance Monitoring
- **"Are NHTSA complaints increasing over time?"** - Regulatory trend monitoring with anomaly detection
- **"Buyback request trends by quarter"** - Legal escalation pattern analysis
- **"Recall mention seasonality"** - Regulatory communication cycle analysis

### Quality & Engineering Intelligence
- **"Warranty claim trends for F-150"** - Vehicle-specific quality evolution
- **"Parts delay patterns over time"** - Supply chain trend analysis
- **"Complexity trends for technical issues"** - Engineering escalation evolution

### Customer Experience Analytics
- **"Sentiment trends for financial assistance"** - Customer experience evolution
- **"Handle time trends for warranty calls"** - Operational efficiency analysis
- **"Transfer rate trends by flag type"** - Process improvement monitoring

## Business Value
Enhanced flag_trends provides strategic temporal intelligence for:
- **Regulatory Compliance**: Early detection of regulatory issue trends and patterns
- **Quality Management**: Proactive quality trend monitoring and anomaly detection
- **Customer Experience**: Sentiment and operational trend analysis for process improvement
- **Resource Planning**: Volume trend forecasting for capacity and resource allocation
- **Business Strategy**: Seasonal pattern recognition and predictive business intelligence

## Technical Features

### Semantic Temporal Engine
- **Model**: Qwen/Qwen3-Embedding-0.6B (same model used for table embeddings)
- **Method**: Time-series semantic similarity analysis with multi-dimensional aggregation
- **Processing**: Daily data aggregation with flexible period grouping (day/week/month)
- **Analytics**: Statistical analysis, anomaly detection, and predictive modeling

### Advanced Time-Series Analysis
- **Multi-dimensional Aggregation**: Volume, sentiment, complexity, operational metrics by time period
- **Statistical Methods**: Z-score anomaly detection, trend analysis, volatility assessment
- **Business Intelligence**: Correlation analysis, pattern recognition, and actionable insights

## Error Handling
Robust error handling with semantic search processing, temporal data validation, and graceful degradation for maximum reliability in production environments.
