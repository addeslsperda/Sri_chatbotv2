"""
Discovers what data is available — date ranges and vehicle names in the database.

Usage:
    python data_discovery.py
    python data_discovery.py --check vehicles
    python data_discovery.py --check dates

Output: JSON with {min_date, max_date, vehicles: [...]}
"""
import argparse
import json
import os
import sys
from pathlib import Path
from databricks import sql
import requests
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parents[4] / ".env", override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


CATALOG = os.environ.get("DATABRICKS_CATALOG", "text_analytics")
SCHEMA = os.environ.get("DATABRICKS_SCHEMA", "nlp_analytics")
CALL_DATA = f"{CATALOG}.{SCHEMA}.call_data"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", choices=["all", "dates", "vehicles"], default="all")
    args, _ = parser.parse_known_args()  # ignore --from/--to passed by SkillExecutor

    result = {}

    with get_connection() as conn:
        if args.check in ("all", "dates"):
            with conn.cursor() as cursor:
                cursor.execute(f"""
                    SELECT
                        DATE(MIN(call_date)) AS min_date,
                        DATE(MAX(call_date)) AS max_date,
                        COUNT(*) AS total_calls
                    FROM {CALL_DATA}
                """)  # nosec B608
                row = cursor.fetchone()
                result["min_date"] = str(row[0]) if row[0] else None
                result["max_date"] = str(row[1]) if row[1] else None
                result["total_calls"] = row[2]

        if args.check in ("all", "vehicles"):
            with conn.cursor() as cursor:
                cursor.execute(f"""
                    SELECT modelvehicleline, COUNT(*) AS call_count
                    FROM {CALL_DATA}
                    WHERE modelvehicleline IS NOT NULL
                    GROUP BY modelvehicleline
                    ORDER BY call_count DESC
                    LIMIT 50
                """)  # nosec B608
                rows = cursor.fetchall()
                result["vehicles"] = [
                    {"modelvehicleline": r[0], "call_count": r[1]} for r in rows
                ]

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)
