---
name: data_discovery
display_name: Data Discovery
description: Checks what data is actually available — the earliest and latest call dates, total call count, and all vehicle names with their call counts. Always use this FIRST when the user's date range returns no results, or when unsure what vehicle names look like in the database.
signals:
  - what data do you have
  - what date range
  - what vehicles are available
  - no results
  - check available data
  - what is in the database
  - latest date
  - earliest date
requires: []
not_good_for: Actual analysis — use this only to discover what data exists before running other skills
---

# Data Discovery

## What this script does
Queries `call_data` to return the min/max call dates, total call count, and a ranked list of all vehicle names. Use this when a query returns no results to confirm the correct date range and vehicle name spelling.

## How to run it

```bash
python .claude/skills/data_discovery/scripts/data_discovery.py
```

## Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--check` | No | `all` | `all`, `dates`, or `vehicles` |

## Example calls

```bash
# Check everything
python .claude/skills/data_discovery/scripts/data_discovery.py

# Check only date range
python .claude/skills/data_discovery/scripts/data_discovery.py --check dates

# Check vehicle names
python .claude/skills/data_discovery/scripts/data_discovery.py --check vehicles
```

## Output format

```json
{
  "min_date": "2025-01-01",
  "max_date": "2025-12-31",
  "total_calls": 142831,
  "vehicles": [
    { "modelvehicleline": "F-150", "call_count": 48221 },
    { "modelvehicleline": "Mustang Mach-E", "call_count": 18432 }
  ]
}
```

## Error output
If something goes wrong, the script prints `{"error": "..."}` to stderr and exits with code 1.
