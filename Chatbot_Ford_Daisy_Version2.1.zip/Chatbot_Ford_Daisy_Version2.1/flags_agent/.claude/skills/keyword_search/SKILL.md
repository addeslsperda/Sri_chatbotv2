---
name: keyword_search
display_name: Enhanced Flag Keyword Search Intelligence
description: Production-grade semantic search using Qwen embeddings with comprehensive multi-table intelligence, data-driven escalation classification, and actionable insights for flag-related keywords. Use for advanced flag analysis with sentiment correlation, operational metrics, and business priority scoring.
signals:
  # FLAG KEYWORD ANALYSIS SIGNALS - Enhanced intelligence focus
  - flag keyword analysis
  - flag keyword insights
  - flag keyword intelligence
  - enhanced flag keyword search
  - flag keyword correlation analysis
  - business impact of flag keyword
  - flag keyword priority analysis
  - flag keyword classification
  
  # SEMANTIC SEARCH SIGNALS - Qwen embedding focus  
  - semantic search for flags
  - semantic analysis of escalation
  - embedding search for flags
  - contextual search for escalation
  - smart search for flags
  - AI search for escalation
  
  # ESCALATION INTELLIGENCE SIGNALS - Multi-table analysis
  - escalation correlation for
  - sentiment analysis for flag keyword
  - multi-table analysis for flags
  - comprehensive flag keyword analysis
  - production flag intelligence
  
  # SPECIFIC FLAG ANALYSIS - Escalation focus
  - NHTSA mentions intelligence
  - buyback keyword analysis
  - supervisor escalation analysis
  - legal threat keyword analysis
  - recall keyword analysis
  - escalation keyword analysis
requires:
  - a keyword or phrase to search for (escalation/flag related)
capabilities:
  - Semantic search using Qwen/Qwen3-Embedding-0.6B embeddings with 10K+ match analysis
  - Multi-table intelligence (call_data + parts_unfiltered + models + sentiments + case_metadata + topic_detail + topic_xwalk)  
  - FLAG BREAKDOWN BY DEFAULT: Always includes breakdown by vehicle model AND topic hierarchy for escalation targeting
  - Topic hierarchy intelligence using Ford's official 3-level topic classification (Level1 > Level2 > Level3)
  - Data-driven threshold calculation using Ford-specific percentiles and standard deviations
  - Business classification (FLAG_ESCALATION_CRISIS, FLAG_HIGH_NEGATIVE, etc.)
  - Apple-to-apple vehicle matching using models table for accurate identification  
  - Comprehensive correlation analysis across sentiment, operational metrics, parts, and topic dimensions
  - AI-powered insights with actionable recommendations based on escalation risk
not_good_for: Simple call counts (use flag_counts), real customer verbatim examples (use flag_examples)
---

# Enhanced Flag Keyword Search Intelligence

## What this does
Performs semantic search using Qwen embeddings across all Ford escalation and flag data with comprehensive multi-table intelligence, data-driven escalation classification, and actionable insights for flag-based keyword analysis.

## Production Features
- Semantic search: Uses Databricks Qwen/Qwen3-Embedding-0.6B embeddings for intelligent flag matching
- Multi-table intelligence: Combines 7 data sources for comprehensive escalation analysis
- Data-driven thresholds: Calculates Ford-specific escalation benchmarks using percentiles and standard deviations
- Business classification: FLAG_ESCALATION_CRISIS, FLAG_HIGH_NEGATIVE, FLAG_OPERATIONAL_CONCERN classifications
- Escalation correlation: Links keywords to sentiment, AHT, complexity, and parts issues  
- Apple-to-apple comparison: Uses models table for accurate vehicle identification
- AI insights: Automated escalation risk assessment with actionable recommendations

## How to run it

```bash
python .claude/skills/keyword_search/scripts/keyword_search.py --keyword "NHTSA supervisor" --include-insights
```

## Enhanced Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--keyword` | Yes |  | Keyword(s) to search for (comma-separated for multiple) |
| `--from` | No | all time | Start date YYYY-MM-DD |
| `--to` | No | all time | End date YYYY-MM-DD |
| `--vehicle` | No | all | Filter to a specific vehicle (partial match) |
| `--by-vehicle` | No | false | Break down results by vehicle model |
| `--similarity-threshold` | No | 0.4 | Minimum similarity score for semantic matching (0.0-1.0) |
| `--semantic-limit` | No | 5000 | Max semantic matches to analyze (minimum 100, higher = more comprehensive) |
| `--limit` | No | 20 | Number of vehicles to return when using `--by-vehicle` |
| `--include-insights` | No | false | Include AI-powered insights and escalation context |

## Example Usage

```bash
# Comprehensive NHTSA analysis with escalation insights
python keyword_search.py --keyword "NHTSA" --include-insights

# Multi-keyword buyback analysis with vehicle breakdown
python keyword_search.py --keyword "buyback,lemon law" --by-vehicle --include-insights

# Vehicle-specific supervisor escalation with high semantic matching
python keyword_search.py --keyword "supervisor escalation" --vehicle "F-150" --semantic-limit 3000 --include-insights

# Legal threat analysis with business classification
python keyword_search.py --keyword "lawyer,attorney,legal action" --include-insights

# High-precision semantic search with custom threshold
python keyword_search.py --keyword "recall no parts" --similarity-threshold 0.6 --include-insights
```

## Enhanced Output Format

```json
{
  "status": "success",
  "analysis_type": "enhanced_flag_keyword_search",
  "parameters": {
    "keywords": "NHTSA,supervisor",
    "search_method": "true_cosine_similarity",
    "similarity_threshold": 0.4,
    "semantic_limit": 5000,
    "vehicle_filter": null,
    "date_range": {"from": "2025-01-01", "to": "2026-12-31"}
  },
  "thresholds_used": {
    "avg_negative_pct": 48.3,
    "high_negative_threshold": 58.7,
    "critical_negative_threshold": 69.1,
    "p90_aht_minutes": 18.2,
    "data_driven": true
  },
  "results": {
    "total_semantic_matches": 1247,
    "negative_calls": 856,
    "negative_pct": 68.6,
    "hardware_related_calls": 634,
    "hardware_pct": 50.8,
    "avg_handle_time_minutes": 16.4,
    "calls_with_transfers": 423,
    "unique_vehicles": 12,
    "flag_classification": "FLAG_ESCALATION_CRISIS",
    "flag_priority_score": 187.3,
    "sample_negative_summary": "Customer reports NHTSA complaint filed, requesting supervisor escalation...",
    "sample_hardware_issue": "brake failure correlation with safety complaint"
  },
  "by_vehicle": [
    {
      "modelvehicleline": "F-SERIES",
      "call_count": 423,
      "negative_pct": 71.2,
      "avg_handle_time_minutes": 19.8,
      "escalation_risk": "HIGH"
    }
  ],
  "by_topic": [
    {
      "topic_hierarchy": "Customer Service > Escalation Management > Supervisor Request",
      "topic_broad": "Customer Service",
      "topic_mid": "Escalation Management", 
      "topic_specific": "Supervisor Request",
      "call_count": 234,
      "negative_pct": 78.2,
      "avg_handle_time_minutes": 22.4
    }
  ],
  "insights": {
    "summary": {
      "total_calls": 1247,
      "classification": "FLAG_ESCALATION_CRISIS",
      "negative_sentiment_pct": 68.6,
      "operational_impact_minutes": 382.1,
      "vehicles_affected": 12,
      "thresholds_used": "data_driven"
    },
    "alerts": [
      {
        "type": "critical",
        "message": "CRITICAL: Escalation crisis detected for flag keywords",
        "severity": "critical",
        "supporting_data": "68.6% negative sentiment, 50.8% hardware correlation"
      }
    ],
    "recommendations": [
      {
        "action": "IMMEDIATE escalation review required for flag keywords",
        "priority": "critical",
        "estimated_impact": "Prevent regulatory compliance issues"
      }
    ]
  }
}
```

## Business Classifications

### Flag Analysis Types
- FLAG_ESCALATION_CRISIS: P85 negative sentiment + >20% hardware correlation (critical regulatory response)
- FLAG_HIGH_NEGATIVE: Above 95th percentile negative sentiment (urgent escalation management)
- FLAG_OPERATIONAL_CONCERN: Above average AHT + multiple transfers (process improvement)
- FLAG_HIGH_COMPLEXITY: Above P85 complexity + negative sentiment (specialized handling)
- FLAG_STANDARD: Normal operational performance

### Business Intelligence
- Semantic Discovery: Qwen embeddings find contextually related escalation calls beyond literal keyword matching
- Multi-Dimensional Correlation: Sentiment + operational metrics + hardware + escalation analysis
- Data-Driven Thresholds: Ford-specific escalation benchmarks calculated from actual data patterns
- Apple-to-Apple Comparison: Proper vehicle identification ensures accurate escalation analysis
- Business Priority Scoring: Weighted scoring based on escalation risk, sentiment, and operational impact

## Key Use Cases

### Regulatory & Compliance
- **"How many calls mention NHTSA or VOQ?"**  Regulatory compliance analysis with semantic discovery
- **"Supervisor escalation analysis"**  Management escalation correlation with business impact assessment
- **"Legal threat mentions breakdown"**  Multi-dimensional legal risk analysis across vehicle models

### Escalation Management  
- **"Buyback request patterns"**  Escalation correlation analysis with data-driven thresholds
- **"Lemon law mentions F-150"**  Vehicle-specific escalation intelligence with business classification
- **"BBB complaint analysis"**  Consumer complaint analysis differentiating escalation vs inquiry

### Business Intelligence
- **"Recall keyword escalation patterns"**  Process improvement analysis with escalation correlation
- **"NHTSA mention sentiment analysis"**  Regulatory risk analysis with sentiment and operational correlation
- **"Escalation keyword satisfaction"**  Brand protection analysis with business impact scoring

## Technical Features

### Semantic Search Engine
- **Model**: Qwen/Qwen3-Embedding-0.6B (exact same model used for table embeddings)
- **Method**: True cosine similarity calculation with local model fallback
- **Processing**: Batch-based embedding comparison (1,000 embeddings per batch)
- **Fallback**: Databricks endpoint → local model → traditional LIKE search
- **Configurable Limits**: Up to 5K+ semantic matches for comprehensive escalation coverage

### Multi-Table Intelligence
- **9 Data Sources**: call_data + sentiments + parts_unfiltered + models + call_table + case_metadata + topic_detail + topic_xwalk + embedding_table
- **Apple-to-Apple**: Proper vehicle matching via models table COALESCE logic
- **Topic Hierarchy**: Ford's official 3-level topic classification with escalation correlation analysis
- **Escalation Correlation**: Sentiment + AHT + complexity + parts + topic analysis for escalation patterns
- **Operational Intelligence**: Handle time, transfers, complexity differential analysis

### Data-Driven Approach
- **No Hardcoded Thresholds**: All escalation benchmarks calculated from actual Ford data patterns
- **Percentile Analysis**: 75th, 85th, 95th percentiles for escalation classification boundaries
- **Standard Deviation**: Statistical significance for threshold calculation
- **Ford-Specific**: Escalation benchmarks derived from same date range and vehicle filters

## Error Handling
Enhanced error handling with semantic search fallbacks, comprehensive logging, and traditional keyword search backup for maximum reliability.

## Business Value
Enhanced flag keyword_search provides critical intelligence for:
- **Regulatory Compliance**: Early detection of NHTSA/regulatory issues through semantic discovery
- **Escalation Management**: Data-driven escalation correlation analysis for resource allocation
- **Legal Risk Management**: Comprehensive legal threat and buyback analysis
- **Operational Excellence**: Multi-dimensional sentiment and operational analysis
- **Brand Protection**: Proactive escalation and reputation risk management
