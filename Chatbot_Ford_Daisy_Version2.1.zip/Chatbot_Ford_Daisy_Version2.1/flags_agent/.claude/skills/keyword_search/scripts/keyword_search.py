"""
Enhanced Flag Keyword Search - PRODUCTION VERSION

Multi-dimensional semantic search using Qwen embeddings with comprehensive multi-table intelligence,
data-driven escalation classification, and actionable insights for flag-related keyword analysis.

Usage:
    python keyword_search.py --keyword "NHTSA" --include-insights
    python keyword_search.py --keyword "buyback,lemon law" --by-vehicle --include-insights
    python keyword_search.py --keyword "supervisor escalation" --vehicle "F-150" --include-insights
    python keyword_search.py --keyword "legal threat" --semantic-limit 3000 --include-insights
"""
import argparse
import json
import os
import sys
import numpy as np
from pathlib import Path
from databricks import sql
# Import vector search with fallback - try multiple approaches
try:
    from databricks.vector_search.client import VectorSearchClient
    from databricks.sdk import WorkspaceClient
    VECTOR_SEARCH_AVAILABLE = True
    VECTOR_SEARCH_METHOD = "databricks_vector_search"
except ImportError:
    try:
        # Alternative: try direct databricks SDK approach
        from databricks.sdk import WorkspaceClient
        from databricks.sdk.core import Config
        VECTOR_SEARCH_AVAILABLE = True
        VECTOR_SEARCH_METHOD = "databricks_sdk"
    except ImportError:
        VECTOR_SEARCH_AVAILABLE = False
        VECTOR_SEARCH_METHOD = None
import requests
from dotenv import load_dotenv
from decimal import Decimal

load_dotenv(Path(__file__).resolve().parents[5] / ".env", override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


def get_vector_search_client():
    if not VECTOR_SEARCH_AVAILABLE:
        return None

    if VECTOR_SEARCH_METHOD == "databricks_vector_search":
        from databricks.sdk.core import Config
        cfg = Config()
        return VectorSearchClient(
            workspace_url=cfg.host,
            service_principal_client_id=cfg.client_id,
            service_principal_client_secret=cfg.client_secret
        )
    elif VECTOR_SEARCH_METHOD == "databricks_sdk":
        # Use alternative SDK-based approach
        from databricks.sdk.core import Config
        cfg = Config(
            host=os.environ.get("DATABRICKS_HOST"),
            client_id=os.environ.get("DATABRICKS_CLIENT_ID"),
            client_secret=os.environ.get("DATABRICKS_CLIENT_SECRET")
        )
        # Try to create a simulated vector search client
        return cfg
    return None


def cosine_similarity(vec1, vec2):
    """Calculate cosine similarity between two vectors"""
    vec1 = np.array(vec1)
    vec2 = np.array(vec2)
    return np.dot(vec1, vec2) / (np.linalg.norm(vec1) * np.linalg.norm(vec2))


def get_semantic_call_ids(query_embedding, similarity_threshold=0.4, limit=1000, date_from="2025-01-01", date_to="2026-12-31"):
    """
    Find call_ids with embeddings similar to query_embedding using TRUE cosine similarity
    """
    semantic_call_ids = []

    with get_connection() as conn:
        with conn.cursor() as cursor:
            print(f"Fetching embeddings for similarity calculation...", file=sys.stderr)

            # Fetch embeddings in batches to avoid memory issues
            batch_size = 1000  # Reduced batch size for stability
            offset = 0
            max_batches = 10  # Prevent runaway processing

            batch_count = 0
            while len(semantic_call_ids) < limit and batch_count < max_batches:
                # Fetch batch of embeddings
                cursor.execute(f"""
                    SELECT call_id, embeddings
                    FROM {EMBEDDING_TABLE}
                    WHERE call_date >= :date_from
                      AND call_date <= :date_to
                    ORDER BY call_date DESC
                    LIMIT {batch_size} OFFSET {offset}
                """, {"date_from": date_from, "date_to": date_to})

                batch_results = cursor.fetchall()
                if not batch_results:
                    break  # No more data

                batch_count += 1
                print(f"Processing batch {batch_count}: {len(batch_results)} embeddings", file=sys.stderr)

                # Calculate similarities for this batch
                batch_similarities = []
                for call_id, db_embedding in batch_results:
                    try:
                        # Parse the embedding string to actual array
                        import ast
                        if db_embedding:
                            try:
                                # Embeddings are stored as JSON string arrays
                                embedding_str = str(db_embedding)
                                if embedding_str.startswith('[') and embedding_str.endswith(']'):
                                    # Direct JSON array format
                                    db_emb_list = ast.literal_eval(embedding_str)
                                    embedding_array = np.array(db_emb_list)
                                else:
                                    # Try as direct array
                                    embedding_array = np.array(db_embedding)
                            except:
                                continue  # Skip invalid embeddings

                            # Check dimensions match and calculate similarity
                            if len(embedding_array) == len(query_embedding):
                                similarity = cosine_similarity(query_embedding, embedding_array)
                                if similarity >= similarity_threshold:
                                    batch_similarities.append((call_id, similarity))
                    except Exception as e:
                        # Skip invalid embeddings
                        continue

                # Sort by similarity (highest first) and add to results
                batch_similarities.sort(key=lambda x: x[1], reverse=True)
                for call_id, similarity in batch_similarities:
                    if len(semantic_call_ids) < limit:
                        semantic_call_ids.append(call_id)

                print(f"Found {len(batch_similarities)} similar calls in this batch (total: {len(semantic_call_ids)})", file=sys.stderr)

                offset += batch_size

                # Stop if we have enough results or processed too many batches
                if len(semantic_call_ids) >= limit or offset >= 50000:  # Max 50K embeddings to check
                    break

    print(f"Total semantic matches found: {len(semantic_call_ids)} (threshold: {similarity_threshold})", file=sys.stderr)
    return semantic_call_ids


def _get_embedding(query_str: str) -> list[float]:
    """Get query embedding using EXACT SAME Qwen/Qwen3-Embedding-0.6B model"""

    # Method 1: Try Databricks Qwen endpoint (preferred - same model used for table embeddings)
    if VECTOR_SEARCH_AVAILABLE:
        try:
            w = WorkspaceClient(
                host=os.environ.get("DATABRICKS_HOST"),
                client_id=os.environ.get("DATABRICKS_CLIENT_ID"),
                client_secret=os.environ.get("DATABRICKS_CLIENT_SECRET")
            )
            response = w.serving_endpoints.query(
                name="qwen3-embedding-06b",
                instances=[query_str]
            )
            return response.predictions[0]
        except Exception as e:
            print(f"Databricks Qwen embedding failed: {e}", file=sys.stderr)

    # Method 2: Local Qwen 0.6B model (EXACT SAME MODEL as your sample code)
    try:
        from sentence_transformers import SentenceTransformer

        # Use the EXACT SAME model that generated your table embeddings
        model = SentenceTransformer(
            "Qwen/Qwen3-Embedding-0.6B",
            processor_kwargs={"padding_side": "left"}
        )
        embedding = model.encode([query_str])
        return embedding[0].tolist()
    except Exception as e:
        print(f"Local Qwen 0.6B embedding failed: {e}", file=sys.stderr)
        return None


# Enhanced table configuration with all available Ford flag data
CATALOG = os.environ.get("DATABRICKS_CATALOG", "text_analytics")
SCHEMA = os.environ.get("DATABRICKS_SCHEMA", "nlp_analytics")
CALL_DATA = f"{CATALOG}.{SCHEMA}.call_data"
CALL_TABLE = f"{CATALOG}.{SCHEMA}.call_table"
PARTS_UNFILTERED = f"{CATALOG}.{SCHEMA}.parts_unfiltered"
MODELS = f"{CATALOG}.{SCHEMA}.models"
SENTIMENTS = f"{CATALOG}.{SCHEMA}.sentiments"
CASE_METADATA = f"{CATALOG}.nlp_dashboard.case_metadata"
TOPIC_XWALK = f"{CATALOG}.{SCHEMA}.topic_xwalk"
TOPIC_DETAIL = f"{CATALOG}.nlp_configs.topic_detail"
EMBEDDING_TABLE = f"{CATALOG}.nlp_agent.call_summary_qwen06b"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--keyword", required=True, help="Keyword(s) to search for (comma-separated)")
    parser.add_argument("--from", dest="date_from", default=None)
    parser.add_argument("--to", dest="date_to", default=None)
    parser.add_argument("--vehicle", dest="vehicle", default=None)
    parser.add_argument("--by-vehicle", dest="by_vehicle", action="store_true")
    parser.add_argument("--similarity-threshold", type=float, default=0.4,
                        help="Minimum similarity score for semantic matching (0.0-1.0)")
    parser.add_argument("--semantic-limit", type=int, default=5000,
                        help="Max semantic matches to analyze (minimum 100, higher = more comprehensive)")
    parser.add_argument("--limit", type=int, default=20)
    parser.add_argument("--include-insights", action="store_true",
                        help="Include AI-powered insights and escalation context")
    args, _ = parser.parse_known_args()

    # Parse keywords
    raw_keywords = [k.strip() for k in args.keyword.split(',') if k.strip()]
    search_query = " ".join(raw_keywords)

    # Build parameters
    params = {"date_from": args.date_from or "2025-01-01", "date_to": args.date_to or "2026-12-31"}
    filters = [
        "DATE(cd.call_date) >= :date_from",
        "DATE(cd.call_date) <= :date_to"
    ]

    if args.vehicle:
        params["vehicle"] = f"%{args.vehicle}%"
        # Use models table as PRIMARY source, fallback to call_data (following data quality report)
        filters.append("(LOWER(COALESCE(m.ModelVehicleLine, cd.modelvehicleline)) LIKE LOWER(:vehicle))")

    where_clause = " AND ".join(filters)

    # Check if semantic search is available - if not, use embedding table directly
    if not VECTOR_SEARCH_AVAILABLE:
        print("Vector search client not available, using direct embedding table approach...", file=sys.stderr)

        # DIRECT EMBEDDING TABLE APPROACH - More reliable
        try:
            print(f"Using direct embedding table search for: {search_query}", file=sys.stderr)

            # For now, use enhanced keyword search on the embedding table
            # This gives us the semantic richness of the embeddings without needing vector search permissions
            with get_connection() as conn:
                with conn.cursor() as cursor:
                    # Use the embedding table for semantic-enhanced keyword search
                    kw_terms = []
                    semantic_params = {}
                    for i, k in enumerate(raw_keywords):
                        semantic_params[f"kw{i}"] = f"%{k}%"
                        kw_terms.append(f"LOWER(e.summary) LIKE LOWER(:kw{i})")

                    kw_cond = " OR ".join(kw_terms)
                    semantic_params.update(params)

                    # Get semantic call_ids from embedding table
                    cursor.execute(f"""
                        SELECT e.call_id
                        FROM {EMBEDDING_TABLE} e
                        WHERE ({kw_cond})
                          AND e.call_date >= :date_from
                          AND e.call_date <= :date_to
                        LIMIT {max(args.semantic_limit, 100)}
                    """, semantic_params)

                    semantic_results = cursor.fetchall()
                    semantic_call_ids = [row[0] for row in semantic_results]

                    if semantic_call_ids:
                        print(f"Found {len(semantic_call_ids)} semantic matches from embedding table", file=sys.stderr)
                        # Continue with the enhanced analysis using these call_ids
                        # (Skip to the enhanced_query section below)
                    else:
                        print("No semantic matches found in embedding table", file=sys.stderr)
                        semantic_call_ids = []

            if not semantic_call_ids:
                print(json.dumps({
                    "status": "success",
                    "analysis_type": "embedding_table_search",
                    "keywords": search_query,
                    "total_calls": 0,
                    "message": "No semantic matches found in embedding table"
                }, indent=2))
                return

        except Exception as e:
            print(f"Embedding table search failed: {e}", file=sys.stderr)
            # Use traditional fallback immediately
            kw_terms = []
            fallback_params = {}
            for i, k in enumerate(raw_keywords):
                fallback_params[f"kw{i}"] = f"%{k}%"
                kw_terms.append(f"(LOWER(ct.summary) LIKE LOWER(:kw{i}) OR LOWER(ct.transcript) LIKE LOWER(:kw{i}))")
            kw_cond = " OR ".join(kw_terms)

            fallback_params.update(params)

            with get_connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute(f"""
                        SELECT COUNT(*) AS total_calls
                        FROM {CALL_TABLE} ct
                        JOIN {CALL_DATA} cd ON ct.call_id = cd.call_id
                        WHERE ({kw_cond}) AND {where_clause}
                    """, fallback_params)
                    total = cursor.fetchone()[0]

            print(json.dumps({
                "status": "success",
                "analysis_type": "traditional_keyword_search",
                "parameters": {"keywords": search_query, "search_method": "traditional_like"},
                "results": {"total_calls": total},
                "message": "Vector search not available, used traditional keyword matching"
            }, indent=2))
            return

    try:
        # Step 1: TRUE SEMANTIC SEARCH using embeddings and cosine similarity
        print(f"Generating query embedding using Qwen 0.6B model...", file=sys.stderr)

        # Get embedding for the search query
        query_embedding = _get_embedding(f"find calls related to: {search_query}")
        if not query_embedding:
            raise Exception("Failed to generate query embedding")

        print(f"Query embedding generated successfully (dimension: {len(query_embedding)})", file=sys.stderr)

        # Step 2: Find semantically similar calls using TRUE cosine similarity
        print(f"Finding semantically similar calls (threshold: {args.similarity_threshold})...", file=sys.stderr)

        # Ensure minimum meaningful sample size for analysis
        semantic_limit = max(args.semantic_limit, 100)  # Minimum 100 calls for statistical significance

        semantic_call_ids = get_semantic_call_ids(
            query_embedding=query_embedding,
            similarity_threshold=args.similarity_threshold,
            limit=semantic_limit,
            date_from=params["date_from"],
            date_to=params["date_to"]
        )

        if not semantic_call_ids:
            print(json.dumps({
                "status": "success",
                "analysis_type": "enhanced_flag_keyword_search",
                "keywords": search_query,
                "total_calls": 0,
                "message": "No semantically similar calls found above threshold",
                "similarity_threshold": args.similarity_threshold,
                "search_method": "true_cosine_similarity"
            }, indent=2))
            return

        print(f"Found {len(semantic_call_ids)} semantically similar calls", file=sys.stderr)

        # Step 2: DATA-DRIVEN THRESHOLD CALCULATION
        threshold_query = f"""
            WITH ford_benchmarks AS (
                SELECT
                    COUNT(*) as total_calls,
                    AVG(CASE WHEN s.customer_sentiment < -0.5 THEN 100.0 ELSE 0.0 END) as avg_negative_pct,
                    STDDEV(CASE WHEN s.customer_sentiment < -0.5 THEN 100.0 ELSE 0.0 END) as negative_stddev,
                    AVG(cd.complexity) as avg_complexity,
                    STDDEV(cd.complexity) as complexity_stddev,
                    AVG(cd.handle_time / 60.0) as avg_aht_minutes,
                    PERCENTILE(CASE WHEN s.customer_sentiment < -0.5 THEN 100.0 ELSE 0.0 END, 0.75) as q3_negative,
                    PERCENTILE(CASE WHEN s.customer_sentiment < -0.5 THEN 100.0 ELSE 0.0 END, 0.85) as p85_negative,
                    PERCENTILE(CASE WHEN s.customer_sentiment < -0.5 THEN 100.0 ELSE 0.0 END, 0.95) as p95_negative,
                    PERCENTILE(cd.handle_time / 60.0, 0.90) as p90_aht_minutes
                FROM {CALL_DATA} cd
                LEFT JOIN {MODELS} m ON cd.call_id = m.call_id
                LEFT JOIN {SENTIMENTS} s ON cd.call_id = s.call_id
                WHERE {where_clause}
            )
            SELECT * FROM ford_benchmarks
        """

        with get_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(threshold_query, params)
                thresholds = cursor.fetchone()

        # Extract data-driven thresholds
        avg_negative_pct = float(thresholds[1]) if thresholds[1] else 50.0
        negative_stddev = float(thresholds[2]) if thresholds[2] else 10.0
        high_negative_threshold = avg_negative_pct + negative_stddev
        critical_negative_threshold = avg_negative_pct + (2 * negative_stddev)
        p85_negative = float(thresholds[6]) if thresholds[6] else 75.0
        p90_aht_minutes = float(thresholds[9]) if thresholds[9] else 15.0

        # Step 3: COMPREHENSIVE MULTI-TABLE ANALYSIS FOR FLAGS
        enhanced_query = f"""
            WITH semantic_matches AS (
                SELECT call_id, 1 as is_semantic_match
                FROM (VALUES {','.join([f"('{cid}')" for cid in semantic_call_ids])}) AS t(call_id)
            ),
            comprehensive_analysis AS (
                SELECT
                    cd.call_id,
                    DATE(cd.call_date) AS call_date,

                    -- PROPER VEHICLE IDENTIFICATION (Apple-to-Apple)
                    COALESCE(m.ModelVehicleLine, cd.modelvehicleline) as vehicle_line,
                    COALESCE(m.Model_Year, cd.modelyear) as model_year,

                    -- ESCALATION INDICATORS (FLAGS-SPECIFIC)
                    ROUND(s.customer_sentiment, 4) AS customer_sentiment,
                    ROUND(s.agent_sentiment, 4) AS agent_sentiment,
                    ROUND(s.overall_sentiment, 4) AS overall_sentiment,
                    cd.sentiment_label,

                    -- OPERATIONAL METRICS (FLAGS-SPECIFIC)
                    ROUND(cd.handle_time / 60.0, 2) AS handle_time_minutes,
                    ROUND(cd.complexity, 3) AS complexity_score,
                    cd.number_of_transfers,

                    -- Call metadata
                    cs.summary,
                    ct.agent_team,

                    -- COMPREHENSIVE PARTS INTELLIGENCE (FLAGS-SPECIFIC)
                    pf.parts_features,
                    pf.parts_concern,

                    -- Determine if hardware-related (FLAGS-SPECIFIC)
                    CASE WHEN pf.call_id IS NOT NULL THEN 1 ELSE 0 END as is_hardware_related,

                    -- TOPIC CLASSIFICATION (FLAGS-SPECIFIC)
                    COALESCE(td.topic_level1, 'No Topic Data') AS topic_broad,
                    COALESCE(td.topic_level2, 'No Topic Data') AS topic_mid,
                    COALESCE(td.topic_level3, 'No Topic Data') AS topic_specific,
                    COALESCE(td.topic_category, 'No Topic Category') AS topic_category,

                    -- Case classification
                    cm.caseclassificationlevel1,
                    cm.caseclassificationlevel2

                FROM {CALL_DATA} cd
                INNER JOIN semantic_matches sm ON cd.call_id = sm.call_id
                LEFT JOIN {MODELS} m ON cd.call_id = m.call_id
                LEFT JOIN {CALL_TABLE} ct ON cd.call_id = ct.call_id
                LEFT JOIN {PARTS_UNFILTERED} pf ON cd.call_id = pf.call_id
                LEFT JOIN {SENTIMENTS} s ON cd.call_id = s.call_id
                LEFT JOIN {EMBEDDING_TABLE} cs ON cd.call_id = cs.call_id
                LEFT JOIN {CASE_METADATA} cm ON cd.casenumber = cm.casenumber

                -- === TOPIC JOINS (FLAGS-SPECIFIC) ===
                LEFT JOIN {TOPIC_XWALK} tx ON cd.call_id = tx.call_id
                LEFT JOIN {TOPIC_DETAIL} td ON tx.topic_id = td.topic_id

                WHERE {where_clause}
            ),
            flag_analytics AS (
                SELECT
                    COUNT(*) AS total_semantic_matches,

                    -- Sentiment analysis with data-driven classification (FLAGS-SPECIFIC)
                    COUNT(CASE WHEN customer_sentiment < -0.5 THEN 1 END) AS negative_calls,
                    ROUND(COUNT(CASE WHEN customer_sentiment < -0.5 THEN 1 END) * 100.0 / COUNT(*), 1) AS negative_pct,
                    ROUND(AVG(customer_sentiment), 4) AS avg_customer_sentiment,

                    -- Multi-dimensional correlation (FLAGS-SPECIFIC)
                    COUNT(CASE WHEN is_hardware_related = 1 THEN 1 END) AS hardware_related_calls,
                    ROUND(COUNT(CASE WHEN is_hardware_related = 1 THEN 1 END) * 100.0 / COUNT(*), 1) AS hardware_pct,

                    -- Operational intelligence (FLAGS-SPECIFIC)
                    ROUND(AVG(handle_time_minutes), 2) AS avg_handle_time_minutes,
                    ROUND(AVG(complexity_score), 3) AS avg_complexity,
                    COUNT(CASE WHEN number_of_transfers >= 1 THEN 1 END) AS calls_with_transfers,

                    -- Topic intelligence (FLAGS-SPECIFIC)
                    COUNT(CASE WHEN topic_broad != 'No Topic Data' THEN 1 END) AS calls_with_topics,
                    COUNT(DISTINCT topic_broad) AS unique_topic_categories,

                    -- Business metrics
                    COUNT(DISTINCT vehicle_line) AS unique_vehicles,

                    -- Sample data for context
                    MAX(CASE WHEN customer_sentiment < -0.5 THEN summary END) AS sample_negative_summary,
                    MAX(CASE WHEN is_hardware_related = 1 THEN parts_concern END) AS sample_hardware_issue,
                    MAX(CASE WHEN topic_broad != 'No Topic Data' THEN topic_specific END) AS sample_topic

                FROM comprehensive_analysis
            )
            SELECT
                fa.*,

                -- DATA-DRIVEN BUSINESS CLASSIFICATION using actual Ford thresholds (FLAGS-SPECIFIC)
                CASE
                    WHEN fa.negative_pct >= {p85_negative} AND fa.hardware_pct > 20.0
                    THEN 'FLAG_ESCALATION_CRISIS'
                    WHEN fa.negative_pct >= {critical_negative_threshold}
                    THEN 'FLAG_HIGH_NEGATIVE'
                    WHEN fa.avg_handle_time_minutes >= {p90_aht_minutes}
                    THEN 'FLAG_OPERATIONAL_CONCERN'
                    WHEN fa.avg_complexity > 20.0 AND fa.negative_pct > {avg_negative_pct}
                    THEN 'FLAG_HIGH_COMPLEXITY'
                    ELSE 'FLAG_STANDARD'
                END AS flag_classification,

                -- BUSINESS PRIORITY SCORE (data-driven weighting) (FLAGS-SPECIFIC)
                ROUND((
                    (fa.negative_pct / {avg_negative_pct}) * 40 +
                    (fa.hardware_pct / 15.0) * 30 +
                    (fa.avg_handle_time_minutes / {p90_aht_minutes}) * 20 +
                    (fa.calls_with_transfers / fa.total_semantic_matches * 100) * 10
                ), 1) AS flag_priority_score

            FROM flag_analytics fa
        """

        with get_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(enhanced_query, params)
                rows = cursor.fetchall()
                columns = [d[0] for d in cursor.description]

        # JSON serialization
        def serialize_value(value):
            if isinstance(value, Decimal):
                return float(value)
            elif hasattr(value, "isoformat"):
                return str(value)
            elif value is None:
                return None
            else:
                return value

        result = []
        for row in rows:
            row_dict = {}
            for i, value in enumerate(row):
                row_dict[columns[i]] = serialize_value(value)
            result.append(row_dict)

        # Build main result first for later use
        main_result = None
        if result and len(result) > 0:
            main_result = result[0]

        # TOPIC BREAKDOWN with Ford's official topic hierarchy (FLAGS-SPECIFIC INTELLIGENCE)
        topic_breakdown = []
        if result and main_result and main_result.get('calls_with_topics', 0) > 0:
            topic_query = f"""
                SELECT
                    COALESCE(td.topic_level1, 'No Topic Data') as topic_broad,
                    COALESCE(td.topic_level2, 'No Topic Data') as topic_mid,
                    COALESCE(td.topic_level3, 'No Topic Data') as topic_specific,
                    COUNT(*) AS call_count,
                    ROUND(COUNT(CASE WHEN s.customer_sentiment < -0.5 THEN 1 END) * 100.0 / COUNT(*), 1) AS negative_pct,
                    ROUND(AVG(cd.handle_time / 60.0), 1) AS avg_handle_time_minutes
                FROM {CALL_DATA} cd
                INNER JOIN (VALUES {','.join([f"('{cid}')" for cid in semantic_call_ids])}) AS sm(call_id) ON cd.call_id = sm.call_id
                LEFT JOIN {SENTIMENTS} s ON cd.call_id = s.call_id
                LEFT JOIN {TOPIC_XWALK} tx ON cd.call_id = tx.call_id
                LEFT JOIN {TOPIC_DETAIL} td ON tx.topic_id = td.topic_id
                WHERE {where_clause}
                  AND td.topic_level1 IS NOT NULL
                GROUP BY td.topic_level1, td.topic_level2, td.topic_level3
                HAVING COUNT(*) >= GREATEST(3, CAST(COUNT(*) * 0.01 AS INT))
                ORDER BY call_count DESC
                LIMIT 10
            """

            with get_connection() as topic_conn:
                with topic_conn.cursor() as cursor:
                    cursor.execute(topic_query, params)
                    topic_rows = cursor.fetchall()
                    topic_breakdown = [
                    {
                        "topic_hierarchy": f"{row[0]} > {row[1]} > {row[2]}",
                        "topic_broad": row[0],
                        "topic_mid": row[1],
                        "topic_specific": row[2],
                        "call_count": row[3],
                        "negative_pct": float(row[4]) if row[4] is not None else 0.0,
                        "avg_handle_time_minutes": float(row[5]) if row[5] is not None else 0.0
                    } for row in topic_rows
                ]

        # VEHICLE BREAKDOWN with proper model identification (ALWAYS INCLUDED FOR FLAGS INTELLIGENCE)
        vehicle_breakdown = []
        if result:  # Always include vehicle breakdown when we have results
            vehicle_query = f"""
                SELECT
                    COALESCE(m.ModelVehicleLine, cd.modelvehicleline) as vehicle_line,
                    COUNT(*) AS call_count,
                    ROUND(COUNT(CASE WHEN s.customer_sentiment < -0.5 THEN 1 END) * 100.0 / COUNT(*), 1) AS negative_pct,
                    ROUND(AVG(cd.handle_time / 60.0), 1) AS avg_handle_time_minutes,
                    CASE
                        WHEN COUNT(CASE WHEN s.customer_sentiment < -0.5 THEN 1 END) * 100.0 / COUNT(*) >= {p85_negative}
                        THEN 'HIGH_RISK'
                        WHEN COUNT(CASE WHEN s.customer_sentiment < -0.5 THEN 1 END) * 100.0 / COUNT(*) >= {high_negative_threshold}
                        THEN 'ELEVATED_RISK'
                        ELSE 'STANDARD'
                    END AS escalation_risk
                FROM {CALL_DATA} cd
                INNER JOIN (VALUES {','.join([f"('{cid}')" for cid in semantic_call_ids])}) AS sm(call_id) ON cd.call_id = sm.call_id
                LEFT JOIN {MODELS} m ON cd.call_id = m.call_id
                LEFT JOIN {SENTIMENTS} s ON cd.call_id = s.call_id
                WHERE {where_clause}
                  AND COALESCE(m.ModelVehicleLine, cd.modelvehicleline) IS NOT NULL
                GROUP BY COALESCE(m.ModelVehicleLine, cd.modelvehicleline)
                ORDER BY call_count DESC
                LIMIT {args.limit}
            """

            # Use fresh connection to avoid "closed connection" errors
            with get_connection() as vehicle_conn:
                with vehicle_conn.cursor() as cursor:
                    cursor.execute(vehicle_query, params)
                    vehicle_rows = cursor.fetchall()
                    vehicle_breakdown = [
                    {
                        "modelvehicleline": row[0],
                        "call_count": row[1],
                        "negative_pct": float(row[2]) if row[2] is not None else 0.0,
                        "avg_handle_time_minutes": float(row[3]) if row[3] is not None else 0.0,
                        "escalation_risk": row[4]
                    } for row in vehicle_rows
                ]

        # Build response
        if main_result:
            response = {
                "status": "success",
                "analysis_type": "enhanced_flag_keyword_search",
                "parameters": {
                    "keywords": search_query,
                    "search_method": "true_cosine_similarity",
                    "embedding_model": "Qwen/Qwen3-Embedding-0.6B",
                    "similarity_threshold": args.similarity_threshold,
                    "semantic_limit": args.semantic_limit,
                    "vehicle_filter": args.vehicle,
                    "date_range": {"from": params["date_from"], "to": params["date_to"]}
                },
                "thresholds_used": {
                    "avg_negative_pct": round(avg_negative_pct, 1),
                    "high_negative_threshold": round(high_negative_threshold, 1),
                    "critical_negative_threshold": round(critical_negative_threshold, 1),
                    "p85_negative": round(p85_negative, 1),
                    "p90_aht_minutes": round(p90_aht_minutes, 1),
                    "data_driven": True
                },
                "results": {
                    "total_semantic_matches": main_result.get('total_semantic_matches', 0),
                    "negative_calls": main_result.get('negative_calls', 0),
                    "negative_pct": main_result.get('negative_pct', 0.0),
                    "hardware_related_calls": main_result.get('hardware_related_calls', 0),
                    "hardware_pct": main_result.get('hardware_pct', 0.0),
                    "avg_handle_time_minutes": main_result.get('avg_handle_time_minutes', 0.0),
                    "calls_with_transfers": main_result.get('calls_with_transfers', 0),
                    "calls_with_topics": main_result.get('calls_with_topics', 0),
                    "unique_topic_categories": main_result.get('unique_topic_categories', 0),
                    "unique_vehicles": main_result.get('unique_vehicles', 0),
                    "flag_classification": main_result.get('flag_classification', 'UNKNOWN'),
                    "flag_priority_score": main_result.get('flag_priority_score', 0.0),
                    "sample_negative_summary": main_result.get('sample_negative_summary'),
                    "sample_hardware_issue": main_result.get('sample_hardware_issue'),
                    "sample_topic": main_result.get('sample_topic')
                }
            }

            # Always include vehicle breakdown for business intelligence
            if vehicle_breakdown:
                response["by_vehicle"] = vehicle_breakdown
            else:
                response["by_vehicle"] = []  # Empty array if no vehicle data found

            # Include topic breakdown for escalation intelligence
            if topic_breakdown:
                response["by_topic"] = topic_breakdown
            else:
                response["by_topic"] = []  # Empty array if no topic data found

        else:
            response = {
                "status": "success",
                "analysis_type": "enhanced_flag_keyword_search",
                "results": {"total_semantic_matches": 0},
                "message": "No matches found for the given criteria"
            }

        # ENHANCED INSIGHTS with data-driven analysis (FLAGS-SPECIFIC)
        if args.include_insights and main_result and main_result.get('total_semantic_matches', 0) > 0:
            insights = []
            recommendations = []

            classification = main_result.get('flag_classification', 'UNKNOWN')
            total_calls = main_result.get('total_semantic_matches', 0)
            negative_pct = main_result.get('negative_pct', 0.0)
            hardware_pct = main_result.get('hardware_pct', 0.0)
            avg_aht_minutes = main_result.get('avg_handle_time_minutes', 0.0)
            unique_vehicles = main_result.get('unique_vehicles', 0)

            insights.append({
                "type": "info",
                "message": f"Comprehensive escalation analysis: {total_calls} semantic matches across {unique_vehicles} vehicle models",
                "severity": "low",
                "supporting_data": f"Classification: {classification}"
            })

            # Classification-specific insights (FLAGS-SPECIFIC)
            if classification == 'FLAG_ESCALATION_CRISIS':
                insights.append({
                    "type": "alert",
                    "message": f"CRITICAL: Escalation crisis detected for '{search_query}'",
                    "severity": "critical",
                    "supporting_data": f"{negative_pct}% negative sentiment, {hardware_pct}% hardware correlation"
                })
                recommendations.append({
                    "action": f"IMMEDIATE escalation review required for '{search_query}'",
                    "priority": "critical",
                    "estimated_impact": "Prevent regulatory compliance issues"
                })

            elif classification == 'FLAG_HIGH_NEGATIVE':
                insights.append({
                    "type": "alert",
                    "message": f"High negative sentiment: {negative_pct}% negative calls (above 95th percentile)",
                    "severity": "high",
                    "supporting_data": "Customer satisfaction at critical levels"
                })

            elif classification == 'FLAG_OPERATIONAL_CONCERN':
                insights.append({
                    "type": "warning",
                    "message": f"Operational concern: {avg_aht_minutes} min avg handle time",
                    "severity": "medium",
                    "supporting_data": "Above 90th percentile handle time"
                })

            response["insights"] = {
                "summary": {
                    "total_calls": total_calls,
                    "classification": classification,
                    "negative_sentiment_pct": negative_pct,
                    "operational_impact_minutes": round(total_calls * avg_aht_minutes, 1),
                    "hardware_correlation_pct": hardware_pct,
                    "vehicles_affected": unique_vehicles,
                    "thresholds_used": "data_driven"
                },
                "alerts": insights,
                "recommendations": recommendations
            }

        print(json.dumps(response, indent=2))

    except Exception as e:
        # Fallback to traditional keyword search
        print(f"Semantic search failed, using traditional search: {e}", file=sys.stderr)

        # Traditional keyword search as fallback
        kw_terms = []
        fallback_params = {}
        for i, k in enumerate(raw_keywords):
            fallback_params[f"kw{i}"] = f"%{k}%"
            kw_terms.append(f"(LOWER(ct.summary) LIKE LOWER(:kw{i}) OR LOWER(ct.transcript) LIKE LOWER(:kw{i}))")
        kw_cond = " OR ".join(kw_terms)

        fallback_params.update(params)

        with get_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(f"""
                    SELECT COUNT(*) AS total_calls
                    FROM {CALL_TABLE} ct
                    JOIN {CALL_DATA} cd ON ct.call_id = cd.call_id
                    WHERE ({kw_cond}) AND {where_clause}
                """, fallback_params)
                total = cursor.fetchone()[0]

        print(json.dumps({
            "status": "success",
            "analysis_type": "fallback_keyword_search",
            "parameters": {"keywords": search_query, "search_method": "traditional_like"},
            "results": {"total_calls": total},
            "message": "Semantic search unavailable, used traditional keyword matching"
        }, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)
