"""
Enhanced Flag Examples using Qwen 0.6B Semantic Embeddings
========================================================

Returns rich flag-related call examples using semantic search with comprehensive multi-table analysis.
Uses same proven column names and approach as working keyword_search.

Usage:
    python flag_examples.py --flag buyback
    python flag_examples.py --flag warranty --vehicle "F-150" --limit 3
    python flag_examples.py --flag recall --keyword "NHTSA"

Output: Rich JSON with detailed call examples and comprehensive context
"""
import argparse
import json
import os
import sys
import numpy as np
from decimal import Decimal
from pathlib import Path
from databricks import sql
import requests
from dotenv import load_dotenv
from sentence_transformers import SentenceTransformer

load_dotenv(Path(__file__).resolve().parents[5] / ".env", override=True)

def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]

def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )

# === TABLE CONFIGURATION (SAME as working keyword_search) ===
CATALOG = os.environ.get("DATABRICKS_CATALOG", "text_analytics")
SCHEMA = os.environ.get("DATABRICKS_SCHEMA", "nlp_analytics")
CALL_DATA = f"{CATALOG}.{SCHEMA}.call_data"
CALL_TABLE = f"{CATALOG}.{SCHEMA}.call_table"
MODELS = f"{CATALOG}.{SCHEMA}.models"
PARTS_UNFILTERED = f"{CATALOG}.{SCHEMA}.parts_unfiltered"
SENTIMENTS = f"{CATALOG}.{SCHEMA}.sentiments"
CASE_METADATA = f"{CATALOG}.nlp_dashboard.case_metadata"
TOPIC_XWALK = f"{CATALOG}.{SCHEMA}.topic_xwalk"
TOPIC_DETAIL = f"{CATALOG}.nlp_configs.topic_detail"
EMBEDDING_TABLE = f"{CATALOG}.nlp_agent.call_summary_qwen06b"

def serialize(v):
    """Convert various types to JSON-serializable format"""
    if isinstance(v, Decimal):
        return float(v)
    if hasattr(v, "isoformat"):
        return str(v)
    return v

def get_query_embedding(query_text):
    """Get query embedding using same working method as flag_counts"""
    print(f"Generating query embedding using Qwen 0.6B model...", file=sys.stderr)

    # Method 1: Try Databricks Qwen endpoint
    try:
        from databricks.sdk import WorkspaceClient
        w = WorkspaceClient(
            host=os.environ.get("DATABRICKS_HOST"),
            client_id=os.environ.get("DATABRICKS_CLIENT_ID"),
            client_secret=os.environ.get("DATABRICKS_CLIENT_SECRET")
        )
        response = w.serving_endpoints.query(
            name="qwen3-embedding-06b",
            instances=[query_text]
        )
        print(f"Databricks Qwen embedding generated successfully (dimension: {len(response.predictions[0])})", file=sys.stderr)
        return response.predictions[0]
    except Exception as e:
        print(f"Databricks Qwen embedding failed: {e}", file=sys.stderr)

    # Method 2: Local Qwen 0.6B model using SentenceTransformer (proven working method)
    try:
        model = SentenceTransformer(
            "Qwen/Qwen3-Embedding-0.6B",
            processor_kwargs={"padding_side": "left"}
        )
        embedding = model.encode([query_text])
        print(f"Query embedding generated successfully (dimension: {len(embedding[0])})", file=sys.stderr)
        return embedding[0].tolist()
    except Exception as e:
        print(f"Local Qwen 0.6B embedding failed: {e}", file=sys.stderr)
        return None

def cosine_similarity(vec1, vec2):
    """Calculate cosine similarity between two vectors"""
    vec1 = np.array(vec1)
    vec2 = np.array(vec2)
    return np.dot(vec1, vec2) / (np.linalg.norm(vec1) * np.linalg.norm(vec2))

def get_semantic_call_ids(query_text, similarity_threshold, limit, date_from="2025-01-01", date_to="2026-12-31"):
    """Find semantically similar calls using same logic as working flag_counts"""
    query_embedding = get_query_embedding(query_text)
    if not query_embedding:
        return []

    print(f"Finding semantically similar calls (threshold: {similarity_threshold})...", file=sys.stderr)

    semantic_call_ids = []

    with get_connection() as conn:
        with conn.cursor() as cursor:
            print("Fetching embeddings for similarity calculation...", file=sys.stderr)

            batch_size = 1000
            offset = 0
            max_batches = 10
            batch_count = 0

            while len(semantic_call_ids) < limit and batch_count < max_batches:
                cursor.execute(f"""
                    SELECT call_id, embeddings
                    FROM {EMBEDDING_TABLE}
                    WHERE call_date >= :date_from
                      AND call_date <= :date_to
                    ORDER BY call_date DESC
                    LIMIT {batch_size} OFFSET {offset}
                """, {"date_from": date_from, "date_to": date_to})

                batch_results = cursor.fetchall()
                if not batch_results:
                    break

                batch_count += 1
                print(f"Processing batch {batch_count}: {len(batch_results)} embeddings", file=sys.stderr)

                batch_similarities = []
                for call_id, db_embedding in batch_results:
                    try:
                        import ast
                        if db_embedding:
                            try:
                                embedding_str = str(db_embedding)
                                if embedding_str.startswith('[') and embedding_str.endswith(']'):
                                    db_emb_list = ast.literal_eval(embedding_str)
                                    embedding_array = np.array(db_emb_list)
                                else:
                                    embedding_array = np.array(db_embedding)
                            except:
                                continue

                            if len(embedding_array) == len(query_embedding):
                                similarity = cosine_similarity(query_embedding, embedding_array)
                                if similarity >= similarity_threshold:
                                    batch_similarities.append((call_id, similarity))
                    except Exception:
                        continue

                # Sort by similarity (highest first) and add to results
                batch_similarities.sort(key=lambda x: x[1], reverse=True)
                for call_id, similarity in batch_similarities:
                    if len(semantic_call_ids) < limit:
                        semantic_call_ids.append(call_id)

                print(f"Found {len(batch_similarities)} similar calls in this batch (total: {len(semantic_call_ids)})", file=sys.stderr)

                offset += batch_size

            print(f"Total semantic matches found: {len(semantic_call_ids)} (threshold: {similarity_threshold})", file=sys.stderr)
            return semantic_call_ids

def main():
    parser = argparse.ArgumentParser(description="Enhanced Flag Examples using Qwen 0.6B Semantic Embeddings")
    parser.add_argument("--flag", required=True, help="Flag type for examples (any semantic term)")
    parser.add_argument("--from", dest="date_from", default="2025-01-01", help="Start date YYYY-MM-DD")
    parser.add_argument("--to", dest="date_to", default="2026-12-31", help="End date YYYY-MM-DD")
    parser.add_argument("--vehicle", help="Filter to specific vehicle")
    parser.add_argument("--keyword", help="Additional keyword filter on summary text")
    parser.add_argument("--similarity-threshold", type=float, default=0.4, help="Similarity threshold")
    parser.add_argument("--limit", type=int, default=20, help="Number of examples to return (recommended: 20-50 for comprehensive business intelligence)")
    parser.add_argument("--summary-mode", action="store_true", help="Return summary-focused output for business users")
    parser.add_argument("--test-flag-types", action="store_true", help="Test multiple flag types for validation")

    args = parser.parse_args()

    # Use the flag name directly as the semantic query
    flag_query = args.flag

    try:
        # === PHASE 1: SEMANTIC SEARCH ===
        # Set limit to 1000 as requested, or use a larger pool for filtering
        search_limit = 1000
        semantic_call_ids = get_semantic_call_ids(flag_query, args.similarity_threshold, search_limit, args.date_from, args.date_to)

        if not semantic_call_ids:
            print(json.dumps({
                "flag": args.flag,
                "semantic_query_used": flag_query,
                "total_examples": 0,
                "examples": [],
                "message": "No semantically similar calls found"
            }))
            return

        print(f"Found {len(semantic_call_ids)} semantically similar calls for detailed analysis", file=sys.stderr)

        # === PHASE 2: COMPREHENSIVE MULTI-TABLE ANALYSIS (Using exact column names from working keyword_search) ===
        call_ids_values = ','.join([f"('{cid}')" for cid in semantic_call_ids])

        # Build additional filters
        filters = []
        params = {}

        if args.date_from:
            filters.append("DATE(cd.call_date) >= :date_from")
            params["date_from"] = args.date_from
        if args.date_to:
            filters.append("DATE(cd.call_date) <= :date_to")
            params["date_to"] = args.date_to
        if args.vehicle:
            filters.append("(LOWER(COALESCE(m.ModelVehicleLine, cd.modelvehicleline)) LIKE LOWER(:vehicle))")
            params["vehicle"] = f"%{args.vehicle}%"
        if args.keyword:
            filters.append("(LOWER(COALESCE(cs.summary, '')) LIKE LOWER(:keyword))")
            params["keyword"] = f"%{args.keyword}%"

        where_clause = " AND ".join(filters) if filters else "1=1"

        # === ENHANCED MULTI-TABLE ENRICHMENT QUERY (Production Ready with validations) ===
        enrichment_query = f"""
            WITH semantic_matches AS (
                SELECT DISTINCT call_id FROM (VALUES {call_ids_values}) AS t(call_id)
            )
            SELECT
                cd.call_id,
                DATE(cd.call_date) AS call_date,

                -- PROPER VEHICLE IDENTIFICATION (Apple-to-Apple matching)
                COALESCE(m.ModelVehicleLine, cd.modelvehicleline, 'No Match Found') as vehicle_line,
                COALESCE(CAST(m.Model_Year AS STRING), CAST(cd.modelyear AS STRING), 'No Vehicle') as model_year,

                -- ESCALATION INDICATORS (Production validated)
                ROUND(COALESCE(s.customer_sentiment, 0.0), 4) AS customer_sentiment,
                ROUND(COALESCE(s.agent_sentiment, 0.0), 4) AS agent_sentiment,
                ROUND(COALESCE(s.overall_sentiment, 0.0), 4) AS overall_sentiment,
                COALESCE(cd.sentiment_label, 'Unknown') as sentiment_label,

                -- OPERATIONAL METRICS (Data validated)
                CASE
                    WHEN cd.handle_time IS NOT NULL AND cd.handle_time > 0
                    THEN ROUND(cd.handle_time / 60.0, 2)
                    ELSE NULL
                END AS handle_time_minutes,
                ROUND(COALESCE(cd.complexity, 0.0), 3) AS complexity_score,
                COALESCE(cd.number_of_transfers, 0) AS number_of_transfers,

                -- Call metadata
                COALESCE(cs.summary, ct.summary, 'No summary available') as summary,
                COALESCE(ct.agent_team, 'Unknown Team') as agent_team,

                -- ENHANCED PARTS INTELLIGENCE (Production ready)
                COALESCE(pf.parts_features, 'No parts data') as parts_features,
                COALESCE(pf.parts_concern, 'No parts concern') as parts_concern,

                -- Enhanced hardware correlation
                CASE
                    WHEN pf.call_id IS NOT NULL AND pf.parts_concern IS NOT NULL
                    THEN 1
                    ELSE 0
                END as is_hardware_related,

                -- TOPIC CLASSIFICATION (Enhanced)
                COALESCE(td.topic_level1, 'No Topic Data') AS topic_broad,
                COALESCE(td.topic_level2, 'No Topic Data') AS topic_mid,
                COALESCE(td.topic_level3, 'No Topic Data') AS topic_specific,
                COALESCE(td.topic_category, 'No Topic Category') AS topic_category,

                -- ENHANCED CASE CLASSIFICATION (Multiple join attempts)
                COALESCE(cm.caseclassificationlevel1,
                         CASE WHEN cd.casenumber IS NOT NULL THEN 'Case Data Available' ELSE 'No Case Data' END) as caseclassificationlevel1,
                COALESCE(cm.caseclassificationlevel2, 'No Classification') as caseclassificationlevel2,

                -- Additional business context
                cd.casenumber

            FROM {CALL_DATA} cd
            INNER JOIN semantic_matches sm ON cd.call_id = sm.call_id
            LEFT JOIN {MODELS} m ON cd.call_id = m.call_id
            LEFT JOIN {CALL_TABLE} ct ON cd.call_id = ct.call_id
            LEFT JOIN {PARTS_UNFILTERED} pf ON cd.call_id = pf.call_id
            LEFT JOIN {SENTIMENTS} s ON cd.call_id = s.call_id
            LEFT JOIN {EMBEDDING_TABLE} cs ON cd.call_id = cs.call_id
            LEFT JOIN {CASE_METADATA} cm ON COALESCE(cd.casenumber, '') = COALESCE(cm.casenumber, '')
            LEFT JOIN {TOPIC_XWALK} tx ON cd.call_id = tx.call_id
            LEFT JOIN {TOPIC_DETAIL} td ON tx.topic_id = td.topic_id

            WHERE {where_clause}

            ORDER BY
                COALESCE(s.customer_sentiment, 0) ASC,  -- Most negative first for priority
                cd.call_date DESC                        -- Recent calls for relevance

            LIMIT {args.limit}
        """

        with get_connection() as conn:
            with conn.cursor() as cursor:
                print(f"Executing comprehensive multi-table enrichment for {args.limit} examples...", file=sys.stderr)
                cursor.execute(enrichment_query, params)
                rows = cursor.fetchall()
                columns = [d[0] for d in cursor.description]

        # === PHASE 3: BUILD ENHANCED EXAMPLE RESPONSE ===
        examples = []
        for row in rows:
            row_dict = dict(zip(columns, [serialize(val) for val in row]))

            # Enhanced computed fields for business intelligence (handle None values)
            customer_sentiment = row_dict.get('customer_sentiment') or 0
            number_of_transfers = row_dict.get('number_of_transfers') or 0
            complexity_score = row_dict.get('complexity_score') or 0
            is_hardware_related = row_dict.get('is_hardware_related') or 0
            handle_time_minutes = row_dict.get('handle_time_minutes') or 0

            # Enhanced business priority calculation
            priority_score = 0
            if customer_sentiment < -0.5:
                priority_score += 3
            elif customer_sentiment < -0.3:
                priority_score += 2
            elif customer_sentiment < -0.1:
                priority_score += 1

            if number_of_transfers > 0:
                priority_score += 2
            if complexity_score > 0.7:
                priority_score += 2
            if is_hardware_related == 1:
                priority_score += 1
            if handle_time_minutes > 15:
                priority_score += 1

            if priority_score >= 5:
                row_dict['business_priority'] = 'critical'
            elif priority_score >= 3:
                row_dict['business_priority'] = 'high'
            elif priority_score >= 1:
                row_dict['business_priority'] = 'medium'
            else:
                row_dict['business_priority'] = 'standard'

            # Enhanced escalation indicators
            row_dict['escalation_indicators'] = []
            if number_of_transfers > 0:
                row_dict['escalation_indicators'].append('multiple_transfers')
            if customer_sentiment < -0.5:
                row_dict['escalation_indicators'].append('very_negative_sentiment')
            elif customer_sentiment < -0.3:
                row_dict['escalation_indicators'].append('negative_sentiment')
            if complexity_score > 0.7:
                row_dict['escalation_indicators'].append('high_complexity')
            if is_hardware_related == 1:
                row_dict['escalation_indicators'].append('hardware_issue')
            if handle_time_minutes > 15:
                row_dict['escalation_indicators'].append('long_handle_time')

            # Add topic hierarchy for easy understanding
            if row_dict.get('topic_broad') != 'No Topic Data':
                row_dict['topic_hierarchy'] = f"{row_dict['topic_broad']} > {row_dict['topic_mid']} > {row_dict['topic_specific']}"

            # Add summary-focused fields for business users
            if args.summary_mode:
                row_dict['business_summary'] = {
                    'call_issue': f"{row_dict['topic_broad']} - {row_dict['topic_specific']}",
                    'vehicle': f"{row_dict['vehicle_line']} {row_dict['model_year']}",
                    'priority': row_dict['business_priority'],
                    'key_indicators': row_dict['escalation_indicators'][:3],  # Top 3 indicators
                    'customer_sentiment_desc': (
                        'Very Negative' if customer_sentiment < -0.5
                        else 'Negative' if customer_sentiment < -0.3
                        else 'Neutral' if customer_sentiment < 0.1
                        else 'Positive'
                    )
                }

            examples.append(row_dict)

        # === FINAL RESPONSE ===
        response = {
            "flag": args.flag,
            "semantic_query_used": flag_query,
            "parameters": {
                "search_method": "pure_semantic_similarity",
                "embedding_model": "Qwen/Qwen3-Embedding-0.6B",
                "similarity_threshold": args.similarity_threshold,
                "semantic_search_limit": search_limit,
                "vehicle_filter": args.vehicle,
                "keyword_filter": args.keyword,
                "date_range": {"from": args.date_from, "to": args.date_to}
            },
            "total_examples": len(examples),
            "total_semantic_matches": len(semantic_call_ids),
            "examples": examples,
            "data_sources": [
                "call_data (call details)",
                "models (vehicle matching)",
                "sentiments (emotion analysis)",
                "parts_unfiltered (hardware correlation)",
                "call_table (complexity metrics)",
                "case_metadata (case classification)",
                "topic_detail (topic intelligence)",
                "embedding_table (summaries)"
            ]
        }

        print(json.dumps(response, indent=2))

    except Exception as e:
        print(json.dumps({
            "error": f"Enhanced flag examples failed: {str(e)}"
        }), file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()