---
name: flag_examples
display_name: Enhanced Flag Call Examples with Multi-Table Intelligence
description: Returns rich, detailed flag-related call examples using Qwen 0.6B semantic embeddings with comprehensive multi-table analysis. Replaces broken boolean flag columns (85% NULL) with intelligent semantic search and enriched context from 8+ data sources. Use for "show me buyback examples", "warranty call details for Bronco", "recall examples with full context".
signals:
  - show me examples
  - example calls
  - buyback call examples
  - warranty call examples
  - what do these calls look like
  - give me examples
  - sample calls
  - show me a buyback call
  - flag call examples
  - detailed flag examples
  - rich call examples
  - comprehensive call examples
requires:
  - a flag name (used as semantic search query)
capabilities:
  - Semantic search using Qwen/Qwen3-Embedding-0.6B embeddings for intelligent flag detection
  - Multi-table enrichment across 8+ data sources for comprehensive call context
  - Rich vehicle information with apple-to-apple matching via models table
  - Sentiment analysis and emotional intelligence from dedicated sentiments table
  - Complexity scoring and escalation indicators for business priority
  - Parts correlation analysis for hardware issue identification
  - Topic hierarchy intelligence using Ford's official 3-level classification
  - Case classification and business context for actionable insights
  - Pure embedding approach - no hardcoded keyword mappings needed
not_good_for: Simple counts (use flag_counts), trend analysis (use flag_trends), high-level summaries (use keyword_search)
---

# Enhanced Flag Call Examples with Multi-Table Intelligence

## What this does
Returns rich, detailed examples of flag-related calls using semantic embeddings with comprehensive multi-table analysis. Uses Qwen 0.6B embeddings to find relevant calls, then enriches each example with detailed context from vehicle data, sentiment analysis, complexity metrics, parts correlation, topic intelligence, and case classification.

## Production Features
- **Semantic search**: Uses Databricks Qwen/Qwen3-Embedding-0.6B embeddings for intelligent flag detection
- **Multi-table enrichment**: Combines 8+ data sources for comprehensive example details
- **Rich vehicle context**: Apple-to-apple vehicle matching with plant codes, series, model years
- **Sentiment intelligence**: Customer and agent sentiment analysis with emotional labels
- **Business priority scoring**: Escalation indicators and priority classification
- **Parts correlation**: Hardware issue identification and component analysis
- **Topic hierarchy**: Ford's official 3-level topic classification for context
- **Case intelligence**: Business classification and case management context

## How to run it

```bash
python .claude/skills/flag_examples/scripts/flag_examples.py --flag buyback --limit 3
```

## Enhanced Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--flag` | Yes | — | Flag type for examples (any semantic term: buyback, warranty, recall, etc.) |
| `--from` | No | 2025-01-01 | Start date YYYY-MM-DD |
| `--to` | No | 2026-12-31 | End date YYYY-MM-DD |
| `--vehicle` | No | all | Filter to specific vehicle (partial match) |
| `--keyword` | No | none | Additional keyword filter on summary text |
| `--similarity-threshold` | No | 0.4 | Minimum similarity score for semantic matching (0.0-1.0) |
| `--limit` | No | 20 | Number of detailed examples to return (recommended: 20-50 for comprehensive business intelligence) |

## Example Usage

```bash
# Rich buyback examples with multi-table context
python flag_examples.py --flag buyback --limit 3

# Warranty examples for specific vehicle with full details
python flag_examples.py --flag warranty --vehicle "F-150" --limit 3

# NHTSA recall examples with keyword filtering
python flag_examples.py --flag recall --keyword "NHTSA" --limit 5

# High-precision semantic matching for specific terms
python flag_examples.py --flag "lemon law" --similarity-threshold 0.6 --limit 2

# Any semantic term works (no predefined list needed)
python flag_examples.py --flag "legal action" --limit 3
python flag_examples.py --flag "parts delay" --limit 4
```

## Enhanced Output Format

```json
{
  "flag": "buyback",
  "semantic_query_used": "buyback",
  "parameters": {
    "search_method": "pure_semantic_similarity",
    "embedding_model": "Qwen/Qwen3-Embedding-0.6B",
    "similarity_threshold": 0.4,
    "vehicle_filter": null,
    "keyword_filter": null,
    "date_range": {"from": "2025-01-01", "to": "2026-12-31"}
  },
  "total_examples": 3,
  "examples": [
    {
      "call_id": "call_789123",
      "call_date": "2026-09-20",
      
      "modelvehicleline": "BRONCO",
      "modelyear": 2024,
      "plant_code": "WAP",
      "series_code": "U725",
      
      "summary": "Customer reports ongoing transmission issues with their 2024 Bronco, requesting buyback under lemon law after 4 unsuccessful repair attempts...",
      "call_length": 1847.5,
      "handle_time": 1204.2,
      "handle_time_minutes": 20.07,
      "number_of_transfers": 2,
      
      "customer_sentiment": -0.72,
      "agent_sentiment": 0.15,
      "sentiment_label": "very_negative",
      
      "complexity_score": 0.89,
      "complexity_category": "high",
      
      "parts_concern": "Transmission Control Module",
      "part_number": "FL3Z-7Z369-B",
      "hardware_correlation": "hardware_related",
      
      "topic_broad": "Vehicle Quality Issues",
      "topic_mid": "Transmission Problems",
      "topic_specific": "Automatic Transmission Failure",
      "topic_hierarchy": "Vehicle Quality Issues > Transmission Problems > Automatic Transmission Failure",
      
      "casenumber": "CASE_2024_089456",
      "caseclassificationlevel1": "Quality",
      "caseclassificationlevel2": "Major Component Failure",
      
      "business_priority": "high",
      "escalation_indicators": [
        "multiple_transfers",
        "very_negative_sentiment",
        "high_complexity",
        "hardware_issue"
      ],
      
      "vin_number": "1FMCU9GD6MUA12345"
    }
  ],
  "data_sources": [
    "call_data (call details)",
    "models (vehicle matching)",
    "sentiments (emotion analysis)",
    "parts_unfiltered (hardware correlation)",
    "call_table (complexity metrics)",
    "case_metadata (case classification)",
    "topic_detail (topic intelligence)",
    "embedding_table (summaries)"
  ]
}
```

## Multi-Table Intelligence Features

### Comprehensive Data Sources
- **call_data**: Core call information, timing, agent details
- **models**: Apple-to-apple vehicle matching with plant codes and series
- **sentiments**: Customer and agent emotion analysis (99.3% complete vs 22.9% in call_data)
- **parts_unfiltered**: Hardware correlation and component failure analysis
- **call_table**: Complexity scoring and operational metrics
- **case_metadata**: Business case classification and management context
- **topic_detail**: Ford's official 3-level topic hierarchy
- **embedding_table**: Enhanced summaries and content analysis

### Business Intelligence Enhancements
- **Escalation Indicators**: Automatic detection of priority patterns (transfers, sentiment, complexity, hardware)
- **Priority Scoring**: Business-driven prioritization based on multiple factors
- **Hardware Correlation**: Links to specific parts and component failures
- **Topic Hierarchy**: Contextual understanding via Ford's classification system
- **Apple-to-Apple Vehicle Matching**: Accurate vehicle identification with plant and series codes

## Key Use Cases

### Regulatory & Compliance Analysis
- **"Show me NHTSA recall examples"** - Detailed regulatory compliance cases with full context
- **"Buyback examples with legal mentions"** - Comprehensive lemon law case analysis
- **"Safety-related examples for F-150"** - Vehicle-specific regulatory intelligence

### Quality & Engineering Intelligence
- **"Transmission problem examples"** - Hardware correlation analysis with parts data
- **"High complexity warranty cases"** - Engineering escalation pattern analysis
- **"Parts delay examples with sentiment"** - Supply chain impact on customer experience

### Customer Experience Analytics
- **"Very negative sentiment examples"** - Customer experience failure analysis
- **"Multiple transfer examples"** - Process improvement case studies
- **"High priority escalation examples"** - Critical case pattern analysis

## Business Value
Enhanced flag_examples provides actionable business intelligence through:
- **Regulatory Compliance**: Detailed regulatory case examples with full context
- **Quality Intelligence**: Hardware correlation analysis for engineering priorities
- **Customer Experience**: Sentiment-driven case analysis for process improvement
- **Operational Excellence**: Complexity and escalation pattern identification
- **Business Priority**: Multi-dimensional priority scoring for resource allocation

## Technical Features

### Semantic Search Engine
- **Model**: Qwen/Qwen3-Embedding-0.6B (same model used for table embeddings)
- **Method**: True cosine similarity with proven SentenceTransformer implementation
- **Processing**: Batch-based embedding comparison for memory efficiency
- **Fallback**: Databricks endpoint → local model (no traditional search needed)

### Multi-Table Architecture
- **8+ Data Sources**: Comprehensive enrichment across all available Ford data
- **Apple-to-Apple Matching**: Proper vehicle identification via models table COALESCE logic
- **Sentiment Intelligence**: Dedicated sentiments table (99.3% vs 22.9% completion rate)
- **Parts Correlation**: Hardware failure pattern analysis via parts_unfiltered

## Error Handling
Robust error handling with semantic search processing, comprehensive logging, and graceful degradation for maximum reliability.
