"""
Enhanced Recall Analysis using Semantic Intelligence & Multi-Table Integration
============================================================================

Uses Qwen 0.6B semantic embeddings + 3-level topic classification + multi-table analysis.
No hardcoded values - all detection based on user query and data-driven thresholds.

Usage:
    python recall_analysis.py --from 2026-01-01 --to 2026-01-31 --flag "recall"
    python recall_analysis.py --from 2026-01-01 --to 2026-01-31 --flag "safety recall" --vehicle "F-150"
    python recall_analysis.py --from 2026-01-01 --to 2026-01-31 --flag "recall parts unavailable"

Output: Comprehensive JSON with recall intelligence using semantic + topic detection
"""
import argparse
import json
import os
import sys
import numpy as np
from decimal import Decimal
from pathlib import Path
from databricks import sql
import requests
from dotenv import load_dotenv
from sentence_transformers import SentenceTransformer

load_dotenv(Path(__file__).resolve().parents[5] / ".env", override=True)

def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]

def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )

# === TABLE CONFIGURATION (SAME as working flag skills) ===
CATALOG = os.environ.get("DATABRICKS_CATALOG", "text_analytics")
SCHEMA = os.environ.get("DATABRICKS_SCHEMA", "nlp_analytics")
CALL_DATA = f"{CATALOG}.{SCHEMA}.call_data"
CALL_TABLE = f"{CATALOG}.{SCHEMA}.call_table"
MODELS = f"{CATALOG}.{SCHEMA}.models"
PARTS_UNFILTERED = f"{CATALOG}.{SCHEMA}.parts_unfiltered"
SENTIMENTS = f"{CATALOG}.{SCHEMA}.sentiments"
CASE_METADATA = f"{CATALOG}.nlp_dashboard.case_metadata"
TOPIC_XWALK = f"{CATALOG}.{SCHEMA}.topic_xwalk"
TOPIC_DETAIL = f"{CATALOG}.nlp_configs.topic_detail"
EMBEDDING_TABLE = f"{CATALOG}.nlp_agent.call_summary_qwen06b"

def serialize(v):
    """Convert various types to JSON-serializable format"""
    if isinstance(v, Decimal):
        return float(v)
    if hasattr(v, "isoformat"):
        return str(v)
    return v

def get_query_embedding(query_text):
    """Get query embedding using same working method as other flag skills"""
    print(f"Generating query embedding for: '{query_text}'", file=sys.stderr)

    # Method 1: Try Databricks Qwen endpoint
    try:
        from databricks.sdk import WorkspaceClient
        w = WorkspaceClient(
            host=os.environ.get("DATABRICKS_HOST"),
            client_id=os.environ.get("DATABRICKS_CLIENT_ID"),
            client_secret=os.environ.get("DATABRICKS_CLIENT_SECRET")
        )
        response = w.serving_endpoints.query(
            name="qwen3-embedding-06b",
            instances=[query_text]
        )
        print(f"Databricks Qwen embedding generated successfully", file=sys.stderr)
        return response.predictions[0]
    except Exception as e:
        print(f"Databricks Qwen embedding failed: {e}", file=sys.stderr)

    # Method 2: Local Qwen 0.6B model (proven working method)
    try:
        model = SentenceTransformer(
            "Qwen/Qwen3-Embedding-0.6B",
            processor_kwargs={"padding_side": "left"}
        )
        embedding = model.encode([query_text])
        print(f"Query embedding generated successfully (dimension: {len(embedding[0])})", file=sys.stderr)
        return embedding[0].tolist()
    except Exception as e:
        print(f"Local Qwen 0.6B embedding failed: {e}", file=sys.stderr)
        return None

def cosine_similarity(vec1, vec2):
    """Calculate cosine similarity between two vectors"""
    vec1 = np.array(vec1)
    vec2 = np.array(vec2)
    return np.dot(vec1, vec2) / (np.linalg.norm(vec1) * np.linalg.norm(vec2))

def get_semantic_call_ids(flag_query, similarity_threshold, limit, date_from, date_to):
    """Find semantically similar calls using same logic as working flag skills"""
    query_embedding = get_query_embedding(flag_query)
    if not query_embedding:
        return []

    print(f"Finding semantically similar calls (threshold: {similarity_threshold})...", file=sys.stderr)

    semantic_call_ids = []

    with get_connection() as conn:
        with conn.cursor() as cursor:
            batch_size = 1000
            offset = 0
            max_batches = 10
            batch_count = 0

            while len(semantic_call_ids) < limit and batch_count < max_batches:
                cursor.execute(f"""
                    SELECT call_id, embeddings
                    FROM {EMBEDDING_TABLE}
                    WHERE call_date >= :date_from
                      AND call_date <= :date_to
                    ORDER BY call_date DESC
                    LIMIT {batch_size} OFFSET {offset}
                """, {"date_from": date_from, "date_to": date_to})

                batch_results = cursor.fetchall()
                if not batch_results:
                    break

                batch_count += 1
                print(f"Processing batch {batch_count}: {len(batch_results)} embeddings", file=sys.stderr)

                batch_similarities = []
                for call_id, db_embedding in batch_results:
                    try:
                        import ast
                        if db_embedding:
                            try:
                                embedding_str = str(db_embedding)
                                if embedding_str.startswith('[') and embedding_str.endswith(']'):
                                    db_emb_list = ast.literal_eval(embedding_str)
                                    embedding_array = np.array(db_emb_list)
                                else:
                                    embedding_array = np.array(db_embedding)
                            except:
                                continue

                            if len(embedding_array) == len(query_embedding):
                                similarity = cosine_similarity(query_embedding, embedding_array)
                                if similarity >= similarity_threshold:
                                    batch_similarities.append((call_id, similarity))
                    except Exception:
                        continue

                # Sort by similarity (highest first) and add to results
                batch_similarities.sort(key=lambda x: x[1], reverse=True)
                for call_id, similarity in batch_similarities:
                    if len(semantic_call_ids) < limit:
                        semantic_call_ids.append(call_id)

                offset += batch_size

            print(f"Total semantic matches found: {len(semantic_call_ids)}", file=sys.stderr)
            return semantic_call_ids

def get_topic_call_ids(flag_query, date_from, date_to):
    """Find calls using 3-level topic classification - search for user query in topics"""
    print(f"Finding calls via 3-level topic classification for: '{flag_query}'", file=sys.stderr)

    with get_connection() as conn:
        with conn.cursor() as cursor:
            # Search ALL 3 topic levels for user query terms
            query_lower = flag_query.lower()
            cursor.execute(f"""
                SELECT DISTINCT cd.call_id
                FROM {CALL_DATA} cd
                JOIN {TOPIC_XWALK} tx ON cd.call_id = tx.call_id
                JOIN {TOPIC_DETAIL} td ON tx.topic_id = td.topic_id
                WHERE DATE(cd.call_date) >= :date_from
                  AND DATE(cd.call_date) <= :date_to
                  AND (
                      LOWER(td.topic_level1) LIKE :query_pattern
                      OR LOWER(td.topic_level2) LIKE :query_pattern
                      OR LOWER(td.topic_level3) LIKE :query_pattern
                      OR LOWER(td.topic_category) LIKE :query_pattern
                  )
            """, {
                "date_from": date_from,
                "date_to": date_to,
                "query_pattern": f"%{query_lower}%"
            })

            topic_call_ids = [row[0] for row in cursor.fetchall()]
            print(f"Found {len(topic_call_ids)} topic-classified calls", file=sys.stderr)
            return topic_call_ids

def perform_comprehensive_analysis(all_call_ids, args):
    """Perform comprehensive multi-table analysis using proven query pattern"""
    print(f"Performing comprehensive analysis on {len(all_call_ids)} calls...", file=sys.stderr)

    # Convert call_ids to VALUES clause
    call_ids_values = ','.join([f"('{cid}')" for cid in all_call_ids[:args.limit]])

    # Build filters
    filters = ["1=1"]
    params = {}

    if args.vehicle:
        filters.append("(LOWER(COALESCE(m.ModelVehicleLine, cd.modelvehicleline)) LIKE LOWER(:vehicle))")
        params["vehicle"] = f"%{args.vehicle}%"

    where_clause = " AND ".join(filters)

    # === COMPREHENSIVE MULTI-TABLE QUERY (Same pattern as your sentiment query) ===
    analysis_query = f"""
        WITH recall_matches AS (
            SELECT DISTINCT call_id FROM (VALUES {call_ids_values}) AS t(call_id)
        )
        SELECT
            -- === CALL IDENTIFICATION ===
            s.call_id,
            cd.casenumber,
            DATE(cd.call_date) AS call_date,

            -- === CALL CONTENT ===
            cs.summary AS call_summary_preview,
            ct.transcript AS call_transcript,

            -- === VEHICLE INFORMATION ===
            COALESCE(m.ModelVehicleLine, cd.modelvehicleline, 'Unknown Vehicle') AS vehicle_model,
            COALESCE(CAST(m.Model_Year AS STRING), CAST(cd.modelyear AS STRING), 'Unknown Year') AS model_year,

            -- === AGENT & TEAM INFORMATION ===
            COALESCE(ct.agent_team, 'Unknown Team') AS agent_team,
            COALESCE(cd.program_name, 'Unknown Program') AS program_name,

            -- === CASE CLASSIFICATION ===
            COALESCE(cm.caseclassificationlevel1, 'No Case Data') AS case_level1,
            COALESCE(cm.caseclassificationlevel2, 'No Case Data') AS case_level2,
            COALESCE(cm.caseclassificationlevel3, 'No Case Data') AS case_level3,

            -- === 3-LEVEL TOPIC HIERARCHY ===
            COALESCE(td.topic_level1, 'No Topic Data') AS topic_broad,
            COALESCE(td.topic_level2, 'No Topic Data') AS topic_mid,
            COALESCE(td.topic_level3, 'No Topic Data') AS topic_specific,
            COALESCE(td.topic_category, 'No Topic Category') AS topic_category,

            -- === PARTS INFORMATION ===
            COALESCE(pf.parts_features, 'No Parts Data') AS parts_features,
            COALESCE(pf.parts_concern, 'No Parts Concern') AS parts_concern,

            -- === PRIMARY SENTIMENT SCORES ===
            ROUND(s.agent_sentiment, 4) AS agent_sentiment,
            ROUND(s.customer_sentiment, 4) AS customer_sentiment,
            ROUND(s.overall_sentiment, 4) AS overall_sentiment,
            ROUND(s.customer_sentiment - s.agent_sentiment, 4) AS sentiment_gap,

            -- === SENTIMENT JOURNEY (Beginning to End) ===
            ROUND(cd.agent_beg_sent, 4) AS agent_start_sentiment,
            ROUND(cd.agent_end_sent, 4) AS agent_end_sentiment,
            ROUND(cd.cust_beg_sent, 4) AS customer_start_sentiment,
            ROUND(cd.cust_end_sent, 4) AS customer_end_sentiment,

            -- === SENTIMENT CHANGES DURING CALL ===
            ROUND(cd.agent_end_sent - cd.agent_beg_sent, 4) AS agent_sentiment_change,
            ROUND(cd.cust_end_sent - cd.cust_beg_sent, 4) AS customer_sentiment_change,

            -- === CALL COMPLEXITY & OPERATIONS ===
            ROUND(cd.complexity, 4) AS complexity_score,
            cd.complexity_label,
            COALESCE(cd.number_of_transfers, 0) AS number_of_transfers,
            CASE
                WHEN cd.handle_time IS NOT NULL AND cd.handle_time > 0
                THEN ROUND(cd.handle_time / 60.0, 2)
                ELSE NULL
            END AS handle_time_minutes,

            -- === DETECTION METHOD ===
            CASE
                WHEN td.topic_level1 IS NOT NULL OR td.topic_level2 IS NOT NULL OR td.topic_level3 IS NOT NULL
                THEN 'Topic Classification'
                ELSE 'Semantic Detection'
            END AS detection_method

        FROM {SENTIMENTS} s
        INNER JOIN recall_matches rm ON s.call_id = rm.call_id
        INNER JOIN {CALL_DATA} cd ON s.call_id = cd.call_id
        LEFT JOIN {EMBEDDING_TABLE} cs ON s.call_id = cs.call_id
        LEFT JOIN {CALL_TABLE} ct ON s.call_id = ct.call_id
        LEFT JOIN {MODELS} m ON s.call_id = m.call_id
        LEFT JOIN {CASE_METADATA} cm ON COALESCE(cd.casenumber, '') = COALESCE(cm.casenumber, '')
        LEFT JOIN {TOPIC_XWALK} tx ON s.call_id = tx.call_id
        LEFT JOIN {TOPIC_DETAIL} td ON tx.topic_id = td.topic_id
        LEFT JOIN {PARTS_UNFILTERED} pf ON s.call_id = pf.call_id

        WHERE {where_clause}

        ORDER BY
            COALESCE(s.customer_sentiment, 0) ASC,
            cd.call_date DESC

        LIMIT {args.limit}
    """

    with get_connection() as conn:
        with conn.cursor() as cursor:
            print(f"Executing comprehensive analysis query...", file=sys.stderr)
            cursor.execute(analysis_query, params)
            rows = cursor.fetchall()
            columns = [d[0] for d in cursor.description]

    # Process results
    examples = []
    sentiment_stats = []
    topic_stats = {}
    vehicle_stats = {}
    detection_methods = {}

    for row in rows:
        row_dict = dict(zip(columns, [serialize(val) for val in row]))
        examples.append(row_dict)

        # Collect statistics
        if row_dict.get('customer_sentiment') is not None:
            sentiment_stats.append(row_dict['customer_sentiment'])

        # Topic statistics
        topic_hierarchy = f"{row_dict.get('topic_broad', 'Unknown')} > {row_dict.get('topic_mid', 'Unknown')} > {row_dict.get('topic_specific', 'Unknown')}"
        topic_stats[topic_hierarchy] = topic_stats.get(topic_hierarchy, 0) + 1

        # Vehicle statistics
        vehicle = row_dict.get('vehicle_model', 'Unknown')
        vehicle_stats[vehicle] = vehicle_stats.get(vehicle, 0) + 1

        # Detection method statistics
        detection_method = row_dict.get('detection_method', 'Unknown')
        detection_methods[detection_method] = detection_methods.get(detection_method, 0) + 1

    return {
        "examples": examples,
        "sentiment_stats": sentiment_stats,
        "topic_stats": topic_stats,
        "vehicle_stats": vehicle_stats,
        "detection_methods": detection_methods
    }

def main():
    parser = argparse.ArgumentParser(description="Enhanced Recall Analysis with Semantic Intelligence")
    parser.add_argument("--from", dest="date_from", required=True, help="Start date YYYY-MM-DD")
    parser.add_argument("--to", dest="date_to", required=True, help="End date YYYY-MM-DD")
    parser.add_argument("--flag", required=True, help="Recall query (e.g., 'recall', 'safety recall', 'recall parts unavailable')")
    parser.add_argument("--vehicle", help="Filter to specific vehicle (partial match)")
    parser.add_argument("--similarity-threshold", type=float, default=0.4, help="Similarity threshold (0.0-1.0)")
    parser.add_argument("--limit", type=int, default=100, help="Number of examples to return (100 or 1000)")

    args = parser.parse_args()

    try:
        print(f"Starting recall analysis for query: '{args.flag}'", file=sys.stderr)

        # === PHASE 1: DUAL DETECTION METHODS ===

        # Method 1: Semantic embedding search
        semantic_call_ids = get_semantic_call_ids(args.flag, args.similarity_threshold, 1000, args.date_from, args.date_to)

        # Method 2: 3-level topic classification
        topic_call_ids = get_topic_call_ids(args.flag, args.date_from, args.date_to)

        # Combine both methods (union for comprehensive coverage)
        all_call_ids = list(set(semantic_call_ids + topic_call_ids))

        if not all_call_ids:
            print(json.dumps({
                "flag": args.flag,
                "semantic_query_used": args.flag,
                "total_matches": 0,
                "semantic_matches": 0,
                "topic_matches": 0,
                "message": "No matching calls found for the specified query"
            }))
            return

        print(f"Total matching calls: {len(all_call_ids)} (semantic: {len(semantic_call_ids)}, topic: {len(topic_call_ids)})", file=sys.stderr)

        # === PHASE 2: COMPREHENSIVE MULTI-TABLE ANALYSIS ===
        analysis_results = perform_comprehensive_analysis(all_call_ids, args)

        # === PHASE 3: BUILD RESPONSE ===

        # Calculate statistics
        avg_sentiment = np.mean(analysis_results["sentiment_stats"]) if analysis_results["sentiment_stats"] else 0

        # Top topics
        top_topics = sorted(analysis_results["topic_stats"].items(), key=lambda x: x[1], reverse=True)[:10]

        # Top vehicles
        top_vehicles = sorted(analysis_results["vehicle_stats"].items(), key=lambda x: x[1], reverse=True)[:10]

        # Final response
        response = {
            "flag": args.flag,
            "semantic_query_used": args.flag,
            "parameters": {
                "search_method": "semantic_embeddings_plus_topics",
                "embedding_model": "Qwen/Qwen3-Embedding-0.6B",
                "similarity_threshold": args.similarity_threshold,
                "topic_levels_analyzed": 3,
                "date_range": {"from": args.date_from, "to": args.date_to},
                "vehicle_filter": args.vehicle
            },
            "detection_summary": {
                "total_matches": len(all_call_ids),
                "semantic_matches": len(semantic_call_ids),
                "topic_matches": len(topic_call_ids),
                "analyzed_examples": len(analysis_results["examples"]),
                "detection_methods": analysis_results["detection_methods"]
            },
            "sentiment_analysis": {
                "avg_customer_sentiment": round(avg_sentiment, 4),
                "total_calls_analyzed": len(analysis_results["sentiment_stats"])
            },
            "topic_classification": [
                {"topic_hierarchy": topic, "call_count": count}
                for topic, count in top_topics
            ],
            "vehicle_analysis": [
                {"vehicle": vehicle, "call_count": count}
                for vehicle, count in top_vehicles
            ],
            "examples": analysis_results["examples"],
            "data_sources": [
                "sentiments (customer/agent sentiment journey)",
                "call_data (core call information)",
                "embedding_table (Qwen 0.6B semantic search)",
                "call_table (transcripts and agent teams)",
                "models (vehicle correlation)",
                "parts_unfiltered (component analysis)",
                "topic_detail (3-level topic hierarchy)",
                "case_metadata (business classification)"
            ]
        }

        print(json.dumps(response, indent=2))

    except Exception as e:
        print(json.dumps({
            "error": f"Enhanced recall analysis failed: {str(e)}"
        }), file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()