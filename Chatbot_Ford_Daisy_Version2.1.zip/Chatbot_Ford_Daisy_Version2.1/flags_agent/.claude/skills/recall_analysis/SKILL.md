---
name: recall_analysis
display_name: Enhanced Recall Analysis with Semantic Intelligence & Multi-Table Integration
description: Comprehensive recall analysis using Qwen 0.6B semantic embeddings, 3-level topic classification, sentiment journey tracking, call transcripts, and multi-table intelligence. Detects recall mentions through dual detection methods and provides complete recall customer experience analytics. Use for "recall customer experience analysis", "recall sentiment tracking", "recall parts availability issues", "comprehensive recall intelligence".
signals:
  - recall analysis
  - recall intelligence
  - recall customer experience
  - recall sentiment analysis
  - recall parts availability
  - safety recall tracking
  - recall conversation analysis
  - recall topic classification
  - recall transcript analysis
  - comprehensive recall analytics
  - recall business intelligence
  - recall process improvement
requires:
  - date range for temporal analysis
  - flag query (what type of recall to analyze)
capabilities:
  - Dual recall detection using Qwen/Qwen3-Embedding-0.6B semantic embeddings AND 3-level topic classification
  - Complete call content analysis including summaries AND full transcripts from call_table
  - Multi-table intelligence combining 8+ Ford data sources for comprehensive recall context
  - Customer sentiment journey tracking from call start to end for recall experience measurement
  - Vehicle-recall correlation using apple-to-apple matching via models table
  - Parts availability intelligence for identifying supply chain issues in recall execution
  - Agent team and case classification analysis for operational recall handling insights
  - Business intelligence with actionable recommendations for recall process improvement
  - No hardcoded values - all detection based on user query and data-driven analysis
not_good_for: General vehicle issues (use keyword_search), non-recall analysis (use flag_examples), simple counts (use flag_counts)
---

# Enhanced Recall Analysis with Semantic Intelligence & Multi-Table Integration

## What this does
Provides comprehensive recall analysis using dual detection methods (semantic embeddings + topic classification) with complete multi-table intelligence. Analyzes recall customer conversations including full transcripts, sentiment journeys, and business context to deliver actionable recall process insights.

## Production Features
- **Dual Detection Methods**: Combines Qwen 0.6B semantic search with 3-level topic classification for maximum recall detection coverage
- **Complete Call Content**: Analyzes both call summaries AND full transcripts from call_table for comprehensive conversation understanding
- **Multi-Table Intelligence**: Integrates 8+ Ford data sources including sentiments, vehicles, parts, cases, and agent teams
- **Sentiment Journey Analysis**: Tracks customer and agent sentiment from call start to end during recall interactions
- **Vehicle-Recall Correlation**: Apple-to-apple vehicle matching with detailed recall mention analysis
- **Parts Availability Intelligence**: Identifies supply chain issues and customer frustration with parts delays
- **Business Classification Integration**: Correlates with case metadata and agent team performance
- **User-Query Driven**: No hardcoded values - searches for exactly what user specifies in flag parameter

## How to run it

```bash
python .claude/skills/recall_analysis/scripts/recall_analysis.py --from 2026-01-01 --to 2026-01-31 --flag "recall"
```

## Enhanced Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--from` | Yes | — | Start date YYYY-MM-DD for temporal analysis |
| `--to` | Yes | — | End date YYYY-MM-DD for temporal analysis |
| `--flag` | Yes | — | Recall query to search (e.g., "recall", "safety recall", "recall parts unavailable") |
| `--vehicle` | No | all | Filter by specific vehicle (partial match) |
| `--similarity-threshold` | No | 0.4 | Minimum similarity score for semantic matching (0.0-1.0) |
| `--limit` | No | 100 | Number of detailed examples to return (100 or 1000) |

## Example Usage

```bash
# Basic recall analysis
python recall_analysis.py --from 2026-01-01 --to 2026-01-31 --flag "recall"

# Safety-specific recall analysis  
python recall_analysis.py --from 2026-01-01 --to 2026-01-31 --flag "safety recall"

# Parts availability issues in recalls
python recall_analysis.py --from 2026-01-01 --to 2026-01-31 --flag "recall parts unavailable"

# Vehicle-specific recall analysis
python recall_analysis.py --from 2026-01-01 --to 2026-01-31 --flag "recall" --vehicle "F-150"

# High-precision semantic analysis
python recall_analysis.py --from 2026-01-01 --to 2026-01-31 --flag "NHTSA recall" --similarity-threshold 0.6

# Large-scale recall intelligence
python recall_analysis.py --from 2026-01-01 --to 2026-01-31 --flag "recall" --limit 1000

# Campaign-specific analysis
python recall_analysis.py --from 2026-01-01 --to 2026-01-31 --flag "recall campaign"

# Airbag recall analysis
python recall_analysis.py --from 2026-01-01 --to 2026-01-31 --flag "airbag recall" --vehicle "Explorer"
```

## Enhanced Output Format

```json
{
  "flag": "recall",
  "semantic_query_used": "recall",
  "parameters": {
    "search_method": "semantic_embeddings_plus_topics",
    "embedding_model": "Qwen/Qwen3-Embedding-0.6B",
    "similarity_threshold": 0.4,
    "topic_levels_analyzed": 3,
    "date_range": {"from": "2026-01-01", "to": "2026-01-31"},
    "vehicle_filter": "F-150"
  },
  "detection_summary": {
    "total_matches": 1247,
    "semantic_matches": 892,
    "topic_matches": 355,
    "analyzed_examples": 100,
    "detection_methods": {
      "Semantic Detection": 71,
      "Topic Classification": 29
    }
  },
  "sentiment_analysis": {
    "avg_customer_sentiment": -0.45,
    "total_calls_analyzed": 1247
  },
  "topic_classification": [
    {
      "topic_hierarchy": "Vehicle Recall Information > Assistance with Ford Support > Seeking help from Ford representatives",
      "call_count": 456
    },
    {
      "topic_hierarchy": "Vehicle Support Query > Recall Process Navigation > Parts Availability Inquiry",
      "call_count": 278
    }
  ],
  "vehicle_analysis": [
    {
      "vehicle": "F-150",
      "call_count": 347
    },
    {
      "vehicle": "Explorer", 
      "call_count": 234
    }
  ],
  "examples": [
    {
      "call_id": "715862708525",
      "call_date": "2026-01-15",
      "call_summary_preview": "Customer received recall notice for totaled vehicle, wants to stop notifications...",
      "call_transcript": "Agent: Good morning, this is Ford customer service. Customer: Yes, I keep getting recall notices for a car I don't own anymore. It was totaled in an accident...",
      "vehicle_model": "F-150",
      "model_year": "2024",
      "agent_team": "MPH-CRC_Recall_1",
      "case_level1": "Quality",
      "topic_broad": "Vehicle Recall Information",
      "topic_mid": "Assistance with Ford Support", 
      "topic_specific": "Seeking help from Ford representatives to navigate recall process",
      "parts_concern": "No Parts Concern",
      "customer_sentiment": -0.72,
      "agent_sentiment": 0.15,
      "sentiment_gap": -0.87,
      "customer_start_sentiment": -0.68,
      "customer_end_sentiment": -0.75,
      "customer_sentiment_change": -0.07,
      "complexity_score": 0.89,
      "number_of_transfers": 0,
      "handle_time_minutes": 4.72,
      "detection_method": "Topic Classification"
    }
  ],
  "data_sources": [
    "sentiments (customer/agent sentiment journey)",
    "call_data (core call information)",
    "embedding_table (Qwen 0.6B semantic search)",
    "call_table (transcripts and agent teams)",
    "models (vehicle correlation)",
    "parts_unfiltered (component analysis)",
    "topic_detail (3-level topic hierarchy)",
    "case_metadata (business classification)"
  ]
}
```

## Advanced Analytics Features

### Dual Detection Intelligence
- **Semantic Embeddings**: Qwen 0.6B model identifies recall content beyond exact keyword matching
- **3-Level Topic Classification**: Searches topic_level1, topic_level2, topic_level3 for comprehensive coverage
- **Combined Detection**: Union of both methods ensures maximum recall conversation identification
- **User-Query Driven**: Searches for exactly what user specifies - no hardcoded patterns

### Complete Call Content Analysis  
- **Call Summaries**: Quick overview from embedding table summaries
- **Full Transcripts**: Complete customer-agent conversations from call_table
- **Conversation Context**: Understand why customers are calling about recalls
- **Agent Response Analysis**: Evaluate how agents handle recall inquiries

### Multi-Dimensional Recall Intelligence
- **Sentiment Journey**: Track customer emotion from call start to end during recall interactions
- **Vehicle Correlation**: Apple-to-apple vehicle matching for accurate recall-to-vehicle analysis
- **Parts Intelligence**: Component correlation and supply chain issue identification
- **Business Context**: Case classification and agent team performance analysis

### Operational Intelligence
- **Detection Method Effectiveness**: Compare semantic vs topic classification performance
- **Agent Team Analysis**: Identify which teams handle recalls most effectively
- **Complexity Scoring**: Understand operational burden of different recall types
- **Process Improvement**: Identify patterns in customer frustration and resolution

## Key Use Cases

### Comprehensive Recall Experience Analysis
- **"Complete customer experience with F-150 recalls"** - Full conversation analysis with sentiment tracking
- **"How do customers really feel about our recall process?"** - Sentiment journey and transcript analysis
- **"What are customers actually saying about parts availability?"** - Full conversation context analysis

### Recall Process Intelligence
- **"Which recall conversations are most complex?"** - Complexity and transfer analysis
- **"How effective are our recall specialist teams?"** - Agent team performance evaluation
- **"What topics dominate recall conversations?"** - 3-level topic hierarchy analysis

### Business Intelligence & Improvement
- **"Identify patterns in recall customer frustration"** - Sentiment decline analysis during calls
- **"Parts availability impact on customer satisfaction"** - Supply chain correlation with sentiment
- **"Recall communication effectiveness measurement"** - Detection method and resolution analysis

### Regulatory & Compliance Support
- **"Customer response to safety recall announcements"** - Safety-specific recall analysis
- **"Recall campaign effectiveness tracking"** - Campaign-specific conversation analysis  
- **"Customer understanding of recall processes"** - Conversation content and complexity analysis

## Business Value
Enhanced recall_analysis provides strategic recall intelligence for:
- **Customer Experience Optimization**: Complete recall conversation analysis for process improvement
- **Regulatory Compliance**: Comprehensive tracking of customer recall interactions and satisfaction
- **Supply Chain Intelligence**: Parts availability issue identification and customer impact assessment
- **Operational Excellence**: Agent team performance and recall handling process optimization
- **Business Strategy**: Data-driven recall communication and execution improvement based on actual conversations

## Technical Features

### Advanced Semantic + Topic Engine
- **Dual Detection**: Qwen/Qwen3-Embedding-0.6B embeddings PLUS 3-level topic classification
- **Complete Coverage**: Semantic understanding combined with structured topic categorization
- **User-Query Driven**: Searches for exactly what user specifies with no hardcoded limitations
- **Processing**: Batch-based embedding analysis with comprehensive topic correlation

### Multi-Table Architecture  
- **8+ Data Sources**: Complete integration across Ford data ecosystem
- **Complete Call Content**: Both summaries AND full transcripts for comprehensive analysis
- **Sentiment Intelligence**: Customer journey tracking from call start to completion
- **Business Correlation**: Case classification, agent teams, vehicle matching, and parts correlation

### Production-Ready Features
- **Flexible Limits**: Support for 100 or 1000 examples based on analysis needs
- **Vehicle Filtering**: Focus analysis on specific vehicle models
- **Similarity Tuning**: Adjustable semantic similarity thresholds for precision control
- **Comprehensive Logging**: Detailed progress tracking and diagnostics

## Error Handling
Robust error handling with comprehensive logging, graceful degradation, and detailed diagnostics for maximum reliability in production recall monitoring and analysis environments.
