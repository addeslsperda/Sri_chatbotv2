"""
Enhanced Flag Counter using Qwen 0.6B Semantic Embeddings
=======================================================

Counts calls for flag types using pure semantic search - no hardcoded keywords needed.
The embeddings understand semantic meaning automatically.

Usage:
    python flag_counts.py --flag buyback
    python flag_counts.py --flag warranty --from 2025-01-01 --to 2026-12-31
    python flag_counts.py --flag recall --by-vehicle

Output: JSON with semantic counts
"""
import argparse
import json
import os
import sys
import numpy as np
from decimal import Decimal
from pathlib import Path
from databricks import sql
from databricks.vector_search.client import VectorSearchClient
import requests
from dotenv import load_dotenv
from transformers import AutoModel, AutoTokenizer
import torch

load_dotenv(Path(__file__).resolve().parents[5] / ".env", override=True)

def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]

def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )

# === TABLE CONFIGURATION ===
CATALOG = os.environ.get("DATABRICKS_CATALOG", "text_analytics")
SCHEMA = os.environ.get("DATABRICKS_SCHEMA", "nlp_analytics")
CALL_DATA = f"{CATALOG}.{SCHEMA}.call_data"
MODELS = f"{CATALOG}.{SCHEMA}.models"
EMBEDDING_TABLE = f"{CATALOG}.nlp_agent.call_summary_qwen06b"

def get_query_embedding(query_text):
    """Get query embedding using EXACT SAME method as working keyword_search"""
    print(f"Generating query embedding using Qwen 0.6B model...", file=sys.stderr)

    # Method 1: Try Databricks Qwen endpoint
    try:
        from databricks.sdk import WorkspaceClient
        w = WorkspaceClient(
            host=os.environ.get("DATABRICKS_HOST"),
            client_id=os.environ.get("DATABRICKS_CLIENT_ID"),
            client_secret=os.environ.get("DATABRICKS_CLIENT_SECRET")
        )
        response = w.serving_endpoints.query(
            name="qwen3-embedding-06b",
            instances=[query_text]
        )
        print(f"Databricks Qwen embedding generated successfully (dimension: {len(response.predictions[0])})", file=sys.stderr)
        return response.predictions[0]
    except Exception as e:
        print(f"Databricks Qwen embedding failed: {e}", file=sys.stderr)

    # Method 2: Local Qwen 0.6B model using SentenceTransformer
    try:
        from sentence_transformers import SentenceTransformer

        model = SentenceTransformer(
            "Qwen/Qwen3-Embedding-0.6B",
            processor_kwargs={"padding_side": "left"}
        )
        embedding = model.encode([query_text])
        print(f"Query embedding generated successfully (dimension: {len(embedding[0])})", file=sys.stderr)
        return embedding[0].tolist()
    except Exception as e:
        print(f"Local Qwen 0.6B embedding failed: {e}", file=sys.stderr)
        return None

def cosine_similarity(vec1, vec2):
    """Calculate cosine similarity between two vectors"""
    vec1 = np.array(vec1)
    vec2 = np.array(vec2)
    return np.dot(vec1, vec2) / (np.linalg.norm(vec1) * np.linalg.norm(vec2))

def get_semantic_call_ids(query_text, similarity_threshold, limit, date_from="2025-01-01", date_to="2026-12-31"):
    """Find semantically similar calls using same logic as working keyword_search"""
    query_embedding = get_query_embedding(query_text)
    if not query_embedding:
        return []

    print(f"Finding semantically similar calls (threshold: {similarity_threshold})...", file=sys.stderr)

    semantic_call_ids = []

    with get_connection() as conn:
        with conn.cursor() as cursor:
            print("Fetching embeddings for similarity calculation...", file=sys.stderr)

            batch_size = 1000
            offset = 0
            max_batches = 10
            batch_count = 0

            while len(semantic_call_ids) < limit and batch_count < max_batches:
                cursor.execute(f"""
                    SELECT call_id, embeddings
                    FROM {EMBEDDING_TABLE}
                    WHERE call_date >= :date_from
                      AND call_date <= :date_to
                    ORDER BY call_date DESC
                    LIMIT {batch_size} OFFSET {offset}
                """, {"date_from": date_from, "date_to": date_to})

                batch_results = cursor.fetchall()
                if not batch_results:
                    break

                batch_count += 1
                print(f"Processing batch {batch_count}: {len(batch_results)} embeddings", file=sys.stderr)

                batch_similarities = []
                for call_id, db_embedding in batch_results:
                    try:
                        import ast
                        if db_embedding:
                            try:
                                embedding_str = str(db_embedding)
                                if embedding_str.startswith('[') and embedding_str.endswith(']'):
                                    db_emb_list = ast.literal_eval(embedding_str)
                                    embedding_array = np.array(db_emb_list)
                                else:
                                    embedding_array = np.array(db_embedding)
                            except:
                                continue

                            if len(embedding_array) == len(query_embedding):
                                similarity = cosine_similarity(query_embedding, embedding_array)
                                if similarity >= similarity_threshold:
                                    batch_similarities.append((call_id, similarity))
                    except Exception:
                        continue

                batch_similarities.sort(key=lambda x: x[1], reverse=True)
                for call_id, similarity in batch_similarities:
                    if len(semantic_call_ids) < limit:
                        semantic_call_ids.append(call_id)

                print(f"Found {len(batch_similarities)} similar calls in this batch (total: {len(semantic_call_ids)})", file=sys.stderr)

                offset += batch_size

            print(f"Total semantic matches found: {len(semantic_call_ids)} (threshold: {similarity_threshold})", file=sys.stderr)
            return semantic_call_ids

def main():
    parser = argparse.ArgumentParser(description="Enhanced Flag Counter using Qwen 0.6B Semantic Embeddings")
    parser.add_argument("--flag", required=True, help="Flag type to count (will be used as semantic query)")
    parser.add_argument("--from", dest="date_from", default="2025-01-01", help="Start date YYYY-MM-DD")
    parser.add_argument("--to", dest="date_to", default="2026-12-31", help="End date YYYY-MM-DD")
    parser.add_argument("--vehicle", help="Filter to specific vehicle")
    parser.add_argument("--by-vehicle", action="store_true", help="Break down by vehicle model")
    parser.add_argument("--similarity-threshold", type=float, default=0.4, help="Similarity threshold")
    parser.add_argument("--semantic-limit", type=int, default=5000, help="Max semantic matches")

    args = parser.parse_args()

    # Use the flag name directly as the semantic query - no mapping needed!
    flag_query = args.flag

    try:
        # Get semantic matches using the flag name directly
        semantic_call_ids = get_semantic_call_ids(flag_query, args.similarity_threshold, args.semantic_limit, args.date_from, args.date_to)

        if not semantic_call_ids:
            print(json.dumps({
                "flag": args.flag,
                "total_calls": 0,
                "message": "No semantically similar calls found"
            }))
            return

        print(f"Found {len(semantic_call_ids)} semantically similar calls", file=sys.stderr)

        # Build filters
        call_ids_values = ','.join([f"('{cid}')" for cid in semantic_call_ids])
        filters = []
        params = {}

        if args.date_from:
            filters.append("DATE(cd.call_date) >= :date_from")
            params["date_from"] = args.date_from
        if args.date_to:
            filters.append("DATE(cd.call_date) <= :date_to")
            params["date_to"] = args.date_to
        if args.vehicle:
            filters.append("(LOWER(COALESCE(m.modelvehicleline, cd.modelvehicleline)) LIKE LOWER(:vehicle))")
            params["vehicle"] = f"%{args.vehicle}%"

        where_clause = " AND ".join(filters) if filters else "1=1"

        # Main count query
        main_query = f"""
            WITH semantic_matches AS (
                SELECT DISTINCT call_id FROM (VALUES {call_ids_values}) AS t(call_id)
            )
            SELECT
                COUNT(*) AS total_calls,
                MIN(cd.call_date) AS min_date,
                MAX(cd.call_date) AS max_date,
                COUNT(DISTINCT COALESCE(m.modelvehicleline, cd.modelvehicleline)) AS unique_vehicles
            FROM {CALL_DATA} cd
            INNER JOIN semantic_matches sm ON cd.call_id = sm.call_id
            LEFT JOIN {MODELS} m ON cd.call_id = m.call_id
            WHERE {where_clause}
        """

        with get_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(main_query, params)
                row = cursor.fetchone()
                total_calls, min_date, max_date, unique_vehicles = row

        # Vehicle breakdown if requested
        vehicle_breakdown = []
        if args.by_vehicle and total_calls > 0:
            vehicle_query = f"""
                SELECT
                    COALESCE(m.modelvehicleline, cd.modelvehicleline, 'No Match Found') as modelvehicleline,
                    COUNT(*) AS call_count
                FROM {CALL_DATA} cd
                INNER JOIN (VALUES {call_ids_values}) AS sm(call_id) ON cd.call_id = sm.call_id
                LEFT JOIN {MODELS} m ON cd.call_id = m.call_id
                WHERE {where_clause}
                GROUP BY COALESCE(m.modelvehicleline, cd.modelvehicleline, 'No Match Found')
                ORDER BY call_count DESC
                LIMIT 20
            """

            with get_connection() as conn2:
                with conn2.cursor() as cursor2:
                    cursor2.execute(vehicle_query, params)
                    vehicle_rows = cursor2.fetchall()
                    vehicle_breakdown = [
                        {"modelvehicleline": row[0], "call_count": row[1]}
                        for row in vehicle_rows
                    ]

        # Build response
        response = {
            "flag": args.flag,
            "semantic_query_used": flag_query,
            "total_calls": total_calls,
            "unique_vehicles": unique_vehicles,
            "date_range": {
                "from": str(min_date) if min_date else None,
                "to": str(max_date) if max_date else None
            },
            "parameters": {
                "search_method": "pure_semantic_similarity",
                "embedding_model": "Qwen/Qwen3-Embedding-0.6B",
                "similarity_threshold": args.similarity_threshold,
                "vehicle_filter": args.vehicle
            }
        }

        if args.by_vehicle and vehicle_breakdown:
            response["by_vehicle"] = vehicle_breakdown

        print(json.dumps(response, indent=2))

    except Exception as e:
        print(json.dumps({
            "error": f"Enhanced flag count failed: {str(e)}"
        }), file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()