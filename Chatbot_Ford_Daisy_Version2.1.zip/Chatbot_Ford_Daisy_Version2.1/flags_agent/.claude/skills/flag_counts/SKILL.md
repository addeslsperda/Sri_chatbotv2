---
name: flag_counts
display_name: Enhanced Flag Call Counter
description: Counts calls for flag types using Qwen 0.6B semantic embeddings. Replaces broken boolean flag columns (85% NULL) with intelligent semantic search. Use for "how many buyback calls", "warranty call count", "recall mentions".
signals:
  - how many buyback
  - how many warranty
  - how many recall
  - how many financial assistance
  - how many cancel
  - flag count
  - calls flagged as
  - buyback requests
  - warranty calls
  - recall calls
  - count of flag calls
  - flag call volume
requires:
  - a flag name (used as semantic search query)
capabilities:
  - Semantic search using Qwen/Qwen3-Embedding-0.6B embeddings for intelligent flag detection
  - Pure embedding-based classification - no hardcoded keyword mappings needed
  - Multi-table analysis across call_data and models for accurate vehicle identification
  - Date and vehicle filtering with semantic understanding
  - Vehicle breakdown analysis for business targeting
not_good_for: Trends over time (use flag_trends), call examples (use flag_examples), detailed analysis (use keyword_search)
---

# Enhanced Flag Call Counter

## What this does
Counts calls for specific flag types using semantic embeddings instead of broken boolean flag columns. Uses Qwen 0.6B embeddings to understand what constitutes a "buyback", "warranty", "recall" etc. call through semantic similarity.

## Production Features
- **Semantic search**: Uses Databricks Qwen/Qwen3-Embedding-0.6B embeddings for intelligent flag detection
- **No hardcoded mappings**: Embeddings automatically understand semantic meaning of flag types
- **Multi-table intelligence**: Combines call_data + models for accurate analysis
- **Apple-to-apple comparison**: Uses models table for proper vehicle identification
- **Pure embedding approach**: No keyword lists - embeddings handle semantic understanding

## How to run it

```bash
python .claude/skills/flag_counts/scripts/flag_counts.py --flag buyback --from 2025-01-01 --to 2026-12-31
```

## Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--flag` | Yes | — | Flag type to count (any semantic term: buyback, warranty, recall, etc.) |
| `--from` | No | 2025-01-01 | Start date YYYY-MM-DD |
| `--to` | No | 2026-12-31 | End date YYYY-MM-DD |
| `--vehicle` | No | all | Filter to a specific vehicle (partial match) |
| `--by-vehicle` | No | false | Break down results by vehicle model |
| `--similarity-threshold` | No | 0.4 | Minimum similarity score for semantic matching (0.0-1.0) |
| `--semantic-limit` | No | 5000 | Maximum semantic matches to analyze |

## Example Usage

```bash
# Basic flag counting with semantic search
python flag_counts.py --flag buyback

# Count warranty calls with date range
python flag_counts.py --flag warranty --from 2025-01-01 --to 2026-12-31

# Recall mentions with vehicle breakdown
python flag_counts.py --flag recall --by-vehicle

# Vehicle-specific financial assistance calls
python flag_counts.py --flag "financial assistance" --vehicle "F-150"

# High-precision semantic matching
python flag_counts.py --flag "lemon law" --similarity-threshold 0.6

# Any semantic term works (no predefined list needed)
python flag_counts.py --flag "legal action"
python flag_counts.py --flag "NHTSA complaint"
python flag_counts.py --flag "parts delay"
```

## Enhanced Output Format

```json
{
  "flag": "buyback",
  "semantic_query_used": "buyback",
  "total_calls": 238,
  "unique_vehicles": 22,
  "date_range": {
    "from": "2025-01-01",
    "to": "2026-12-31"
  },
  "parameters": {
    "search_method": "pure_semantic_similarity",
    "embedding_model": "Qwen/Qwen3-Embedding-0.6B",
    "similarity_threshold": 0.4,
    "vehicle_filter": null
  },
  "by_vehicle": [
    {
      "modelvehicleline": "F-SERIES",
      "call_count": 34
    },
    {
      "modelvehicleline": "BRONCO",
      "call_count": 13
    }
  ]
}
```

## Key Advantages

### Semantic Intelligence
- **No hardcoded keywords**: Embeddings understand "lemon law" = "buyback" automatically
- **Contextual understanding**: Finds related concepts without explicit mapping
- **Natural language queries**: Use any flag-related term as input

### Data Quality
- **Replaces broken boolean flags**: 85% NULL flag columns replaced with 100% semantic analysis
- **Accurate counts**: Uses actual call content via embeddings, not unreliable flag columns
- **Apple-to-apple vehicle matching**: Proper vehicle identification via models table

### Business Intelligence
- **Vehicle breakdown**: Shows flag distribution across vehicle models
- **Date filtering**: Analyze flag patterns within specific time periods
- **Flexible thresholds**: Adjust semantic similarity for precision vs recall

## Technical Features

### Semantic Search Engine
- **Model**: Qwen/Qwen3-Embedding-0.6B (same model used for table embeddings)
- **Method**: True cosine similarity calculation with local model fallback
- **Processing**: Batch-based embedding comparison (1,000 embeddings per batch)
- **Fallback**: Databricks endpoint → local model (no traditional search needed)

### Multi-Table Intelligence
- **2 Data Sources**: call_data + models for accurate analysis
- **Apple-to-Apple**: Proper vehicle matching via models table COALESCE logic
- **Date Intelligence**: Flexible date range filtering with semantic results

## Use Cases

### Regulatory & Compliance
- **"How many NHTSA calls?"** - Finds all regulatory-related calls semantically
- **"Recall mention count"** - Counts recall-related discussions
- **"Legal action mentions"** - Identifies legal threat patterns

### Business Operations
- **"Buyback request volume"** - Counts repurchase/lemon law related calls
- **"Warranty claim count"** - Identifies warranty-related discussions
- **"Service cancellation volume"** - Tracks cancellation patterns

### Vehicle Intelligence
- **"Parts delay calls by vehicle"** - Vehicle-specific supply chain analysis
- **"F-150 recall mentions"** - Model-specific regulatory tracking
- **"Financial assistance F-Series"** - Payment assistance by vehicle line

## Business Value
Enhanced flag_counts provides accurate call volume intelligence for:
- **Regulatory Compliance**: Accurate NHTSA/regulatory call volumes
- **Business Operations**: Reliable buyback, warranty, service volumes
- **Vehicle Analysis**: Flag distribution across vehicle models  
- **Process Improvement**: Data-driven resource allocation based on actual volumes

## Error Handling
Robust error handling with semantic search fallbacks and comprehensive logging for maximum reliability.
