---
disabled: true
description: >
  Tracks and analyzes NHTSA mentions, VOQ (Vehicle Owner Questionnaire), buyback requests,
  lemon law, BBB complaints, legal issues, attorney/lawyer mentions, recalls, supervisor requests,
  and escalation patterns. Use for "NHTSA", "VOQ", "buyback", "lemon law", "lemon",
  "BBB", "recall", "legal", "attorney", "lawyer", "supervisor", "escalation",
  "find all cases where X was mentioned", "how many calls contain X" (for flag keywords).

routing_examples:
  - question: "find all cases where NHTSA was mentioned"
    reason: "NHTSA escalation keyword — goes here not vehicle_agent"
  - question: "How many customers in the last 90 days have requested their vehicle to be bought back?"
    reason: "Counter-example: has 'how many' but buyback = flag, NOT operations count"
  - question: "how many calls have the word supervisor?"
    reason: "Counter-example: has 'how many' but supervisor = escalation, NOT operations"
  - question: "Lincoln CRC calls about repurchase"
    reason: "Tricky: 'repurchase' = buyback = flag — not vehicle_agent or operations"
  - question: "What is the customers sentiment when they learn their buyback request has been denied?"
    reason: "Counter-example: has 'buyback' but question is about sentiment — goes to sentiment_agent NOT here"
  - question: "rear axle shaft recalls"
    reason: "Short recall mention — goes here not vehicle_agent even though it's about a vehicle part"

skills:
  escalation_tracking: "Track and summarize BBB, NHTSA, buyback requests, legal issues, lemon law, supervisor requests"
  flag_counts: "Count of specific flag types — buyback, warranty, recall, NHTSA, supervisor mentions"
  flag_trends: "Are escalations increasing or decreasing over time, trend in flag types"
  flag_examples: "Example escalated calls, show flagged call transcripts"
  recall_analysis: "Recall-specific analysis — which recalls, affected vehicles, call volume, what customers say"
  keyword_search: "Search for specific terms in transcripts/summaries — use for 'find all cases where X was mentioned'"
  data_discovery: "Schema and available fields"

stage2_prompt: |
  You are selecting the best skill for a FLAGS/ESCALATION question in Ford's CRC analytics tool (called Daisy).

  Available skills:
  - escalation_tracking: General escalation summary — BBB, NHTSA, buyback, legal, lemon law, supervisor
  - flag_counts: Count specific flag types — use for "how many X were there" with a flag keyword
  - flag_trends: Are escalations increasing/decreasing over time, trend in flag counts
  - flag_examples: Example escalated calls, show me flagged call transcripts
  - recall_analysis: Recall-specific analysis — which recalls, affected vehicles, call volume
  - keyword_search: Search for specific terms — use for "find all cases where X was mentioned", "how many calls contain X", "count mentions of X"

  Decision rules (apply in order):
  1. "Recall" / "recall analysis" / "rear axle" / "transmission recall" / "Canadian recall" -> recall_analysis
  2. "How many buyback / NHTSA / lemon / supervisor" (simple count, flag keyword is the subject) -> flag_counts (set flag_type)
  3. "Find all cases where X was mentioned" / "count by vehicle line" / "count by month for mention of X" / "breakdown by X for keyword Y" -> keyword_search (set search_term=X)  (NOTE: "how many calls have the word X" -> keyword_search, not flag_counts)
  4. "Are escalations increasing" / "trend in escalations" / "buybacks increasing" -> flag_trends
  5. "Show me examples" / "give me transcripts" / "example flagged calls" -> flag_examples
  6. "customer indicate their vehicle is a lemon" / "called their vehicle a lemon" / "said their vehicle is a lemon" / "mentioned lemon" as an experience description -> escalation_tracking  (this is NOT a keyword search — it's tracking an escalation pattern)
  7. General escalation question -> escalation_tracking

  Date parsing:
  - "last 6 months" = 180 days ago to today
  - "last 90 days" = 90 days ago to today
  - "last 30 days" = 30 days ago to today
  - "July" = 2026-07-01 to 2026-07-31 (use current year)

  Params to extract:
  - flag_type: REQUIRED when routing to flag_counts, flag_trends, or flag_examples.
    Valid values: buyback, warranty, recall, financial_assistance, cancel, dealership, parts,
    vehicle_breakdown, tech_team, repair, rewards, service, vehicle_order, fleet, VOR
    Aliases to resolve: "lemon" / "lemon law" / "repurchase" / "attorney" / "lawyer" -> flag_type=buyback
                        "NHTSA" / "safety" -> flag_type=recall
    If no specific flag is mentioned (e.g. "show escalation examples" with no flag type) — omit flag_type entirely.
  - search_term: for keyword_search only. Extract as COMMA-SEPARATED values when multiple terms given.
    EXAMPLES: "NHTSA or VOQ" -> search_term="NHTSA,VOQ"  (NOT "NHTSA OR VOQ")
              "buyback or lemon" -> search_term="buyback,lemon"
              "NHTSA" -> search_term="NHTSA"
  - vehicle, date_from (YYYY-MM-DD), date_to (YYYY-MM-DD)

  Return ONLY valid JSON: {"skill": "<skill_name>", "params": {<extracted_params>}, "reason": "<brief>"}
---

# Flags Agent

Routes questions about escalation flags — NHTSA, VOQ, buyback requests, lemon law,
BBB, recalls, supervisor escalations, and legal issues. Also handles keyword searches
for these specific escalation terms in call transcripts.
