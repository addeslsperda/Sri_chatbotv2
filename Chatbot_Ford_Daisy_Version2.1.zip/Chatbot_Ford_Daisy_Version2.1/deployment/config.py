"""
Configuration Management for Ford Analytics API
Environment-based settings with validation
"""
import os
from typing import Optional
from pathlib import Path
from pydantic import Field
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """
    Application settings loaded from environment variables.

    Environment variables can be set in:
    - .env file (local development)
    - Environment variables (production)
    - Docker secrets (containerized)
    """

    # Application
    APP_NAME: str = "Ford Analytics API"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False
    ENVIRONMENT: str = Field(default="development", pattern="^(development|staging|production)$")

    # API Server
    API_HOST: str = "0.0.0.0"  # nosec B104 - containerized service binds all interfaces behind ALB
    API_PORT: int = 8000
    API_WORKERS: int = 4

    # CORS
    CORS_ORIGINS: str = "http://localhost:3000,http://localhost:5173"  # Comma-separated

    # Databricks
    DATABRICKS_HOST: str
    DATABRICKS_CLIENT_ID: str
    DATABRICKS_CLIENT_SECRET: str
    DATABRICKS_WAREHOUSE_ID: Optional[str] = None

    # Claude/LLM (for future use)
    ANTHROPIC_API_KEY: Optional[str] = None
    LLM_MODEL: str = "claude-sonnet-4-20250514"
    LLM_MAX_TOKENS: int = 4096
    LLM_TEMPERATURE: float = 0.0

    # Timeouts
    SKILL_TIMEOUT: int = 120  # seconds
    API_TIMEOUT: int = 60  # seconds

    # Rate Limiting
    RATE_LIMIT_ENABLED: bool = True
    RATE_LIMIT_PER_MINUTE: int = 60

    # Logging
    LOG_LEVEL: str = "INFO"
    LOG_FORMAT: str = "json"  # json or text

    # Caching (future)
    REDIS_URL: Optional[str] = None
    CACHE_TTL: int = 3600  # seconds

    # Monitoring
    SENTRY_DSN: Optional[str] = None
    ENABLE_METRICS: bool = False

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = True

    @property
    def cors_origins_list(self) -> list[str]:
        """Parse CORS origins from comma-separated string."""
        return [origin.strip() for origin in self.CORS_ORIGINS.split(",")]

    @property
    def is_production(self) -> bool:
        """Check if running in production."""
        return self.ENVIRONMENT == "production"

    @property
    def is_development(self) -> bool:
        """Check if running in development."""
        return self.ENVIRONMENT == "development"

    def validate_databricks(self) -> bool:
        """Validate Databricks credentials are set."""
        return bool(
            self.DATABRICKS_HOST and
            self.DATABRICKS_CLIENT_ID and
            self.DATABRICKS_CLIENT_SECRET
        )


# Singleton instance
_settings: Optional[Settings] = None


def get_settings() -> Settings:
    """Get application settings (singleton)."""
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings


def reload_settings():
    """Reload settings (useful for testing)."""
    global _settings
    _settings = None
    return get_settings()


# Environment-specific configurations
class DevelopmentConfig:
    """Development environment settings."""
    DEBUG = True
    LOG_LEVEL = "DEBUG"
    RATE_LIMIT_ENABLED = False


class ProductionConfig:
    """Production environment settings."""
    DEBUG = False
    LOG_LEVEL = "WARNING"
    RATE_LIMIT_ENABLED = True
    API_WORKERS = 8


class StagingConfig:
    """Staging environment settings."""
    DEBUG = False
    LOG_LEVEL = "INFO"
    RATE_LIMIT_ENABLED = True
    API_WORKERS = 4


# Environment config mapping
ENV_CONFIGS = {
    "development": DevelopmentConfig,
    "staging": StagingConfig,
    "production": ProductionConfig,
}


def get_env_config(environment: str):
    """Get environment-specific configuration."""
    return ENV_CONFIGS.get(environment, DevelopmentConfig)
