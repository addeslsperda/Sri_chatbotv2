"""
Production middleware for Litestar
Request ID tracking, rate limiting, monitoring
"""
import time
import uuid
import logging
from typing import Dict, Any
from litestar import Request, Response
from litestar.middleware.base import AbstractMiddleware
from litestar.types import ASGIApp, Scope, Receive, Send
from litestar.datastructures import State


logger = logging.getLogger(__name__)


class RequestIDMiddleware(AbstractMiddleware):
    """
    Add unique request ID to each request.
    Useful for tracing requests across logs.
    """

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        """Process request with unique ID."""
        if scope["type"] == "http":
            # Generate or extract request ID
            request_id = scope.get("headers", {}).get("x-request-id")
            if not request_id:
                request_id = str(uuid.uuid4())

            # Add to scope
            scope["state"] = scope.get("state", {})
            scope["state"]["request_id"] = request_id

            # Add to response headers
            async def send_wrapper(message):
                if message["type"] == "http.response.start":
                    headers = list(message.get("headers", []))
                    headers.append((b"x-request-id", request_id.encode()))
                    message["headers"] = headers
                await send(message)

            await self.app(scope, receive, send_wrapper)
        else:
            await self.app(scope, receive, send)


class PerformanceMiddleware(AbstractMiddleware):
    """
    Track request performance and log slow requests.
    """

    def __init__(self, app: ASGIApp, slow_threshold_ms: float = 1000):
        super().__init__(app)
        self.slow_threshold_ms = slow_threshold_ms

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        """Track request duration."""
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        start_time = time.time()

        # Process request
        await self.app(scope, receive, send)

        # Calculate duration
        duration_ms = (time.time() - start_time) * 1000

        # Log slow requests
        if duration_ms > self.slow_threshold_ms:
            path = scope.get("path", "")
            method = scope.get("method", "")
            logger.warning(
                f"Slow request: {method} {path}",
                extra={
                    "duration_ms": duration_ms,
                    "path": path,
                    "method": method
                }
            )


class RateLimitMiddleware(AbstractMiddleware):
    """
    Simple in-memory rate limiting.
    For production, use Redis-based rate limiting.
    """

    def __init__(
        self,
        app: ASGIApp,
        max_requests: int = 60,
        window_seconds: int = 60
    ):
        super().__init__(app)
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self.request_counts: Dict[str, list] = {}

    def _get_client_ip(self, scope: Scope) -> str:
        """Extract client IP from request."""
        # Check X-Forwarded-For header (behind proxy)
        headers = dict(scope.get("headers", []))
        forwarded = headers.get(b"x-forwarded-for")
        if forwarded:
            return forwarded.decode().split(",")[0].strip()

        # Fallback to client
        client = scope.get("client")
        if client:
            return client[0]

        return "unknown"

    def _is_rate_limited(self, client_ip: str) -> bool:
        """Check if client is rate limited."""
        now = time.time()

        # Get request timestamps for this client
        if client_ip not in self.request_counts:
            self.request_counts[client_ip] = []

        timestamps = self.request_counts[client_ip]

        # Remove old timestamps
        cutoff = now - self.window_seconds
        timestamps = [ts for ts in timestamps if ts > cutoff]
        self.request_counts[client_ip] = timestamps

        # Check limit
        if len(timestamps) >= self.max_requests:
            return True

        # Add current request
        timestamps.append(now)
        return False

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        """Check rate limit before processing request."""
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        client_ip = self._get_client_ip(scope)

        # Check rate limit
        if self._is_rate_limited(client_ip):
            # Return 429 Too Many Requests
            response_body = b'{"error": "Rate limit exceeded"}'

            await send({
                "type": "http.response.start",
                "status": 429,
                "headers": [
                    (b"content-type", b"application/json"),
                    (b"content-length", str(len(response_body)).encode()),
                ],
            })

            await send({
                "type": "http.response.body",
                "body": response_body,
            })

            logger.warning(f"Rate limit exceeded for client: {client_ip}")
            return

        # Process request
        await self.app(scope, receive, send)


class ErrorHandlingMiddleware(AbstractMiddleware):
    """
    Catch and log all unhandled exceptions.
    """

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        """Catch exceptions and return proper error response."""
        try:
            await self.app(scope, receive, send)
        except Exception as e:
            logger.exception("Unhandled exception in request processing")

            # Return 500 error
            error_body = b'{"error": "Internal server error"}'

            if scope["type"] == "http":
                await send({
                    "type": "http.response.start",
                    "status": 500,
                    "headers": [
                        (b"content-type", b"application/json"),
                        (b"content-length", str(len(error_body)).encode()),
                    ],
                })

                await send({
                    "type": "http.response.body",
                    "body": error_body,
                })


class SecurityHeadersMiddleware(AbstractMiddleware):
    """
    Add security headers to responses.
    """

    SECURITY_HEADERS = [
        (b"x-content-type-options", b"nosniff"),
        (b"x-frame-options", b"DENY"),
        (b"x-xss-protection", b"1; mode=block"),
        (b"strict-transport-security", b"max-age=31536000; includeSubDomains"),
    ]

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        """Add security headers to response."""
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        async def send_wrapper(message):
            if message["type"] == "http.response.start":
                headers = list(message.get("headers", []))
                headers.extend(self.SECURITY_HEADERS)
                message["headers"] = headers
            await send(message)

        await self.app(scope, receive, send_wrapper)


# Health check helper
def create_health_data(state: State) -> Dict[str, Any]:
    """
    Create health check data.

    Args:
        state: Application state

    Returns:
        Health check dictionary
    """
    return {
        "status": "healthy",
        "timestamp": time.time(),
        "checks": {
            "api": "ok",
            # Add more checks as needed
            # "database": check_database(),
            # "cache": check_redis(),
        }
    }
