"""Deployment configuration and utilities"""
from .config import get_settings, Settings

__all__ = ["get_settings", "Settings"]
