/**
 * DAISY Version 2: Frontend Conversation Download
 * JavaScript functions for downloading conversations from the frontend
 */

class ConversationDownloader {
    constructor(apiBaseUrl = '/api') {
        this.apiBaseUrl = apiBaseUrl;
        this.currentSessionId = this.generateSessionId();
    }

    /**
     * Generate a new session ID
     */
    generateSessionId() {
        return 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }

    /**
     * Start a new conversation session
     */
    async startSession(userId = null, sessionType = 'exploratory') {
        try {
            const response = await fetch(`${this.apiBaseUrl}/sessions/start`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    user_id: userId,
                    session_type: sessionType
                })
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            this.currentSessionId = data.session_id;

            // Store session ID in localStorage for persistence
            localStorage.setItem('daisy_session_id', this.currentSessionId);

            console.log('DAISY V2: Session started:', this.currentSessionId);
            return this.currentSessionId;
        } catch (error) {
            console.error('Failed to start session:', error);
            // Use generated session ID as fallback
            localStorage.setItem('daisy_session_id', this.currentSessionId);
            return this.currentSessionId;
        }
    }

    /**
     * End the current conversation session
     */
    async endSession(sessionId = null, completed = true, finalAction = null) {
        const targetSessionId = sessionId || this.currentSessionId;

        try {
            const response = await fetch(`${this.apiBaseUrl}/sessions/${targetSessionId}/end`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    completed: completed,
                    final_action: finalAction
                })
            });

            if (response.ok) {
                console.log('DAISY V2: Session ended:', targetSessionId);
            }
        } catch (error) {
            console.error('Failed to end session:', error);
        }
    }

    /**
     * Log a user question
     */
    async logQuestion(questionText, agentType = null, skillUsed = null, responseTime = null, userSatisfaction = null) {
        try {
            const response = await fetch(`${this.apiBaseUrl}/questions/log`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    question_text: questionText,
                    session_id: this.currentSessionId,
                    agent_type: agentType,
                    skill_used: skillUsed,
                    response_time: responseTime,
                    user_satisfaction: userSatisfaction
                })
            });

            if (response.ok) {
                const data = await response.json();
                console.log('DAISY V2: Question logged:', data.question_id);
                return data.question_id;
            }
        } catch (error) {
            console.error('Failed to log question:', error);
        }
        return null;
    }

    /**
     * Log skill execution
     */
    async logSkillExecution(agentType, skillName, status = 'success', duration = null, parameters = null) {
        try {
            const response = await fetch(`${this.apiBaseUrl}/skills/log`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    session_id: this.currentSessionId,
                    agent_type: agentType,
                    skill_name: skillName,
                    execution_status: status,
                    duration_seconds: duration,
                    input_parameters: parameters
                })
            });

            if (response.ok) {
                const data = await response.json();
                console.log('DAISY V2: Skill execution logged:', data.execution_id);
                return data.execution_id;
            }
        } catch (error) {
            console.error('Failed to log skill execution:', error);
        }
        return null;
    }

    /**
     * Download conversation in specified format
     */
    async downloadConversation(sessionId = null, format = 'json') {
        const targetSessionId = sessionId || this.currentSessionId;

        if (!['json', 'csv', 'txt'].includes(format)) {
            throw new Error('Format must be json, csv, or txt');
        }

        try {
            // Show loading indicator
            this.showDownloadStatus('Preparing download...', 'info');

            const response = await fetch(`${this.apiBaseUrl}/conversations/${targetSessionId}/download?format=${format}`, {
                method: 'GET'
            });

            if (!response.ok) {
                throw new Error(`Download failed: ${response.status} ${response.statusText}`);
            }

            // Get filename from response headers
            const contentDisposition = response.headers.get('Content-Disposition');
            let filename = `daisy_conversation_${targetSessionId.substr(0, 8)}_${new Date().toISOString().substr(0, 10)}.${format}`;

            if (contentDisposition) {
                const filenameMatch = contentDisposition.match(/filename="(.+)"/);
                if (filenameMatch) {
                    filename = filenameMatch[1];
                }
            }

            // Create blob and download
            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);

            const a = document.createElement('a');
            a.href = url;
            a.download = filename;
            a.style.display = 'none';

            document.body.appendChild(a);
            a.click();

            // Cleanup
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);

            this.showDownloadStatus('Download completed!', 'success');

            // Log the download action
            await this.logSkillExecution('system', 'conversation_download', 'success', null, {
                format: format,
                filename: filename
            });

            return filename;

        } catch (error) {
            console.error('Download failed:', error);
            this.showDownloadStatus(`Download failed: ${error.message}`, 'error');
            throw error;
        }
    }

    /**
     * Get conversation summary
     */
    async getConversationSummary(sessionId = null) {
        const targetSessionId = sessionId || this.currentSessionId;

        try {
            const response = await fetch(`${this.apiBaseUrl}/conversations/${targetSessionId}`, {
                method: 'GET'
            });

            if (!response.ok) {
                throw new Error(`Failed to get summary: ${response.status}`);
            }

            return await response.json();
        } catch (error) {
            console.error('Failed to get conversation summary:', error);
            return null;
        }
    }

    /**
     * Get complete conversation data (for preview)
     */
    async getConversationData(sessionId = null) {
        const targetSessionId = sessionId || this.currentSessionId;

        try {
            const response = await fetch(`${this.apiBaseUrl}/conversations/${targetSessionId}/data`, {
                method: 'GET'
            });

            if (!response.ok) {
                throw new Error(`Failed to get data: ${response.status}`);
            }

            return await response.json();
        } catch (error) {
            console.error('Failed to get conversation data:', error);
            return null;
        }
    }

    /**
     * Show download status to user
     */
    showDownloadStatus(message, type = 'info') {
        // Create or update status element
        let statusElement = document.getElementById('daisy-download-status');

        if (!statusElement) {
            statusElement = document.createElement('div');
            statusElement.id = 'daisy-download-status';
            statusElement.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 12px 20px;
                border-radius: 6px;
                color: white;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                font-size: 14px;
                font-weight: 500;
                box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
                z-index: 10000;
                transition: all 0.3s ease;
                max-width: 300px;
            `;
            document.body.appendChild(statusElement);
        }

        // Set colors based on type
        const colors = {
            info: '#2563eb',
            success: '#059669',
            error: '#dc2626',
            warning: '#d97706'
        };

        statusElement.style.backgroundColor = colors[type] || colors.info;
        statusElement.textContent = message;
        statusElement.style.opacity = '1';
        statusElement.style.transform = 'translateY(0)';

        // Auto-hide after delay (except for errors)
        if (type !== 'error') {
            setTimeout(() => {
                if (statusElement) {
                    statusElement.style.opacity = '0';
                    statusElement.style.transform = 'translateY(-20px)';
                    setTimeout(() => {
                        if (statusElement && statusElement.parentNode) {
                            statusElement.parentNode.removeChild(statusElement);
                        }
                    }, 300);
                }
            }, type === 'success' ? 3000 : 5000);
        }
    }

    /**
     * Initialize session from localStorage or create new
     */
    initializeSession() {
        const storedSessionId = localStorage.getItem('daisy_session_id');
        if (storedSessionId) {
            this.currentSessionId = storedSessionId;
            console.log('DAISY V2: Restored session:', this.currentSessionId);
        } else {
            this.startSession();
        }
        return this.currentSessionId;
    }

    /**
     * Create download buttons and add to page
     */
    createDownloadButtons(containerId = 'daisy-download-buttons') {
        let container = document.getElementById(containerId);

        if (!container) {
            container = document.createElement('div');
            container.id = containerId;
            container.style.cssText = `
                position: fixed;
                bottom: 20px;
                right: 20px;
                display: flex;
                flex-direction: column;
                gap: 8px;
                z-index: 1000;
            `;
            document.body.appendChild(container);
        }

        // Clear existing buttons
        container.innerHTML = '';

        // Button styles
        const buttonStyle = `
            padding: 10px 16px;
            border: none;
            border-radius: 6px;
            color: white;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            font-size: 13px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s ease;
            min-width: 120px;
            text-align: center;
        `;

        // Create download buttons
        const formats = [
            { format: 'json', label: 'Download JSON', color: '#2563eb' },
            { format: 'csv', label: 'Download CSV', color: '#059669' },
            { format: 'txt', label: 'Download TXT', color: '#7c2d12' }
        ];

        formats.forEach(({ format, label, color }) => {
            const button = document.createElement('button');
            button.textContent = label;
            button.style.cssText = buttonStyle + `background-color: ${color};`;

            button.addEventListener('mouseover', () => {
                button.style.transform = 'translateY(-1px)';
                button.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.2)';
            });

            button.addEventListener('mouseout', () => {
                button.style.transform = 'translateY(0)';
                button.style.boxShadow = 'none';
            });

            button.addEventListener('click', async () => {
                try {
                    await this.downloadConversation(null, format);
                } catch (error) {
                    console.error(`Failed to download ${format}:`, error);
                }
            });

            container.appendChild(button);
        });

        return container;
    }
}

// Global instance
window.daisyDownloader = new ConversationDownloader();

// Auto-initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    if (window.daisyDownloader) {
        window.daisyDownloader.initializeSession();

        // Auto-create download buttons if there's a chat interface
        const chatElements = ['chat-container', 'conversation-area', 'messages-container'];
        const hasChatInterface = chatElements.some(id => document.getElementById(id));

        if (hasChatInterface) {
            window.daisyDownloader.createDownloadButtons();
        }
    }
});

// Convenience functions for easy integration
function logQuestion(text, agent = null, skill = null, responseTime = null) {
    return window.daisyDownloader?.logQuestion(text, agent, skill, responseTime);
}

function logSkill(agent, skill, status = 'success', duration = null) {
    return window.daisyDownloader?.logSkillExecution(agent, skill, status, duration);
}

function downloadConversation(format = 'json') {
    return window.daisyDownloader?.downloadConversation(null, format);
}

function getSessionId() {
    return window.daisyDownloader?.currentSessionId;
}

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        ConversationDownloader,
        logQuestion,
        logSkill,
        downloadConversation,
        getSessionId
    };
}