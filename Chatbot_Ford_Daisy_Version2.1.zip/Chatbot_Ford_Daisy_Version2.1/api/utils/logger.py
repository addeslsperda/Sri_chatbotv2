"""
Logging configuration for the API.
Log level is controlled by the LOG_LEVEL environment variable (default: INFO).
Set LOG_LEVEL=DEBUG in .env to see all debug output during development.
"""
import logging
import os
import sys


def setup_logger(name: str = "ford_analytics_api") -> logging.Logger:
    """
    Set up a logger with consistent formatting.
    Respects LOG_LEVEL environment variable (DEBUG / INFO / WARNING / ERROR).

    Args:
        name: Logger name

    Returns:
        Configured logger instance
    """
    logger = logging.getLogger(name)

    if logger.handlers:
        return logger

    # Read level from env — default INFO, set DEBUG in .env for development
    level_name = os.getenv("LOG_LEVEL", "INFO").upper()
    level = getattr(logging, level_name, logging.INFO)

    logger.setLevel(level)

    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(level)

    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    handler.setFormatter(formatter)

    logger.addHandler(handler)

    return logger


api_logger = setup_logger("api")
