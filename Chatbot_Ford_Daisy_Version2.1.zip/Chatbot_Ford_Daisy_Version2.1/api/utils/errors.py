"""
Custom error types for better error handling
"""
from litestar.exceptions import HTTPException
from litestar.status_codes import (
    HTTP_400_BAD_REQUEST,
    HTTP_404_NOT_FOUND,
    HTTP_500_INTERNAL_SERVER_ERROR
)


class RoutingError(HTTPException):
    """Raised when question cannot be routed to any agent."""
    status_code = HTTP_400_BAD_REQUEST

    def __init__(self, question: str):
        super().__init__(
            detail=f"Could not find an appropriate agent to handle: '{question}'"
        )


class SkillNotFoundError(HTTPException):
    """Raised when a skill doesn't exist."""
    status_code = HTTP_404_NOT_FOUND

    def __init__(self, agent_name: str, skill_name: str):
        super().__init__(
            detail=f"Skill '{skill_name}' not found in agent '{agent_name}'"
        )


class SkillExecutionError(HTTPException):
    """Raised when skill execution fails."""
    status_code = HTTP_500_INTERNAL_SERVER_ERROR

    def __init__(self, agent_name: str, skill_name: str, error: str):
        super().__init__(
            detail=f"Skill '{skill_name}' in agent '{agent_name}' failed: {error}"
        )


class FormattingError(HTTPException):
    """Raised when response formatting fails."""
    status_code = HTTP_500_INTERNAL_SERVER_ERROR

    def __init__(self, result_type: str, error: str):
        super().__init__(
            detail=f"Failed to format result type '{result_type}': {error}"
        )
