"""
Ford Analytics API - Litestar Backend

Clean architecture:
- LLM client is SEPARATE (can be moved to its own container)
- Skill execution is pure Python (no LLM)
- API layer orchestrates between them
"""
import os
from pathlib import Path

# Load .env FIRST — before any service imports that need credentials.
# .env lives in the project root (one level above this file's directory).
from dotenv import load_dotenv
_env_path = Path(__file__).resolve().parent.parent / ".env"
load_dotenv(_env_path, override=True)

# Debug mode is OFF unless explicitly enabled via env (never leak stack traces in prod).
DEBUG = os.getenv("API_DEBUG", "false").lower() in ("1", "true", "yes")

from litestar import Litestar, get
from litestar.config.cors import CORSConfig
from litestar.exceptions import HTTPException
from litestar.response import Response
from litestar.static_files import create_static_files_router
from litestar.status_codes import HTTP_500_INTERNAL_SERVER_ERROR

# Import routes
from api.routes import health, agents, query, conversation


# Built frontend lives in api/static (produced by `npm run build` in ../demo).
# When present, the Python app serves the UI and the API from one origin — which
# is how it runs on Databricks Apps (single URL, single SSO login).
_STATIC_DIR = Path(__file__).resolve().parent / "static"

# Configure CORS for SvelteKit frontend.
# Same-origin in production (UI served from this app), so this only matters for
# local dev where the Vite dev server runs on a separate port.
_cors_origins = os.getenv(
    "CORS_ORIGINS",
    "http://localhost:5173,http://localhost:5174,http://localhost:3000",
).split(",")
cors_config = CORSConfig(
    allow_origins=[o.strip() for o in _cors_origins if o.strip()],
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["*"],
    allow_credentials=True,
)


# Global exception handler
def handle_exception(request, exc: Exception) -> Response:
    """Handle all uncaught exceptions."""
    return Response(
        content={
            "error": str(exc),
            "type": type(exc).__name__,
            "detail": "An unexpected error occurred"
        },
        status_code=HTTP_500_INTERNAL_SERVER_ERROR,
        media_type="application/json",
    )


# Create app
route_handlers = [
    health.router,
    query.router,
    agents.router,
    conversation.router,
]

# Serve the built frontend from the app root ("/") when it exists. Registered
# last so the /health and /api/* routes always take precedence. html_mode makes
# it fall back to index.html for client-side routes (SPA behavior).
if _STATIC_DIR.is_dir():
    route_handlers.append(
        create_static_files_router(
            path="/",
            directories=[_STATIC_DIR],
            html_mode=True,
        )
    )

app = Litestar(
    route_handlers=route_handlers,
    cors_config=cors_config,
    exception_handlers={
        HTTP_500_INTERNAL_SERVER_ERROR: handle_exception
    },
    debug=DEBUG  # env-driven (API_DEBUG); defaults to False for production safety
)


if __name__ == "__main__":
    import uvicorn

    print("=" * 70)
    print("Ford Analytics API - Litestar Backend")
    print("=" * 70)
    print("\nStarting server at http://localhost:8000")
    print("\nEndpoints:")
    print("  GET  /health              - Health check")
    print("  POST /api/query           - Natural language query")
    print("  POST /api/agents/vehicle  - Vehicle agent")
    print("  POST /api/agents/ops      - Operations agent")
    print("  POST /api/agents/sentiment - Sentiment agent")
    print("  POST /api/agents/flags    - Flags agent")
    print("\nDocs: http://localhost:8000/schema")
    print("=" * 70 + "\n")

    uvicorn.run(
        "api.app:app",
        host="0.0.0.0",  # nosec B104 - containerized service binds all interfaces behind ALB
        port=8000,
        reload=True  # Hot reload for development
    )
