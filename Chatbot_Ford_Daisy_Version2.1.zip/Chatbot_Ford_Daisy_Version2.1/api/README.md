# Ford Analytics API - Clean Architecture

This is the refactored, production-ready API for the Daisy chatbot.

## Architecture Overview

```
api/
├── app.py                 # Main Litestar application
├── routes/                # API endpoints
│   ├── query.py          # Natural language query endpoint (main)
│   ├── agents.py         # Direct agent endpoints
│   └── health.py         # Health check
├── services/             # Business logic layer
│   ├── router_service.py       # Routes questions to skills
│   ├── executor_service.py     # Executes skills
│   └── llm_formatter_service.py # Formats responses with Claude LLM
├── models/               # Pydantic data models
│   └── query.py          # Request/response models
└── utils/                # Utilities
    ├── logger.py         # Logging configuration
    └── errors.py         # Custom error types
```

## Key Features

### 1. LLM-Based Formatting
- Uses Claude API to format all responses
- No hardcoded formatters needed
- Natural, conversational output
- Handles all 52 skills automatically

### 2. Clean Separation of Concerns
- **Routes**: Handle HTTP requests/responses
- **Services**: Contain business logic
- **Models**: Define data structures
- **Utils**: Provide cross-cutting concerns

### 3. Comprehensive Error Handling
- Custom error types for different failure modes
- Proper HTTP status codes
- Detailed logging for debugging

### 4. No Performance Hacks
- Removed module reload hack (was slowing every request)
- Proper singleton pattern for services
- Efficient service initialization

## Main Endpoint: `/api/query`

### Request
```json
POST /api/query
{
  "question": "What are the top issues this week?",
  "date_from": "2026-01-01",
  "date_to": "2026-01-31"
}
```

### Response
```json
{
  "question": "What are the top issues this week?",
  "answer": "TOP ISSUES ANALYSIS\n\nTotal calls analyzed: 143,985\n\nTop 10 issues:\n...",
  "data": { ... },
  "agent_used": "vehicle_agent",
  "skill_used": "topic_trends",
  "confidence": 0.95
}
```

## How It Works

### 1. Routing
```
User Question -> RouterService
              DOWN
Uses IntelligentRouter (LLM-powered)
              DOWN
Returns: agent + skill + params
```

### 2. Execution
```
Route -> ExecutorService
      DOWN
Executes skill via SkillExecutor
      DOWN
Returns: Raw JSON data
```

### 3. Formatting
```
Raw Data -> LLMFormatterService
         DOWN
Sends to Claude API with comprehensive prompt
         DOWN
Returns: Natural language response
```

### 4. Response
```
Formatted Answer + Raw Data -> User
```

## Environment Variables

Required in `.env`:
```
# AWS Bedrock (for Claude API)
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=your_access_key
AWS_SECRET_ACCESS_KEY=your_secret_key

# Databricks (for data queries)
DATABRICKS_HOST=https://your-workspace.cloud.databricks.com
DATABRICKS_HTTP_PATH=/sql/1.0/warehouses/your_warehouse
DATABRICKS_CLIENT_ID=your_client_id
DATABRICKS_CLIENT_SECRET=your_client_secret
DATABRICKS_CATALOG=text_analytics
DATABRICKS_SCHEMA=nlp_analytics
```

## Running the API

### Development
```bash
python -m api.app
```

Server starts at: http://localhost:8000

### Production
```bash
uvicorn api.app:app --host 0.0.0.0 --port 8000 --workers 4
```

## Testing

### Health Check
```bash
curl http://localhost:8000/health
```

### Query Test
```bash
curl -X POST http://localhost:8000/api/query \
  -H "Content-Type: application/json" \
  -d '{"question": "What are the top issues this week?"}'
```

## API Documentation

Once running, visit:
- **OpenAPI Schema**: http://localhost:8000/schema
- **API Docs**: http://localhost:8000/schema/swagger

## Adding New Skills

No code changes needed! The LLM formatter automatically handles new skills:

1. Create skill in appropriate agent folder
2. Router will learn to route to it
3. LLM formatter will automatically format output
4. Done!

## Cost Estimates

### LLM Formatting Costs (Claude Sonnet 4.5)
- ~$0.008 per query
- 1,000 queries/day = $8/day = $240/month
- 10,000 queries/day = $80/day = $2,400/month

### Reducing Costs
1. Use Claude Haiku for simpler queries (~75% cheaper)
2. Cache common responses
3. Only format for user-facing queries

## Migration Notes

### Old vs New

**Old (query_fixed.py)**:
- 303 lines
- Hardcoded formatters
- Module reload hack
- 6 formatters (didn't cover all skills)

**New (query.py)**:
- 100 lines
- LLM-based formatting
- No performance hacks
- Covers all 52 skills automatically

### Backward Compatibility

The API response format is identical, so existing clients don't need changes.

## Troubleshooting

### "RoutingError: Could not route question"
- Check if question is too ambiguous
- Review intelligent_router.py routing logic
- Check LLM routing is enabled

### "SkillExecutionError"
- Check Databricks credentials in .env
- Verify skill exists in agent folder
- Check skill script for errors

### "LLM formatting failed"
- Check AWS Bedrock credentials
- Verify Claude API access
- Check network connectivity
- Fallback formatter will be used automatically

## Performance

Typical response times:
- Routing: ~10-50ms
- Skill execution: ~100-500ms (database query)
- LLM formatting: ~200-500ms (Claude API)
- **Total: ~310-1050ms** (~0.5 second average)

## Future Enhancements

- [ ] Add conversation history support
- [ ] Implement response caching
- [ ] Add streaming responses
- [ ] Multi-agent orchestration
- [ ] Add metrics/monitoring
- [ ] Add rate limiting
- [ ] Add authentication

## Support

For issues or questions, check:
1. Server logs: `/tmp/api_server.log`
2. Application logs (stdout)
3. Databricks query logs
