"""
Centralized query models for the API
All request/response models in one place - no duplication
"""
from pydantic import BaseModel, Field


class ChatTurn(BaseModel):
    """A single completed conversation turn sent back by the client."""
    question: str = Field(..., description="User's question")
    answer: str = Field(..., description="Daisy's answer")
    agent_used: str | None = Field(None, description="Agent that handled it")
    skill_used: str | None = Field(None, description="Skill that was executed")
    params: dict | None = Field(None, description="Params used in the skill call (vehicle, dates, etc.)")


class QueryRequest(BaseModel):
    """Natural language query request."""
    question: str = Field(..., description="Natural language question from user")
    date_from: str | None = Field(None, description="Optional start date filter (YYYY-MM-DD)")
    date_to: str | None = Field(None, description="Optional end date filter (YYYY-MM-DD)")
    chat_history: list[ChatTurn] = Field(
        default_factory=list,
        description="Previous conversation turns for context (most recent last, max 10)"
    )
    page_context: str | None = Field(
        None,
        description="Current page/view the user is on (injected by frontend for 'what page am I on?' queries)"
    )
    session_id: str | None = Field(
        None,
        description="Optional session ID for conversation tracking"
    )


class QueryResponse(BaseModel):
    """Standard query response."""
    question: str = Field(..., description="Original question asked")
    answer: str = Field(..., description="Human-readable answer")
    data: dict | None = Field(None, description="Raw data from skill execution")
    agent_used: str = Field(..., description="Agent that handled the query")
    skill_used: str = Field(..., description="Skill that was executed")
    confidence: float | None = Field(None, description="Router confidence score (0-1)")
    params: dict | None = Field(None, description="Params used in the skill call (vehicle, dates, etc.)")


class AgentRequest(BaseModel):
    """Direct agent request (for /api/agents/* endpoints)."""
    skill: str = Field(..., description="Skill name to execute")
    params: dict = Field(default_factory=dict, description="Parameters for the skill")


class AgentResponse(BaseModel):
    """Direct agent response."""
    success: bool = Field(..., description="Whether execution succeeded")
    data: dict | None = Field(None, description="Result data if successful")
    error: str | None = Field(None, description="Error message if failed")
