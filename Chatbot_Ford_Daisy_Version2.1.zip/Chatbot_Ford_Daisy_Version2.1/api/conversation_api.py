"""
DAISY Version 2: Conversation API Endpoints
FastAPI endpoints for conversation tracking and downloading
"""
from fastapi import FastAPI, HTTPException, Response, Depends
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import Dict, List, Optional, Any
import uuid
import os
import sys
from pathlib import Path
from datetime import datetime

# Add tracking module to path
sys.path.append(str(Path(__file__).resolve().parents[1] / 'tracking'))

from conversation_tracker import conversation_tracker, log_question, log_skill, start_session, end_session
from conversation_downloader import ConversationDownloader

app = FastAPI(
    title="DAISY Version 2 - Conversation API",
    description="API endpoints for conversation tracking and export functionality",
    version="2.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Pydantic models for request/response
class QuestionRequest(BaseModel):
    question_text: str = Field(..., description="The user's question")
    session_id: Optional[str] = Field(None, description="Session ID (auto-generated if not provided)")
    agent_type: Optional[str] = Field(None, description="Type of agent used")
    skill_used: Optional[str] = Field(None, description="Skill that was executed")
    response_status: str = Field("success", description="Response status")
    response_time: Optional[float] = Field(None, description="Response time in seconds")
    user_satisfaction: Optional[int] = Field(None, ge=1, le=5, description="User satisfaction rating 1-5")

class SkillExecutionRequest(BaseModel):
    session_id: str = Field(..., description="Session ID")
    agent_type: str = Field(..., description="Type of agent")
    skill_name: str = Field(..., description="Name of the skill")
    execution_status: str = Field("success", description="Execution status")
    duration_seconds: Optional[float] = Field(None, description="Execution duration")
    input_parameters: Optional[Dict[str, Any]] = Field(None, description="Input parameters")
    tables_accessed: Optional[List[str]] = Field(None, description="Database tables accessed")
    records_returned: Optional[int] = Field(None, description="Number of records returned")
    error_message: Optional[str] = Field(None, description="Error message if failed")

class SessionRequest(BaseModel):
    user_id: Optional[str] = Field(None, description="User ID")
    session_type: str = Field("exploratory", description="Type of session")

class ConversationResponse(BaseModel):
    session_id: str
    total_questions: int
    total_skills_executed: int
    session_duration_minutes: Optional[float]
    success_rate: Optional[float]

# Global downloader instance
downloader = ConversationDownloader()

@app.get("/", response_model=Dict[str, str])
async def root():
    """API root endpoint"""
    return {
        "message": "DAISY Version 2 - Conversation API",
        "version": "2.0.0",
        "status": "active"
    }

@app.post("/sessions/start", response_model=Dict[str, str])
async def start_conversation_session(request: SessionRequest):
    """Start a new conversation session"""
    try:
        session_id = conversation_tracker.start_conversation_session(
            user_id=request.user_id,
            session_type=request.session_type
        )
        return {
            "session_id": session_id,
            "status": "started",
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to start session: {str(e)}")

@app.post("/sessions/{session_id}/end")
async def end_conversation_session(
    session_id: str,
    completed: bool = True,
    final_action: Optional[str] = None
):
    """End a conversation session"""
    try:
        conversation_tracker.end_conversation_session(
            session_id=session_id,
            session_completed=completed,
            final_action=final_action
        )
        return {
            "session_id": session_id,
            "status": "ended",
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to end session: {str(e)}")

@app.post("/questions/log", response_model=Dict[str, str])
async def log_user_question(request: QuestionRequest):
    """Log a user question to the tracking system"""
    try:
        question_id = conversation_tracker.log_user_question(
            question_text=request.question_text,
            session_id=request.session_id,
            agent_type=request.agent_type,
            skill_used=request.skill_used,
            response_status=request.response_status,
            response_time=request.response_time,
            user_satisfaction=request.user_satisfaction
        )
        return {
            "question_id": question_id,
            "session_id": request.session_id or conversation_tracker.session_id,
            "status": "logged",
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to log question: {str(e)}")

@app.post("/skills/log", response_model=Dict[str, str])
async def log_skill_execution(request: SkillExecutionRequest):
    """Log a skill execution to the tracking system"""
    try:
        execution_id = conversation_tracker.log_skill_execution(
            session_id=request.session_id,
            agent_type=request.agent_type,
            skill_name=request.skill_name,
            execution_status=request.execution_status,
            duration_seconds=request.duration_seconds,
            input_parameters=request.input_parameters,
            tables_accessed=request.tables_accessed,
            records_returned=request.records_returned,
            error_message=request.error_message
        )
        return {
            "execution_id": execution_id,
            "session_id": request.session_id,
            "status": "logged",
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to log skill execution: {str(e)}")

@app.get("/conversations/{session_id}", response_model=ConversationResponse)
async def get_conversation_summary(session_id: str):
    """Get conversation summary for a session"""
    try:
        data = downloader.get_conversation_data(session_id)

        if "error" in data:
            raise HTTPException(status_code=404, detail=data["error"])

        session_info = data.get("session_info", {})

        return ConversationResponse(
            session_id=session_id,
            total_questions=data.get("total_questions", 0),
            total_skills_executed=data.get("total_skills_executed", 0),
            session_duration_minutes=session_info.get("session_duration_minutes"),
            success_rate=session_info.get("success_rate")
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to retrieve conversation: {str(e)}")

@app.get("/conversations/{session_id}/download")
async def download_conversation(
    session_id: str,
    format: str = "json",
    response: Response = None
):
    """Download conversation in specified format (json, csv, txt)"""

    if format not in ["json", "csv", "txt"]:
        raise HTTPException(status_code=400, detail="Format must be 'json', 'csv', or 'txt'")

    try:
        # Generate the file based on format
        if format == "json":
            file_path = downloader.export_conversation_json(session_id)
            media_type = "application/json"
        elif format == "csv":
            file_path = downloader.export_conversation_csv(session_id)
            media_type = "text/csv"
        elif format == "txt":
            file_path = downloader.export_conversation_txt(session_id)
            media_type = "text/plain"

        # Check if file exists
        if not os.path.exists(file_path):
            raise HTTPException(status_code=500, detail="Failed to generate download file")

        # Generate appropriate filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"daisy_conversation_{session_id[:8]}_{timestamp}.{format}"

        return FileResponse(
            path=file_path,
            filename=filename,
            media_type=media_type,
            headers={
                "Content-Disposition": f"attachment; filename={filename}",
                "Access-Control-Expose-Headers": "Content-Disposition"
            }
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to download conversation: {str(e)}")

@app.get("/conversations/{session_id}/data")
async def get_conversation_data(session_id: str):
    """Get complete conversation data as JSON (for preview)"""
    try:
        data = downloader.get_conversation_data(session_id)

        if "error" in data:
            raise HTTPException(status_code=404, detail=data["error"])

        return JSONResponse(content=data)

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to retrieve conversation data: {str(e)}")

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    try:
        # Test database connection
        conn = downloader._get_databricks_connection()
        if conn is None:
            return {
                "status": "warning",
                "message": "API running but database connection unavailable",
                "timestamp": datetime.utcnow().isoformat()
            }

        return {
            "status": "healthy",
            "message": "All systems operational",
            "timestamp": datetime.utcnow().isoformat(),
            "database": "connected"
        }
    except Exception as e:
        return {
            "status": "error",
            "message": f"Health check failed: {str(e)}",
            "timestamp": datetime.utcnow().isoformat()
        }

@app.get("/analytics/summary")
async def get_analytics_summary(days: int = 7):
    """Get analytics summary for the last N days"""
    try:
        # This would typically query the analytics tables
        # For now, return a placeholder structure
        return {
            "period_days": days,
            "total_sessions": 0,
            "total_questions": 0,
            "total_skills_executed": 0,
            "avg_session_duration": 0.0,
            "success_rate": 0.0,
            "most_used_agents": [],
            "most_common_question_categories": [],
            "error_rate": 0.0,
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to retrieve analytics: {str(e)}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)