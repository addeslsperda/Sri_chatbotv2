"""
Direct agent access endpoints — bypass routing, call a specific skill directly.
Uses the executor_service singleton (not a new SkillExecutor per request).
"""
from litestar import Router, post
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from api.models.query import AgentRequest, AgentResponse
from api.services.executor_service import executor_service
from api.utils.logger import api_logger


@post("/api/agents/vehicle")
async def vehicle_agent(data: AgentRequest) -> AgentResponse:
    """Vehicle agent direct endpoint."""
    try:
        result = executor_service.execute_direct(
            agent_name="vehicle_agent",
            skill_name=data.skill,
            params=data.params
        )
        return AgentResponse(success=True, data=result)
    except Exception as e:
        api_logger.error(f"vehicle_agent direct call failed: {e}")
        return AgentResponse(success=False, error=str(e))


@post("/api/agents/operations")
async def operations_agent(data: AgentRequest) -> AgentResponse:
    """Operations agent direct endpoint."""
    try:
        result = executor_service.execute_direct(
            agent_name="operations_agent",
            skill_name=data.skill,
            params=data.params
        )
        return AgentResponse(success=True, data=result)
    except Exception as e:
        api_logger.error(f"operations_agent direct call failed: {e}")
        return AgentResponse(success=False, error=str(e))


@post("/api/agents/sentiment")
async def sentiment_agent(data: AgentRequest) -> AgentResponse:
    """Sentiment agent direct endpoint."""
    try:
        result = executor_service.execute_direct(
            agent_name="sentiment_agent",
            skill_name=data.skill,
            params=data.params
        )
        return AgentResponse(success=True, data=result)
    except Exception as e:
        api_logger.error(f"sentiment_agent direct call failed: {e}")
        return AgentResponse(success=False, error=str(e))


@post("/api/agents/flags")
async def flags_agent(data: AgentRequest) -> AgentResponse:
    """Flags agent direct endpoint."""
    try:
        result = executor_service.execute_direct(
            agent_name="flags_agent",
            skill_name=data.skill,
            params=data.params
        )
        return AgentResponse(success=True, data=result)
    except Exception as e:
        api_logger.error(f"flags_agent direct call failed: {e}")
        return AgentResponse(success=False, error=str(e))


@post("/api/agents/bluecruise")
async def bluecruise_agent(data: AgentRequest) -> AgentResponse:
    """BlueCruise agent direct endpoint."""
    try:
        result = executor_service.execute_direct(
            agent_name="bluecruise_agent",
            skill_name=data.skill,
            params=data.params
        )
        return AgentResponse(success=True, data=result)
    except Exception as e:
        api_logger.error(f"bluecruise_agent direct call failed: {e}")
        return AgentResponse(success=False, error=str(e))


# Create router
router = Router(
    path="",
    route_handlers=[
        vehicle_agent,
        operations_agent,
        sentiment_agent,
        flags_agent,
        bluecruise_agent,
    ]
)
