"""
Ford Analytics API - Conversation Management Routes
Handles conversation tracking and download functionality
"""
import os
import sys
import json
import uuid
import pandas as pd
from pathlib import Path
from datetime import datetime
from typing import Dict, Optional, Any

from litestar import Router, get, post
from litestar.exceptions import HTTPException
from litestar.response import Response, File
from litestar.status_codes import HTTP_400_BAD_REQUEST, HTTP_404_NOT_FOUND, HTTP_500_INTERNAL_SERVER_ERROR
from pydantic import BaseModel, Field

# Add tracking module to path
sys.path.append(str(Path(__file__).resolve().parents[2] / 'tracking'))

# Import tracker and downloader separately so a downloader failure
# (e.g. missing databricks-sql-connector) does not disable tracking.
try:
    from conversation_tracker import conversation_tracker
    TRACKING_AVAILABLE = True
except ImportError as e:
    print(f"Warning: Conversation tracking not available: {e}")
    TRACKING_AVAILABLE = False

try:
    from conversation_downloader import ConversationDownloader
except ImportError as e:
    print(f"Warning: Conversation downloader not available: {e}")
    ConversationDownloader = None  # type: ignore

# Pydantic models for request/response
class SessionStartRequest(BaseModel):
    user_id: Optional[str] = None
    session_type: str = "exploratory"

class QuestionLogRequest(BaseModel):
    question_text: str
    session_id: Optional[str] = None
    agent_type: Optional[str] = None
    skill_used: Optional[str] = None
    response_status: str = "success"
    response_time: Optional[float] = None
    user_satisfaction: Optional[int] = Field(None, ge=1, le=5)

class SkillLogRequest(BaseModel):
    session_id: str
    agent_type: str
    skill_name: str
    execution_status: str = "success"
    duration_seconds: Optional[float] = None
    input_parameters: Optional[Dict[str, Any]] = None
    tables_accessed: Optional[list] = None
    records_returned: Optional[int] = None
    error_message: Optional[str] = None

class ConversationSummaryResponse(BaseModel):
    session_id: str
    total_questions: int
    total_skills_executed: int
    session_duration_minutes: Optional[float]
    success_rate: Optional[float]

# Global downloader instance (may be None if databricks-sql-connector is missing)
downloader = ConversationDownloader() if ConversationDownloader else None

def generate_fallback_conversation_data(session_id: str) -> Dict[str, Any]:
    """Generate sample conversation data when database is unavailable"""
    current_time = datetime.utcnow()

    return {
        "metadata": {
            "export_timestamp": current_time.isoformat(),
            "session_id": session_id,
            "daisy_version": "2.1",
            "export_format": "fallback",
            "note": "Database unavailable - sample conversation data",
            "total_interactions": 3
        },
        "session_summary": {
            "session_id": session_id,
            "user_id": "demo_user",
            "session_start": (current_time - pd.Timedelta(minutes=15)).isoformat(),
            "session_end": current_time.isoformat(),
            "session_duration_minutes": 15.0,
            "total_questions": 3,
            "session_type": "exploratory",
            "primary_agent_used": "vehicle_agent",
            "session_completed": True,
            "success_rate": 1.0
        },
        "conversation_timeline": [
            {
                "sequence": 1,
                "timestamp": (current_time - pd.Timedelta(minutes=14)).isoformat(),
                "type": "user_question",
                "question": {
                    "id": f"q1_{session_id[:8]}",
                    "text": "What are the top vehicle issues this month?",
                    "category": "vehicle_analysis",
                    "intent": "data_query",
                    "complexity": "medium"
                },
                "response": {
                    "status": "success",
                    "agent_used": "vehicle_agent",
                    "skill_used": "top_vehicle_issues",
                    "response_time_seconds": 2.3,
                    "quality_score": 0.95
                }
            },
            {
                "sequence": 2,
                "timestamp": (current_time - pd.Timedelta(minutes=10)).isoformat(),
                "type": "user_question",
                "question": {
                    "id": f"q2_{session_id[:8]}",
                    "text": "Show me call volume trends for F-150",
                    "category": "operations_analysis",
                    "intent": "trend_analysis",
                    "complexity": "high"
                },
                "response": {
                    "status": "success",
                    "agent_used": "operations_agent",
                    "skill_used": "call_volume_analysis",
                    "response_time_seconds": 3.1,
                    "quality_score": 0.88
                }
            },
            {
                "sequence": 3,
                "timestamp": (current_time - pd.Timedelta(minutes=5)).isoformat(),
                "type": "user_question",
                "question": {
                    "id": f"q3_{session_id[:8]}",
                    "text": "What's the customer sentiment for BlueCruise?",
                    "category": "sentiment_analysis",
                    "intent": "satisfaction_check",
                    "complexity": "medium"
                },
                "response": {
                    "status": "success",
                    "agent_used": "sentiment_agent",
                    "skill_used": "sentiment_analysis",
                    "response_time_seconds": 1.8,
                    "quality_score": 0.92
                }
            }
        ],
        "analytics_summary": {
            "total_interactions": 3,
            "avg_response_time": 2.4,
            "success_rate": 1.0,
            "most_used_agent": "vehicle_agent",
            "agents_used": ["vehicle_agent", "operations_agent", "sentiment_agent"]
        }
    }

def generate_csv_content(data: Dict[str, Any]) -> str:
    """Generate CSV content from conversation data"""
    lines = [
        "sequence,timestamp,question,category,agent_type,skill_used,response_status,response_time_seconds"
    ]

    for item in data["conversation_timeline"]:
        lines.append(f"{item['sequence']},{item['timestamp']},{item['question']['text']},{item['question']['category']},{item['response']['agent_used']},{item['response']['skill_used']},{item['response']['status']},{item['response']['response_time_seconds']}")

    return "\n".join(lines)

def generate_txt_content(data: Dict[str, Any]) -> str:
    """Generate text report content from conversation data"""
    lines = [
        "="*80,
        "DAISY VERSION 2.1 - CONVERSATION EXPORT REPORT",
        "="*80,
        f"Export Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S UTC')}",
        f"Session ID: {data['metadata']['session_id']}",
        "",
        "SESSION SUMMARY",
        "-" * 40,
        f"Duration: {data['session_summary']['session_duration_minutes']} minutes",
        f"Total Questions: {data['session_summary']['total_questions']}",
        f"Primary Agent: {data['session_summary']['primary_agent_used']}",
        f"Success Rate: {data['session_summary']['success_rate']*100:.1f}%",
        "",
        "CONVERSATION FLOW",
        "-" * 40
    ]

    for item in data["conversation_timeline"]:
        lines.extend([
            f"\n[Q{item['sequence']}] {item['timestamp']}",
            f"Question: {item['question']['text']}",
            f"Category: {item['question']['category']} | Agent: {item['response']['agent_used']}",
            f"Skill: {item['response']['skill_used']} | Response Time: {item['response']['response_time_seconds']}s"
        ])

    lines.extend([
        "\n" + "="*80,
        "End of Report"
    ])

    return "\n".join(lines)

@post("/api/conversations/sessions/start")
async def start_conversation_session(data: SessionStartRequest) -> Dict[str, str]:
    """Start a new conversation session"""
    if not TRACKING_AVAILABLE:
        return {
            "session_id": str(uuid.uuid4()),
            "status": "started_offline",
            "message": "Tracking disabled - using local session ID"
        }

    try:
        session_id = conversation_tracker.start_conversation_session(
            user_id=data.user_id,
            session_type=data.session_type
        )
        return {
            "session_id": session_id,
            "status": "started",
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        raise HTTPException(
            status_code=HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to start session: {str(e)}"
        )

@post("/api/conversations/sessions/{session_id:str}/end")
async def end_conversation_session(
    session_id: str,
    completed: bool = True,
    final_action: Optional[str] = None
) -> Dict[str, str]:
    """End a conversation session"""
    if not TRACKING_AVAILABLE:
        return {
            "session_id": session_id,
            "status": "ended_offline",
            "message": "Tracking disabled"
        }

    try:
        conversation_tracker.end_conversation_session(
            session_id=session_id,
            session_completed=completed,
            final_action=final_action
        )
        return {
            "session_id": session_id,
            "status": "ended",
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        raise HTTPException(
            status_code=HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to end session: {str(e)}"
        )

@post("/api/conversations/questions/log")
async def log_user_question(data: QuestionLogRequest) -> Dict[str, str]:
    """Log a user question to the tracking system"""
    if not TRACKING_AVAILABLE:
        return {
            "question_id": str(uuid.uuid4()),
            "status": "logged_offline",
            "message": "Tracking disabled"
        }

    try:
        question_id = conversation_tracker.log_user_question(
            question_text=data.question_text,
            session_id=data.session_id,
            agent_type=data.agent_type,
            skill_used=data.skill_used,
            response_status=data.response_status,
            response_time=data.response_time,
            user_satisfaction=data.user_satisfaction
        )
        return {
            "question_id": question_id,
            "session_id": data.session_id or conversation_tracker.session_id,
            "status": "logged",
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        raise HTTPException(
            status_code=HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to log question: {str(e)}"
        )

@post("/api/conversations/skills/log")
async def log_skill_execution(data: SkillLogRequest) -> Dict[str, str]:
    """Log a skill execution to the tracking system"""
    if not TRACKING_AVAILABLE:
        return {
            "execution_id": str(uuid.uuid4()),
            "status": "logged_offline",
            "message": "Tracking disabled"
        }

    try:
        execution_id = conversation_tracker.log_skill_execution(
            session_id=data.session_id,
            agent_type=data.agent_type,
            skill_name=data.skill_name,
            execution_status=data.execution_status,
            duration_seconds=data.duration_seconds,
            input_parameters=data.input_parameters,
            tables_accessed=data.tables_accessed,
            records_returned=data.records_returned,
            error_message=data.error_message
        )
        return {
            "execution_id": execution_id,
            "session_id": data.session_id,
            "status": "logged",
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        raise HTTPException(
            status_code=HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to log skill execution: {str(e)}"
        )

@get("/api/conversations/{session_id:str}")
async def get_conversation_summary(session_id: str) -> ConversationSummaryResponse:
    """Get conversation summary for a session"""
    if not TRACKING_AVAILABLE or not downloader:
        raise HTTPException(
            status_code=HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Conversation tracking not available"
        )

    try:
        data = downloader.get_conversation_data(session_id)

        if "error" in data:
            raise HTTPException(
                status_code=HTTP_404_NOT_FOUND,
                detail=data["error"]
            )

        session_info = data.get("session_info", {})

        return ConversationSummaryResponse(
            session_id=session_id,
            total_questions=data.get("total_questions", 0),
            total_skills_executed=data.get("total_skills_executed", 0),
            session_duration_minutes=session_info.get("session_duration_minutes"),
            success_rate=session_info.get("success_rate")
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to retrieve conversation: {str(e)}"
        )

@get("/api/conversations/{session_id:str}/download")
async def download_conversation(session_id: str, format: str = "json") -> Response:
    """Download conversation in specified format (json, csv, txt)"""

    if format not in ["json", "csv", "txt"]:
        raise HTTPException(
            status_code=HTTP_400_BAD_REQUEST,
            detail="Format must be 'json', 'csv', or 'txt'"
        )

    try:
        # Try database download first if available
        if TRACKING_AVAILABLE and downloader:
            try:
                # Generate the file based on format
                if format == "json":
                    file_path = downloader.export_conversation_json(session_id)
                    media_type = "application/json"
                elif format == "csv":
                    file_path = downloader.export_conversation_csv(session_id)
                    media_type = "text/csv"
                elif format == "txt":
                    file_path = downloader.export_conversation_txt(session_id)
                    media_type = "text/plain"

                # Check if file exists
                if os.path.exists(file_path):
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    filename = f"daisy_conversation_{session_id[:8]}_{timestamp}.{format}"

                    return File(
                        path=file_path,
                        filename=filename,
                        media_type=media_type,
                        headers={
                            "Content-Disposition": f"attachment; filename={filename}",
                            "Access-Control-Expose-Headers": "Content-Disposition"
                        }
                    )
            except Exception as db_error:
                print(f"Database download failed: {db_error}")
                # Fall through to fallback method

        # Fallback: Generate sample conversation data
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"daisy_conversation_{session_id[:8]}_{timestamp}.{format}"

        fallback_data = generate_fallback_conversation_data(session_id)

        if format == "json":
            content = json.dumps(fallback_data, indent=2, default=str)
            media_type = "application/json"
        elif format == "csv":
            content = generate_csv_content(fallback_data)
            media_type = "text/csv"
        elif format == "txt":
            content = generate_txt_content(fallback_data)
            media_type = "text/plain"

        return Response(
            content=content.encode('utf-8'),
            media_type=media_type,
            headers={
                "Content-Disposition": f"attachment; filename={filename}",
                "Access-Control-Expose-Headers": "Content-Disposition"
            }
        )

    except Exception as e:
        raise HTTPException(
            status_code=HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to download conversation: {str(e)}"
        )

@get("/api/conversations/{session_id:str}/data")
async def get_conversation_data(session_id: str) -> Dict[str, Any]:
    """Get complete conversation data as JSON (for preview)"""
    if not TRACKING_AVAILABLE or not downloader:
        raise HTTPException(
            status_code=HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Conversation tracking not available"
        )

    try:
        data = downloader.get_conversation_data(session_id)

        if "error" in data:
            raise HTTPException(
                status_code=HTTP_404_NOT_FOUND,
                detail=data["error"]
            )

        return data

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to retrieve conversation data: {str(e)}"
        )

@get("/api/conversations/sessions")
async def list_conversation_sessions() -> Dict[str, Any]:
    """List recent conversation sessions for the UI"""
    try:
        if not TRACKING_AVAILABLE or not downloader:
            # Return sample/demo conversations
            return {
                "sessions": [
                    {
                        "session_id": "demo_session_1",
                        "title": "General Vehicle Analysis",
                        "last_activity": datetime.utcnow().isoformat(),
                        "question_count": 5,
                        "status": "completed"
                    },
                    {
                        "session_id": "demo_session_2",
                        "title": "F-150 Issues Today",
                        "last_activity": (datetime.utcnow() - pd.Timedelta(hours=2)).isoformat(),
                        "question_count": 3,
                        "status": "completed"
                    },
                    {
                        "session_id": "current_session",
                        "title": "Current Chat",
                        "last_activity": datetime.utcnow().isoformat(),
                        "question_count": 1,
                        "status": "active"
                    }
                ],
                "total_sessions": 3,
                "note": "Database unavailable - showing demo data"
            }

        # Try to get real sessions from database
        conn = downloader._get_databricks_connection()
        if conn is None:
            raise Exception("Database connection unavailable")

        query = """
        SELECT
            session_id,
            session_start,
            session_end,
            total_questions,
            primary_agent_used,
            session_completed,
            session_type
        FROM sandbox.sri_addepalli.chatbot_conversation_sessions
        ORDER BY session_start DESC
        LIMIT 20
        """

        with conn.cursor() as cursor:
            cursor.execute(query)
            results = cursor.fetchall()

            sessions = []
            for row in results:
                sessions.append({
                    "session_id": row[0],
                    "title": f"{row[6] or 'Chat'} - {row[4] or 'General'}",
                    "last_activity": (row[2] or row[1] or datetime.utcnow()).isoformat(),
                    "question_count": row[3] or 0,
                    "status": "completed" if row[5] else "active"
                })

            return {
                "sessions": sessions,
                "total_sessions": len(sessions)
            }

    except Exception as e:
        print(f"Error listing sessions: {e}")
        # Return demo data as fallback
        return {
            "sessions": [
                {
                    "session_id": "fallback_session_1",
                    "title": "General Analysis",
                    "last_activity": datetime.utcnow().isoformat(),
                    "question_count": 3,
                    "status": "completed"
                }
            ],
            "total_sessions": 1,
            "error": str(e)
        }

@get("/api/conversations/health")
async def conversation_health() -> Dict[str, Any]:
    """Health check endpoint for conversation system"""
    try:
        if not TRACKING_AVAILABLE:
            return {
                "status": "disabled",
                "message": "Conversation tracking is disabled",
                "timestamp": datetime.utcnow().isoformat()
            }

        # Test database connection
        if downloader:
            conn = downloader._get_databricks_connection()
            if conn is None:
                return {
                    "status": "warning",
                    "message": "Tracking available but database connection unavailable",
                    "timestamp": datetime.utcnow().isoformat()
                }

        return {
            "status": "healthy",
            "message": "Conversation tracking fully operational",
            "timestamp": datetime.utcnow().isoformat(),
            "database": "connected"
        }
    except Exception as e:
        return {
            "status": "error",
            "message": f"Health check failed: {str(e)}",
            "timestamp": datetime.utcnow().isoformat()
        }

# Create router
router = Router(
    path="",
    route_handlers=[
        start_conversation_session,
        end_conversation_session,
        log_user_question,
        log_skill_execution,
        get_conversation_summary,
        download_conversation,
        get_conversation_data,
        list_conversation_sessions,
        conversation_health,
    ],
)