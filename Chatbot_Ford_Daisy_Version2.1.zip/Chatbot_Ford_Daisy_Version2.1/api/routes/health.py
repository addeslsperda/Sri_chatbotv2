"""
Health check endpoint
"""
from litestar import Router, get
from datetime import datetime, timezone


@get("/health")
async def health_check() -> dict:
    """Health check endpoint."""
    return {
        "status": "healthy",
        "service": "Ford Analytics API",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "version": "1.0.0"
    }


# Create router
router = Router(path="", route_handlers=[health_check])
