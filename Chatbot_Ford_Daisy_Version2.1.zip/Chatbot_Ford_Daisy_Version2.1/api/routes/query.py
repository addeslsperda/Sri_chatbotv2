"""
Natural language query endpoint - the heart of Daisy chatbot.

This endpoint:
1. Routes natural language questions to appropriate skills
2. Executes the skills
3. Formats results into conversational responses using Claude LLM
4. Tracks conversations and skill executions to Databricks tables
"""
import asyncio
import json
import sys
import time
from pathlib import Path
from collections.abc import AsyncGenerator

from litestar import Router, post
from litestar.response import Stream

from api.models import QueryRequest, QueryResponse
from api.services import router_service, executor_service, llm_formatter_service
from api.utils.logger import api_logger
from api.utils.errors import RoutingError, SkillNotFoundError, SkillExecutionError

# Add conversation tracking
sys.path.append(str(Path(__file__).resolve().parents[2] / 'tracking'))

try:
    from conversation_tracker import conversation_tracker
    TRACKING_AVAILABLE = True
    api_logger.info("Conversation tracking enabled")
except ImportError as e:
    TRACKING_AVAILABLE = False
    api_logger.warning(f"Conversation tracking disabled: {e}")


def _router_history(chat_history: list) -> list:
    """Convert ChatTurn list to the dict format IntelligentRouterV2 expects."""
    return [
        {
            "question": t.question,
            "agent":    t.agent_used or "",
            "skill":    t.skill_used or "",
            "params":   t.params or {}
        }
        for t in chat_history[-5:]
    ]


def _formatter_context(chat_history: list) -> str | None:
    """Build a rich conversation context string for the LLM formatter.

    Last 2 turns: full answers + metadata.
    Older turns (3-5): compressed to question + key params only.
    This limits context bloat while preserving what the formatter needs.
    """
    if not chat_history:
        return None

    recent = chat_history[-5:]
    cutoff = max(0, len(recent) - 2)  # last 2 turns get full text
    parts = []

    for i, t in enumerate(recent):
        meta = []
        if t.agent_used:
            meta.append(t.agent_used.replace("_agent", "").replace("_", " ").title())
        if t.skill_used:
            meta.append(t.skill_used.replace("_", " "))
        if t.params:
            relevant = {k: v for k, v in (t.params or {}).items()
                        if k in ("date_from", "date_to", "vehicle", "keyword", "search_term")}
            if relevant:
                meta.append(f"params={relevant}")

        if i < cutoff:
            # Compressed: question + metadata only (no full answer)
            meta_str = f" [{' | '.join(meta)}]" if meta else ""
            parts.append(f"User: {t.question}{meta_str}")
            if t.answer:
                # First 400 chars to preserve the key finding
                snippet = t.answer[:400].rsplit(' ', 1)[0] + "…" if len(t.answer) > 400 else t.answer
                parts.append(f"Daisy: {snippet}")
        else:
            # Full: question + metadata + complete answer
            parts.append(f"User: {t.question}")
            if meta:
                parts.append(f"[{' | '.join(meta)}]")
            parts.append(f"Daisy: {t.answer}")
        parts.append("")

    return "\n".join(parts).strip()


@post("/api/query")
async def query_endpoint(data: QueryRequest) -> QueryResponse:
    """
    Natural language query endpoint for Daisy chatbot.

    Process:
    1. Route question to appropriate agent/skill using intelligent router
    2. Execute the skill with user parameters
    3. Format result into conversational response using Claude LLM
    4. Return both formatted answer and raw data

    Args:
        data: Query request containing:
            - question: Natural language question from user
            - date_from: Optional start date filter (YYYY-MM-DD)
            - date_to: Optional end date filter (YYYY-MM-DD)
            - chat_history: Optional list of previous ChatTurn objects for context

    Returns:
        Query response containing:
            - question: Original question
            - answer: Natural language formatted answer (from Claude)
            - data: Raw JSON data from skill execution
            - agent_used: Which agent handled the query
            - skill_used: Which skill was executed
            - confidence: Router confidence score

    Raises:
        RoutingError: If question cannot be routed to any skill (400)
        SkillNotFoundError: If routed skill doesn't exist (404)
        SkillExecutionError: If skill execution fails (500)
    """
    api_logger.info(
        f"Received query: '{data.question}' "
        f"(history_turns={len(data.chat_history)}, "
        f"date_from={data.date_from}, date_to={data.date_to})"
    )

    # Start timing for tracking
    start_time = time.time()
    session_id = data.session_id if hasattr(data, 'session_id') else None

    # Build context objects once — reused by both router and formatter
    router_history   = _router_history(data.chat_history)
    formatter_context = _formatter_context(data.chat_history)

    try:
        # Step 1: Route the question to appropriate agent/skill
        #         Pass chat history so Stage1+Stage2 can consider conversation context
        route = router_service.route(data.question, chat_history=router_history)

        agent_name = route['agent']
        skill_name = route['skill']
        confidence = route.get('confidence', 0.0)

        # Smalltalk: no skill execution needed — respond directly
        # routing_reason is passed so the formatter can distinguish
        # knowledge_gap (out-of-scope analytics) from greetings/system questions
        if agent_name == "smalltalk":
            routing_reason = route.get("reason", "")
            is_knowledge_gap = routing_reason.lower().startswith("knowledge_gap")
            answer = llm_formatter_service.format(
                result={
                    "message": "knowledge_gap" if is_knowledge_gap else "smalltalk",
                    "question": data.question,
                    "routing_reason": routing_reason
                },
                question=data.question,
                agent_used="smalltalk",
                skill_used="respond",
                conversation_context=formatter_context,
                page_context=data.page_context
            )
            return QueryResponse(
                question=data.question,
                answer=answer,
                data={"message": "smalltalk"},
                agent_used="smalltalk",
                skill_used="respond",
                confidence=float(confidence)
            )

        api_logger.info(
            f"Routed to {agent_name}/{skill_name} (confidence: {confidence:.2%})"
        )

        # Step 2: Prepare parameters (merge user params with route defaults)
        user_params = {}
        if data.date_from:
            user_params['date_from'] = data.date_from
        if data.date_to:
            user_params['date_to'] = data.date_to

        api_logger.debug(f"user_params={user_params}  route_params={route.get('params', {})}")

        # Step 3: Execute the skill
        # Catch execution errors and let the formatter respond gracefully
        # (better UX than a raw 500 — lets Claude explain what went wrong)
        try:
            result = executor_service.execute(route, user_params)
            api_logger.info(
                f"Skill executed successfully, returned {len(result)} data keys"
            )
        except SkillExecutionError as exec_err:
            # Pass error into formatter so Claude can give a conversational response
            error_detail = str(exec_err.detail)
            api_logger.warning(f"Skill execution error caught, routing to formatter: {error_detail}")
            result = {
                "error": error_detail,
                "agent": agent_name,
                "skill": skill_name,
                "params_used": route.get("params", {})
            }

        # Step 4: Format the result into conversational response using Claude LLM
        #         Pass conversation context so Daisy can reference prior turns
        answer = llm_formatter_service.format(
            result=result,
            question=data.question,
            agent_used=agent_name,
            skill_used=skill_name,
            conversation_context=formatter_context,
            current_params=route.get("params"),
            page_context=data.page_context
        )

        api_logger.info(
            f"Response formatted successfully ({len(answer)} characters)"
        )

        # Step 5: Track the conversation and skill execution
        response_time = time.time() - start_time

        if TRACKING_AVAILABLE:
            try:
                # Log the user question
                conversation_tracker.log_user_question(
                    question_text=data.question,
                    session_id=session_id,
                    agent_type=agent_name,
                    skill_used=skill_name,
                    response_status="success",
                    response_time=response_time
                )

                # Log the skill execution
                conversation_tracker.log_skill_execution(
                    session_id=session_id,
                    agent_type=agent_name,
                    skill_name=skill_name,
                    execution_status="success",
                    duration_seconds=response_time,
                    input_parameters={
                        "date_from": data.date_from,
                        "date_to": data.date_to,
                        "question": data.question
                    },
                    records_returned=len(result.get('data', [])) if isinstance(result.get('data'), list) else None
                )

                api_logger.info(f"Conversation tracked: session_id={session_id}, agent={agent_name}, skill={skill_name}")

            except Exception as track_error:
                api_logger.warning(f"Failed to track conversation: {track_error}")

        # Step 6: Return the complete response
        return QueryResponse(
            question=data.question,
            answer=answer,
            data=result,
            agent_used=agent_name,
            skill_used=skill_name,
            confidence=confidence,
            params=route.get("params")
        )

    except (RoutingError, SkillNotFoundError, SkillExecutionError) as e:
        # Track failed queries
        if TRACKING_AVAILABLE:
            try:
                response_time = time.time() - start_time
                error_agent = getattr(e, 'agent', 'unknown')
                error_skill = getattr(e, 'skill', 'unknown')

                conversation_tracker.log_user_question(
                    question_text=data.question,
                    session_id=session_id,
                    agent_type=error_agent,
                    skill_used=error_skill,
                    response_status="error",
                    response_time=response_time
                )

                conversation_tracker.log_skill_execution(
                    session_id=session_id,
                    agent_type=error_agent,
                    skill_name=error_skill,
                    execution_status="error",
                    duration_seconds=response_time,
                    error_message=str(e)
                )
            except Exception as track_error:
                api_logger.warning(f"Failed to track error: {track_error}")

        # Re-raise known errors (they have proper HTTP status codes)
        raise
    except Exception as e:
        # Track unexpected errors
        if TRACKING_AVAILABLE:
            try:
                response_time = time.time() - start_time
                conversation_tracker.log_user_question(
                    question_text=data.question,
                    session_id=session_id,
                    response_status="error",
                    response_time=response_time
                )
            except Exception as track_error:
                api_logger.warning(f"Failed to track unexpected error: {track_error}")

        # Catch any unexpected errors
        api_logger.error(f"Unexpected error in query endpoint: {str(e)}", exc_info=True)
        raise SkillExecutionError("unknown", "unknown", str(e))


def _sse(event: str, data: dict) -> bytes:
    """Encode a single SSE message."""
    return f"event: {event}\ndata: {json.dumps(data)}\n\n".encode()


@post("/api/query/stream", media_type="text/event-stream")
async def query_stream_endpoint(data: QueryRequest) -> Stream:
    """
    Streaming version of /api/query that emits SSE progress events.

    Events emitted (in order):
      status  {stage: "routing",    message: "..."}
      status  {stage: "routed",     message: "...", agent, skill}
      status  {stage: "executing",  message: "..."}
      status  {stage: "formatting", message: "..."}
      result  {question, answer, data, agent_used, skill_used, confidence}
      error   {message: "..."}   (only on failure)
    """
    router_history    = _router_history(data.chat_history)
    formatter_context = _formatter_context(data.chat_history)

    # Initialize tracking for streaming endpoint
    start_time = time.time()
    session_id = data.session_id if hasattr(data, 'session_id') else None

    async def generate() -> AsyncGenerator[bytes, None]:
        try:
            # ── Stage 1: Routing ────────────────────────────────────────
            yield _sse("status", {"stage": "routing", "message": "Doodling circles while I figure this out…"})

            route = await asyncio.to_thread(
                router_service.route, data.question, router_history
            )

            agent_name = route["agent"]
            skill_name = route["skill"]
            confidence = route.get("confidence", 0.0)

            # ── Stage 2: Smalltalk fast-path ────────────────────────────
            if agent_name == "smalltalk":
                yield _sse("status", {"stage": "formatting", "message": "Almost there… just stapling the pages together…"})
                answer = await asyncio.to_thread(
                    llm_formatter_service.format,
                    {"message": "smalltalk", "question": data.question},
                    data.question, "smalltalk", "respond", formatter_context,
                    None, data.page_context
                )
                yield _sse("result", {
                    "question": data.question, "answer": answer,
                    "data": {"message": "smalltalk"},
                    "agent_used": "smalltalk", "skill_used": "respond",
                    "confidence": float(confidence)
                })
                return

            # Human-readable labels
            agent_label = agent_name.replace("_agent", "").replace("_", " ").title()
            yield _sse("status", {
                "stage": "routed",
                "message": f"Waving the {agent_label} Agent over — they're already running!",
                "agent": agent_name,
                "skill": skill_name,
            })
            # Brief pause so the "routed" stage (and its agent chip) is actually
            # visible to the client instead of being instantly overwritten by
            # the next event. Timing only — no wording changed.
            await asyncio.sleep(0.7)

            # ── Stage 3: Execute skill ──────────────────────────────────
            yield _sse("status", {
                "stage": "executing",
                "message": "Crunching so hard you can hear it…",
            })

            user_params: dict = {}
            if data.date_from:
                user_params["date_from"] = data.date_from
            if data.date_to:
                user_params["date_to"] = data.date_to

            result = await asyncio.to_thread(executor_service.execute, route, user_params)

            # ── Stage 4: LLM formatting ─────────────────────────────────
            yield _sse("status", {"stage": "formatting", "message": "Almost there… just stapling the pages together…"})

            answer = await asyncio.to_thread(
                llm_formatter_service.format,
                result, data.question, agent_name, skill_name, formatter_context,
                route.get("params"), data.page_context
            )

            # ── Track conversation and skill execution ──────────────────
            if TRACKING_AVAILABLE:
                try:
                    response_time = time.time() - start_time

                    # Log the user question
                    conversation_tracker.log_user_question(
                        question_text=data.question,
                        session_id=session_id,
                        agent_type=agent_name,
                        skill_used=skill_name,
                        response_status="success",
                        response_time=response_time
                    )

                    # Log the skill execution
                    conversation_tracker.log_skill_execution(
                        session_id=session_id,
                        agent_type=agent_name,
                        skill_name=skill_name,
                        execution_status="success",
                        duration_seconds=response_time,
                        input_parameters={
                            "date_from": data.date_from,
                            "date_to": data.date_to,
                            "question": data.question
                        },
                        records_returned=len(result.get('data', [])) if isinstance(result.get('data'), list) else None
                    )

                    api_logger.info(f"Streaming conversation tracked: session_id={session_id}, agent={agent_name}, skill={skill_name}")

                except Exception as track_error:
                    api_logger.warning(f"Failed to track streaming conversation: {track_error}")

            # ── Done ────────────────────────────────────────────────────
            yield _sse("result", {
                "question": data.question,
                "answer": answer,
                "data": result,
                "agent_used": agent_name,
                "skill_used": skill_name,
                "confidence": float(confidence),
                "params": route.get("params"),
            })

        except Exception as exc:
            # Track streaming errors
            if TRACKING_AVAILABLE:
                try:
                    response_time = time.time() - start_time
                    conversation_tracker.log_user_question(
                        question_text=data.question,
                        session_id=session_id,
                        response_status="error",
                        response_time=response_time
                    )
                except Exception as track_error:
                    api_logger.warning(f"Failed to track streaming error: {track_error}")

            api_logger.error(f"Streaming query error: {exc}", exc_info=True)
            yield _sse("error", {"message": str(exc)})

    return Stream(generate(), media_type="text/event-stream", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


# Create router
router = Router(path="", route_handlers=[query_endpoint, query_stream_endpoint])
