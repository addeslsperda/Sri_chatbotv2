"""
Enhanced Natural Language Query Endpoint
Supports multi-agent routing and orchestration
More accurate routing with scoring system
"""
from litestar import Router, post
from litestar.exceptions import HTTPException
from pydantic import BaseModel
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from core.agents.skill_executor import SkillExecutor
from core.agents.intelligent_router import IntelligentRouter


class QueryRequest(BaseModel):
    """Natural language query request."""
    question: str
    date_from: str | None = None
    date_to: str | None = None
    max_agents: int = 3  # Maximum number of agents to call


class AgentResult(BaseModel):
    """Result from a single agent/skill."""
    agent: str
    skill: str
    success: bool
    data: dict | None = None
    error: str | None = None
    confidence: float


class QueryResponse(BaseModel):
    """Enhanced query response with multi-agent support."""
    question: str
    answer: str
    results: list[AgentResult]
    agents_used: list[str]
    skills_used: list[str]
    routing_explanation: str


@post("/api/query/enhanced")
async def enhanced_query_endpoint(data: QueryRequest) -> QueryResponse:
    """
    Enhanced natural language query endpoint.

    Features:
    - Multi-agent routing
    - Confidence scoring
    - Orchestrated execution
    - Combined results

    Args:
        data: Query request

    Returns:
        Combined results from multiple agents
    """
    # Step 1: Route question to agent(s)
    router = IntelligentRouter(use_llm=False)  # Set to True when LLM is integrated
    routes = router.route(data.question)

    # Limit to max_agents
    routes = routes[:data.max_agents]

    # Step 2: Build parameters
    params_base = {}
    if data.date_from:
        params_base["date_from"] = data.date_from
    if data.date_to:
        params_base["date_to"] = data.date_to

    # Step 3: Execute each route
    executor = SkillExecutor(Path(__file__).parent.parent.parent)
    results = []

    for route in routes:
        # Merge route params with user params
        params = {**route["params"], **params_base}

        try:
            result_data = executor.execute_skill(
                agent_name=route["agent"],
                skill_name=route["skill"],
                params=params
            )

            results.append(AgentResult(
                agent=route["agent"],
                skill=route["skill"],
                success=True,
                data=result_data,
                error=None,
                confidence=route.get("confidence", 0)
            ))

        except Exception as e:
            results.append(AgentResult(
                agent=route["agent"],
                skill=route["skill"],
                success=False,
                data=None,
                error=str(e),
                confidence=route.get("confidence", 0)
            ))

    # Step 4: Generate combined answer
    successful_results = [r for r in results if r.success]

    if not successful_results:
        answer = "No results found"
    elif len(successful_results) == 1:
        # Single result
        result = successful_results[0]
        data_dict = result.data or {}

        if "lemon_candidates" in data_dict:
            answer = f"Found {len(data_dict['lemon_candidates'])} lemon law candidates"
        elif "emerging_issues" in data_dict:
            answer = f"Found {len(data_dict['emerging_issues'])} emerging issues"
        elif "dealers" in data_dict:
            answer = f"Analyzed {len(data_dict['dealers'])} dealers"
        elif "serial_callers" in data_dict:
            answer = f"Found {len(data_dict['serial_callers'])} serial callers"
        else:
            answer = "Analysis complete"
    else:
        # Multiple results - combine insights
        insights = []
        for result in successful_results:
            data_dict = result.data or {}

            if "lemon_candidates" in data_dict:
                insights.append(f"{len(data_dict['lemon_candidates'])} lemon candidates")
            elif "emerging_issues" in data_dict:
                insights.append(f"{len(data_dict['emerging_issues'])} emerging issues")
            elif "dealers" in data_dict:
                insights.append(f"{len(data_dict['dealers'])} dealers analyzed")
            elif "sentiment_breakdown" in data_dict:
                insights.append("sentiment analysis")
            elif "escalation_breakdown" in data_dict:
                insights.append(f"{len(data_dict['escalation_breakdown'])} escalation types")

        answer = f"Multi-agent analysis: {', '.join(insights)}"

    # Step 5: Build response
    agents_used = [r.agent for r in successful_results]
    skills_used = [r.skill for r in successful_results]

    routing_explanation = "; ".join([
        f"{r['agent']}/{r['skill']} (confidence: {r.get('confidence', 0)})"
        for r in routes
    ])

    return QueryResponse(
        question=data.question,
        answer=answer,
        results=results,
        agents_used=agents_used,
        skills_used=skills_used,
        routing_explanation=routing_explanation
    )


# Create router
router = Router(path="", route_handlers=[enhanced_query_endpoint])
