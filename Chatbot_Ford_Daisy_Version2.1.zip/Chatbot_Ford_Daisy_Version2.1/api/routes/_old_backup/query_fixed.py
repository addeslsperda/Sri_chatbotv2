"""
Natural language query endpoint
Routes questions to appropriate agent/skill using ScalableRouter
"""
from litestar import Router, post
from litestar.exceptions import HTTPException
from pydantic import BaseModel
from pathlib import Path
import sys
import importlib

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from core.agents.skill_executor import SkillExecutor


class QueryRequest(BaseModel):
    """Natural language query request."""
    question: str
    date_from: str | None = None
    date_to: str | None = None


class QueryResponse(BaseModel):
    """Query response."""
    answer: str
    data: dict | None = None
    agent_used: str
    skill_used: str


def get_routing_decision(question: str):
    """
    Get routing decision directly from intelligent router.
    Creates fresh instance each time to avoid module caching issues.
    """
    # Force reload the module
    if 'core.agents.intelligent_router' in sys.modules:
        importlib.reload(sys.modules['core.agents.intelligent_router'])

    from core.agents.intelligent_router import IntelligentRouter

    router = IntelligentRouter(use_llm=True)  # ENABLED: LLM routing for 85%+ accuracy
    routes = router.route(question)

    if not routes:
        return None

    # Return top route
    return routes[0]


def generate_detailed_answer(result: dict, question: str) -> str:
    """Generate detailed natural language answer from results."""

    # Emerging Issues
    if 'emerging_issues' in result:
        issues = result.get('emerging_issues', [])
        insights = result.get('insights', {})
        date_range = result.get('date_range', '')
        comparison = result.get('comparison_period', '')
        total_current = result.get('total_current_calls', 0)

        if not issues:
            return f"No significant emerging issues detected between {date_range} (compared to {comparison})."

        answer_parts = [
            f"EMERGING ISSUES ANALYSIS ({date_range})",
            f"\nAnalyzed {total_current:,} calls compared to baseline period ({comparison})\n",
            f"Found {len(issues)} emerging issues:\n"
        ]

        for i, issue in enumerate(issues[:5], 1):  # Top 5
            issue_name = issue.get('issue', 'Unknown')
            current = issue.get('current_calls', 0)
            baseline = issue.get('baseline_calls', 0)
            spike = issue.get('spike_pct', 0)
            net = issue.get('net_increase', 0)
            velocity = issue.get('velocity', 'medium')
            sentiment = issue.get('avg_sentiment', 0)

            velocity_icon = {
                'critical': '[CRITICAL]',
                'high': '[HIGH]',
                'medium': '[MEDIUM]',
                'low': '[LOW]'
            }.get(velocity, '')

            answer_parts.append(
                f"{i}. {velocity_icon} {issue_name.upper()}\n"
                f"   • Current period: {current} calls | Baseline: {baseline} calls\n"
                f"   • Spike: +{spike:.1f}% ({net:+d} calls)\n"
                f"   • Velocity: {velocity} | Sentiment: {sentiment:.2f}\n"
            )

        # Add insights
        if insights:
            answer_parts.append(f"\nKEY INSIGHTS:")
            if insights.get('highest_spike'):
                answer_parts.append(f"   • Highest spike: {insights['highest_spike']}")
            if insights.get('fastest_velocity'):
                answer_parts.append(f"   • Fastest growth: {insights['fastest_velocity']}")
            if insights.get('critical_issues', 0) > 0:
                answer_parts.append(f"   • [WARNING] {insights['critical_issues']} CRITICAL issues requiring immediate action")

        return "\n".join(answer_parts)

    # Lemon Law Candidates
    elif 'lemon_candidates' in result:
        candidates = result.get('lemon_candidates', [])
        insights = result.get('insights', {})

        if not candidates:
            return "No lemon law candidates found with the specified criteria."

        answer_parts = [
            f"LEMON LAW ANALYSIS\n",
            f"Found {len(candidates)} vehicles with multiple calls:\n"
        ]

        for i, vehicle in enumerate(candidates[:5], 1):
            vin = vehicle.get('vin_masked', 'N/A')
            model = vehicle.get('vehicle', 'Unknown')
            calls = vehicle.get('call_count', 0)
            sentiment = vehicle.get('avg_sentiment', 0)
            escalated = vehicle.get('escalated', False)
            buyback = vehicle.get('buyback_requested', False)

            status_icons = []
            if buyback:
                status_icons.append('[BUYBACK]')
            if escalated:
                status_icons.append('[ESCALATED]')

            status = ' | '.join(status_icons) if status_icons else ''

            if status:
                answer_parts.append(
                    f"{i}. VIN {vin} ({model})\n"
                    f"   • {calls} calls | Sentiment: {sentiment:.2f}\n"
                    f"   • {status}\n"
                )
            else:
                answer_parts.append(
                    f"{i}. VIN {vin} ({model})\n"
                    f"   • {calls} calls | Sentiment: {sentiment:.2f}\n"
                )

        if insights.get('buyback_requested_count'):
            answer_parts.append(f"\n[WARNING] {insights['buyback_requested_count']} vehicles with buyback requests")

        return "\n".join(answer_parts)

    # Topic Trends
    elif 'phrase_topics' in result:
        topics = result.get('phrase_topics', [])[:10]
        total = result.get('total_calls', 0)

        if not topics:
            return "No topics found for the specified period."

        answer_parts = [
            f"TOP ISSUES ANALYSIS\n",
            f"Total calls analyzed: {total:,}\n",
            f"Top 10 issues:\n"
        ]

        for i, topic in enumerate(topics, 1):
            # Handle both old field names (phrase/phrase_count) and new (topic/call_count)
            phrase = topic.get('topic') or topic.get('phrase', 'Unknown')
            count = topic.get('call_count') or topic.get('phrase_count', 0)
            pct = topic.get('pct_of_calls') or topic.get('percentage', 0)

            # Progress bar
            bar_length = int(pct / 5)  # 20 chars max (100% / 5)
            bar = '#' * bar_length

            answer_parts.append(
                f"{i:2}. {phrase:40} {count:6,} ({pct:5.1f}%) {bar}"
            )

        return "\n".join(answer_parts)

    # Team/Operations Data
    elif 'teams' in result or 'results' in result:
        teams = result.get('teams') or result.get('results', [])

        if not teams:
            return "No team data found."

        answer_parts = [
            f"TEAM PERFORMANCE ANALYSIS\n",
            f"Analyzed {len(teams)} teams:\n"
        ]

        for i, team in enumerate(teams[:10], 1):
            name = team.get('team', 'Unknown')
            calls = team.get('call_count', 0)
            answer_parts.append(f"{i:2}. {name:50} {calls:6,} calls")

        return "\n".join(answer_parts)

    # Positive Feedback
    elif 'positive_examples' in result:
        examples = result.get('positive_examples', [])

        if not examples:
            return "No positive feedback found for the specified period."

        answer_parts = [
            f"POSITIVE FEEDBACK ANALYSIS\n",
            f"Found {len(examples)} positive themes:\n"
        ]

        for i, ex in enumerate(examples[:5], 1):
            theme = ex.get('theme', 'Unknown')
            count = ex.get('count', 0)
            answer_parts.append(f"{i}. {theme} ({count} mentions)")

        return "\n".join(answer_parts)

    # Escalations
    elif 'escalations' in result:
        esc = result.get('escalations', {})
        total = sum(esc.values()) if isinstance(esc, dict) else 0

        answer_parts = [
            f"ESCALATION ANALYSIS\n",
            f"Total escalations: {total:,}\n",
            f"Breakdown:\n"
        ]

        for esc_type, count in esc.items():
            answer_parts.append(f"  • {esc_type:20} {count:5,} cases")

        return "\n".join(answer_parts)

    # Generic fallback
    else:
        return "Analysis complete"


@post("/api/query")
async def query_endpoint(data: QueryRequest) -> QueryResponse:
    """
    Natural language query endpoint with scalable routing.

    Args:
        data: Query request with question and optional date range

    Returns:
        Query response with answer and data
    """
    # Get routing decision
    route = get_routing_decision(data.question)

    if not route:
        raise HTTPException(
            status_code=400,
            detail="Could not route question to any skill"
        )

    agent_name = route["agent"]
    skill_name = route["skill"]

    # Build parameters - merge route params with request params
    params = route.get("params", {}).copy()
    if data.date_from:
        params["date_from"] = data.date_from
    if data.date_to:
        params["date_to"] = data.date_to

    # Execute skill
    executor = SkillExecutor(Path(__file__).parent.parent.parent)

    try:
        result = executor.execute_skill(
            agent_name=agent_name,
            skill_name=skill_name,
            params=params
        )

        # Generate natural language answer based on result type
        answer = generate_detailed_answer(result, data.question)

        return QueryResponse(
            answer=answer,
            data=result,
            agent_used=agent_name,
            skill_used=skill_name
        )

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Skill execution failed: {str(e)}"
        )


# Create router
router = Router(path="", route_handlers=[query_endpoint])
