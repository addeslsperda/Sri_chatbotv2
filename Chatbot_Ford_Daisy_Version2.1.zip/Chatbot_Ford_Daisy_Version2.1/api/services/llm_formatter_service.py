"""
LLM-based formatter service using Claude API.
Converts raw JSON results into natural, conversational responses.
"""
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from core.llm_client.claude_client import get_client
from api.utils.logger import api_logger


# Per-skill formatting hints injected into every formatter prompt.
# Tells Daisy HOW to structure the output for each specific skill
# so responses are specific rather than generic.
SKILL_HINTS: dict[str, str] = {
    # ── vehicle_agent ─────────────────────────────────────────────────────────
    "vin_history":          "Lead with lemon law candidates (if any), ranked by call count. Mask VINs to last 4 digits. Group by severity: strong_candidate -> monitoring -> normal. Show call count, avg sentiment, and primary issue per VIN.",
    "emerging_issues":      "Lead with the highest-spike issues. Show current vs baseline call counts and % change. Apply [CRITICAL] for spikes >100%, [WARNING] for >50%. Mention sentiment if negative.",
    "keyword_search": (
        "Lead with total matching calls and the keyword(s) searched. "
        "If total_calls is 0, DO NOT just say 'no data' — instead: (1) state the exact keyword searched, "
        "(2) suggest 2-3 alternative shorter or broader search terms the user could try "
        "(e.g. if 'ordering home chargers online' found nothing, suggest 'home charger', 'charging station', 'Ford Charge Station Pro'), "
        "(3) note that call data uses agent-written summaries which may use different phrasing. "
        "If results found: the 'by_vehicle' key contains a vehicle-level breakdown (modelvehicleline, call_count, negative_pct). "
        "ALWAYS present the by_vehicle breakdown — rank vehicles by call_count, show top 5-10 with their call counts and negative_pct. "
        "This is especially critical for follow-up questions asking 'which vehicles' or 'break down by vehicle'. "
        "Also include 2-3 example phrases if present in sample_negative_summary or sample_customer_voice."
    ),
    "vehicle_pain_points":  "Data in 'results' key (list). Each row: pain_point (string), call_count, pct_of_calls, avg_sentiment, negative_pct, avg_complexity, switching_pct, competitor_brands. Lead with vehicle name and total_calls. Rank by call_count. Highlight top pain points by call volume. Flag high switching_pct with [WARNING]. If avg_sentiment is very negative (<-0.3), note customer impact.",
    "topic_trends":         "Data is in 'critical_topics', 'high_impact_topics', and 'trending_topics' arrays. Each topic has: topic_hierarchy (level1, level2, level3), impact_level (CRITICAL/HIGH/MEDIUM/LOW), business_impact_score, call_count, pct_of_calls, metrics (avg_sentiment, negative_calls, negative_pct, avg_complexity, vehicles_affected). These are REAL TOPICS from topic_xwalk/topic_detail — present them as topic_level1 > topic_level2 (> topic_level3 if available). Lead with critical, then high-impact. Apply [CRITICAL]/[WARNING] tags. Show call count, pct_of_calls, and negative_pct per topic. summary_stats has total_calls_analyzed. If vehicle_filter is set, note which vehicle. These are TOPICS not pain points — present the topic hierarchy clearly.",
    "vehicle_examples":     "Data is in 'verbatims'. ALWAYS state total_verbatims_returned and negative_sentiment_pct BEFORE quoting any examples — frequency context is required. Present 3-5 call summaries (summary or transcript_excerpt fields). Show call date, vehicle, and the core complaint. Do not paraphrase. If search_method='fallback_traditional', note that results are keyword-matched. If follow_up_analysis exists, briefly summarise the parts or topic correlation.",
    "third_party_mentions": "Lead with total mention count and overall sentiment. Group detected issues by category. Note any safety or legal language patterns.",
    "vehicle_volume":       "If 'vehicles' key present (--by-model was used): rank by call_count, show top 10 models. If 'time_series' key present: show volume trend by period, note any spikes. 'metadata' shows filters and date range used. 'comparative_analysis' (if present) contains period-over-period change — lead with that if it exists. 'warnings' lists any data quality notes — surface these to the user.",
    "model_year_analysis":  "Compare model years side by side. Highlight which year has the most calls and worst sentiment. Show year-over-year trend if multiple years present.",
    "issue_breakdown":      "Data in 'pain_point_breakdown' (list of pain point categories). Each row has: pain_point, call_count, switching_count, avg_aht. 'summary' has total_calls_analyzed, total_brand_switching_cases, overall_switching_rate_pct, unique_pain_points. If 'related_parts_breakdown' exists, show top parts. Rank by call_count. Flag high switching_count with [WARNING]. If pain_point_breakdown is empty, say so and suggest running keyword_search or vehicle_pain_points instead.",
    "transcript_export":        "Daisy CAN export transcripts. Present 3-5 representative transcript excerpts from the data. Show date, vehicle, and sentiment. If CSV was requested, note the file was generated (check 'filename' key). If 'total_transcripts_returned' > 0, lead with the count and summarize key themes. If data contains 'full_transcript' or 'call_summary', quote relevant excerpts. NEVER say you cannot export transcripts — this skill does exactly that.",
    "data_discovery":           "Summarize date range available, total call count, and top vehicle models. Present as a quick data coverage overview — no more than 10 lines.",
    # ── operations_agent ──────────────────────────────────────────────────────
    "aht_analysis":             "Lead with overall AHT. 'metadata.filters' shows what was applied. 'aht_drivers' has top categories driving long handle times — always include if present. Show by team or vehicle if group_by was set. Flag groups >20% above average with [WARNING].",
    "temporal_comparison":      "Keys: 'comparison' (two periods), 'overall_metrics' (period1 vs period2: total_calls, avg_sentiment, avg_complexity, avg_aht, transfer_rate). Show absolute AND % change per metric with +/- signs. Lead with the most significant change. Include topic/team breakdowns if present.",
    "team_volume":              "Data in 'results' (list of rows). 'metadata.query_params.filters' shows applied filters. 'metadata.total_calls' is grand total. Rank results by total_calls. State clearly which filter slice was used (program, team, or location).",
    "team_routing_analysis":    "Key 'team_routing': each row has team, call_count, pct_of_topic, avg_aht, avg_complexity, transfer_rate. Lead with which team handles the most volume for the topic. Flag high transfer_rate teams with [WARNING]. Note if one team is dominant (>30% share).",
    "complexity_analysis":      "'complexity_drivers' lists categories driving high complexity. 'insights' has thresholds. Lead with Low/Medium/High % distribution. Show top 3 drivers by call count. Flag groups with >50% High complexity with [WARNING].",
    "callback_analysis":        "'callback_drivers' lists issues causing repeat calls. 'insights' has FCR rate. Lead with overall callback rate. Top 3 drivers by callback volume. Flag callback_rate >15% with [WARNING]. Note FCR improving or worsening trend.",
    "day_of_week":              "Lead with busiest day (volume) and hardest day (AHT). Show AHT and sentiment per day. Clearly contrast weekday vs weekend patterns. Flag days >20% above weekly AHT average with [WARNING].",
    "hour_of_day":              "Hourly breakdown (0-23). Lead with peak volume hour and highest AHT hour. Note staffing-critical windows. Flag hours >20% above daily AHT average with [WARNING].",
    "regional_analysis":        "Keys: 'metadata' and 'results'. Each row: region/location, call_count, avg_aht, avg_sentiment, avg_complexity. Rank by call_count. Flag regions with sentiment < -0.2 or AHT >25% above average. Note Canada/Lincoln/South America segments if present. Geographic outliers — states significantly above or below average.",
    "trend_analysis":           "'metadata.trend_period' is week/month/quarter. Shows period-over-period for volume, AHT, complexity, sentiment. Use [INCREASING]/[DECREASING]/[STABLE] per metric. Lead with steepest change. State if most recent period is better or worse than the prior-period average.",
    # ── sentiment_agent ───────────────────────────────────────────────────────
    "positive_feedback":        "Lead with what went well. Highlight specific vehicles, topics, or agent behaviors getting positive feedback. Use an upbeat but factual tone.",
    "sentiment_deep_dive":      "Break down sentiment by topic. Lead with the most negative drivers. Include 1-2 actual customer phrases per topic to ground the insight.",
    "agent_customer_sentiment": "Compare agent sentiment vs customer sentiment side by side. Highlight agents with the biggest gap. Note teams with consistently low scores.",
    "nps_trend":                "Lead with the current NPS score and trend direction. Show month-over-month change. Note any vehicles or topics correlated with NPS drops.",
    "sentiment_by_vehicle":     "Rank vehicles by sentiment score. Show which vehicles are improving vs declining. Apply [WARNING] to vehicles with sentiment below -0.3.",
    "resolution_analysis":      "Lead with overall FCR rate and trend. Show which vehicles/teams have the lowest FCR. Provide 1-2 example call types that most often require follow-up.",
    # ── flags_agent ───────────────────────────────────────────────────────────
    "escalation_tracking":      "Lead with total escalations and trend direction. Show top escalation phrases and which vehicles/teams are most affected. Apply [CRITICAL] if escalations are rising.",
    "flag_counts": (
        "IMPORTANT DATA NOTE: Boolean flags (recall_flag, buyback_flag, etc.) only exist in call_table for "
        "2023-2024 data. If total_calls=0 and the date range is 2025 or later, clearly tell the user: "
        "'Flag data is only available through end of 2024 — try querying January 2023 to December 2024.' "
        "Do NOT imply the data might exist but be categorized differently when the issue is simply that "
        "the date range has no flag data. If results ARE found: show flag counts with % of total calls "
        "flagged, top vehicles, and trend direction."
    ),
    "flag_trends":              "Show how each flag's frequency has changed over time. Use [INCREASING]/[DECREASING] tags. Lead with the fastest-rising flags.",
    "flag_examples":            "Show 3-5 concrete call examples for this flag. Include the actual escalation/flag phrase used, date, and vehicle.",
    "recall_analysis":          "Show recall-related call volume and top complaint types. Note any legal or safety language (NHTSA, VOQ, attorney, lemon law). Apply [CRITICAL] if buyback language is frequent.",
    # ── smalltalk ─────────────────────────────────────────────────────────────
    "respond": (
        "You are Daisy, an AI analytics assistant built for Ford's CRC (Customer Relationship Center) team. "
        "You help analysts and product managers explore customer call center data through natural language — no SQL or dashboards needed.\n\n"
        "What you can do:\n"
        "- Vehicle Issues: pain points by model, trending topics, emerging issues, transcript examples, keyword searches, semantic/conceptual search\n"
        "- Operations: call volume, AHT, team performance, transfers, peak hours, regional/geographic filters, temporal comparisons\n"
        "- Sentiment & NPS: customer satisfaction, positive feedback, defection risk, agent vs customer sentiment\n"
        "- Flags & Escalations: NHTSA, buyback, lemon law, recalls, VOQ, supervisor requests, escalation trends\n"
        "- BlueCruise: subscription issues, top problems, vehicle breakdowns, volume trends\n\n"
        "If 'Current page:' appears in System Context, use it to answer 'what page am I on' questions accurately.\n"
        "If the user sends a greeting or chit-chat: respond naturally like a knowledgeable colleague and invite an analytics question.\n"
        "If the Data field shows message='knowledge_gap': the user asked about something outside Daisy's current knowledge. "
        "Respond exactly like this: '\u274c I don't currently have knowledge about [topic from routing_reason or question]. "
        "This looks like a valid analytics question that isn't covered by my current dataset yet. "
        "I'll flag this as a knowledge gap request for our data team to prepare.\n\n"
        "In the meantime, the closest thing I can currently help with is:\n"
        "[list 2-3 specific alternative questions Daisy CAN answer that are related to the topic].'\n"
        "NEVER say 'I can't help with that' without offering specific alternatives.\n"
        "Never fabricate data. Never dump tables. Keep conversational replies concise."
    ),
    # ── bluecruise_agent ──────────────────────────────────────────────────────
    "call_volume":              "Data in 'data' (list of rows). Each row: call_count, complaint_pct, negative_pct, deactivation_calls, hardware_calls, total_calls. If insights.summary exists: lead with total_calls and complaint_pct trend. Show whether volume is growing or shrinking. Flag complaint_pct > 30% with [WARNING].",
    "top_issues":               "Data in 'data' key (list). Each row: issue/pain_point/reason dimension (depends on analysis_type), call_count, negative_pct, churn_rate. If insights.summary.crisis_issues > 0, flag with [CRITICAL]. Rank by call_count. Lead with the #1 issue and its churn risk. Use insights.recommendations if present.",
    "vehicle_breakdown":        "Data in 'data' key. Each row has: modelvehicleline, call_count, pct_of_total_calls, negative_pct, churn_rate, hardware_pct, vehicle_classification. Show [CRITICAL] for CRITICAL_VEHICLE, [WARNING] for HARDWARE_PRONE or CHURN_RISK. Rank by vehicle_priority_score if available, else call_count.",
    "vehicle_topics":           "Data in 'data' key. Shows topics per vehicle. Highlight vehicle-specific patterns that differ from fleet average. If comparing vehicles, show the biggest divergences.",
    "sentiment_trend":          "Data in 'data' key (time series). Each row: period, call_count, avg_sentiment_score (0=negative, 1=positive), negative_pct, negative_hardware_pct, negative_churn_pct. insights.summary has trend_direction. Show overall trend direction. Flag sentiment drops >5% MoM with [WARNING]. If negative_hardware_pct is high, call out hardware as a driver. If negative_churn_pct is high, flag churn risk.",
    "contact_volume_trend":     "Data in 'data' key (time series). Show week-over-week or month-over-month change. Use insights.insights for anomaly alerts if present. Flag accelerating volume with [WARNING].",
    "subscription_issues":      "Data in 'data' key. Each row: subscription_category, call_count, negative_pct, hardware_correlation_pct, billing_pct, angry_churn_calls, sample_hardware_issue, top_negative_topic. Lead with Deactivations category (REVENUE_CRITICAL — highest churn risk). Flag categories with hardware_correlation_pct > 20% with [WARNING]. Show sample_negative_feedback or top_pain_point if present.",
    "subscription_stage":       "Show distribution across subscription stages (trial, activation, billing, cancellation). Highlight stage with highest drop-off or issue concentration.",
    "call_examples":            "Data in 'examples' key. Present 3-5 representative BlueCruise call summaries. Show call_date, modelvehicleline, customer_voice, example_classification. Flag EXAMPLE_CHURN_RISK and EXAMPLE_HARDWARE_CRISIS with [WARNING]. Lead with the most negative examples. If insights.summary.total_examples exists, state it upfront.",
}


class LLMFormatterService:
    """
    LLM-based response formatter.

    Uses Claude to convert raw JSON skill results into natural, conversational
    Daisy responses. Per-skill hints in SKILL_HINTS ensure each skill type
    gets appropriately structured output rather than generic prose.

    This approach eliminates the need for hardcoded formatters and automatically
    handles all skill result types with contextual, conversational responses.
    """

    def __init__(self):
        """Initialize the LLM formatter (client created lazily on first use)."""
        self._client = None  # deferred — avoids crashing at startup if credentials missing
        api_logger.info("LLMFormatterService initialized (client will connect on first use)")

    @property
    def client(self):
        """Lazy-load the Claude client on first access."""
        if self._client is None:
            self._client = get_client()
            api_logger.info("LLMFormatterService: Claude client connected")
        return self._client

    def format(
        self,
        result: dict,
        question: str,
        agent_used: str,
        skill_used: str,
        conversation_context: str | None = None,
        current_params: dict | None = None,
        page_context: str | None = None
    ) -> str:
        """
        Format a skill result into a conversational Daisy response.

        Args:
            result: Raw JSON dict from skill execution
            question: Original user question
            agent_used: Which agent handled the query
            skill_used: Which skill was executed
            conversation_context: Optional prior conversation turns as plain text
            current_params: Params used for the current query (vehicle, dates, etc.)
            page_context: Current page/view the user is on (for "what page am I on?" queries)

        Returns:
            Natural language response string
        """
        try:
            system_prompt = self._build_system_prompt()
            user_prompt = self._build_user_prompt(
                result, question, agent_used, skill_used, conversation_context, current_params, page_context
            )

            response = self.client.complete(
                prompt=user_prompt,
                system_prompt=system_prompt,
                max_tokens=8096,
                temperature=0.3
            )

            api_logger.debug(f"Formatter produced {len(response)} chars for {agent_used}/{skill_used}")
            return response.strip()

        except Exception as e:
            api_logger.error(f"LLM formatting failed: {str(e)}", exc_info=True)
            return self._fallback_format(result, question)

    def _build_system_prompt(self) -> str:
        """Build the system prompt that defines Daisy's persona and style."""
        return """You are Daisy, an AI analytics assistant for Ford's CRC (Customer Relationship Center).
You help Ford product managers and call center analysts understand customer call data.

Your role:
- Provide clear, concise, actionable insights from call center data
- Use business language, not technical jargon
- Reference specific numbers and percentages from the data
- Highlight trends, anomalies, and actionable items
- Apply [WARNING] tags for concerning patterns, [CRITICAL] for urgent issues

Conversation awareness (critical):
- You have access to the full prior conversation under "# Previous Conversation"
- When answering a follow-up question, explicitly connect your answer to what was discussed before
- If the user says "those calls", "that vehicle", "same period", "of those" — refer back to the prior answer by name
- Never re-introduce context the user already knows from earlier in the conversation
- If the new data directly answers a question raised in a prior turn, say so explicitly
- Build on prior answers — do not repeat what was already stated unless asked

Answer quality (critical):
- Before writing your response, verify: does the retrieved data actually answer the question?
- If yes: lead with the direct answer, support with specific numbers.
- If the data is EMPTY (zero rows, zero counts, no records):
  1. State clearly that no results were found for the exact query.
  2. Suggest 2-3 alternative phrasings, broader date ranges, or related skills.
  3. If this seems like a valid topic, end with: "This may be a knowledge gap — I'll flag it for our data team to prepare coverage for [topic]."
- If the data partially answers: answer the part you can, then explicitly state what's missing.
- NEVER fabricate numbers or be vague ("several", "many") when actual numbers are in the data.
- If the data contains an 'error' key, interpret it for the user in plain English — never show raw error text:
  * 'required: --vehicle' -> Ask user to specify a vehicle name (e.g. F-150, Bronco, Mach-E).
  * 'required: --keyword' or 'required: --entity' -> Ask user to specify the keyword or brand name.
  * 'required: --from' or 'required: --to' -> Ask user to provide a date range.
  * Other errors -> Briefly explain what went wrong and how to re-ask.

Knowledge gap handling:
- If a topic is genuinely not tracked in the available data, say: "I don't currently have data on [specific topic]. If this is a priority, flag it as a knowledge gap request for our data team."
- Always pair a knowledge gap response with the closest available alternative.
- Example: "I don't have TPMS-specific data, but I can search for 'tire pressure' in call summaries, or show you general Bronco pain points."

Ford/Lincoln vehicle lineup: F-150, F-250, F-350, F-Series, Bronco, Bronco Sport, Explorer,
Expedition, Ranger, Maverick, Escape, Edge, Fusion, Transit, Transit Connect,
Mustang, Mustang Mach-E, F-150 Lightning, Navigator, Corsair, Nautilus, Aviator.

Always lead with the key finding, then support with data."""

    def _build_user_prompt(
        self,
        result: dict,
        question: str,
        agent_used: str,
        skill_used: str,
        conversation_context: str | None,
        current_params: dict | None = None,
        page_context: str | None = None
    ) -> str:
        """Build the user prompt with all necessary context."""
        prompt_parts = [
            "# User Question",
            f'"{question}"',
            "",
            "# System Context",
            f"Agent used: {agent_used}",
            f"Skill executed: {skill_used}",
        ]

        # Show exact params used — lets formatter say "for F-Series in June 2025"
        # instead of vague "in your requested period"
        if current_params:
            relevant = {k: v for k, v in current_params.items()
                        if v and k in ("date_from", "date_to", "vehicle", "keyword", "search_term",
                                       "flag", "group_by", "topic")}
            if relevant:
                prompt_parts.append(f"Query parameters: {json.dumps(relevant)}")

        # Page context — tells Daisy what the user is currently looking at
        if page_context:
            prompt_parts.append(f"Current page: {page_context}")

        prompt_parts.append("")

        # Add conversation context if available
        if conversation_context:
            prompt_parts.extend([
                "# Previous Conversation",
                conversation_context,
                ""
            ])

        # Inject per-skill formatting guidance if available
        hint = SKILL_HINTS.get(skill_used)
        if hint:
            prompt_parts.extend([
                "# Formatting Guidance for This Skill",
                hint,
                ""
            ])

        # Trim only skills that return raw transcript/example rows (can be 100+ items).
        # For analytics skills (trends, breakdowns, volumes) preserve all rows so
        # Claude sees the full dataset and can give complete, accurate answers.
        EXAMPLE_SKILLS = {"vehicle_examples", "transcript_export", "call_examples", "flag_examples", "vin_history"}
        MAX_EXAMPLE_ROWS = 5
        MAX_ANALYTICS_ROWS = 50  # enough for any reasonable breakdown

        trimmed_result = {}
        for k, v in result.items():
            if isinstance(v, list):
                limit = MAX_EXAMPLE_ROWS if skill_used in EXAMPLE_SKILLS else MAX_ANALYTICS_ROWS
                if len(v) > limit:
                    trimmed_result[k] = v[:limit]
                    trimmed_result[f"{k}_total_available"] = len(v)
                else:
                    trimmed_result[k] = v
            else:
                trimmed_result[k] = v

        # Add the data
        prompt_parts.extend([
            "# Data Retrieved",
            "```json",
            json.dumps(trimmed_result, indent=2, default=str),
            "```",
            "",
            "# Your Task",
            "Analyze the data above and answer the user's question. Requirements:",
            "1. FIRST check: does the retrieved data answer the question? If not, say so explicitly before anything else.",
            "2. Directly and completely answer what was asked — do not leave gaps.",
            "3. Follow the Formatting Guidance above for this specific skill type.",
            "4. If there is a Previous Conversation, connect this answer to it naturally.",
            "5. Use specific numbers and percentages from the data — never be vague.",
            "6. Add [WARNING] or [CRITICAL] tags where the data warrants it.",
            "7. If data is empty or zero: diagnose why, suggest alternatives, flag as knowledge gap if warranted.",
            "8. If the question asks about something not in this data: say so explicitly + offer the nearest available alternative.",
            "",
            "Generate your response now:"
        ])

        return "\n".join(prompt_parts)

    def _fallback_format(self, result: dict, question: str) -> str:
        """
        Simple fallback formatting if LLM call fails.
        Just presents key information in a basic readable format.
        """
        api_logger.warning("Using fallback formatter")

        if not result:
            return "No data was returned for your query."

        # Find the largest list or most relevant key
        main_data = None
        main_key = None

        for key, value in result.items():
            if isinstance(value, list) and value:
                if main_data is None or len(value) > len(main_data):
                    main_data = value
                    main_key = key

        if main_data:
            count = len(main_data)
            formatted_key = main_key.replace('_', ' ').title()
            return (
                f"Analysis complete: Found {count} {formatted_key}\n\n"
                "For detailed formatting, please ensure the Claude API is configured correctly."
            )

        keys = list(result.keys())
        return (
            f"Analysis complete. Retrieved data for: {', '.join(keys)}\n\n"
            "For detailed formatting, please ensure the Claude API is configured correctly."
        )


# Singleton instance
llm_formatter_service = LLMFormatterService()
