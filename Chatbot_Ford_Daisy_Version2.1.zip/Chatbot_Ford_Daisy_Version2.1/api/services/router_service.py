"""
Router service - routes user questions to appropriate agent/skill.
Uses the config-driven two-stage IntelligentRouterV2 with AGENT.md auto-discovery.
"""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from core.agents.intelligent_router_v2 import IntelligentRouterV2
from api.utils.logger import api_logger
from api.utils.errors import RoutingError


class RouterService:
    """
    Service that routes natural language questions to appropriate agent/skill combinations.

    Wraps IntelligentRouterV2 (config-driven two-stage LLM routing) with:
    - Clean single-route API interface (query.py expects a dict, not a list)
    - Logging for observability
    - Graceful error handling with keyword fallback
    """

    def __init__(self, use_llm: bool = True):
        self.router = IntelligentRouterV2(use_llm=use_llm)
        self.use_llm = use_llm
        api_logger.info(
            f"RouterService initialized with IntelligentRouterV2 "
            f"(use_llm={use_llm}, agents={list(self.router.agents.keys())})"
        )

    def route(self, question: str, chat_history: list = None) -> dict:
        """
        Route a user question to the most appropriate agent and skill.

        Args:
            question: User's natural language question
            chat_history: Optional list of recent Q&A pairs for context

        Returns:
            Route dictionary:
                - agent: Agent name (e.g. "vehicle_agent")
                - skill: Skill name (e.g. "emerging_issues")
                - params: Parameters for the skill (includes date defaults)
                - confidence: Confidence score (0-5)
                - reason: Why this route was chosen

        Raises:
            RoutingError: If no suitable route can be found
        """
        api_logger.info(f"Routing question: '{question}'")

        try:
            routes = self.router.route(question, chat_history=chat_history)

            if not routes:
                api_logger.warning(f"No routes found for: '{question}'")
                raise RoutingError(question)

            top_route = routes[0]

            api_logger.info(
                f"Routed to {top_route['agent']}/{top_route['skill']} "
                f"(confidence: {top_route.get('confidence', 0)}/5, "
                f"reason: {top_route.get('reason', '')})"
            )

            return top_route

        except RoutingError:
            # Re-raise routing errors as-is
            raise
        except Exception as e:
            # Wrap unexpected errors
            api_logger.error(f"Routing failed with error: {str(e)}", exc_info=True)
            raise RoutingError(question)

    def reload(self):
        """Reload all AGENT.md configs from disk without restarting the server."""
        self.router.reload()
        api_logger.info(f"Router reloaded — agents: {list(self.router.agents.keys())}")

    def route_multiple(self, question: str, max_routes: int = 3, chat_history: list = None) -> list:
        """
        Get multiple routing suggestions for a question.

        Useful for:
        - Multi-agent queries
        - Showing alternative interpretations
        - Confidence comparison

        Args:
            question: User's natural language question
            max_routes: Maximum number of routes to return

        Returns:
            List of route dictionaries, sorted by confidence (highest first)
        """
        api_logger.info(f"Getting multiple routes (max={max_routes}) for: '{question}'")

        try:
            routes = self.router.route(question, chat_history=chat_history)

            if not routes:
                api_logger.warning(f"No routes found for: '{question}'")
                return []

            limited = routes[:max_routes]
            for i, r in enumerate(limited, 1):
                api_logger.debug(f"  {i}. {r['agent']}/{r['skill']} (confidence: {r.get('confidence', 0)}/5)")

            return limited

        except Exception as e:
            api_logger.error(f"Multi-route failed with error: {str(e)}", exc_info=True)
            return []


# Singleton instance
router_service = RouterService(use_llm=True)
