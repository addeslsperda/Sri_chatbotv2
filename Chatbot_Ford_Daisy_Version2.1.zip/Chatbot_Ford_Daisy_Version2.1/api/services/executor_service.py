"""
Executor service - executes agent skills with error handling.
Wraps the core skill executor with better logging and error management.
"""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from core.agents.skill_executor import SkillExecutor
from api.utils.logger import api_logger
from api.utils.errors import SkillNotFoundError, SkillExecutionError


class ExecutorService:
    """
    Service that executes agent skills safely with proper error handling.

    This service wraps the core SkillExecutor with:
    - Better error handling and reporting
    - Logging for debugging
    - Parameter validation and merging
    - Clean API interface
    """

    def __init__(self, project_root: Path | None = None):
        """
        Initialize executor service.

        Args:
            project_root: Path to project root (auto-detected if not provided)
        """
        if project_root is None:
            # Auto-detect project root (3 levels up from this file)
            project_root = Path(__file__).parent.parent.parent

        self.executor = SkillExecutor(project_root)
        self.project_root = project_root

        api_logger.info(f"ExecutorService initialized (project_root={project_root})")

    def execute(
        self,
        route: dict,
        user_params: dict | None = None
    ) -> dict:
        """
        Execute a skill based on routing information and user parameters.

        Args:
            route: Route dictionary from router containing:
                - agent: Agent name
                - skill: Skill name
                - params: Default skill parameters
            user_params: User-provided parameters (date filters, etc.)
                These override route defaults.

        Returns:
            Result dictionary from skill execution

        Raises:
            SkillNotFoundError: If skill doesn't exist
            SkillExecutionError: If skill execution fails
        """
        agent_name = route.get('agent')
        skill_name = route.get('skill')
        route_params = route.get('params', {})

        if not agent_name or not skill_name:
            raise ValueError("Route must contain 'agent' and 'skill' fields")

        # Merge parameters (user params override route defaults)
        merged_params = {**route_params, **(user_params or {})}

        api_logger.debug(
            f"executor_service — route_params={route_params} "
            f"user_params={user_params} merged_params={merged_params}"
        )

        api_logger.info(
            f"Executing {agent_name}/{skill_name} with params: {merged_params}"
        )

        try:
            # Execute the skill
            result = self.executor.execute_skill(
                agent_name=agent_name,
                skill_name=skill_name,
                params=merged_params
            )

            # Log success
            api_logger.info(
                f"Skill {agent_name}/{skill_name} executed successfully "
                f"(returned {len(result)} keys)"
            )

            # Handle list results (some skills return lists instead of dicts)
            if isinstance(result, list):
                api_logger.debug("Wrapping list result in dictionary")
                result = {"results": result}

            # Auto-create flat 'results' key for chart renderer if missing.
            # Finds the first array-of-dicts in the output, strips nested
            # objects (keeps str/int/float/None only) so the frontend
            # normalizeRows() / Vt() always finds clean chart data.
            if isinstance(result, dict) and 'results' not in result:
                for _val in result.values():
                    if (isinstance(_val, list) and len(_val) > 1
                            and isinstance(_val[0], dict)):
                        _flat = []
                        for _item in _val:
                            _row = {}
                            for _k, _v in _item.items():
                                if _v is None:
                                    _row[_k] = _v
                                elif isinstance(_v, bool):
                                    _row[_k] = int(_v)
                                elif isinstance(_v, (str, int, float)):
                                    _row[_k] = _v
                                # dicts, lists, and other complex types are skipped
                            if len(_row) >= 2:
                                _flat.append(_row)
                        if _flat:
                            result['results'] = _flat
                        break

            return result

        except FileNotFoundError as e:
            # Skill doesn't exist
            api_logger.error(f"Skill not found: {agent_name}/{skill_name}")
            raise SkillNotFoundError(agent_name, skill_name)

        except Exception as e:
            # Skill execution failed
            error_msg = str(e)
            api_logger.error(
                f"Skill execution failed: {agent_name}/{skill_name} - {error_msg}",
                exc_info=True
            )
            raise SkillExecutionError(agent_name, skill_name, error_msg)

    def execute_direct(
        self,
        agent_name: str,
        skill_name: str,
        params: dict | None = None
    ) -> dict:
        """
        Execute a skill directly without routing.

        Useful for:
        - Direct agent endpoints (/api/agents/*)
        - Testing
        - Admin operations

        Args:
            agent_name: Name of the agent
            skill_name: Name of the skill
            params: Skill parameters

        Returns:
            Result dictionary from skill execution

        Raises:
            SkillNotFoundError: If skill doesn't exist
            SkillExecutionError: If skill execution fails
        """
        route = {
            'agent': agent_name,
            'skill': skill_name,
            'params': params or {}
        }

        return self.execute(route, user_params=None)

    def list_available_skills(self, agent_name: str) -> list[str]:
        """
        List all available skills for a given agent.

        Args:
            agent_name: Name of the agent

        Returns:
            List of skill names available for this agent
        """
        try:
            agent_path = self.project_root / agent_name

            # Try .claude/skills first (common pattern)
            skills_path = agent_path / ".claude" / "skills"
            if not skills_path.exists():
                skills_path = agent_path / "skills"

            if not skills_path.exists():
                api_logger.warning(f"No skills directory found for agent: {agent_name}")
                return []

            skills = [
                d.name for d in skills_path.iterdir()
                if d.is_dir() and not d.name.startswith('.')
            ]

            api_logger.info(f"Found {len(skills)} skills for {agent_name}")
            return sorted(skills)

        except Exception as e:
            api_logger.error(f"Failed to list skills for {agent_name}: {str(e)}")
            return []


# Singleton instance
executor_service = ExecutorService()
