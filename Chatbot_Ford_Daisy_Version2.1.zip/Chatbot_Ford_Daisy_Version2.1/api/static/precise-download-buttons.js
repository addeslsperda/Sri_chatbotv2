/**
 * PRECISE Download Button Integration - Only target conversation history items
 * This replaces the aggressive approach with a very targeted one
 */

console.log('🎯 Loading PRECISE download buttons script...');

// Remove ALL existing download buttons first
function clearAllDownloadButtons() {
    document.querySelectorAll('.daisy-download-btn, .global-download-btn').forEach(btn => {
        btn.remove();
    });
    console.log('🧹 Cleared all existing download buttons');
}

// VERY PRECISE: Only add buttons to actual conversation history items
function addPreciseDownloadButtons() {
    console.log('🎯 Adding PRECISE download buttons...');
    clearAllDownloadButtons();

    let buttonsAdded = 0;

    // Method 1: Look for elements that contain BOTH "General" AND "Today" (from your screenshot)
    const conversationElements = Array.from(document.querySelectorAll('*')).filter(element => {
        const text = element.textContent || '';
        const hasGeneralToday = text.includes('General') && text.includes('Today');
        const isSmallElement = element.children.length < 5; // Not a container
        const hasReasonableSize = text.length > 5 && text.length < 50;

        return hasGeneralToday && isSmallElement && hasReasonableSize;
    });

    console.log(`🔍 Found ${conversationElements.length} elements with General+Today`);

    conversationElements.forEach((element, index) => {
        if (!element.querySelector('.daisy-download-btn')) {
            const downloadBtn = createPreciseDownloadButton();
            element.appendChild(downloadBtn);
            buttonsAdded++;
            console.log(`✅ Added button ${buttonsAdded} to: "${element.textContent.trim().substring(0, 30)}"`);
        }
    });

    // Method 2: Look for "hi" conversation (from your screenshot)
    const hiElements = Array.from(document.querySelectorAll('*')).filter(element => {
        const text = (element.textContent || '').trim();
        return text === 'hi' || (text.includes('hi') && text.length < 20);
    });

    console.log(`🔍 Found ${hiElements.length} "hi" elements`);

    hiElements.forEach((element, index) => {
        if (!element.querySelector('.daisy-download-btn')) {
            const downloadBtn = createPreciseDownloadButton();
            element.appendChild(downloadBtn);
            buttonsAdded++;
            console.log(`✅ Added button ${buttonsAdded} to "hi" conversation`);
        }
    });

    // Add ONE global download button (top right)
    if (!document.querySelector('.global-download-btn')) {
        const globalBtn = createGlobalDownloadButton();
        document.body.appendChild(globalBtn);
        buttonsAdded++;
        console.log('✅ Added global download button');
    }

    console.log(`🎯 TOTAL: Added ${buttonsAdded} precise download buttons`);
    return buttonsAdded;
}

function createPreciseDownloadButton() {
    const btn = document.createElement('button');
    btn.className = 'daisy-download-btn';
    btn.innerHTML = '💾'; // Download icon
    btn.title = 'Download this conversation';
    btn.style.cssText = `
        background: #28a745;
        border: none;
        border-radius: 3px;
        color: white;
        padding: 4px 6px;
        margin-left: 8px;
        font-size: 14px;
        cursor: pointer;
        display: inline-block;
        position: relative;
        z-index: 1000;
    `;

    btn.onclick = function(e) {
        e.preventDefault();
        e.stopPropagation();

        const sessionId = 'conversation-' + Date.now();
        const downloadUrl = `/api/conversations/${sessionId}/download?format=json`;

        btn.innerHTML = '⏳';
        window.open(downloadUrl, '_blank');

        setTimeout(() => {
            btn.innerHTML = '✅';
            setTimeout(() => btn.innerHTML = '💾', 1500);
        }, 500);
    };

    return btn;
}

function createGlobalDownloadButton() {
    const btn = document.createElement('button');
    btn.className = 'global-download-btn';
    btn.innerHTML = '💾 Download Current Chat';
    btn.title = 'Download current conversation';
    btn.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #007AFF;
        border: none;
        border-radius: 6px;
        color: white;
        padding: 8px 12px;
        font-size: 14px;
        cursor: pointer;
        z-index: 9999;
        box-shadow: 0 2px 4px rgba(0,0,0,0.3);
    `;

    btn.onclick = function() {
        const sessionId = 'current-' + Date.now();
        window.open(`/api/conversations/${sessionId}/download?format=json`, '_blank');
    };

    return btn;
}

// Expose to global scope for manual use
window.addPreciseDownloadButtons = addPreciseDownloadButtons;
window.clearAllDownloadButtons = clearAllDownloadButtons;

// Don't auto-run - let user trigger manually
console.log('🎯 PRECISE download buttons ready. Use: window.addPreciseDownloadButtons()');

// Auto-run ONLY if URL suggests we're on the main chat page
if (window.location.pathname === '/' || window.location.pathname.includes('chat')) {
    setTimeout(() => {
        console.log('🎯 Auto-running precise download buttons...');
        addPreciseDownloadButtons();
    }, 3000);
}