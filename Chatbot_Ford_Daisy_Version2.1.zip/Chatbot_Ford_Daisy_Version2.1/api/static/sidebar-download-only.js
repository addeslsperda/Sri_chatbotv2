/**
 * SIDEBAR DOWNLOAD - Adds a hover-visible download button to each
 * conversation item in the sidebar history.
 *
 * Key insight: Svelte conditionally renders .sb-del (the delete button)
 * only while the conversation is hovered. So we can NOT anchor to .sb-del.
 * Instead we inject into every .sb-conv and use CSS :hover to show/hide,
 * exactly mirroring the native delete-button behaviour.
 *
 * Conversations live in localStorage under "daisy_convs".
 */

(function () {
  'use strict';

  /* ── one-time CSS injection ──────────────────────────────────── */
  var STYLE_ID = 'daisy-dl-style';
  if (!document.getElementById(STYLE_ID)) {
    var s = document.createElement('style');
    s.id = STYLE_ID;
    s.textContent =
      /* hidden by default, shown on parent hover */
      '.daisy-dl-btn{' +
        'display:none;position:absolute;top:50%;right:34px;' +
        'transform:translateY(-50%);' +
        'background:var(--panel);border:1px solid var(--border);' +
        'width:22px;height:22px;border-radius:6px;padding:0;' +
        'align-items:center;justify-content:center;' +
        'color:var(--text2);cursor:pointer;' +
        'transition:color .12s,background .12s;' +
      '}' +
      /* show on conversation hover (same trigger as sb-del) */
      '.sb-conv:hover .daisy-dl-btn{display:flex}' +
      /* hover highlight */
      '.daisy-dl-btn:hover{color:#2a78d6;background:rgba(42,120,214,.12)}';
    document.head.appendChild(s);
  }

  /* ── helpers ─────────────────────────────────────────────────── */

  function getConversations() {
    try {
      var raw = localStorage.getItem('daisy_convs');
      return raw ? JSON.parse(raw) : [];
    } catch (e) { return []; }
  }

  function findConversation(titleText) {
    var convs  = getConversations();
    var needle = (titleText || '').trim().toLowerCase();
    if (!needle) return convs[0] || null;
    return (
      convs.find(function (c) { return (c.title || '').toLowerCase() === needle; }) ||
      convs.find(function (c) { return (c.title || '').toLowerCase().startsWith(needle.slice(0, 30)); }) ||
      null
    );
  }

  function buildQAText(conv) {
    if (!conv || !conv.messages) return 'No conversation data found.';
    var lines = [
      '='.repeat(70),
      'DAISY - Conversation Export',
      'Title : ' + (conv.title || 'Untitled'),
      'Date  : ' + (conv.createdAt || new Date().toISOString()),
      '='.repeat(70),
      ''
    ];
    var qNum = 0;
    conv.messages.forEach(function (m, i) {
      if (m.role === 'user') {
        qNum++;
        lines.push('--- Question ' + qNum + ' ---');
        lines.push(m.content || '');
        lines.push('');
        var next = conv.messages[i + 1];
        if (next && next.role === 'daisy') {
          lines.push('--- Answer ' + qNum + ' ---');
          lines.push(next.content || '');
          if (next.agent) lines.push('  [Agent: ' + next.agent + ']');
          if (next.skill) lines.push('  [Skill: ' + next.skill + ']');
          lines.push('');
        }
      }
    });
    lines.push('='.repeat(70));
    lines.push('End of conversation');
    return lines.join('\n');
  }

  function downloadFile(filename, content) {
    var blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    var url  = URL.createObjectURL(blob);
    var a    = document.createElement('a');
    a.href = url; a.download = filename; a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 2000);
  }

  /* ── DOM injection ──────────────────────────────────────────── */

  function injectDownloadButtons() {
    document.querySelectorAll('.sb-conv').forEach(function (convItem) {
      // skip if already injected
      if (convItem.querySelector('.daisy-dl-btn')) return;

      var dlBtn = document.createElement('button');
      dlBtn.className = 'daisy-dl-btn';
      dlBtn.setAttribute('aria-label', 'Download conversation');
      dlBtn.title = 'Download conversation';

      dlBtn.innerHTML =
        '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" ' +
        'stroke="currentColor" stroke-width="2.2" stroke-linecap="round">' +
        '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>' +
        '<polyline points="7 10 12 15 17 10"/>' +
        '<line x1="12" y1="15" x2="12" y2="3"/>' +
        '</svg>';

      dlBtn.addEventListener('click', function (e) {
        e.preventDefault();
        e.stopPropagation();

        var titleEl  = convItem.querySelector('.sb-cv-title');
        var titleTxt = titleEl ? titleEl.textContent : '';
        var conv     = findConversation(titleTxt);

        if (!conv) {
          alert('Could not find this conversation\'s data.');
          return;
        }

        var text     = buildQAText(conv);
        var safeName = (conv.title || 'conversation')
          .replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 40);
        var filename = 'daisy_' + safeName + '_' +
          new Date().toISOString().slice(0, 10) + '.txt';

        downloadFile(filename, text);

        dlBtn.style.color = '#1baf7a';
        setTimeout(function () { dlBtn.style.color = ''; }, 1200);
      });

      convItem.appendChild(dlBtn);
    });
  }

  /* ── lifecycle ───────────────────────────────────────────────── */

  setTimeout(injectDownloadButtons, 2500);

  var debounce;
  new MutationObserver(function () {
    clearTimeout(debounce);
    debounce = setTimeout(injectDownloadButtons, 800);
  }).observe(document.body, { childList: true, subtree: true });

})();