/**
 * DAISY Version 2: Conversation Download Integration
 * Integrates seamlessly with your existing Litestar + SvelteKit chat interface
 */

class DaisyConversationManager {
    constructor(apiBaseUrl = '/api/conversations') {
        this.apiBaseUrl = apiBaseUrl;
        this.currentSessionId = null;
        this.isInitialized = false;
        this.questionCount = 0;
        this.skillCount = 0;
    }

    /**
     * Initialize the conversation manager
     */
    async initialize() {
        if (this.isInitialized) return this.currentSessionId;

        try {
            // Check if there's an existing session in localStorage
            const existingSessionId = localStorage.getItem('daisy_session_id');
            const sessionTimestamp = localStorage.getItem('daisy_session_timestamp');

            // Check if session is recent (less than 24 hours old)
            if (existingSessionId && sessionTimestamp) {
                const sessionAge = Date.now() - parseInt(sessionTimestamp);
                if (sessionAge < 24 * 60 * 60 * 1000) { // 24 hours
                    this.currentSessionId = existingSessionId;
                    console.log('DAISY: Restored existing session:', existingSessionId.substr(0, 8));
                    this.isInitialized = true;
                    return this.currentSessionId;
                }
            }

            // Start new session
            await this.startNewSession();
            return this.currentSessionId;

        } catch (error) {
            console.warn('DAISY: Failed to initialize session, using offline mode:', error);
            // Fallback to local session ID
            this.currentSessionId = 'offline_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
            localStorage.setItem('daisy_session_id', this.currentSessionId);
            localStorage.setItem('daisy_session_timestamp', Date.now().toString());
            this.isInitialized = true;
            return this.currentSessionId;
        }
    }

    /**
     * Start a new conversation session
     */
    async startNewSession(userId = null, sessionType = 'chat') {
        try {
            const response = await fetch(`${this.apiBaseUrl}/sessions/start`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    user_id: userId,
                    session_type: sessionType
                })
            });

            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }

            const data = await response.json();
            this.currentSessionId = data.session_id;

            // Store session info
            localStorage.setItem('daisy_session_id', this.currentSessionId);
            localStorage.setItem('daisy_session_timestamp', Date.now().toString());

            this.isInitialized = true;
            this.questionCount = 0;
            this.skillCount = 0;

            console.log('DAISY: New session started:', this.currentSessionId.substr(0, 8));
            this.showNotification('New conversation session started', 'info');

            return this.currentSessionId;

        } catch (error) {
            console.error('DAISY: Failed to start session:', error);
            throw error;
        }
    }

    /**
     * Log a user question
     */
    async logQuestion(questionText, agentType = null, skillUsed = null, responseTime = null, userSatisfaction = null) {
        if (!this.currentSessionId) {
            await this.initialize();
        }

        try {
            const response = await fetch(`${this.apiBaseUrl}/questions/log`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    question_text: questionText,
                    session_id: this.currentSessionId,
                    agent_type: agentType,
                    skill_used: skillUsed,
                    response_time: responseTime,
                    user_satisfaction: userSatisfaction
                })
            });

            if (response.ok) {
                const data = await response.json();
                this.questionCount++;
                console.log('DAISY: Question logged:', data.question_id?.substr(0, 8));
                return data.question_id;
            }
        } catch (error) {
            console.warn('DAISY: Failed to log question:', error);
        }

        return null;
    }

    /**
     * Log skill execution
     */
    async logSkill(agentType, skillName, status = 'success', duration = null, parameters = null, recordsReturned = null) {
        if (!this.currentSessionId) {
            await this.initialize();
        }

        try {
            const response = await fetch(`${this.apiBaseUrl}/skills/log`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    session_id: this.currentSessionId,
                    agent_type: agentType,
                    skill_name: skillName,
                    execution_status: status,
                    duration_seconds: duration,
                    input_parameters: parameters,
                    records_returned: recordsReturned
                })
            });

            if (response.ok) {
                const data = await response.json();
                this.skillCount++;
                console.log('DAISY: Skill logged:', skillName, status);
                return data.execution_id;
            }
        } catch (error) {
            console.warn('DAISY: Failed to log skill:', error);
        }

        return null;
    }

    /**
     * Download conversation in specified format
     */
    async downloadConversation(format = 'json', sessionId = null) {
        const targetSessionId = sessionId || this.currentSessionId;

        if (!targetSessionId) {
            throw new Error('No active session to download');
        }

        if (!['json', 'csv', 'txt'].includes(format)) {
            throw new Error('Format must be json, csv, or txt');
        }

        try {
            this.showNotification(`Preparing ${format.toUpperCase()} download...`, 'info');

            const response = await fetch(`${this.apiBaseUrl}/${targetSessionId}/download?format=${format}`, {
                method: 'GET'
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.detail || `Download failed: ${response.status} ${response.statusText}`);
            }

            // Get filename from response headers
            const contentDisposition = response.headers.get('Content-Disposition');
            let filename = `daisy_conversation_${targetSessionId.substr(0, 8)}_${new Date().toISOString().substr(0, 10)}.${format}`;

            if (contentDisposition) {
                const filenameMatch = contentDisposition.match(/filename="(.+)"/);
                if (filenameMatch) {
                    filename = filenameMatch[1];
                }
            }

            // Create blob and download
            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);

            const a = document.createElement('a');
            a.href = url;
            a.download = filename;
            a.style.display = 'none';

            document.body.appendChild(a);
            a.click();

            // Cleanup
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);

            this.showNotification(`Downloaded ${filename}`, 'success');

            return filename;

        } catch (error) {
            console.error('DAISY: Download failed:', error);
            this.showNotification(`Download failed: ${error.message}`, 'error');
            throw error;
        }
    }

    /**
     * Get conversation summary
     */
    async getConversationSummary(sessionId = null) {
        const targetSessionId = sessionId || this.currentSessionId;

        if (!targetSessionId) {
            return null;
        }

        try {
            const response = await fetch(`${this.apiBaseUrl}/${targetSessionId}`, {
                method: 'GET'
            });

            if (response.ok) {
                return await response.json();
            }
        } catch (error) {
            console.warn('DAISY: Failed to get conversation summary:', error);
        }

        return null;
    }

    /**
     * End current session
     */
    async endSession(sessionId = null, completed = true) {
        const targetSessionId = sessionId || this.currentSessionId;

        if (!targetSessionId) {
            return;
        }

        try {
            const response = await fetch(`${this.apiBaseUrl}/sessions/${targetSessionId}/end`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    completed: completed,
                    final_action: 'user_ended'
                })
            });

            if (response.ok) {
                console.log('DAISY: Session ended:', targetSessionId.substr(0, 8));

                // Clear local session if it's the current one
                if (targetSessionId === this.currentSessionId) {
                    localStorage.removeItem('daisy_session_id');
                    localStorage.removeItem('daisy_session_timestamp');
                    this.currentSessionId = null;
                    this.isInitialized = false;
                    this.questionCount = 0;
                    this.skillCount = 0;
                }
            }
        } catch (error) {
            console.warn('DAISY: Failed to end session:', error);
        }
    }

    /**
     * Show notification to user
     */
    showNotification(message, type = 'info', duration = 3000) {
        // Remove any existing notifications
        const existingNotification = document.getElementById('daisy-notification');
        if (existingNotification) {
            existingNotification.remove();
        }

        // Create notification element
        const notification = document.createElement('div');
        notification.id = 'daisy-notification';
        notification.textContent = message;

        // Style the notification
        const colors = {
            info: '#007AFF',
            success: '#28a745',
            error: '#dc3545',
            warning: '#ffc107'
        };

        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 12px 20px;
            border-radius: 6px;
            color: white;
            background: ${colors[type] || colors.info};
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            font-size: 14px;
            font-weight: 500;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            z-index: 10000;
            transition: all 0.3s ease;
            max-width: 300px;
            word-wrap: break-word;
        `;

        document.body.appendChild(notification);

        // Auto-remove after duration (except for errors)
        if (type !== 'error') {
            setTimeout(() => {
                if (notification && notification.parentNode) {
                    notification.style.opacity = '0';
                    notification.style.transform = 'translateY(-20px)';
                    setTimeout(() => {
                        if (notification && notification.parentNode) {
                            notification.parentNode.removeChild(notification);
                        }
                    }, 300);
                }
            }, duration);
        }
    }

    /**
     * Create download button element
     */
    createDownloadButton(options = {}) {
        const {
            text = '[DOWNLOAD]',
            title = 'Download conversation',
            className = 'daisy-download-btn',
            style = {}
        } = options;

        const button = document.createElement('button');
        button.textContent = text;
        button.title = title;
        button.className = className;

        // Default styles
        const defaultStyle = {
            background: '#007AFF',
            border: 'none',
            borderRadius: '6px',
            color: 'white',
            padding: '8px 12px',
            fontSize: '14px',
            cursor: 'pointer',
            transition: 'all 0.2s ease',
            ...style
        };

        Object.assign(button.style, defaultStyle);

        // Add hover effects
        button.addEventListener('mouseenter', () => {
            button.style.background = '#0056b3';
            button.style.transform = 'translateY(-1px)';
        });

        button.addEventListener('mouseleave', () => {
            button.style.background = defaultStyle.background;
            button.style.transform = 'translateY(0)';
        });

        // Add click handler
        button.addEventListener('click', async () => {
            try {
                await this.downloadConversation('json');
            } catch (error) {
                console.error('Download failed:', error);
            }
        });

        return button;
    }

    /**
     * Create download dropdown with multiple formats
     */
    createDownloadDropdown(options = {}) {
        const {
            className = 'daisy-download-dropdown',
            buttonText = '[DOWNLOAD] ▼',
            buttonTitle = 'Download conversation'
        } = options;

        const dropdown = document.createElement('div');
        dropdown.className = className;
        dropdown.style.cssText = `
            position: relative;
            display: inline-block;
        `;

        const button = document.createElement('button');
        button.textContent = buttonText;
        button.title = buttonTitle;
        button.style.cssText = `
            background: #007AFF;
            border: none;
            border-radius: 6px;
            color: white;
            padding: 8px 12px;
            font-size: 14px;
            cursor: pointer;
            transition: background 0.2s ease;
        `;

        const menu = document.createElement('div');
        menu.style.cssText = `
            position: absolute;
            top: 100%;
            right: 0;
            background: white;
            border: 1px solid #ddd;
            border-radius: 6px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            z-index: 1000;
            min-width: 140px;
            display: none;
        `;

        const formats = [
            { format: 'json', label: '📄 JSON', title: 'Structured data format' },
            { format: 'csv', label: '[DATA] CSV', title: 'Spreadsheet format' },
            { format: 'txt', label: '📝 TXT', title: 'Human-readable report' }
        ];

        formats.forEach(({ format, label, title }) => {
            const menuItem = document.createElement('button');
            menuItem.textContent = label;
            menuItem.title = title;
            menuItem.style.cssText = `
                display: block;
                width: 100%;
                padding: 10px 15px;
                border: none;
                background: white;
                text-align: left;
                cursor: pointer;
                transition: background 0.2s ease;
            `;

            menuItem.addEventListener('mouseenter', () => {
                menuItem.style.background = '#f8f9fa';
            });

            menuItem.addEventListener('mouseleave', () => {
                menuItem.style.background = 'white';
            });

            menuItem.addEventListener('click', async () => {
                menu.style.display = 'none';
                try {
                    await this.downloadConversation(format);
                } catch (error) {
                    console.error('Download failed:', error);
                }
            });

            menu.appendChild(menuItem);
        });

        // Toggle menu
        button.addEventListener('click', (e) => {
            e.stopPropagation();
            menu.style.display = menu.style.display === 'none' ? 'block' : 'none';
        });

        // Close menu when clicking outside
        document.addEventListener('click', () => {
            menu.style.display = 'none';
        });

        dropdown.appendChild(button);
        dropdown.appendChild(menu);

        return dropdown;
    }

    /**
     * Get current session stats
     */
    getSessionStats() {
        return {
            sessionId: this.currentSessionId,
            questionsLogged: this.questionCount,
            skillsExecuted: this.skillCount,
            isActive: this.isInitialized && !!this.currentSessionId
        };
    }
}

// Global instance - available throughout your SvelteKit app
window.daisyConversation = new DaisyConversationManager();

// Auto-initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        window.daisyConversation.initialize().catch(console.warn);
    });
} else {
    // DOM is already ready
    window.daisyConversation.initialize().catch(console.warn);
}

// Intercept and enhance query requests to automatically include session_id
window.enhanceDaisyQuery = function(originalQueryData) {
    if (!window.daisyConversation?.currentSessionId) {
        // Initialize session if not already done
        window.daisyConversation?.initialize().catch(console.warn);
    }

    return {
        ...originalQueryData,
        session_id: window.daisyConversation?.currentSessionId
    };
};

// Auto-enhance fetch requests to /api/query
const originalFetch = window.fetch;
window.fetch = function(url, options = {}) {
    // Check if this is a query request
    if (url.includes('/api/query') && options.method === 'POST' && options.body) {
        try {
            const body = JSON.parse(options.body);
            if (body.question && !body.session_id) {
                // Auto-add session_id
                body.session_id = window.daisyConversation?.currentSessionId;
                options.body = JSON.stringify(body);
                console.log('DAISY: Auto-added session_id to query request');
            }
        } catch (e) {
            // If JSON parsing fails, continue with original request
        }
    }

    return originalFetch.call(this, url, options);
};

// Convenience functions for easy integration
window.logDaisyQuestion = (text, agent, skill, responseTime) =>
    window.daisyConversation?.logQuestion(text, agent, skill, responseTime);

window.logDaisySkill = (agent, skill, status, duration, params) =>
    window.daisyConversation?.logSkill(agent, skill, status, duration, params);

window.downloadDaisyConversation = (format) =>
    window.daisyConversation?.downloadConversation(format);

window.getDaisySessionStats = () =>
    window.daisyConversation?.getSessionStats();

window.getDaisySessionId = () =>
    window.daisyConversation?.currentSessionId;

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { DaisyConversationManager };
}