/**
 * DAISY Chart Renderer v2
 * Skill-aware Chart.js modal with view chips + metric chips.
 */
(function () {
  'use strict';

  var CHARTJS_CDN = '/chart.umd.min.js';  // local copy — no CDN dependency
  var MODAL_ID = 'daisy-cm-v2';
  var STYLE_ID = 'daisy-cm-v2-style';
  var MAX_ROWS = 60;
  var PIE_MAX = 14;
  var NUM_THRESH = 0.5;
  var DATE_RE = /(date|day|week|month|quarter|year|period|time)/i;
  var ID_RE = /(^|_)(id|vin|call_id|topic_id|pacode|uuid)$/i;
  var LABEL_PRIORITY = [
    'issue', 'pain_point', 'topic_name', 'topic', 'parts_features', 'parts_concern',
    'modelvehicleline', 'vehicle', 'model_year', 'year', 'period', 'date', 'label', 'name'
  ];
  var PALETTE = [
    '#29abe2', '#0f8a9b', '#4ecdc4', '#45b7d1', '#96ceb4',
    '#f8b500', '#f26b38', '#9c4dcc', '#2e8b57', '#ef3e7a',
    '#60a5fa', '#06b6d4', '#34d399', '#f59e0b', '#ef4444'
  ];

  var activeChart = null;
  var chartjsLoaded = false;
  var loadCallbacks = [];
  var specCache = null;
  var state = {
    type: 'bar',
    viewId: null,
    metricKey: null,
    scatterX: null,
    scatterY: null
  };

  function injectCSS() {
    if (document.getElementById(STYLE_ID)) return;
    var s = document.createElement('style');
    s.id = STYLE_ID;
    s.textContent = [
      '.viz-root{display:none!important}',
      '#'+MODAL_ID+'{display:none;position:fixed;inset:0;z-index:9998;align-items:center;justify-content:center;font-family:inherit}',
      '#'+MODAL_ID+'.dcm-open{display:flex}',
      '.dcm-bd{position:fixed;inset:0;background:rgba(0,0,0,.45);backdrop-filter:blur(3px)}',
      '.dcm-dlg{position:relative;z-index:9999;background:var(--panel,#fff);border:1px solid var(--border,rgba(40,35,25,.1));border-radius:18px;width:min(1080px,96vw);max-height:92vh;display:flex;flex-direction:column;box-shadow:0 28px 70px rgba(0,0,0,.22);overflow:hidden}',
      '.dcm-hdr{display:flex;align-items:flex-start;justify-content:space-between;padding:14px 16px 12px;gap:10px;border-bottom:1px solid var(--border,rgba(40,35,25,.1))}',
      '.dcm-title-wrap{min-width:0;flex:1}',
      '.dcm-ttl{font-size:14px;font-weight:700;color:var(--text1,#23282b);letter-spacing:-.2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
      '.dcm-sub{font-size:11.5px;color:var(--text2,#5c666b);margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
      '.dcm-ctrl{display:flex;align-items:center;gap:8px;flex-shrink:0}',
      '.dcm-types{display:flex;gap:4px;flex-wrap:wrap;justify-content:flex-end}',
      '.dcm-tb{border:1px solid var(--border,rgba(40,35,25,.1));background:var(--panel-2,#efece4);color:var(--text2,#5c666b);border-radius:8px;padding:4px 10px;font-size:11.5px;cursor:pointer;transition:all .12s;font-family:inherit}',
      '.dcm-tb.act,.dcm-tb:hover{background:var(--accent,#29abe2);color:var(--accent-ink,#fff);border-color:var(--accent,#29abe2)}',
      '.dcm-x{background:none;border:none;color:var(--text2,#5c666b);font-size:17px;cursor:pointer;padding:4px 7px;border-radius:8px;line-height:1;transition:color .12s,background .12s;font-family:inherit}',
      '.dcm-x:hover{color:var(--text1,#23282b);background:var(--panel-2,#efece4)}',
      '.dcm-body{padding:16px 18px 18px;overflow:auto;flex:1}',
      '.dcm-chip-row{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin:0 0 12px}',
      '.dcm-chip-row:last-of-type{margin-bottom:14px}',
      '.dcm-chip-label{font-size:11px;font-weight:700;letter-spacing:.02em;color:var(--text2,#5c666b);text-transform:uppercase;margin-right:2px}',
      '.dcm-chip{display:inline-flex;align-items:center;gap:6px;border:1px solid var(--border,rgba(40,35,25,.1));background:var(--panel-2,#efece4);color:var(--text2,#5c666b);border-radius:999px;padding:4px 10px;font-size:11.5px;cursor:pointer;transition:all .12s;font-family:inherit}',
      '.dcm-chip.on{background:var(--accent,#29abe2);color:var(--accent-ink,#fff);border-color:var(--accent,#29abe2)}',
      '.dcm-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0;display:inline-block}',
      '.dcm-scatter{display:none;gap:10px;align-items:center;flex-wrap:wrap;padding:0 0 12px;font-size:11.5px;color:var(--text2,#5c666b)}',
      '.dcm-sel{border:1px solid var(--border,rgba(40,35,25,.1));background:var(--panel-2,#efece4);color:var(--text1,#23282b);border-radius:8px;padding:4px 8px;font-size:11px;font-family:inherit}',
      '.dcm-cw{position:relative;min-height:350px}',
      '.dcm-empty{color:var(--text2,#5c666b);font-size:13px;text-align:center;padding:64px 20px}',
      '.dcm-note{font-size:11px;color:var(--text2,#5c666b);margin-top:10px}',
      '@media (max-width:900px){.dcm-hdr{flex-direction:column;align-items:stretch}.dcm-ctrl{justify-content:space-between}.dcm-dlg{width:min(98vw,1080px)}}'
    ].join('');
    document.head.appendChild(s);
  }

  function loadChartJs(cb) {
    if (chartjsLoaded) { cb(); return; }
    loadCallbacks.push(cb);
    if (loadCallbacks.length > 1) return;
    var s = document.createElement('script');
    s.src = CHARTJS_CDN;
    s.onload = function () {
      chartjsLoaded = true;
      loadCallbacks.forEach(function (f) { f(); });
      loadCallbacks = [];
    };
    s.onerror = function () { console.error('[Daisy] Failed to load Chart.js'); };
    document.head.appendChild(s);
  }

  function isPlainObject(v) {
    return !!v && typeof v === 'object' && !Array.isArray(v);
  }

  function humanize(str) {
    return String(str || '')
      .replace(/\./g, ' · ')
      .replace(/_/g, ' ')
      .replace(/\b\w/g, function (c) { return c.toUpperCase(); });
  }

  function truncate(str, max) {
    str = String(str == null ? '' : str);
    return str.length > max ? str.slice(0, max - 1) + '…' : str;
  }

  function toLabel(v) {
    if (v == null) return '';
    if (Array.isArray(v)) return v.map(toLabel).filter(Boolean).join(', ');
    if (isPlainObject(v)) {
      var s = v.name || v.label || v.title || v.value || v.pain_point || v.topic ||
              v.issue || v.parts_features || v.parts_concern || v.description ||
              v.level2 || v.level1 || v.display_name;
      return s != null ? String(s) : JSON.stringify(v);
    }
    return String(v);
  }

  function getAtPath(obj, path) {
    if (!obj || !path) return undefined;
    var cur = obj;
    var parts = String(path).split('.');
    for (var i = 0; i < parts.length; i++) {
      if (cur == null) return undefined;
      cur = cur[parts[i]];
    }
    return cur;
  }

  function flattenObject(obj, prefix, out) {
    out = out || {};
    if (!isPlainObject(obj)) return out;
    Object.keys(obj).forEach(function (key) {
      var val = obj[key];
      var next = prefix ? prefix + '.' + key : key;
      if (Array.isArray(val)) {
        out[next] = val.map(toLabel).join(', ');
      } else if (isPlainObject(val)) {
        flattenObject(val, next, out);
      } else {
        out[next] = val;
      }
    });
    return out;
  }

  function isFiniteNumber(v) {
    return typeof v === 'number' && isFinite(v);
  }

  function toNumber(v) {
    if (isFiniteNumber(v)) return v;
    if (typeof v === 'string') {
      var cleaned = v.replace(/[%,$]/g, '').trim();
      if (!cleaned || /^new$/i.test(cleaned)) return null;
      var n = Number(cleaned);
      return isFinite(n) ? n : null;
    }
    return null;
  }

  function isDateLike(v) {
    if (v == null) return false;
    if (typeof v === 'number') return false;
    var s = String(v).trim();
    if (!s) return false;
    return /^\d{4}-\d{2}-\d{2}/.test(s) || /^\d{4}-\d{2}/.test(s) || /\bQ[1-4]\b/i.test(s);
  }

  function normalizeRows(data) {
    if (!data) return null;
    if (Array.isArray(data)) {
      return data.every(function (r) { return isPlainObject(r); }) ? data : null;
    }
    if (isPlainObject(data)) {
      var candidates = [data.results].concat(Object.values(data));
      for (var i = 0; i < candidates.length; i++) {
        var c = candidates[i];
        if (Array.isArray(c) && c.length && c.every(function (r) { return isPlainObject(r); })) {
          return c;
        }
      }
    }
    return null;
  }

  function extractArrayViews(obj, prefix, out) {
    out = out || [];
    if (!isPlainObject(obj)) return out;
    Object.keys(obj).forEach(function (key) {
      var val = obj[key];
      var next = prefix ? prefix + '.' + key : key;
      if (Array.isArray(val) && val.length && val.every(function (r) { return isPlainObject(r); })) {
        out.push({ id: next, name: humanize(key), rows: val });
      } else if (isPlainObject(val)) {
        extractArrayViews(val, next, out);
      }
    });
    return out;
  }

  function detectLabelKey(flatRows) {
    if (!flatRows.length) return null;
    var keys = [];
    flatRows.forEach(function (r) {
      Object.keys(r).forEach(function (k) {
        if (keys.indexOf(k) < 0) keys.push(k);
      });
    });
    for (var i = 0; i < LABEL_PRIORITY.length; i++) {
      var wanted = LABEL_PRIORITY[i];
      var exact = keys.find(function (k) { return k === wanted || k.split('.').slice(-1)[0] === wanted; });
      if (exact) return exact;
    }
    var dateKey = keys.find(function (k) {
      return DATE_RE.test(k) && flatRows.some(function (r) { return isDateLike(r[k]); });
    });
    if (dateKey) return dateKey;
    return keys.find(function (k) {
      return !ID_RE.test(k) && flatRows.some(function (r) {
        return typeof r[k] === 'string' && r[k].trim();
      });
    }) || keys[0];
  }

  function collectMetrics(flatRows, preferred) {
    if (!flatRows.length) return [];
    var keys = [];
    flatRows.forEach(function (r) {
      Object.keys(r).forEach(function (k) {
        if (keys.indexOf(k) < 0) keys.push(k);
      });
    });
    var all = keys.filter(function (k) {
      if (ID_RE.test(k)) return false;
      var nonNull = flatRows.filter(function (r) { return r[k] != null && r[k] !== ''; });
      if (!nonNull.length) return false;
      var nums = nonNull.filter(function (r) { return toNumber(r[k]) != null; });
      return nums.length / nonNull.length >= NUM_THRESH;
    }).map(function (k, idx) {
      return { key: k, label: humanize(k.split('.').slice(-1)[0]), color: PALETTE[idx % PALETTE.length] };
    });
    if (!preferred || !preferred.length) return all;
    var ordered = [];
    preferred.forEach(function (wanted) {
      var found = all.find(function (m) { return m.key === wanted; });
      if (found) ordered.push(found);
    });
    all.forEach(function (m) {
      if (!ordered.find(function (x) { return x.key === m.key; })) ordered.push(m);
    });
    return ordered;
  }

  function makeView(cfg) {
    var rows = (cfg.rows || []).slice(0, MAX_ROWS);
    if (!rows.length) return null;
    var flatRows = rows.map(function (r) { return flattenObject(r, '', {}); });
    var labelKey = cfg.labelKey || detectLabelKey(flatRows);
    var metrics = (cfg.metrics || collectMetrics(flatRows, cfg.preferredMetrics || [])).filter(function (m) {
      return flatRows.some(function (row) { return toNumber(row[m.key]) != null; });
    });
    if (!metrics.length) {
      var fallbackMetric = {
        key: '__count__',
        label: 'Count',
        color: PALETTE[0],
        value: function () { return 1; }
      };
      metrics = [fallbackMetric];
    }
    return {
      id: cfg.id,
      name: cfg.name,
      rows: rows,
      flatRows: flatRows,
      labelKey: labelKey,
      labelFn: cfg.labelFn || function (row, flat) { return toLabel(flat[labelKey]); },
      metrics: metrics,
      defaultMetric: cfg.defaultMetric || metrics[0].key,
      defaultType: cfg.defaultType || (labelKey && DATE_RE.test(labelKey) ? 'line' : 'bar'),
      note: cfg.note || '',
      preserveOrder: !!cfg.preserveOrder
    };
  }

  function metricValue(metric, row, flat) {
    if (metric.value) return metric.value(row, flat);
    return toNumber(flat[metric.key]);
  }

  function findFirstArray(data, names) {
    for (var i = 0; i < names.length; i++) {
      var v = getAtPath(data, names[i]);
      if (Array.isArray(v) && v.length) return v;
    }
    return null;
  }

  function buildSkillSpec(skill, data) {
    skill = (skill || '').toLowerCase();
    if (!data) return null;

    if (skill === 'emerging_issues') {
      var emerging = (data.emerging_issues || []).map(function (r) {
        return Object.assign({ __kind: 'emerging' }, r);
      });
      var fresh = (data.new_issues || []).map(function (r) {
        return Object.assign({
          __kind: 'new',
          baseline_calls: 0,
          net_increase: r.current_calls || 0,
          spike_pct_numeric: null,
          avg_sentiment: null,
          escalation_rate: null,
          churn_risk_rate: null
        }, r);
      });
      var combined = emerging.concat(fresh);
      if (!combined.length) return null;
      return {
        title: 'Emerging Issues',
        subtitle: (data.date_range || '') + (data.comparison_period ? ' vs ' + data.comparison_period : ''),
        views: [
          makeView({
            id: 'all',
            name: 'All Issues',
            rows: combined,
            labelKey: 'issue',
            defaultType: 'pie',
            preferredMetrics: [
              'current_calls', 'baseline_calls', 'spike_pct', 'net_increase',
              'avg_sentiment', 'escalation_rate', 'churn_risk_rate', 'current_pct_of_calls'
            ],
            note: data.early_warnings && data.early_warnings.length ? data.early_warnings[0].alert : ''
          }),
          emerging.length ? makeView({
            id: 'emerging',
            name: 'Spiking Issues',
            rows: emerging,
            labelKey: 'issue',
            defaultType: 'pie',
            preferredMetrics: [
              'current_calls', 'baseline_calls', 'spike_pct', 'net_increase',
              'avg_sentiment', 'escalation_rate', 'current_pct_of_calls'
            ]
          }) : null,
          fresh.length ? makeView({
            id: 'new',
            name: 'New Issues',
            rows: fresh,
            labelKey: 'issue',
            defaultType: 'bar',
            preferredMetrics: ['current_calls', 'net_increase']
          }) : null
        ].filter(Boolean)
      };
    }

    if (skill === 'topic_trends') {
      function topicRow(segment, row) {
        var h = row.topic_hierarchy || {};
        return Object.assign({ __segment: segment }, row, {
          topic_label: [h.level1, h.level2, h.level3].filter(Boolean).slice(0, 2).join(' › ') || row.topic_name || h.level2 || h.level1 || 'Topic',
          negative_pct_flat: getAtPath(row, 'metrics.negative_pct'),
          avg_sentiment_flat: getAtPath(row, 'metrics.avg_sentiment'),
          avg_complexity_flat: getAtPath(row, 'metrics.avg_complexity'),
          vehicles_affected_flat: getAtPath(row, 'metrics.vehicles_affected')
        });
      }
      var critical = (data.critical_topics || []).map(function (r) { return topicRow('Critical', r); });
      var high = (data.high_impact_topics || []).map(function (r) { return topicRow('High Impact', r); });
      var trending = (data.trending_topics || []).map(function (r) { return topicRow('Trending', r); });
      var allTopics = critical.concat(high).concat(trending);
      if (!allTopics.length) return null;
      var topicMetrics = ['call_count', 'pct_of_calls', 'business_impact_score', 'metrics.negative_pct', 'metrics.avg_sentiment', 'metrics.avg_complexity', 'metrics.vehicles_affected'];
      return {
        title: 'Topic Trends',
        subtitle: data.summary_stats && data.summary_stats.total_calls_analyzed ? 'Calls analyzed: ' + data.summary_stats.total_calls_analyzed : '',
        views: [
          makeView({ id: 'all', name: 'All Topics', rows: allTopics, labelKey: 'topic_label', defaultType: 'bar', preferredMetrics: topicMetrics }),
          critical.length ? makeView({ id: 'critical', name: 'Critical', rows: critical, labelKey: 'topic_label', defaultType: 'bar', preferredMetrics: topicMetrics }) : null,
          high.length ? makeView({ id: 'high', name: 'High Impact', rows: high, labelKey: 'topic_label', defaultType: 'bar', preferredMetrics: topicMetrics }) : null,
          trending.length ? makeView({ id: 'trending', name: 'Trending', rows: trending, labelKey: 'topic_label', defaultType: 'bar', preferredMetrics: topicMetrics }) : null
        ].filter(Boolean)
      };
    }

    if (skill === 'vehicle_pain_points') {
      var painRows = data.pain_points || data.results || normalizeRows(data) || [];
      if (!painRows.length) return null;
      return {
        title: 'Vehicle Pain Points',
        subtitle: data.vehicle ? String(data.vehicle) : '',
        views: [makeView({
          id: 'pain_points',
          name: 'Pain Points',
          rows: painRows,
          labelKey: 'pain_point',
          defaultType: 'bar',
          preferredMetrics: [
            'call_count', 'pct_of_calls', 'sentiment_metrics.negative_pct',
            'sentiment_metrics.avg_sentiment', 'performance_metrics.avg_complexity',
            'business_intelligence.switching_pct'
          ]
        })]
      };
    }

    if (skill === 'issue_breakdown') {
      var views = [];
      var parts = findFirstArray(data, ['issue_breakdown.parts_breakdown', 'parts_breakdown', 'related_parts_breakdown']);
      var topics = findFirstArray(data, ['issue_breakdown.topic_breakdown', 'topic_breakdown']);
      var pain = findFirstArray(data, ['pain_point_breakdown', 'issue_breakdown.pain_point_breakdown']);
      if (parts && parts.length) views.push(makeView({
        id: 'parts',
        name: 'Parts',
        rows: parts,
        labelFn: function (row) { return row.parts_features ? row.parts_features + (row.parts_concern ? ' · ' + row.parts_concern : '') : row.parts_concern || 'Part'; },
        defaultType: 'bar',
        preferredMetrics: ['call_count', 'avg_sentiment', 'avg_complexity', 'avg_aht']
      }));
      if (topics && topics.length) views.push(makeView({
        id: 'topics',
        name: 'Topics',
        rows: topics,
        labelFn: function (row) { return row.topic_name || [row.topic_level1, row.topic_level2].filter(Boolean).join(' › ') || 'Topic'; },
        defaultType: 'bar',
        preferredMetrics: ['call_count', 'avg_sentiment', 'avg_complexity', 'avg_aht']
      }));
      if (pain && pain.length) views.push(makeView({
        id: 'pain',
        name: 'Pain Points',
        rows: pain,
        labelKey: 'pain_point',
        defaultType: 'bar',
        preferredMetrics: ['call_count', 'avg_sentiment', 'brand_switching_risk_pct', 'brand_switching_risk_count', 'switching_count', 'avg_aht']
      }));
      if (views.length) return { title: 'Issue Breakdown', subtitle: '', views: views };
    }

    if (skill === 'vehicle_volume') {
      var vehicleRows = data.vehicles || (Array.isArray(data) && data.length && data[0].modelvehicleline ? data : null);
      var timeRows = data.time_series || (Array.isArray(data) && data.length && data[0].period ? data : null);
      var vv = [];
      if (vehicleRows && vehicleRows.length) vv.push(makeView({
        id: 'vehicles', name: 'By Vehicle', rows: vehicleRows, labelKey: 'modelvehicleline', defaultType: 'bar', preferredMetrics: ['call_count']
      }));
      if (timeRows && timeRows.length) vv.push(makeView({
        id: 'time_series', name: 'Over Time', rows: timeRows, labelKey: 'period', defaultType: 'line', preferredMetrics: ['call_count'], preserveOrder: true
      }));
      if (vv.length) return { title: 'Call Volume', subtitle: '', views: vv };
    }

    if (skill === 'keyword_search') {
      var byVehicle = data.by_vehicle || data.results || normalizeRows(data) || [];
      if (byVehicle.length) {
        return {
          title: 'Keyword Search',
          subtitle: data.total_calls != null ? 'Matching calls: ' + data.total_calls : '',
          views: [makeView({
            id: 'by_vehicle', name: 'By Vehicle', rows: byVehicle, labelKey: 'modelvehicleline', defaultType: 'bar', preferredMetrics: ['call_count', 'negative_pct', 'avg_sentiment']
          })]
        };
      }
    }

    // ── vehicle_agent: vin_history ──────────────────────────────────────────────
    if (skill === 'vin_history') {
      var vinRows = data.lemon_candidates || normalizeRows(data) || [];
      if (vinRows.length) {
        return {
          title: 'VIN History — Problem Vehicles',
          subtitle: data.total_problem_vehicles != null ? 'Problem vehicles: ' + data.total_problem_vehicles : '',
          views: [makeView({
            id: 'lemon', name: 'Lemon Candidates', rows: vinRows,
            labelKey: 'vin_masked', defaultType: 'bar',
            preferredMetrics: ['call_count', 'days_span', 'avg_sentiment']
          })]
        };
      }
    }

    // ── vehicle_agent: model_year_analysis ────────────────────────────────────────
    if (skill === 'model_year_analysis') {
      var myRows = data.results || data.year_breakdown || normalizeRows(data) || [];
      if (myRows.length) {
        return {
          title: 'Model Year Analysis',
          subtitle: data.metadata && data.metadata.vehicle_filter ? String(data.metadata.vehicle_filter) : '',
          views: [makeView({
            id: 'years', name: 'By Model Year', rows: myRows,
            labelKey: 'model_year', defaultType: 'bar', preserveOrder: true,
            preferredMetrics: ['call_count', 'avg_aht_minutes', 'avg_complexity', 'avg_overall_sentiment']
          })]
        };
      }
    }

    // ── vehicle_agent: third_party_mentions ───────────────────────────────────────
    if (skill === 'third_party_mentions') {
      var tpmViews = [];
      var tpmVehicles = data.top_vehicles || [];
      var tpmCategories = data.issue_categories || [];
      if (tpmVehicles.length) tpmViews.push(makeView({
        id: 'vehicles', name: 'By Vehicle', rows: tpmVehicles,
        labelKey: 'modelvehicleline', defaultType: 'bar',
        preferredMetrics: ['mention_count', 'avg_sentiment']
      }));
      if (tpmCategories.length) tpmViews.push(makeView({
        id: 'categories', name: 'Issue Categories', rows: tpmCategories,
        labelKey: 'category', defaultType: 'pie',
        preferredMetrics: ['mention_count', 'avg_sentiment']
      }));
      if (tpmViews.length) {
        return {
          title: 'Third-Party Mentions' + (data.entity ? ' — ' + data.entity : ''),
          subtitle: data.total_mentions != null ? 'Total mentions: ' + data.total_mentions : '',
          views: tpmViews
        };
      }
    }

    // ── operations_agent: aht_analysis ────────────────────────────────────────────
    if (skill === 'aht_analysis') {
      var ahtViews = [];
      var ahtRows = data.aht_analysis || normalizeRows(data) || [];
      var ahtDrivers = data.aht_drivers || [];
      if (ahtRows.length) ahtViews.push(makeView({
        id: 'aht', name: 'AHT Analysis', rows: ahtRows,
        defaultType: 'bar',
        preferredMetrics: ['avg_aht_minutes', 'total_calls', 'avg_complexity', 'transfer_rate_pct', 'avg_sentiment']
      }));
      if (ahtDrivers.length) ahtViews.push(makeView({
        id: 'drivers', name: 'AHT Drivers', rows: ahtDrivers,
        defaultType: 'bar',
        preferredMetrics: ['avg_aht_minutes', 'call_count', 'avg_complexity']
      }));
      if (ahtViews.length) return { title: 'AHT Analysis', subtitle: '', views: ahtViews };
    }

    // ── operations_agent: team_volume ─────────────────────────────────────────────
    if (skill === 'team_volume') {
      var tvRows = data.results || normalizeRows(data) || [];
      if (tvRows.length) {
        return {
          title: 'Team Volume',
          subtitle: data.metadata && data.metadata.total_calls ? 'Total calls: ' + data.metadata.total_calls : '',
          views: [makeView({
            id: 'teams', name: 'Results', rows: tvRows,
            defaultType: 'bar',
            preferredMetrics: ['total_calls', 'call_count', 'avg_aht_minutes', 'avg_sentiment', 'avg_complexity']
          })]
        };
      }
    }

    // ── operations_agent: temporal_comparison ─────────────────────────────────────
    if (skill === 'temporal_comparison') {
      var tcViews = [];
      var dimChanges = getAtPath(data, 'dimensional_analysis.changes') || [];
      var incIssues = getAtPath(data, 'change_summary.increasing_issues') || [];
      var decIssues = getAtPath(data, 'change_summary.decreasing_issues') || [];
      if (dimChanges.length) tcViews.push(makeView({
        id: 'changes', name: 'All Changes', rows: dimChanges,
        defaultType: 'bar',
        preferredMetrics: ['call_volume_change_pct', 'p2_calls', 'p1_calls', 'sentiment_change']
      }));
      if (incIssues.length) tcViews.push(makeView({
        id: 'increasing', name: 'Increasing', rows: incIssues,
        defaultType: 'bar',
        preferredMetrics: ['call_volume_change_pct', 'p2_calls', 'p1_calls']
      }));
      if (decIssues.length) tcViews.push(makeView({
        id: 'decreasing', name: 'Decreasing', rows: decIssues,
        defaultType: 'bar',
        preferredMetrics: ['call_volume_change_pct', 'p2_calls', 'p1_calls']
      }));
      if (tcViews.length) return { title: 'Temporal Comparison', subtitle: '', views: tcViews };
    }

    // ── operations_agent: hour_of_day ─────────────────────────────────────────────
    if (skill === 'hour_of_day') {
      var hodRows = data.hourly_data || normalizeRows(data) || [];
      if (hodRows.length) {
        return {
          title: 'Hour of Day Analysis',
          subtitle: '',
          views: [makeView({
            id: 'hourly', name: 'By Hour', rows: hodRows,
            labelKey: 'hour_of_day', defaultType: 'line', preserveOrder: true,
            preferredMetrics: ['total_calls', 'avg_handle_time_minutes', 'avg_sentiment', 'transfer_rate_pct', 'avg_complexity']
          })]
        };
      }
    }

    // ── operations_agent: day_of_week ─────────────────────────────────────────────
    if (skill === 'day_of_week') {
      var dowRows = data.daily_data || normalizeRows(data) || [];
      if (dowRows.length) {
        return {
          title: 'Day of Week Analysis',
          subtitle: '',
          views: [makeView({
            id: 'daily', name: 'By Day', rows: dowRows,
            labelKey: 'day_name', defaultType: 'bar', preserveOrder: true,
            preferredMetrics: ['total_calls', 'avg_handle_time_minutes', 'avg_sentiment', 'transfer_rate_pct', 'avg_complexity']
          })]
        };
      }
    }

    // ── operations_agent: regional_analysis ───────────────────────────────────────
    if (skill === 'regional_analysis') {
      var regRows = data.results || normalizeRows(data) || [];
      if (regRows.length) {
        return {
          title: 'Regional Analysis',
          subtitle: '',
          views: [makeView({
            id: 'regions', name: 'By Region', rows: regRows,
            defaultType: 'bar',
            preferredMetrics: ['total_calls', 'call_count', 'avg_aht_minutes', 'avg_sentiment', 'avg_complexity']
          })]
        };
      }
    }

    // ── operations_agent: trend_analysis ──────────────────────────────────────────
    if (skill === 'trend_analysis') {
      var trendRows = data.trend_data || normalizeRows(data) || [];
      if (trendRows.length) {
        return {
          title: 'Trend Analysis',
          subtitle: data.metadata && data.metadata.trend_period ? 'Period: ' + data.metadata.trend_period : '',
          views: [makeView({
            id: 'trends', name: 'Trend', rows: trendRows,
            labelKey: 'period', defaultType: 'line', preserveOrder: true,
            preferredMetrics: ['total_calls', 'avg_aht_minutes', 'avg_sentiment', 'avg_complexity', 'volume_change_pct']
          })]
        };
      }
    }

    // ── operations_agent: complexity_analysis ─────────────────────────────────────
    if (skill === 'complexity_analysis') {
      var cxViews = [];
      var cxDrivers = data.complexity_drivers || [];
      var cxGroups = getAtPath(data, 'complexity_analysis.groups') || [];
      if (cxDrivers.length) cxViews.push(makeView({
        id: 'drivers', name: 'Complexity Drivers', rows: cxDrivers,
        defaultType: 'bar',
        preferredMetrics: ['call_count', 'avg_complexity', 'avg_aht_minutes', 'avg_sentiment']
      }));
      if (cxGroups.length) cxViews.push(makeView({
        id: 'groups', name: 'By Group', rows: cxGroups,
        defaultType: 'bar',
        preferredMetrics: ['call_count', 'avg_complexity', 'avg_aht_minutes']
      }));
      if (cxViews.length) return { title: 'Complexity Analysis', subtitle: '', views: cxViews };
    }

    // ── operations_agent: callback_analysis ───────────────────────────────────────
    if (skill === 'callback_analysis') {
      var cbDrivers = data.callback_drivers || [];
      if (cbDrivers.length) {
        return {
          title: 'Callback Analysis',
          subtitle: getAtPath(data, 'callback_analysis.overall.callback_rate_pct') != null
            ? 'Callback rate: ' + getAtPath(data, 'callback_analysis.overall.callback_rate_pct') + '%' : '',
          views: [makeView({
            id: 'drivers', name: 'Callback Drivers', rows: cbDrivers,
            defaultType: 'bar',
            preferredMetrics: ['callback_count', 'callback_rate_pct', 'call_count', 'avg_aht_minutes', 'avg_sentiment']
          })]
        };
      }
    }

    // ── operations_agent: team_routing_analysis ───────────────────────────────────
    if (skill === 'team_routing_analysis') {
      var trRows = data.team_routing || normalizeRows(data) || [];
      if (trRows.length) {
        return {
          title: 'Team Routing Analysis',
          subtitle: '',
          views: [makeView({
            id: 'teams', name: 'By Team', rows: trRows,
            labelKey: 'agent_team', defaultType: 'bar',
            preferredMetrics: ['call_count', 'pct_of_topic', 'avg_aht', 'avg_complexity', 'transfer_rate']
          })]
        };
      }
    }

    // ── sentiment_agent: sentiment_deep_dive ──────────────────────────────────────
    if (skill === 'sentiment_deep_dive') {
      var sdTopics = data.topics_analyzed || normalizeRows(data) || [];
      if (sdTopics.length) {
        var sdFlat = sdTopics.map(function (r) {
          return Object.assign({}, r, {
            positive_pct: getAtPath(r, 'sentiment_distribution.positive.pct'),
            negative_pct: getAtPath(r, 'sentiment_distribution.negative.pct'),
            neutral_pct: getAtPath(r, 'sentiment_distribution.neutral.pct')
          });
        });
        return {
          title: 'Sentiment Deep Dive',
          subtitle: data.vehicle && data.vehicle !== 'all' ? 'Vehicle: ' + data.vehicle : '',
          views: [makeView({
            id: 'topics', name: 'By Topic', rows: sdFlat,
            labelKey: 'topic', defaultType: 'bar',
            preferredMetrics: ['call_count', 'avg_sentiment', 'negative_pct', 'positive_pct']
          })]
        };
      }
    }

    // ── sentiment_agent: sentiment_by_vehicle ─────────────────────────────────────
    if (skill === 'sentiment_by_vehicle') {
      var sbvRows = normalizeRows(data) || [];
      if (sbvRows.length) {
        return {
          title: 'Sentiment by Vehicle',
          subtitle: '',
          views: [makeView({
            id: 'vehicles', name: 'By Vehicle', rows: sbvRows,
            labelKey: 'modelvehicleline', defaultType: 'bar',
            preferredMetrics: ['total_calls', 'avg_sentiment', 'negative_pct', 'positive_pct', 'avg_complexity']
          })]
        };
      }
    }

    // ── sentiment_agent: nps_trend ────────────────────────────────────────────────
    if (skill === 'nps_trend') {
      var npsRows = normalizeRows(data) || [];
      if (npsRows.length) {
        return {
          title: 'NPS Trend',
          subtitle: '',
          views: [makeView({
            id: 'nps', name: 'NPS Over Time', rows: npsRows,
            defaultType: 'line', preserveOrder: true,
            preferredMetrics: ['avg_nps', 'call_count', 'avg_fcr', 'avg_brand_trust']
          })]
        };
      }
    }

    // ── sentiment_agent: agent_customer_sentiment ─────────────────────────────────
    if (skill === 'agent_customer_sentiment') {
      var acsRows = normalizeRows(data) || [];
      if (acsRows.length) {
        return {
          title: 'Agent vs Customer Sentiment',
          subtitle: '',
          views: [makeView({
            id: 'comparison', name: 'Sentiment Gap', rows: acsRows,
            defaultType: 'bar',
            preferredMetrics: ['avg_agent_sentiment', 'avg_customer_sentiment', 'sentiment_gap', 'call_count']
          })]
        };
      }
    }

    // ── sentiment_agent: resolution_analysis ──────────────────────────────────────
    if (skill === 'resolution_analysis') {
      var resRows = data.breakdown || [];
      if (resRows.length) {
        return {
          title: 'Resolution Analysis',
          subtitle: data.fcr_rate != null ? 'FCR Rate: ' + data.fcr_rate + '%' : '',
          views: [makeView({
            id: 'breakdown', name: 'By Category', rows: resRows,
            defaultType: 'bar',
            preferredMetrics: ['call_count', 'fcr_rate', 'avg_sentiment']
          })]
        };
      }
    }

    // ── bluecruise_agent: helper to extract data from {status, data, insights} ───
    function bcData(d) { return d && d.data ? d.data : normalizeRows(d) || []; }
    function bcSub(d) {
      var s = getAtPath(d, 'insights.summary.total_calls_analyzed');
      return s != null ? 'Calls analyzed: ' + s : '';
    }

    // ── bluecruise_agent: call_volume ─────────────────────────────────────────────
    if (skill === 'call_volume') {
      var bcvRows = bcData(data);
      if (bcvRows.length) {
        return {
          title: 'BlueCruise Call Volume',
          subtitle: bcSub(data),
          views: [makeView({
            id: 'volume', name: 'Volume', rows: bcvRows,
            labelKey: 'period', defaultType: 'line', preserveOrder: true,
            preferredMetrics: ['call_count', 'complaint_pct', 'avg_sentiment']
          })]
        };
      }
    }

    // ── bluecruise_agent: top_issues ──────────────────────────────────────────────
    if (skill === 'top_issues') {
      var btiRows = bcData(data);
      if (btiRows.length) {
        return {
          title: 'BlueCruise Top Issues',
          subtitle: bcSub(data),
          views: [makeView({
            id: 'issues', name: 'Issues', rows: btiRows,
            defaultType: 'bar',
            preferredMetrics: ['call_count', 'negative_pct', 'avg_sentiment', 'churn_risk_pct']
          })]
        };
      }
    }

    // ── bluecruise_agent: vehicle_breakdown ───────────────────────────────────────
    if (skill === 'vehicle_breakdown') {
      var bvbRows = bcData(data);
      if (bvbRows.length) {
        return {
          title: 'BlueCruise Vehicle Breakdown',
          subtitle: bcSub(data),
          views: [makeView({
            id: 'vehicles', name: 'By Vehicle', rows: bvbRows,
            labelKey: 'modelvehicleline', defaultType: 'bar',
            preferredMetrics: ['call_count', 'negative_pct', 'avg_sentiment', 'churn_risk_pct']
          })]
        };
      }
    }

    // ── bluecruise_agent: vehicle_topics ──────────────────────────────────────────
    if (skill === 'vehicle_topics') {
      var bvtRows = bcData(data);
      if (bvtRows.length) {
        return {
          title: 'BlueCruise Vehicle Topics',
          subtitle: bcSub(data),
          views: [makeView({
            id: 'topics', name: 'Topics', rows: bvtRows,
            defaultType: 'bar',
            preferredMetrics: ['call_count', 'negative_pct', 'avg_sentiment']
          })]
        };
      }
    }

    // ── bluecruise_agent: sentiment_trend ─────────────────────────────────────────
    if (skill === 'sentiment_trend') {
      var bstRows = bcData(data);
      if (bstRows.length) {
        return {
          title: 'BlueCruise Sentiment Trend',
          subtitle: bcSub(data),
          views: [makeView({
            id: 'sentiment', name: 'Sentiment', rows: bstRows,
            labelKey: 'period', defaultType: 'line', preserveOrder: true,
            preferredMetrics: ['avg_sentiment', 'negative_pct', 'call_count']
          })]
        };
      }
    }

    // ── bluecruise_agent: contact_volume_trend ────────────────────────────────────
    if (skill === 'contact_volume_trend') {
      var bcctRows = bcData(data);
      if (bcctRows.length) {
        return {
          title: 'BlueCruise Contact Volume Trend',
          subtitle: bcSub(data),
          views: [makeView({
            id: 'trend', name: 'Volume Trend', rows: bcctRows,
            labelKey: 'period', defaultType: 'line', preserveOrder: true,
            preferredMetrics: ['call_count', 'complaint_count', 'complaint_pct']
          })]
        };
      }
    }

    // ── bluecruise_agent: subscription_issues ─────────────────────────────────────
    if (skill === 'subscription_issues') {
      var bsiRows = bcData(data);
      if (bsiRows.length) {
        return {
          title: 'BlueCruise Subscription Issues',
          subtitle: bcSub(data),
          views: [makeView({
            id: 'subscriptions', name: 'Issues', rows: bsiRows,
            defaultType: 'bar',
            preferredMetrics: ['call_count', 'negative_pct', 'avg_sentiment', 'churn_risk_pct']
          })]
        };
      }
    }

    // ── bluecruise_agent: subscription_stage ──────────────────────────────────────
    if (skill === 'subscription_stage') {
      var bssRows = bcData(data);
      if (bssRows.length) {
        return {
          title: 'BlueCruise Subscription Stage',
          subtitle: bcSub(data),
          views: [makeView({
            id: 'stages', name: 'By Stage', rows: bssRows,
            defaultType: 'bar',
            preferredMetrics: ['call_count', 'negative_pct', 'avg_sentiment']
          })]
        };
      }
    }

    // ── bluecruise_agent: keyword_search (BC-specific) ───────────────────────────
    if (skill === 'keyword_search' && data && data.status === 'success') {
      var bksRows = bcData(data);
      if (bksRows.length) {
        return {
          title: 'BlueCruise Keyword Search',
          subtitle: bcSub(data),
          views: [makeView({
            id: 'results', name: 'Results', rows: bksRows,
            defaultType: 'bar',
            preferredMetrics: ['call_count', 'negative_pct', 'avg_sentiment']
          })]
        };
      }
    }

    // ── Generic fallback ─────────────────────────────────────────────────────────
    var extracted = extractArrayViews(data, '', []);
    var built = extracted.map(function (v, idx) {
      return makeView({
        id: v.id || ('view_' + idx),
        name: v.name || ('View ' + (idx + 1)),
        rows: v.rows,
        defaultType: /time|period|trend|month|week|day/i.test(v.id) ? 'line' : 'bar'
      });
    }).filter(Boolean);
    if (built.length) {
      return { title: humanize(skill || 'Chart'), subtitle: '', views: built };
    }

    var rows = normalizeRows(data);
    if (rows && rows.length) {
      return {
        title: humanize(skill || 'Chart'),
        subtitle: '',
        views: [makeView({ id: 'default', name: 'Results', rows: rows })]
      };
    }

    return null;
  }

  function getActiveView() {
    if (!specCache || !specCache.views || !specCache.views.length) return null;
    return specCache.views.find(function (v) { return v.id === state.viewId; }) || specCache.views[0];
  }

  function getActiveMetric(view) {
    view = view || getActiveView();
    if (!view || !view.metrics || !view.metrics.length) return null;
    return view.metrics.find(function (m) { return m.key === state.metricKey; }) || view.metrics[0];
  }

  function isDark() {
    return document.documentElement.getAttribute('data-theme') === 'dark';
  }

  function fmtVal(v) {
    if (typeof v !== 'number' || !isFinite(v)) return String(v);
    if (Math.abs(v) >= 1e6) return (v / 1e6).toFixed(1) + 'M';
    if (Math.abs(v) >= 1e3) return (v / 1e3).toFixed(v % 1e3 === 0 ? 0 : 1) + 'k';
    if (Math.abs(v) < 1 && v !== 0) return v.toFixed(2);
    return Number.isInteger(v) ? String(v) : v.toFixed(1);
  }

  function colorAt(i, alpha) {
    var hex = PALETTE[i % PALETTE.length].replace('#', '');
    if (alpha == null) return '#' + hex;
    var a = Math.max(0, Math.min(255, Math.round(alpha * 255))).toString(16).padStart(2, '0');
    return '#' + hex + a;
  }

  function sortRowsForMetric(view, metric, type) {
    var items = view.rows.map(function (row, idx) {
      return {
        row: row,
        flat: view.flatRows[idx],
        label: truncate(view.labelFn(row, view.flatRows[idx]) || 'Unknown', 52),
        value: metricValue(metric, row, view.flatRows[idx])
      };
    }).filter(function (x) { return x.label && x.value != null && isFinite(x.value); });

    if (!items.length) return [];
    var preserve = view.preserveOrder || type === 'line' || items.every(function (x) { return isDateLike(x.label); });
    if (!preserve) {
      items.sort(function (a, b) { return b.value - a.value; });
    }
    if ((type === 'pie' || type === 'doughnut') && items.length > PIE_MAX) {
      var head = items.slice(0, PIE_MAX - 1);
      var tail = items.slice(PIE_MAX - 1);
      var other = tail.reduce(function (sum, x) { return sum + x.value; }, 0);
      head.push({ label: 'Other', value: other, row: null, flat: null });
      return head;
    }
    return items;
  }

  function buildScatterSelectors(view) {
    var sx = document.getElementById('dcm-sx');
    var sy = document.getElementById('dcm-sy');
    if (!sx || !sy) return;
    sx.innerHTML = '';
    sy.innerHTML = '';
    view.metrics.forEach(function (m, idx) {
      var ox = document.createElement('option');
      ox.value = m.key;
      ox.textContent = m.label;
      sx.appendChild(ox);
      var oy = document.createElement('option');
      oy.value = m.key;
      oy.textContent = m.label;
      sy.appendChild(oy);
      if (!state.scatterX && idx === 0) state.scatterX = m.key;
      if (!state.scatterY && idx === 1) state.scatterY = m.key;
    });
    if (view.metrics.length === 1) state.scatterY = view.metrics[0].key;
    sx.value = state.scatterX || view.metrics[0].key;
    sy.value = state.scatterY || view.metrics[Math.min(1, view.metrics.length - 1)].key;
  }

  function renderEmpty(msg) {
    var canvas = document.getElementById('dcm-canvas');
    if (!canvas) return;
    canvas.style.display = 'none';
    var wrap = canvas.parentElement;
    wrap.innerHTML = '<div class="dcm-empty">' + msg + '</div>';
  }

  function restoreCanvas() {
    var wrap = document.querySelector('.dcm-cw');
    if (!wrap) return null;
    wrap.innerHTML = '<canvas id="dcm-canvas"></canvas>';
    return document.getElementById('dcm-canvas');
  }

  function renderChart() {
    if (!specCache) return;
    if (activeChart) { activeChart.destroy(); activeChart = null; }
    var view = getActiveView();
    var metric = getActiveMetric(view);
    var canvas = restoreCanvas();
    if (!view || !metric || !canvas) return;

    var type = state.type || view.defaultType || 'bar';
    var scatterCfg = document.getElementById('dcm-scatter');
    if (scatterCfg) scatterCfg.style.display = type === 'scatter' ? 'flex' : 'none';

    if (type === 'scatter') {
      buildScatterSelectors(view);
      if (view.metrics.length < 2) {
        renderEmpty('Scatter needs at least 2 numeric metrics. Try Bar or Pie instead.');
        return;
      }
      var xMetric = view.metrics.find(function (m) { return m.key === state.scatterX; }) || view.metrics[0];
      var yMetric = view.metrics.find(function (m) { return m.key === state.scatterY; }) || view.metrics[1] || view.metrics[0];
      var pts = view.rows.map(function (row, idx) {
        var flat = view.flatRows[idx];
        return {
          x: metricValue(xMetric, row, flat),
          y: metricValue(yMetric, row, flat),
          _l: truncate(view.labelFn(row, flat) || 'Point', 80)
        };
      }).filter(function (p) { return p.x != null && p.y != null && isFinite(p.x) && isFinite(p.y); });
      if (!pts.length) {
        renderEmpty('No chartable scatter points found for this view.');
        return;
      }
      activeChart = new Chart(canvas.getContext('2d'), {
        type: 'scatter',
        data: { datasets: [{ label: xMetric.label + ' vs ' + yMetric.label, data: pts, backgroundColor: colorAt(0, 0.7), borderColor: colorAt(0), pointRadius: 5, pointHoverRadius: 7 }] },
        options: chartOptions('scatter', xMetric.label, yMetric.label, function (ctx) {
          var p = ctx.raw;
          return ' ' + p._l + ': ' + xMetric.label + '=' + fmtVal(p.x) + ', ' + yMetric.label + '=' + fmtVal(p.y);
        })
      });
      return;
    }

    var items = sortRowsForMetric(view, metric, type);
    if (!items.length) {
      renderEmpty('No chartable values found for this metric.');
      return;
    }
    var labels = items.map(function (x) { return x.label; });
    var values = items.map(function (x) { return x.value; });
    var isPie = type === 'pie' || type === 'doughnut';
    var isLine = type === 'line';
    var isHBar = type === 'hbar';

    activeChart = new Chart(canvas.getContext('2d'), {
      type: isHBar ? 'bar' : type,
      data: {
        labels: labels,
        datasets: [{
          label: metric.label,
          data: values,
          backgroundColor: isLine ? colorAt(0, 0.18) : (isPie || isHBar ? labels.map(function (_, i) { return colorAt(i, isPie ? 0.78 : 0.9); }) : labels.map(function (_, i) { return colorAt(i, 0.82); })),
          borderColor: isPie || isHBar ? labels.map(function (_, i) { return colorAt(i); }) : (isLine ? colorAt(0) : labels.map(function (_, i) { return colorAt(i); })),
          borderWidth: isLine ? 2 : 1.5,
          fill: isLine,
          tension: 0.28,
          pointRadius: isLine ? 4 : undefined,
          pointHoverRadius: isLine ? 6 : undefined,
          borderRadius: isLine || isPie ? undefined : 5,
          hoverOffset: isPie ? 8 : undefined
        }]
      },
      options: chartOptions(type, view.labelKey || 'Label', metric.label, function (ctx) {
        if (isPie) {
          var total = ctx.dataset.data.reduce(function (a, b) { return a + b; }, 0);
          var pct = total > 0 ? ((ctx.raw / total) * 100).toFixed(1) : '0.0';
          return ' ' + ctx.label + ': ' + fmtVal(ctx.raw) + ' (' + pct + '%)';
        }
        return ' ' + metric.label + ': ' + fmtVal(ctx.raw);
      }, isHBar)
    });
  }

  function chartOptions(type, xTitle, yTitle, tooltipFn, isHBar) {
    var dark = isDark();
    var gridC = dark ? 'rgba(255,255,255,.08)' : 'rgba(0,0,0,.06)';
    var tickC = dark ? '#a2acb0' : '#5c666b';
    var isPie = type === 'pie' || type === 'doughnut';
    return {
      indexAxis: isHBar ? 'y' : 'x',
      responsive: true,
      maintainAspectRatio: !isHBar,
      animation: { duration: 260, easing: 'easeOutQuart' },
      interaction: { mode: 'nearest', intersect: false },
      plugins: {
        legend: isPie ? { position: 'right', labels: { color: tickC, boxWidth: 12, padding: 12, font: { size: 11 } } } : { display: false },
        tooltip: { callbacks: { label: tooltipFn } }
      },
      scales: isPie ? {} : {
        x: {
          beginAtZero: !!isHBar,
          title: { display: !isHBar, text: humanize(xTitle), color: tickC, font: { size: 11 } },
          grid: isHBar ? { color: gridC } : { display: false },
          ticks: { color: tickC, font: { size: 11 }, maxRotation: isHBar ? 0 : 30, minRotation: 0, callback: isHBar ? function (v) { return fmtVal(v); } : undefined }
        },
        y: {
          beginAtZero: !isHBar,
          title: { display: isHBar, text: humanize(yTitle), color: tickC, font: { size: 11 } },
          grid: isHBar ? { display: false } : { color: gridC },
          ticks: { color: tickC, font: { size: 11 }, callback: !isHBar ? function (v) { return fmtVal(v); } : undefined }
        }
      }
    };
  }

  function buildModal() {
    var el = document.createElement('div');
    el.id = MODAL_ID;
    el.innerHTML = [
      '<div class="dcm-bd"></div>',
      '<div class="dcm-dlg">',
        '<div class="dcm-hdr">',
          '<div class="dcm-title-wrap">',
            '<div class="dcm-ttl">Chart</div>',
            '<div class="dcm-sub"></div>',
          '</div>',
          '<div class="dcm-ctrl">',
            '<div class="dcm-types">',
              '<button class="dcm-tb" data-t="bar">Bar</button>',
              '<button class="dcm-tb" data-t="hbar">H-Bar</button>',
              '<button class="dcm-tb" data-t="line">Line</button>',
              '<button class="dcm-tb" data-t="scatter">Scatter</button>',
              '<button class="dcm-tb" data-t="pie">Pie</button>',
              '<button class="dcm-tb" data-t="doughnut">Doughnut</button>',
            '</div>',
            '<button class="dcm-x" aria-label="Close chart">&#x2715;</button>',
          '</div>',
        '</div>',
        '<div class="dcm-body">',
          '<div id="dcm-view-row" class="dcm-chip-row"></div>',
          '<div id="dcm-metric-row" class="dcm-chip-row"></div>',
          '<div id="dcm-scatter" class="dcm-scatter">',
            '<strong>X:</strong>',
            '<select id="dcm-sx" class="dcm-sel"></select>',
            '<strong>Y:</strong>',
            '<select id="dcm-sy" class="dcm-sel"></select>',
          '</div>',
          '<div class="dcm-cw"><canvas id="dcm-canvas"></canvas></div>',
          '<div id="dcm-note" class="dcm-note"></div>',
        '</div>',
      '</div>'
    ].join('');
    return el;
  }

  function closeModal() {
    var m = document.getElementById(MODAL_ID);
    if (m) m.classList.remove('dcm-open');
    if (activeChart) { activeChart.destroy(); activeChart = null; }
    specCache = null;
    state = { type: 'bar', viewId: null, metricKey: null, scatterX: null, scatterY: null };
  }

  function getModal() {
    var m = document.getElementById(MODAL_ID);
    if (m) return m;
    m = buildModal();
    document.body.appendChild(m);
    m.querySelector('.dcm-bd').addEventListener('click', closeModal);
    m.querySelector('.dcm-x').addEventListener('click', closeModal);
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeModal(); });
    m.querySelectorAll('.dcm-tb').forEach(function (btn) {
      btn.addEventListener('click', function () {
        if (!specCache) return;
        state.type = btn.dataset.t;
        syncTypeButtons();
        renderChart();
      });
    });
    ['dcm-sx', 'dcm-sy'].forEach(function (id) {
      var el = document.getElementById(id);
      if (!el) return;
      el.addEventListener('change', function () {
        if (id === 'dcm-sx') state.scatterX = el.value;
        else state.scatterY = el.value;
        renderChart();
      });
    });
    return m;
  }

  function syncTypeButtons() {
    var m = document.getElementById(MODAL_ID);
    if (!m) return;
    m.querySelectorAll('.dcm-tb').forEach(function (btn) {
      btn.classList.toggle('act', btn.dataset.t === state.type);
    });
  }

  function renderViewChips() {
    var row = document.getElementById('dcm-view-row');
    if (!row || !specCache) return;
    row.innerHTML = '';
    if (!specCache.views || specCache.views.length <= 1) return;
    row.appendChild(chipLabel('View'));
    specCache.views.forEach(function (view, idx) {
      var chip = document.createElement('button');
      chip.className = 'dcm-chip' + ((state.viewId || specCache.views[0].id) === view.id ? ' on' : '');
      chip.textContent = view.name || ('View ' + (idx + 1));
      chip.addEventListener('click', function () {
        state.viewId = view.id;
        state.metricKey = view.defaultMetric;
        state.type = view.defaultType || 'bar';
        state.scatterX = null;
        state.scatterY = null;
        renderControls();
        renderChart();
      });
      row.appendChild(chip);
    });
  }

  function chipLabel(text) {
    var span = document.createElement('span');
    span.className = 'dcm-chip-label';
    span.textContent = text;
    return span;
  }

  function renderMetricChips() {
    var row = document.getElementById('dcm-metric-row');
    var note = document.getElementById('dcm-note');
    if (!row || !specCache) return;
    row.innerHTML = '';
    var view = getActiveView();
    if (!view) return;
    row.appendChild(chipLabel('Metric'));
    view.metrics.forEach(function (metric, idx) {
      var chip = document.createElement('button');
      chip.className = 'dcm-chip' + ((state.metricKey || view.defaultMetric) === metric.key ? ' on' : '');
      chip.innerHTML = '<span class="dcm-dot" style="background:' + (metric.color || PALETTE[idx % PALETTE.length]) + '"></span>' + metric.label;
      chip.addEventListener('click', function () {
        state.metricKey = metric.key;
        renderMetricChips();
        renderChart();
      });
      row.appendChild(chip);
    });
    if (note) note.textContent = view.note || '';
  }

  function renderControls() {
    renderViewChips();
    renderMetricChips();
    syncTypeButtons();
  }

  function openModal(spec) {
    specCache = spec;
    var view = spec.views[0];
    state.viewId = view.id;
    state.metricKey = view.defaultMetric;
    state.type = view.defaultType || 'bar';
    state.scatterX = null;
    state.scatterY = null;

    var m = getModal();
    m.querySelector('.dcm-ttl').textContent = spec.title || 'Chart';
    m.querySelector('.dcm-sub').textContent = spec.subtitle || '';
    renderControls();
    m.classList.add('dcm-open');
    requestAnimationFrame(renderChart);
  }

  function getActiveConv() {
    try {
      var raw = localStorage.getItem('daisy_convs');
      if (!raw) return null;
      var convs = JSON.parse(raw);
      if (!convs || !convs.length) return null;
      var ansCount = document.querySelectorAll('.turn-daisy').length;
      var candidates = convs.filter(function (c) {
        var dc = (c.messages || []).filter(function (m) { return m.role === 'daisy'; }).length;
        return dc === ansCount;
      });
      if (candidates.length) {
        return candidates.reduce(function (a, b) {
          return new Date(a.updatedAt || 0) >= new Date(b.updatedAt || 0) ? a : b;
        });
      }
      return convs.reduce(function (a, b) {
        return new Date(a.updatedAt || 0) >= new Date(b.updatedAt || 0) ? a : b;
      });
    } catch (e) {
      return null;
    }
  }

  function findMsgForBtn(btn) {
    var ansEl = btn.closest('.turn-daisy');
    if (!ansEl) return null;
    var conv = getActiveConv();
    if (!conv || !conv.messages) return null;
    var allAns = Array.from(document.querySelectorAll('.turn-daisy'));
    var idx = allAns.indexOf(ansEl);
    if (idx < 0) return null;
    var daisyMsgs = conv.messages.filter(function (m) { return m.role === 'daisy'; });
    return daisyMsgs[idx] || null;
  }

  function isChartBtn(btn) {
    if (!btn || btn.tagName !== 'BUTTON') return false;
    var t = (btn.textContent || '').replace(/\s+/g, ' ').trim().toLowerCase();
    return t === 'chart' || t === 'hide chart';
  }

  function onDocClick(e) {
    var btn = e.target.closest('button');
    if (!btn || !isChartBtn(btn)) return;
    e.stopPropagation();
    var msg = findMsgForBtn(btn);
    if (!msg || !msg.data) return;
    var spec = buildSkillSpec(msg.skill, msg.data);
    if (!spec || !spec.views || !spec.views.length) return;
    loadChartJs(function () { openModal(spec); });
  }

  injectCSS();

  var obs = new MutationObserver(function (mutations) {
    mutations.forEach(function (m) {
      m.addedNodes.forEach(function (node) {
        if (node.nodeType !== 1) return;
        if (node.classList && node.classList.contains('viz-root')) node.style.cssText += ';display:none!important';
        var found = node.querySelectorAll ? node.querySelectorAll('.viz-root') : [];
        Array.prototype.forEach.call(found, function (el) { el.style.cssText += ';display:none!important'; });
      });
    });
  });
  obs.observe(document.documentElement, { childList: true, subtree: true });
  document.addEventListener('click', onDocClick, true);
  console.log('[Daisy] Chart renderer v2 loaded');
})();
