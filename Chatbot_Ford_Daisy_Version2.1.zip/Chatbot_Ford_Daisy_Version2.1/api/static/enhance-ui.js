/**
 * DAISY Version 2.1 - UI Enhancement Script
 * Adds download buttons to conversation history and improves functionality
 */

(function() {
    'use strict';

    // Initialize conversation manager
    if (typeof window.daisyConversation === 'undefined') {
        console.log('[TOOL] Loading conversation manager...');

        // Load the conversation download script if not already loaded
        if (!document.querySelector('script[src*="conversation-download"]')) {
            const script = document.createElement('script');
            script.src = '/conversation-download.js';
            script.onload = function() {
                console.log('[OK] Conversation download functionality loaded');
                initializeUI();
            };
            document.head.appendChild(script);
        } else {
            initializeUI();
        }
    } else {
        initializeUI();
    }

    function initializeUI() {
        console.log('🎨 Initializing DAISY UI enhancements...');

        // Auto-initialize conversation tracking
        if (window.daisyConversation) {
            window.daisyConversation.initialize().then(() => {
                console.log('[OK] Conversation tracking initialized');
            }).catch(err => {
                console.warn('[WARN] Conversation tracking failed:', err);
            });
        }

        // Add download buttons to conversation items
        addDownloadButtons();

        // Monitor for new conversation items being added
        observeConversationChanges();

        // Add global download option to header/menu
        addGlobalDownloadOption();

        console.log('[DEPLOY] DAISY UI enhancements ready!');
    }

    function addDownloadButtons() {
        console.log('[INFO] Adding download buttons...');

        // Wait for SvelteKit to fully render
        setTimeout(() => {
            // MUCH MORE PRECISE - only target actual conversation items in the left sidebar
            const selectors = [
                // Only look in the left sidebar/history area
                '.sidebar div:has(span:contains("General"))',
                '.history div:has(span:contains("Today"))',
                // Look for items that have BOTH text content AND are small/specific
                'div[class*="conversation-item"]',
                'li[class*="conversation"]',
                '[data-conversation-id]',
                // Only very specific sidebar items
                'aside div[role="button"]',
                'nav div[role="button"]'
            ];

            let buttonsAdded = 0;

            selectors.forEach(selector => {
                try {
                    const elements = document.querySelectorAll(selector);
                    console.log(`[DEBUG] Selector "${selector}" found ${elements.length} elements`);

                    elements.forEach((element, index) => {
                        // Skip if already has download button
                        if (element.querySelector('.daisy-download-btn')) return;

                        // Look for any button in this element (delete, settings, etc.)
                        const hasButton = element.querySelector('button, [role="button"]');

                        // VERY STRICT - only elements that are clearly conversation items
                        const hasConversationText = element.textContent && (
                            (element.textContent.includes('General') && element.textContent.includes('Today')) ||
                            (element.textContent.trim() === 'hi') ||
                            (element.classList.contains('conversation-item'))
                        );

                        // ONLY add if it's in the sidebar AND looks like a conversation
                        const isInSidebar = element.closest('aside, .sidebar, .history, nav') ||
                                          element.getBoundingClientRect().left < 300; // Left side of screen

                        if (hasButton && hasConversationText && isInSidebar) {
                            console.log(`[INFO] Adding download button to element ${index + 1} (selector: ${selector})`);
                            addDownloadButtonToElement(element);
                            buttonsAdded++;
                        }
                    });
                } catch (e) {
                    // Skip invalid selectors
                    console.log(`[DEBUG] Skipped selector "${selector}": ${e.message}`);
                }
            });

            console.log(`[SUCCESS] Added ${buttonsAdded} download buttons total`);

            // If no buttons were added, try a more desperate approach
            if (buttonsAdded === 0) {
                console.log('[FALLBACK] No buttons added, trying fallback method...');
                addDownloadButtonFallback();
            }
        }, 1000); // Give SvelteKit time to render
    }

    function addDownloadButtonToElement(element) {
        // Skip if download button already exists
        if (element.querySelector('.daisy-download-btn')) return;

        // Create download button
        const downloadBtn = createDownloadButton('current');

        // Find the best place to insert it
        const existingButton = element.querySelector('button, [role="button"]');

        if (existingButton) {
            // Insert right after the existing button
            existingButton.parentNode.insertBefore(downloadBtn, existingButton.nextSibling);
        } else {
            // Just append to the element
            element.appendChild(downloadBtn);
        }

        // Make sure it's visible
        downloadBtn.style.display = 'inline-block';
        downloadBtn.style.visibility = 'visible';
    }

    function addDownloadButtonFallback() {
        // Last resort: just add buttons to anything that might be clickable
        const fallbackElements = document.querySelectorAll('li, div');

        Array.from(fallbackElements).slice(0, 5).forEach((element, index) => {
            if (!element.querySelector('.daisy-download-btn') &&
                element.textContent &&
                element.textContent.trim().length > 0 &&
                element.textContent.trim().length < 50) {  // Likely to be a title/name

                console.log(`[FALLBACK] Adding download button to element ${index + 1}: "${element.textContent.trim().substring(0, 30)}..."`);
                addDownloadButtonToElement(element);
            }
        });
    }

    function addDownloadButtonToItem(item) {
        // Skip if download button already exists
        if (item.querySelector('.daisy-download-btn')) return;

        // Try to extract conversation/session ID
        const conversationId = extractConversationId(item);

        // Find where to insert the download button (near delete button if exists)
        const deleteButton = item.querySelector('button[title*="delete" i], button[aria-label*="delete" i], .delete-btn');
        const insertTarget = deleteButton ? deleteButton.parentElement : item;

        // Create download button
        const downloadBtn = createDownloadButton(conversationId);

        if (deleteButton) {
            // Insert before or after delete button
            deleteButton.parentNode.insertBefore(downloadBtn, deleteButton);
        } else {
            // Append to the item
            insertTarget.appendChild(downloadBtn);
        }
    }

    function addDownloadButtonNear(deleteBtn) {
        // Extract conversation ID from nearby elements
        const conversationId = extractConversationId(deleteBtn.closest('[data-conversation-id], .conversation-item, li, div'));

        // Create download button
        const downloadBtn = createDownloadButton(conversationId);

        // Insert before the delete button
        deleteBtn.parentNode.insertBefore(downloadBtn, deleteBtn);
    }

    function extractConversationId(element) {
        if (!element) return null;

        // Try various ways to get conversation/session ID
        const idSources = [
            () => element.dataset.conversationId,
            () => element.dataset.sessionId,
            () => element.getAttribute('data-id'),
            () => element.id,
            () => element.querySelector('[data-conversation-id]')?.dataset.conversationId,
            () => element.querySelector('[data-session-id]')?.dataset.sessionId,
            // Look for IDs in text content (UUIDs, etc.)
            () => {
                const text = element.textContent || '';
                const uuidMatch = text.match(/[a-f0-9]{8}-?[a-f0-9]{4}-?[a-f0-9]{4}-?[a-f0-9]{4}-?[a-f0-9]{12}/i);
                return uuidMatch ? uuidMatch[0] : null;
            }
        ];

        for (const getIdFunc of idSources) {
            try {
                const id = getIdFunc();
                if (id && id.trim()) return id.trim();
            } catch (e) {
                // Continue to next method
            }
        }

        // Fallback: use current session ID if available
        return window.daisyConversation?.currentSessionId || 'current';
    }

    function createDownloadButton(conversationId) {
        const btn = document.createElement('button');
        btn.className = 'daisy-download-btn';
        btn.innerHTML = '[DOWNLOAD]';
        btn.title = 'Download conversation';
        btn.setAttribute('aria-label', 'Download conversation');

        // Style the button to match existing UI
        btn.style.cssText = `
            background: #007AFF;
            border: none;
            border-radius: 4px;
            color: white;
            padding: 6px 10px;
            margin: 0 2px;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 32px;
            height: 32px;
        `;

        // Hover effects
        btn.addEventListener('mouseenter', () => {
            btn.style.background = '#0056b3';
            btn.style.transform = 'translateY(-1px)';
        });

        btn.addEventListener('mouseleave', () => {
            btn.style.background = '#007AFF';
            btn.style.transform = 'translateY(0)';
        });

        // Click handler
        btn.addEventListener('click', async (e) => {
            e.preventDefault();
            e.stopPropagation();

            try {
                btn.disabled = true;
                btn.innerHTML = '⏳';

                const sessionId = conversationId || window.daisyConversation?.currentSessionId || 'current';

                if (window.daisyConversation) {
                    await window.daisyConversation.downloadConversation('json', sessionId);
                } else {
                    // Fallback: direct API call
                    window.open(`/api/conversations/${sessionId}/download?format=json`, '_blank');
                }

                // Show success
                btn.innerHTML = '[OK]';
                setTimeout(() => {
                    btn.innerHTML = '[DOWNLOAD]';
                    btn.disabled = false;
                }, 1500);

            } catch (error) {
                console.error('Download failed:', error);
                btn.innerHTML = '[ERROR]';
                setTimeout(() => {
                    btn.innerHTML = '[DOWNLOAD]';
                    btn.disabled = false;
                }, 2000);
            }
        });

        return btn;
    }

    function addGlobalDownloadOption() {
        // Look for header, nav, or menu areas to add global download
        const headerSelectors = ['header', 'nav', '.header', '.navbar', '.menu', '.toolbar'];

        for (const selector of headerSelectors) {
            const header = document.querySelector(selector);
            if (header && !header.querySelector('.global-download-btn')) {
                const globalBtn = createGlobalDownloadButton();
                header.appendChild(globalBtn);
                break;
            }
        }
    }

    function createGlobalDownloadButton() {
        const container = document.createElement('div');
        container.className = 'global-download-container';
        container.style.cssText = `
            display: inline-block;
            margin-left: 10px;
            position: relative;
        `;

        const btn = document.createElement('button');
        btn.className = 'global-download-btn';
        btn.innerHTML = '[DOWNLOAD] Download';
        btn.title = 'Download current conversation';
        btn.style.cssText = `
            background: #28a745;
            border: none;
            border-radius: 6px;
            color: white;
            padding: 8px 16px;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.2s ease;
        `;

        btn.addEventListener('click', async () => {
            try {
                if (window.daisyConversation) {
                    await window.daisyConversation.downloadConversation('json');
                } else {
                    const sessionId = 'current';
                    window.open(`/api/conversations/${sessionId}/download?format=json`, '_blank');
                }
            } catch (error) {
                console.error('Global download failed:', error);
                alert('Download failed. Please try again.');
            }
        });

        container.appendChild(btn);
        return container;
    }

    function observeConversationChanges() {
        // Watch for dynamically added conversation items
        const observer = new MutationObserver((mutations) => {
            let shouldUpdate = false;

            mutations.forEach((mutation) => {
                if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                    mutation.addedNodes.forEach((node) => {
                        if (node.nodeType === Node.ELEMENT_NODE) {
                            // Check if the added node or its children might be conversation items
                            const isConversationRelated =
                                node.matches && (
                                    node.matches('[data-conversation-id], .conversation-item, .chat-item') ||
                                    node.querySelector('[data-conversation-id], .conversation-item, .chat-item, button[title*="delete"]')
                                );

                            if (isConversationRelated) {
                                shouldUpdate = true;
                            }
                        }
                    });
                }
            });

            if (shouldUpdate) {
                // Debounce multiple rapid changes
                clearTimeout(window.daisyUpdateTimeout);
                window.daisyUpdateTimeout = setTimeout(() => {
                    addDownloadButtons();
                }, 500);
            }
        });

        // Start observing
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });

        console.log('[WATCH] Watching for new conversation items...');
    }

    // Auto-enhance conversation tracking
    function enhanceConversationTracking() {
        // Intercept query requests to add session tracking
        const originalFetch = window.fetch;
        window.fetch = function(...args) {
            const [url, options = {}] = args;

            // Enhance /api/query requests
            if (url.includes('/api/query') && options.method === 'POST') {
                try {
                    if (options.body && window.daisyConversation?.currentSessionId) {
                        const body = JSON.parse(options.body);
                        if (!body.session_id) {
                            body.session_id = window.daisyConversation.currentSessionId;
                            options.body = JSON.stringify(body);
                        }
                    }
                } catch (e) {
                    // If parsing fails, continue with original request
                }
            }

            return originalFetch.apply(this, args);
        };
    }

    // Initialize when DOM is ready AND when SvelteKit loads
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            enhanceConversationTracking();
            // Also try again after SvelteKit loads
            setTimeout(initializeUI, 2000);
            setTimeout(initializeUI, 5000);
        });
    } else {
        enhanceConversationTracking();
        // Try immediately and again after SvelteKit loads
        setTimeout(initializeUI, 1000);
        setTimeout(initializeUI, 3000);
        setTimeout(initializeUI, 6000);
    }

    // Monitor for SvelteKit route changes
    let lastUrl = location.href;
    new MutationObserver(() => {
        const url = location.href;
        if (url !== lastUrl) {
            lastUrl = url;
            console.log('[INFO] Route changed, re-adding download buttons...');
            setTimeout(addDownloadButtons, 1000);
        }
    }).observe(document, { subtree: true, childList: true });

    console.log('[TOOL] DAISY UI Enhancement script loaded');
})();