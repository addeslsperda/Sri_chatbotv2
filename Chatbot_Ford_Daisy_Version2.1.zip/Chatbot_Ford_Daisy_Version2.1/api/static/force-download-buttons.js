/**
 * Force Download Button Integration - Manual Trigger
 * Run this in browser console if download buttons don't appear automatically
 */

window.forceAddDownloadButtons = function() {
    console.log('=== FORCE ADDING DOWNLOAD BUTTONS ===');

    // Remove any existing download buttons first
    document.querySelectorAll('.daisy-download-btn, .global-download-btn').forEach(btn => btn.remove());

    // MUCH MORE PRECISE - only target actual conversation history items
    const selectors = [
        // Only look for actual conversation items in sidebar
        'aside div[class*="conversation"]',
        'nav li[class*="chat"]',
        '.sidebar .conversation-item',
        '[data-conversation-id]',
        // Very specific selectors for the left sidebar only
        'div:has(span:contains("General")):has(span:contains("Today"))',
        'li:contains("hi")'  // Only if it contains "hi" like in screenshot
    ];

    let buttonsAdded = 0;

    selectors.forEach(selector => {
        try {
            document.querySelectorAll(selector).forEach(item => {
                // Skip if already has download button
                if (item.querySelector('.daisy-download-btn')) return;

                // Skip very large containers or body/html
                if (item.tagName === 'BODY' || item.tagName === 'HTML' || item.children.length > 10) return;

                // ONLY target items that are clearly in the conversation history sidebar
                const isInLeftSidebar = item.getBoundingClientRect && item.getBoundingClientRect().left < 300;
                const hasDeleteButton = item.querySelector('button[title*="delete"], button:contains("🗑")');

                // Must be a conversation item with delete button AND in left sidebar
                const isConversationItem = hasDeleteButton && isInLeftSidebar &&
                    item.textContent && item.textContent.trim().length < 100;

                if (isConversationItem && !item.querySelector('.daisy-download-btn')) {
                    // Create download button
                    const downloadBtn = document.createElement('button');
                    downloadBtn.className = 'daisy-download-btn';
                    downloadBtn.innerHTML = '[⬇]';
                    downloadBtn.title = 'Download conversation';
                    downloadBtn.style.cssText = `
                        background: #007AFF;
                        border: none;
                        border-radius: 4px;
                        color: white;
                        padding: 4px 8px;
                        margin: 0 2px;
                        font-size: 12px;
                        cursor: pointer;
                        display: inline-block;
                        position: relative;
                        z-index: 9999;
                    `;

                    // Add click handler
                    downloadBtn.onclick = function(e) {
                        e.preventDefault();
                        e.stopPropagation();

                        // Try to get session ID from URL or generate one
                        const sessionId = 'current-' + Date.now();
                        const downloadUrl = `/api/conversations/${sessionId}/download?format=json`;

                        // Open download in new tab
                        window.open(downloadUrl, '_blank');

                        // Show feedback
                        downloadBtn.innerHTML = '[✓]';
                        setTimeout(() => {
                            downloadBtn.innerHTML = '[⬇]';
                        }, 2000);
                    };

                    // Find best place to insert
                    const existingBtn = item.querySelector('button, [role="button"]');
                    if (existingBtn) {
                        // Insert next to existing button
                        existingBtn.parentNode.insertBefore(downloadBtn, existingBtn.nextSibling);
                    } else {
                        // Append to item
                        item.appendChild(downloadBtn);
                    }

                    buttonsAdded++;
                    console.log(`Added download button ${buttonsAdded} to:`, item.textContent?.substring(0, 30) || selector);
                }
            });
        } catch (e) {
            // Skip invalid selectors
            console.log('Skipped selector:', selector, e.message);
        }
    });

    // Add global download button
    if (!document.querySelector('.global-download-btn')) {
        const globalBtn = document.createElement('button');
        globalBtn.className = 'global-download-btn';
        globalBtn.innerHTML = '[DOWNLOAD] Current Chat';
        globalBtn.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #28a745;
            border: none;
            border-radius: 6px;
            color: white;
            padding: 8px 16px;
            font-size: 14px;
            cursor: pointer;
            z-index: 9999;
            box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        `;

        globalBtn.onclick = function() {
            const sessionId = 'current-' + Date.now();
            window.open(`/api/conversations/${sessionId}/download?format=json`, '_blank');
        };

        document.body.appendChild(globalBtn);
        buttonsAdded++;
    }

    console.log(`=== TOTAL DOWNLOAD BUTTONS ADDED: ${buttonsAdded} ===`);

    if (buttonsAdded === 0) {
        console.log('No suitable locations found. Available elements:');
        console.log('Buttons:', document.querySelectorAll('button').length);
        console.log('Delete buttons:', document.querySelectorAll('button[title*="delete"]').length);
        console.log('List items:', document.querySelectorAll('li').length);
    }

    return buttonsAdded;
};

// Auto-run on load
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        console.log('Auto-running forceAddDownloadButtons...');
        window.forceAddDownloadButtons();
    }, 2000);
});

// Also run when script loads if DOM is ready
if (document.readyState !== 'loading') {
    setTimeout(() => {
        console.log('Running forceAddDownloadButtons on script load...');
        window.forceAddDownloadButtons();
    }, 1000);
}

console.log('Force download buttons script loaded. Run window.forceAddDownloadButtons() in console if needed.');