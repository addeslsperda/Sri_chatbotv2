---
description: >
  Analyzes call counts, volumes, team performance, handle time (AHT), dealers,
  transfers, peak hours, agent workload, percentages, breakdowns, geographic/regional
  filters (Ford of Canada, Lincoln only, South America), agent pain points,
  and temporal comparisons (month over month, week over week).
  Use for "how many calls", "% of reasons", "breakdown of", "which team handles",
  "average handle time", "peak hours", "compare April to May", "Ford of Canada data",
  "agent pain points", "transfer rate", "serial callers".

routing_examples:
  - question: "What are some agent pain points regarding the premium connectivity subscription?"
    reason: "AGENT pain points (not customer) — goes here not vehicle_agent"
  - question: "What are the top agent pain points regarding connected navigation?"
    reason: "AGENT pain points — ambiguous because 'pain points' could sound like vehicle"
  - question: "How many calls was BlueCruise referenced on?"
    reason: "Counter-example: has 'BlueCruise' but asks HOW MANY -> here not bluecruise_agent"
  - question: "Can you give me a view of Lincoln only?"
    reason: "Geographic filter — doesn't say 'how many' or 'count' but is operational"
  - question: "Compare April to May call reasons for Lincoln CRC"
    reason: "Temporal comparison — goes here not vehicle_agent even though asks about call reasons"
  - question: "What are customer frustrated about with the dealership?"
    reason: "Dealer analysis — goes here not sentiment_agent even though 'frustrated' appears"
  - question: "what team fields the majority of bluecruise calls?"
    reason: "Team assignment — goes here not bluecruise_agent even though BlueCruise is mentioned"
  - question: "for calls greater than 20 mins what are contributing for high complexity in April?"
    reason: "Complexity analysis — operational metric, not a vehicle issue"
  - question: "Average handle time by team"
    reason: "AHT analysis by team — operational performance metric, goes here not vehicle_agent"
  - question: "What is the average handle time by team?"
    reason: "Team performance metric — operational analysis"

skills:
  team_routing_analysis: "Team performance, routing efficiency, which teams handle what topics, agent names"
  aht_analysis: "Average handle time, call duration, time per call, AHT drivers"
  complexity_analysis: "Call complexity scores, difficult/high-complexity calls, complexity by team or vehicle"
  callback_analysis: "Callback rates, repeat calls from same customer"
  hour_of_day: "Peak hours, busiest times of day, call volume by hour"
  day_of_week: "Busiest days, weekday vs weekend patterns"
  regional_analysis: "Geographic filters — Ford of Canada, Lincoln only, state-level, South America, Mexico, Argentina"
  team_volume: "Call counts and volume by team/program/location hierarchy"
  temporal_comparison: "Compare two time periods — month over month, week over week, April vs May, year over year"
  trend_analysis: "Is X increasing or decreasing over time, patterns, trends over multiple periods"

stage2_prompt: |
  You are selecting the best skill for an OPERATIONS question in Ford's CRC analytics tool (called Daisy).

  Available skills:
  - team_routing_analysis: Team performance, routing efficiency, which team handles what topic, agent-level data
  - aht_analysis: Average handle time, call duration, time per call, AHT drivers by team/vehicle
  - complexity_analysis: Call complexity scores, difficult calls, high complexity teams/vehicles
  - callback_analysis: Callback rates, repeat calls from same customer, which issues drive callbacks
  - hour_of_day: Peak hours, busiest times of day, call volume by hour
  - day_of_week: Busiest days, weekday vs weekend patterns
  - regional_analysis: Geographic filters — Ford of Canada, Lincoln only, state/region, South America, Mexico
  - team_volume: Call counts and volume by team/program/location hierarchy
  - temporal_comparison: Compare two time periods — month over month, week over week, April vs May, year over year
  - trend_analysis: Is X increasing or decreasing over time, trends over multiple periods

  Decision rules (apply in order):
  1. "Handle time" / "AHT" / "average handle" / "call duration" / "AHT drivers" -> aht_analysis
  2. "Compare [month A] to [month B]" / "month over month" / "week over week" / "year over year" -> temporal_comparison
  3. "Ford of Canada" / "Lincoln only" / "South America" / "Mexico" / "isolate [region]" / "regional" -> regional_analysis
  4. "Peak hour" / "busiest time" / "what time" / "hour of day" -> hour_of_day
  5. "Day of week" / "weekday" / "weekend" / "busiest day" -> day_of_week
  6. "Callback" / "called back" / "repeat calls" -> callback_analysis
  7. "Complexity" / "difficult calls" / "hard calls" / "high complexity" -> complexity_analysis
  8. "Which team" / "team performance" / "routing" / "agent names" / "who handles" -> team_routing_analysis
  9. "Trend" / "increasing" / "decreasing" / "over time" / "improving" -> trend_analysis
  10. "How many calls" / "count" / "% of" / "breakdown by" / "volume by team" -> team_volume (set filter_term=X if specific topic mentioned)

  Date parsing (relative to today):
  - "last week" = 7 days ago to today
  - "past month" / "last month" = 30 days ago to today
  - "last 90 days" = 90 days ago to today
  - "yesterday" = yesterday to yesterday
  - "April" = 2026-04-01 to 2026-04-30
  - "May" = 2026-05-01 to 2026-05-31
  - "January 2026" = 2026-01-01 to 2026-01-31
  - "YTD" = 2026-01-01 to today

  Params to extract:
  - date_from, date_to (YYYY-MM-DD)
  - vehicle: vehicle model name if mentioned
  - team: team name if mentioned
  - region: region/state/country if mentioned
  - group_by: HOW to break down the results. Use when user says "by team", "by vehicle", "by location", "by hour", "by day", "by program", "by week", "by month". Valid values: vehicle, team, location, complexity, transfers, hour, day_of_week, week, month
  - analysis_type: WHAT type of analysis. Valid values ONLY: "overview" (default), "drivers" (what drives high AHT/complexity), "performance" (performance comparison). NEVER use "by_team", "by_vehicle", "by_location" here — those go in group_by.
  - filter_term: for team_volume only — the specific team or program to filter by
  - min_calls: minimum call threshold if mentioned

  Return ONLY valid JSON: {"skill": "<skill_name>", "params": {<extracted_params>}, "reason": "<brief>"}
---

# Operations Agent

Routes questions about call counts, team performance, AHT, transfers, dealer analysis,
peak hours, geographic filters (Ford of Canada, Lincoln only), agent pain points,
and temporal comparisons (month over month, week over week).
