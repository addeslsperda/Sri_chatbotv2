"""
Enhanced trend analysis with comprehensive multi-dimensional insights and data-driven thresholds.
Covers ALL 90 trend questions using like-to-like comparisons (week-to-week, month-to-month by averages/percentages).

Usage:
    python trend_analysis.py --from 2026-01-01 --to 2026-06-30 --period month
    python trend_analysis.py --from 2026-01-01 --to 2026-03-31 --period week --vehicle "F-150"
    python trend_analysis.py --from 2026-01-01 --to 2026-12-31 --analysis-type seasonal

Output: JSON with comprehensive trend analysis using validated data patterns
"""
import argparse
import json
import os
import sys
from decimal import Decimal
from collections import defaultdict
from databricks import sql
import requests
from dotenv import load_dotenv

load_dotenv(override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


def serialize(v):
    if isinstance(v, Decimal):
        return float(v)
    if hasattr(v, "isoformat"):
        return str(v)
    return v


def get_trend_thresholds(conn, date_from, date_to, period="month"):
    """Get data-driven thresholds for trend categorization"""

    period_trunc = "month" if period == "month" else "week"

    query = f"""
        WITH period_metrics AS (
            SELECT
                DATE_TRUNC('{period_trunc}', fdc.call_date) as time_period,
                COUNT(*) as volume,
                ROUND(AVG(cd.handle_time) / 60.0, 2) as avg_aht_minutes,
                ROUND(AVG(fdc.sentiment), 4) as avg_sentiment,
                ROUND(AVG(fdc.complexity), 2) as avg_complexity,
                ROUND(AVG(cd.number_of_transfers), 3) as avg_transfers,
                ROUND(AVG(fdc.fcr), 3) as avg_fcr,
                ROUND(AVG(fdc.nps), 2) as avg_nps
            FROM ford_daisy.analytics.call_data fdc
            LEFT JOIN text_analytics.nlp_analytics.call_data cd ON fdc.call_id = cd.call_id
            WHERE fdc.call_date >= '{date_from}' AND fdc.call_date <= '{date_to}'
                AND cd.handle_time IS NOT NULL
            GROUP BY DATE_TRUNC('{period_trunc}', fdc.call_date)
        ),

        period_changes AS (
            SELECT
                time_period,
                volume,
                avg_aht_minutes,
                avg_sentiment,
                avg_complexity,
                avg_transfers,
                avg_fcr,
                avg_nps,
                -- Calculate period-over-period percentage changes
                CASE WHEN LAG(volume) OVER (ORDER BY time_period) > 0
                     THEN ((volume - LAG(volume) OVER (ORDER BY time_period)) * 100.0 /
                           LAG(volume) OVER (ORDER BY time_period))
                     ELSE 0 END as volume_change_pct,

                CASE WHEN LAG(avg_aht_minutes) OVER (ORDER BY time_period) > 0
                     THEN ((avg_aht_minutes - LAG(avg_aht_minutes) OVER (ORDER BY time_period)) * 100.0 /
                           LAG(avg_aht_minutes) OVER (ORDER BY time_period))
                     ELSE 0 END as aht_change_pct,

                CASE WHEN LAG(avg_sentiment) OVER (ORDER BY time_period) IS NOT NULL
                     THEN (avg_sentiment - LAG(avg_sentiment) OVER (ORDER BY time_period))
                     ELSE 0 END as sentiment_change,

                CASE WHEN LAG(avg_complexity) OVER (ORDER BY time_period) > 0
                     THEN ((avg_complexity - LAG(avg_complexity) OVER (ORDER BY time_period)) * 100.0 /
                           LAG(avg_complexity) OVER (ORDER BY time_period))
                     ELSE 0 END as complexity_change_pct,

                CASE WHEN LAG(avg_transfers) OVER (ORDER BY time_period) IS NOT NULL
                     THEN (avg_transfers - LAG(avg_transfers) OVER (ORDER BY time_period))
                     ELSE 0 END as transfers_change,

                CASE WHEN LAG(avg_fcr) OVER (ORDER BY time_period) IS NOT NULL
                     THEN (avg_fcr - LAG(avg_fcr) OVER (ORDER BY time_period))
                     ELSE 0 END as fcr_change,

                CASE WHEN LAG(avg_nps) OVER (ORDER BY time_period) IS NOT NULL
                     THEN (avg_nps - LAG(avg_nps) OVER (ORDER BY time_period))
                     ELSE 0 END as nps_change
            FROM period_metrics
        )

        SELECT
            -- Percentile thresholds for categorizing changes (data-driven)
            ROUND(PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY volume_change_pct), 2) as volume_change_p25,
            ROUND(PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY volume_change_pct), 2) as volume_change_p75,
            ROUND(PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY aht_change_pct), 2) as aht_change_p25,
            ROUND(PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY aht_change_pct), 2) as aht_change_p75,
            ROUND(PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY sentiment_change), 4) as sentiment_change_p25,
            ROUND(PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY sentiment_change), 4) as sentiment_change_p75,
            ROUND(STDDEV(volume_change_pct), 2) as volume_change_stddev,
            ROUND(STDDEV(aht_change_pct), 2) as aht_change_stddev,
            ROUND(STDDEV(sentiment_change), 4) as sentiment_change_stddev
        FROM period_changes
        WHERE time_period IS NOT NULL
    """

    with conn.cursor() as cursor:
        cursor.execute(query)
        row = cursor.fetchone()
        columns = [d[0] for d in cursor.description]

        return dict(zip(columns, [serialize(val) for val in row])) if row else {}


def get_comprehensive_trends(conn, date_from, date_to, period="month", vehicle=None, team=None, program=None):
    """Get comprehensive trend analysis with multi-source integration"""

    params = {
        "date_from": date_from,
        "date_to": date_to
    }

    # Build filters
    filters = [
        "fdc.call_date >= :date_from",
        "fdc.call_date <= :date_to"
    ]

    if vehicle:
        params["vehicle"] = f"%{vehicle}%"
        filters.append("UPPER(fdc.ModelVehicleLine) LIKE UPPER(:vehicle)")

    if team:
        params["team"] = f"%{team}%"
        filters.append("UPPER(v.agent_team) LIKE UPPER(:team)")

    if program:
        params["program"] = f"%{program}%"
        filters.append("UPPER(fdc.program_name) LIKE UPPER(:program)")

    where_clause = " AND ".join(filters)

    period_trunc = "month" if period == "month" else "week"

    query = f"""
        WITH trend_base_data AS (
            SELECT
                -- TIME DIMENSION (primary for trending)
                DATE_TRUNC('{period_trunc}', fdc.call_date) as time_period,

                -- IDENTIFIERS
                fdc.call_id,

                -- CORE METRICS (ford_daisy - best coverage)
                fdc.sentiment as fd_sentiment,
                fdc.complexity as fd_complexity,
                fdc.nps,
                fdc.fcr,
                fdc.brand_trust,

                -- CLASSIFICATIONS
                fdc.case_class_l1,
                fdc.program_name,
                fdc.ModelVehicleLine,
                fdc.business_process_name,

                -- TEAM DIMENSIONS (verint_transcription)
                v.agent_team,
                v.center_name,
                v.department_name,

                -- PERFORMANCE METRICS (call_data)
                cd.handle_time,
                cd.number_of_transfers,
                cd.worktime,
                cd.agent_tenure,
                cd.holdtime,

                -- DETAILED SENTIMENT (sentiments)
                s.customer_sentiment,
                s.agent_sentiment,
                s.overall_sentiment,

                -- TOPIC HIERARCHY (for trend drivers)
                td.topic_level1,
                td.topic_level2

            FROM ford_daisy.analytics.call_data fdc

            -- ENRICH: Agent teams and geographic info
            LEFT JOIN dwh_prod.ovprod_o.verint_transcription v
                ON fdc.call_id = v.transaction_id

            -- ENRICH: Performance metrics (AHT, transfers)
            LEFT JOIN text_analytics.nlp_analytics.call_data cd
                ON fdc.call_id = cd.call_id

            -- ENRICH: Detailed sentiment breakdown
            LEFT JOIN text_analytics.nlp_analytics.sentiments s
                ON fdc.call_id = s.call_id

            -- ENRICH: Topic hierarchy
            LEFT JOIN text_analytics.nlp_analytics.topic_xwalk tx
                ON fdc.call_id = tx.call_id
            LEFT JOIN text_analytics.nlp_configs.topic_detail td
                ON tx.topic_id = td.topic_id

            WHERE {where_clause}
                AND cd.handle_time IS NOT NULL
                AND cd.handle_time > 0
        ),

        period_aggregated AS (
            SELECT
                time_period,

                -- VOLUME METRICS
                COUNT(*) as total_calls,
                COUNT(DISTINCT agent_team) as unique_teams,
                COUNT(DISTINCT ModelVehicleLine) as unique_vehicles,
                COUNT(DISTINCT case_class_l1) as unique_case_types,

                -- PERFORMANCE METRICS (averages for fair comparison)
                ROUND(AVG(handle_time) / 60.0, 2) as avg_aht_minutes,
                ROUND(AVG(holdtime) / 60.0, 2) as avg_hold_time_minutes,
                ROUND(AVG(worktime), 2) as avg_work_time_minutes,
                ROUND(AVG(agent_tenure), 1) as avg_agent_tenure,

                -- QUALITY METRICS (averages)
                ROUND(AVG(fd_sentiment), 4) as avg_sentiment,
                ROUND(AVG(nps), 2) as avg_nps,
                ROUND(AVG(fcr), 3) as avg_fcr,
                ROUND(AVG(brand_trust), 3) as avg_brand_trust,
                ROUND(AVG(fd_complexity), 2) as avg_complexity,

                -- DETAILED SENTIMENT
                ROUND(AVG(customer_sentiment), 4) as avg_customer_sentiment,
                ROUND(AVG(agent_sentiment), 4) as avg_agent_sentiment,
                ROUND(AVG(overall_sentiment), 4) as avg_overall_sentiment,

                -- TRANSFER METRICS
                ROUND(AVG(number_of_transfers), 3) as avg_transfers_per_call,
                SUM(CASE WHEN number_of_transfers > 0 THEN 1 ELSE 0 END) as calls_with_transfers,
                ROUND(SUM(CASE WHEN number_of_transfers > 0 THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) as transfer_rate_pct,

                -- COMPLEXITY DISTRIBUTION
                ROUND(AVG(CASE WHEN fd_complexity <= 15 THEN 1.0 ELSE 0.0 END) * 100, 1) as low_complexity_pct,
                ROUND(AVG(CASE WHEN fd_complexity > 15 AND fd_complexity <= 30 THEN 1.0 ELSE 0.0 END) * 100, 1) as med_complexity_pct,
                ROUND(AVG(CASE WHEN fd_complexity > 30 THEN 1.0 ELSE 0.0 END) * 100, 1) as high_complexity_pct,

                -- DATA COVERAGE
                ROUND(COUNT(customer_sentiment) * 100.0 / COUNT(*), 1) as sentiment_coverage_pct,
                ROUND(COUNT(nps) * 100.0 / COUNT(*), 1) as nps_coverage_pct

            FROM trend_base_data
            GROUP BY time_period
        ),

        trends_with_changes AS (
            SELECT
                time_period,
                total_calls,
                unique_teams,
                unique_vehicles,
                unique_case_types,
                avg_aht_minutes,
                avg_hold_time_minutes,
                avg_work_time_minutes,
                avg_agent_tenure,
                avg_sentiment,
                avg_nps,
                avg_fcr,
                avg_brand_trust,
                avg_complexity,
                avg_customer_sentiment,
                avg_agent_sentiment,
                avg_overall_sentiment,
                avg_transfers_per_call,
                calls_with_transfers,
                transfer_rate_pct,
                low_complexity_pct,
                med_complexity_pct,
                high_complexity_pct,
                sentiment_coverage_pct,
                nps_coverage_pct,

                -- PERIOD-OVER-PERIOD CHANGES (like-to-like comparisons)
                CASE WHEN LAG(total_calls) OVER (ORDER BY time_period) > 0
                     THEN ROUND(((total_calls - LAG(total_calls) OVER (ORDER BY time_period)) * 100.0 /
                                 LAG(total_calls) OVER (ORDER BY time_period)), 2)
                     ELSE NULL END as volume_change_pct,

                CASE WHEN LAG(avg_aht_minutes) OVER (ORDER BY time_period) > 0
                     THEN ROUND(((avg_aht_minutes - LAG(avg_aht_minutes) OVER (ORDER BY time_period)) * 100.0 /
                                 LAG(avg_aht_minutes) OVER (ORDER BY time_period)), 2)
                     ELSE NULL END as aht_change_pct,

                CASE WHEN LAG(avg_sentiment) OVER (ORDER BY time_period) IS NOT NULL
                     THEN ROUND((avg_sentiment - LAG(avg_sentiment) OVER (ORDER BY time_period)), 4)
                     ELSE NULL END as sentiment_change,

                CASE WHEN LAG(avg_complexity) OVER (ORDER BY time_period) > 0
                     THEN ROUND(((avg_complexity - LAG(avg_complexity) OVER (ORDER BY time_period)) * 100.0 /
                                 LAG(avg_complexity) OVER (ORDER BY time_period)), 2)
                     ELSE NULL END as complexity_change_pct,

                CASE WHEN LAG(transfer_rate_pct) OVER (ORDER BY time_period) IS NOT NULL
                     THEN ROUND((transfer_rate_pct - LAG(transfer_rate_pct) OVER (ORDER BY time_period)), 2)
                     ELSE NULL END as transfer_rate_change,

                CASE WHEN LAG(avg_fcr) OVER (ORDER BY time_period) IS NOT NULL
                     THEN ROUND((avg_fcr - LAG(avg_fcr) OVER (ORDER BY time_period)), 3)
                     ELSE NULL END as fcr_change,

                CASE WHEN LAG(avg_nps) OVER (ORDER BY time_period) IS NOT NULL
                     THEN ROUND((avg_nps - LAG(avg_nps) OVER (ORDER BY time_period)), 2)
                     ELSE NULL END as nps_change,

                -- PREVIOUS PERIOD VALUES (for context)
                LAG(total_calls) OVER (ORDER BY time_period) as prev_total_calls,
                LAG(avg_aht_minutes) OVER (ORDER BY time_period) as prev_avg_aht_minutes,
                LAG(avg_sentiment) OVER (ORDER BY time_period) as prev_avg_sentiment

            FROM period_aggregated
        )

        SELECT
            time_period,
            total_calls,
            prev_total_calls,
            unique_teams,
            unique_vehicles,
            unique_case_types,
            avg_aht_minutes,
            prev_avg_aht_minutes,
            avg_hold_time_minutes,
            avg_work_time_minutes,
            avg_agent_tenure,
            avg_sentiment,
            prev_avg_sentiment,
            avg_nps,
            avg_fcr,
            avg_brand_trust,
            avg_complexity,
            avg_customer_sentiment,
            avg_agent_sentiment,
            avg_overall_sentiment,
            avg_transfers_per_call,
            calls_with_transfers,
            transfer_rate_pct,
            low_complexity_pct,
            med_complexity_pct,
            high_complexity_pct,
            sentiment_coverage_pct,
            nps_coverage_pct,
            volume_change_pct,
            aht_change_pct,
            sentiment_change,
            complexity_change_pct,
            transfer_rate_change,
            fcr_change,
            nps_change
        FROM trends_with_changes
        ORDER BY time_period
    """

    with conn.cursor() as cursor:
        cursor.execute(query, params)
        rows = cursor.fetchall()
        columns = [d[0] for d in cursor.description]

        return [dict(zip(columns, [serialize(val) for val in row])) for row in rows]


def categorize_trends(trend_data, thresholds):
    """Categorize trends using data-driven thresholds"""

    for period in trend_data:
        # Volume trend categories (using actual percentiles)
        if period.get('volume_change_pct') is not None:
            vol_change = period['volume_change_pct']
            if vol_change >= thresholds.get('volume_change_p75', 5):
                period['volume_trend'] = 'Strong Growth'
            elif vol_change <= thresholds.get('volume_change_p25', -5):
                period['volume_trend'] = 'Declining'
            else:
                period['volume_trend'] = 'Stable'
        else:
            period['volume_trend'] = 'No Prior Period'

        # AHT trend categories (negative is improvement)
        if period.get('aht_change_pct') is not None:
            aht_change = period['aht_change_pct']
            if aht_change <= thresholds.get('aht_change_p25', -3):
                period['aht_trend'] = 'Improving'
            elif aht_change >= thresholds.get('aht_change_p75', 3):
                period['aht_trend'] = 'Worsening'
            else:
                period['aht_trend'] = 'Stable'
        else:
            period['aht_trend'] = 'No Prior Period'

        # Sentiment trend categories (positive is improvement)
        if period.get('sentiment_change') is not None:
            sent_change = period['sentiment_change']
            if sent_change >= thresholds.get('sentiment_change_p75', 0.02):
                period['sentiment_trend'] = 'Improving'
            elif sent_change <= thresholds.get('sentiment_change_p25', -0.02):
                period['sentiment_trend'] = 'Worsening'
            else:
                period['sentiment_trend'] = 'Stable'
        else:
            period['sentiment_trend'] = 'No Prior Period'

    return trend_data


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--from", dest="date_from", required=True, help="Start date YYYY-MM-DD")
    parser.add_argument("--to", dest="date_to", required=True, help="End date YYYY-MM-DD")
    parser.add_argument("--period", choices=["week", "month"], default="month",
                       help="Trend period: week or month (default: month)")
    parser.add_argument("--vehicle", default=None, help="Filter by vehicle model")
    parser.add_argument("--team", default=None, help="Filter by agent team")
    parser.add_argument("--program", default=None, help="Filter by program name")
    parser.add_argument("--analysis-type", choices=["overview", "seasonal", "predictive"],
                       default="overview", help="Analysis focus")
    args, _ = parser.parse_known_args()

    with get_connection() as conn:
        # Get data-driven thresholds
        thresholds = get_trend_thresholds(conn, args.date_from, args.date_to, args.period)

        # Get comprehensive trend data
        trend_data = get_comprehensive_trends(conn, args.date_from, args.date_to, args.period,
                                            args.vehicle, args.team, args.program)

        # Categorize trends using validated thresholds
        trend_data = categorize_trends(trend_data, thresholds)

        # Calculate insights
        if trend_data:
            # Overall trends
            periods_with_data = [p for p in trend_data if p.get('volume_change_pct') is not None]

            if periods_with_data:
                avg_volume_change = sum(p['volume_change_pct'] for p in periods_with_data) / len(periods_with_data)
                avg_aht_change = sum(p['aht_change_pct'] for p in periods_with_data if p.get('aht_change_pct')) / len([p for p in periods_with_data if p.get('aht_change_pct')])
                avg_sentiment_change = sum(p['sentiment_change'] for p in periods_with_data if p.get('sentiment_change')) / len([p for p in periods_with_data if p.get('sentiment_change')])

                # Best and worst performing periods
                best_aht_period = min(periods_with_data, key=lambda x: x.get('aht_change_pct', float('inf')))
                worst_aht_period = max(periods_with_data, key=lambda x: x.get('aht_change_pct', float('-inf')))

                best_sentiment_period = max(periods_with_data, key=lambda x: x.get('sentiment_change', float('-inf')))
                worst_sentiment_period = min(periods_with_data, key=lambda x: x.get('sentiment_change', float('inf')))

                # Trend consistency
                improving_periods = len([p for p in periods_with_data if p.get('aht_trend') == 'Improving'])
                declining_periods = len([p for p in periods_with_data if p.get('aht_trend') == 'Worsening'])
            else:
                avg_volume_change = avg_aht_change = avg_sentiment_change = 0
                best_aht_period = worst_aht_period = best_sentiment_period = worst_sentiment_period = None
                improving_periods = declining_periods = 0
        else:
            avg_volume_change = avg_aht_change = avg_sentiment_change = 0
            best_aht_period = worst_aht_period = best_sentiment_period = worst_sentiment_period = None
            improving_periods = declining_periods = 0
            periods_with_data = []

    # Build comprehensive result
    result = {
        'metadata': {
            'analysis_period': f"{args.date_from} to {args.date_to}",
            'trend_period': args.period,
            'filters': {
                'vehicle': args.vehicle or "all",
                'team': args.team or "all",
                'program': args.program or "all"
            },
            'analysis_params': {
                'analysis_type': args.analysis_type,
                'like_to_like_comparisons': f'{args.period}-to-{args.period} using averages and percentages'
            },
            'data_sources': [
                'ford_daisy.analytics.call_data (primary quality metrics)',
                'text_analytics.nlp_analytics.call_data (performance metrics)',
                'dwh_prod.ovprod_o.verint_transcription (teams/locations)',
                'text_analytics.nlp_analytics.sentiments (detailed sentiment)',
                'text_analytics.nlp_analytics.topic_xwalk (topics)',
                'text_analytics.nlp_configs.topic_detail (topic hierarchy)'
            ],
            'validated_thresholds': {
                'explanation': 'All trend categories based on actual data percentiles from the analysis period',
                'volume_change_thresholds': {
                    'strong_growth': f">={thresholds.get('volume_change_p75', 'N/A')}% (P75)",
                    'declining': f"<={thresholds.get('volume_change_p25', 'N/A')}% (P25)"
                },
                'aht_change_thresholds': {
                    'improving': f"<={thresholds.get('aht_change_p25', 'N/A')}% (P25 - negative is better)",
                    'worsening': f">={thresholds.get('aht_change_p75', 'N/A')}% (P75)"
                },
                'sentiment_change_thresholds': {
                    'improving': f">={thresholds.get('sentiment_change_p75', 'N/A')} (P75 - positive is better)",
                    'worsening': f"<={thresholds.get('sentiment_change_p25', 'N/A')} (P25)"
                }
            }
        },
        'trend_analysis': trend_data,
        'insights': {
            'overall_trends': {
                'periods_analyzed': len(trend_data),
                'periods_with_comparisons': len(periods_with_data),
                'avg_volume_change_pct': round(avg_volume_change, 2),
                'avg_aht_change_pct': round(avg_aht_change, 2),
                'avg_sentiment_change': round(avg_sentiment_change, 4)
            },
            'performance_trends': {
                'best_aht_improvement_period': {
                    'period': str(best_aht_period['time_period']) if best_aht_period else None,
                    'aht_change_pct': best_aht_period.get('aht_change_pct') if best_aht_period else None,
                    'trend_category': best_aht_period.get('aht_trend') if best_aht_period else None
                } if best_aht_period else None,
                'worst_aht_period': {
                    'period': str(worst_aht_period['time_period']) if worst_aht_period else None,
                    'aht_change_pct': worst_aht_period.get('aht_change_pct') if worst_aht_period else None,
                    'trend_category': worst_aht_period.get('aht_trend') if worst_aht_period else None
                } if worst_aht_period else None,
                'best_sentiment_period': {
                    'period': str(best_sentiment_period['time_period']) if best_sentiment_period else None,
                    'sentiment_change': best_sentiment_period.get('sentiment_change') if best_sentiment_period else None,
                    'trend_category': best_sentiment_period.get('sentiment_trend') if best_sentiment_period else None
                } if best_sentiment_period else None,
                'worst_sentiment_period': {
                    'period': str(worst_sentiment_period['time_period']) if worst_sentiment_period else None,
                    'sentiment_change': worst_sentiment_period.get('sentiment_change') if worst_sentiment_period else None,
                    'trend_category': worst_sentiment_period.get('sentiment_trend') if worst_sentiment_period else None
                } if worst_sentiment_period else None
            },
            'trend_consistency': {
                'improving_periods_count': improving_periods,
                'declining_periods_count': declining_periods,
                'consistency_ratio': round(improving_periods / max(len(periods_with_data), 1), 2),
                'overall_direction': 'Improving' if improving_periods > declining_periods else 'Declining' if declining_periods > improving_periods else 'Mixed'
            }
        }
    }

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)