---
name: trend_analysis
display_name: Enhanced Trend Analysis
description: Comprehensive time-series trend analysis with data-driven thresholds and like-to-like comparisons (week-to-week, month-to-month by averages/percentages). Multi-source integration covering performance trends, seasonal patterns, anomaly detection, and predictive insights. Uses validated percentile-based categories for trend classification. Use for "is AHT improving", "monthly trends", "performance over time", "seasonal patterns".
signals:
  - is AHT improving
  - monthly trends
  - month-over-month
  - week-over-week
  - performance over time
  - are we improving
  - trend over time
  - how have we performed
  - show me trends
  - seasonal patterns
  - performance trending
  - metric trends
requires:
  - a multi-period date range (e.g. 3+ months for meaningful trends)
not_good_for: Single period snapshot (use team_volume), period comparison (use temporal_comparison)
---

# Enhanced Trend Analysis

## What this script does
Comprehensive time-series trend analysis using ford_daisy.analytics.call_data + 5 enrichment sources with data-driven trend categorization:
- **Like-to-like period comparisons** (week-to-week, month-to-month using averages and percentages)
- **Data-driven trend thresholds** using actual percentiles (P25, P75) from analysis period
- **Multi-dimensional trending** - volume, AHT, sentiment, complexity, transfers, FCR, NPS
- **Seasonal pattern detection** and business cycle analysis
- **Performance consistency tracking** - improving vs declining periods
- **Cross-metric correlation trending** - how metrics relate over time
- **Anomaly identification** and early warning indicators
- **Predictive trend insights** for forecasting

## When to use
- "Is AHT improving over time?"
- "Show me monthly trends for 2024"
- "Are we getting better at handling calls?"
- "Month-over-month performance analysis"
- "Week-over-week efficiency trends"
- "How have we performed over the last 6 months?"
- "What are our seasonal patterns?"
- "Which metrics are consistently improving?"
- "Are performance improvements sustainable?"
- "Show me performance trends by team/vehicle"

## Parameters
- `--from` and `--to`: Date range (required) - should span multiple periods (3+ months recommended)
- `--period`: Granularity - "week" or "month" (default: month)
- `--vehicle`: Filter by vehicle model (optional)
- `--team`: Filter by agent team (optional)
- `--program`: Filter by program name (optional)
- `--analysis-type`: Focus area - "overview", "seasonal", "predictive" (default: overview)

## Output format

```json
{
  "metadata": {
    "analysis_period": "2026-01-01 to 2026-06-30",
    "trend_period": "month",
    "filters": { "vehicle": "all", "team": "all", "program": "all" },
    "analysis_params": {
      "analysis_type": "overview",
      "like_to_like_comparisons": "month-to-month using averages and percentages"
    },
    "data_sources": [
      "ford_daisy.analytics.call_data (primary quality metrics)",
      "text_analytics.nlp_analytics.call_data (performance metrics)",
      "dwh_prod.ovprod_o.verint_transcription (teams/locations)",
      "text_analytics.nlp_analytics.sentiments (detailed sentiment)",
      "text_analytics.nlp_analytics.topic_xwalk (topics)",
      "text_analytics.nlp_configs.topic_detail (topic hierarchy)"
    ],
    "validated_thresholds": {
      "explanation": "All trend categories based on actual data percentiles from the analysis period",
      "volume_change_thresholds": {
        "strong_growth": ">=8.5% (P75)",
        "declining": "<=-5.2% (P25)"
      },
      "aht_change_thresholds": {
        "improving": "<=-3.1% (P25 - negative is better)",
        "worsening": ">=4.2% (P75)"
      },
      "sentiment_change_thresholds": {
        "improving": ">=0.025 (P75 - positive is better)",
        "worsening": "<=-0.018 (P25)"
      }
    }
  },
  "trend_analysis": [
    {
      "time_period": "2026-01-01T00:00:00",
      "total_calls": 143985,
      "prev_total_calls": null,
      "avg_aht_minutes": 11.52,
      "prev_avg_aht_minutes": null,
      "avg_sentiment": 0.0982,
      "prev_avg_sentiment": null,
      "avg_complexity": 19.8,
      "avg_nps": 4.25,
      "avg_fcr": 1.42,
      "transfer_rate_pct": 7.8,
      "volume_change_pct": null,
      "aht_change_pct": null,
      "sentiment_change": null,
      "complexity_change_pct": null,
      "transfer_rate_change": null,
      "volume_trend": "No Prior Period",
      "aht_trend": "No Prior Period",
      "sentiment_trend": "No Prior Period"
    },
    {
      "time_period": "2026-02-01T00:00:00",
      "total_calls": 132346,
      "prev_total_calls": 143985,
      "avg_aht_minutes": 11.28,
      "prev_avg_aht_minutes": 11.52,
      "avg_sentiment": 0.1045,
      "prev_avg_sentiment": 0.0982,
      "volume_change_pct": -8.08,
      "aht_change_pct": -2.08,
      "sentiment_change": 0.0063,
      "volume_trend": "Declining",
      "aht_trend": "Stable",
      "sentiment_trend": "Stable"
    }
  ],
  "insights": {
    "overall_trends": {
      "periods_analyzed": 6,
      "periods_with_comparisons": 5,
      "avg_volume_change_pct": -2.15,
      "avg_aht_change_pct": 1.25,
      "avg_sentiment_change": 0.0028
    },
    "performance_trends": {
      "best_aht_improvement_period": {
        "period": "2026-03-01T00:00:00",
        "aht_change_pct": -4.8,
        "trend_category": "Improving"
      },
      "worst_aht_period": {
        "period": "2026-05-01T00:00:00",
        "aht_change_pct": 6.2,
        "trend_category": "Worsening"
      }
    },
    "trend_consistency": {
      "improving_periods_count": 2,
      "declining_periods_count": 3,
      "consistency_ratio": 0.4,
      "overall_direction": "Declining"
    }
  }
}
```

## Example calls

```bash
# Monthly trends for 6 months
python .claude/skills/trend_analysis/scripts/trend_analysis.py --from 2026-01-01 --to 2026-06-30 --period month

# Weekly trends for Q1
python .claude/skills/trend_analysis/scripts/trend_analysis.py --from 2026-01-01 --to 2026-03-31 --period week

# Vehicle-specific trends
python .claude/skills/trend_analysis/scripts/trend_analysis.py --from 2026-01-01 --to 2026-12-31 --period month --vehicle "F-150"

# Team performance trends
python .claude/skills/trend_analysis/scripts/trend_analysis.py --from 2026-01-01 --to 2026-06-30 --team "Technical" --period month

# Seasonal analysis
python .claude/skills/trend_analysis/scripts/trend_analysis.py --from 2026-01-01 --to 2026-12-31 --period month --analysis-type seasonal
```

## Key Insights Provided

### **[DATA] Data-Driven Trend Categories**
- **Volume Trends**: Strong Growth (>=P75%), Declining (<=P25%), Stable (P25-P75)
- **AHT Trends**: Improving (<=P25% - negative is better), Worsening (>=P75%), Stable
- **Sentiment Trends**: Improving (>=P75 - positive is better), Worsening (<=P25%), Stable
- **All thresholds calculated from actual data percentiles - no hardcoded assumptions**

### **🔄 Like-to-Like Comparisons**
- **Week-to-week**: Same period length, percentage changes, average-based
- **Month-to-month**: Fair seasonal comparisons, volume percentage changes
- **Performance consistency**: Track improving vs declining periods over time
- **Cross-metric correlations**: How AHT, sentiment, complexity trend together

### **[TREND] Performance Trending**
- **Best/worst performing periods** with specific improvement percentages
- **Consistency tracking**: How many periods show improvement vs decline
- **Trend sustainability**: Are improvements lasting or temporary?
- **Early warning detection**: Periods showing concerning trend changes

### **[TARGET] Seasonal & Cyclical Patterns**
- **Monthly seasonal effects**: Holiday impacts, business cycle patterns
- **Weekly patterns**: Monday vs Friday, weekend effects
- **Quarterly trends**: Business cycle correlation with performance
- **Annual patterns**: Year-over-year improvement tracking

### **[INFO] Predictive Insights**
- **Trend trajectory**: Where performance is heading based on recent patterns
- **Acceleration/deceleration**: Are trends speeding up or slowing down?
- **Goal achievement**: On track to meet annual performance targets?
- **Intervention needs**: Which trends need management attention?

## Trend Interpretation Guide

### **[TREND] Improvement Indicators:**
- `aht_trend: "Improving"` -> Handle time decreasing (good!)
- `sentiment_trend: "Improving"` -> Customer satisfaction increasing (good!)
- `volume_trend: "Strong Growth"` -> Higher call volume (capacity planning needed)
- `consistency_ratio: >0.6` -> More periods improving than declining (sustainable progress)

### **📉 Decline Indicators:**
- `aht_trend: "Worsening"` -> Handle time increasing (needs attention)
- `sentiment_trend: "Worsening"` -> Customer satisfaction declining (priority fix)
- `overall_direction: "Declining"` -> More declining than improving periods (intervention needed)

### **[TARGET] Stable Patterns:**
- Changes within normal variation (P25-P75 range)
- Consistent performance without major swings
- Baseline established for future comparison

## Validated Data Principles
- **No hardcoded thresholds**: All categories based on actual data percentiles
- **Like-to-like only**: Week-to-week, month-to-month, same conditions
- **Percentage-based**: Fair comparisons regardless of absolute values
- **Average-driven**: Volume trends use averages, not raw totals
- **Business context**: Seasonal awareness, holiday effects considered

## Error output
If something goes wrong, the script prints `{"error": "..."}` to stderr and exits with code 1.

## Notes
- **Multi-source integration**: Uses 6 data sources for comprehensive trend insights
- **Privacy protection**: NO AGENT NAMES revealed (team-level analysis only)
- **Statistical significance**: Requires 3+ periods for meaningful trend analysis
- **Data-driven categories**: All thresholds calculated from actual analysis period data
- **Seasonal awareness**: Accounts for business cycles, holidays, and operational patterns
- **Predictive capability**: Provides trend trajectory and early warning indicators
- Best used for strategic planning, performance management, and operational optimization