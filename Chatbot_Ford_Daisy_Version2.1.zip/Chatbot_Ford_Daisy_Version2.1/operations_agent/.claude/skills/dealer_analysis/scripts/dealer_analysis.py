"""
Analyzes dealer performance - complaint rates, service quality, and customer sentiment.
Identifies problem dealers requiring intervention.

Usage:
    python dealer_analysis.py --from 2026-01-01 --to 2026-01-31
    python dealer_analysis.py --from 2026-01-01 --to 2026-01-31 --sort sentiment
    python dealer_analysis.py --from 2026-01-01 --to 2026-01-31 --state "TX"
    python dealer_analysis.py --from 2026-01-01 --to 2026-01-31 --issue-type refused_service

Output: JSON with dealer rankings (highest volume first by default)
"""
import argparse
import json
import os
import sys
from collections import defaultdict
from decimal import Decimal
from pathlib import Path
from databricks import sql
import requests
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parents[4] / ".env", override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


CATALOG = os.environ.get("DATABRICKS_CATALOG", "text_analytics")
SCHEMA = os.environ.get("DATABRICKS_SCHEMA", "nlp_analytics")
DASHBOARD_SCHEMA = os.environ.get("DATABRICKS_DASHBOARD_SCHEMA", "nlp_dashboard")
CALL_DATA = f"{CATALOG}.{SCHEMA}.call_data"
CALL_TABLE = f"{CATALOG}.{SCHEMA}.call_table"
DEALER_LOOKUP = f"{CATALOG}.{DASHBOARD_SCHEMA}.dealer_lookup"


def serialize(v):
    if isinstance(v, Decimal): return float(v)
    if hasattr(v, "isoformat"): return str(v)
    return v


# Dealer issue patterns
DEALER_ISSUES = {
    'refused_service': ['dealer refused', 'refused service', 'refused repair', 'won\'t fix', 'won\'t repair', 'turned me away'],
    'repair_failure': ['repair didn\'t fix', 'not fixed', 'still broken', 'problem came back', 'same issue'],
    'warranty_denial': ['denied warranty', 'warranty denied', 'refused warranty', 'not covered'],
    'parts_unavailable': ['no parts', 'parts unavailable', 'backorder', 'waiting for parts'],
    'overcharge': ['overcharged', 'charged too much', 'expensive', 'price too high']
}


def detect_dealer_issues(summary, transcript):
    """Detect dealer-related issues from text"""
    text = (summary or "").lower() + " " + (transcript or "").lower()

    issues = []
    for issue_type, keywords in DEALER_ISSUES.items():
        if any(kw in text for kw in keywords):
            issues.append(issue_type)

    return issues


def extract_dealer_mention(summary, transcript):
    """Check if dealer/dealership is mentioned"""
    text = (summary or "").lower() + " " + (transcript or "").lower()
    dealer_keywords = ['dealer', 'dealership', 'service center', 'service department']
    return any(kw in text for kw in dealer_keywords)


def classify_risk_level(sentiment, escalation_rate, call_count):
    """Classify dealer risk level"""
    if sentiment < -0.5 or escalation_rate > 10 or call_count > 200:
        return 'high'
    elif sentiment < -0.3 or escalation_rate > 5 or call_count > 100:
        return 'medium'
    else:
        return 'low'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--from", dest="date_from", required=True)
    parser.add_argument("--to", dest="date_to", required=True)
    parser.add_argument("--vehicle", default=None)
    parser.add_argument("--state", default=None)
    parser.add_argument("--sort", choices=['volume', 'sentiment', 'escalation'], default='volume')
    parser.add_argument("--issue-type", dest="issue_type",
                       choices=['refused_service', 'repair_failure', 'warranty_denial', 'all'],
                       default='all')
    parser.add_argument("--min-calls", dest="min_calls", type=int, default=20)
    parser.add_argument("--limit", type=int, default=30)
    args, _ = parser.parse_known_args()

    # Build base filters
    params = {"date_from": args.date_from, "date_to": args.date_to}
    base_filters = [
        "DATE(cd.call_date) >= :date_from",
        "DATE(cd.call_date) <= :date_to",
    ]

    if args.vehicle:
        params["vehicle"] = f"%{args.vehicle}%"
        base_filters.append("LOWER(cd.modelvehicleline) LIKE LOWER(:vehicle)")

    if args.state:
        params["state"] = f"%{args.state}%"
        base_filters.append("LOWER(ct.Agent_Team) LIKE LOWER(:state)")

    # Add dealer mention filter
    dealer_keywords = ['dealer', 'dealership', 'service center', 'service department']
    dealer_conditions = []
    for i, kw in enumerate(dealer_keywords):
        params[f"dk{i}"] = f"%{kw}%"
        dealer_conditions.append(f"LOWER(ct.summary) LIKE :dk{i} OR LOWER(ct.transcript) LIKE :dk{i}")
    base_filters.append(f"({' OR '.join(dealer_conditions)})")

    # Add issue-specific filter if requested
    if args.issue_type != 'all':
        issue_keywords = DEALER_ISSUES[args.issue_type]
        issue_conditions = []
        for i, kw in enumerate(issue_keywords):
            params[f"ik{i}"] = f"%{kw}%"
            issue_conditions.append(f"LOWER(ct.summary) LIKE :ik{i} OR LOWER(ct.transcript) LIKE :ik{i}")
        base_filters.append(f"({' OR '.join(issue_conditions)})")

    base_where = " AND ".join(base_filters)

    with get_connection() as conn:
        # True count of dealer-related calls (not capped by sample LIMIT)
        with conn.cursor() as cursor:
            cursor.execute(f"""
                SELECT COUNT(*)
                FROM {CALL_DATA} cd
                JOIN {CALL_TABLE} ct ON cd.call_id = ct.call_id
                WHERE {base_where}
                  AND ct.summary IS NOT NULL
            """, params)  # nosec B608
            total_dealer_calls = cursor.fetchone()[0]

        # Sample rows for dealer grouping and issue detection (most recent 500)
        with conn.cursor() as cursor:
            query = f"""
                SELECT
                    cd.call_id,
                    ct.Agent_Team,
                    ct.summary,
                    ct.transcript,
                    cd.cust_end_sent,
                    cd.handle_time,
                    cd.modelvehicleline,
                    cd.vin,
                    cd.pacode,
                    COALESCE(dl.dealer, 'Unknown Dealer') AS dealer_name,
                    COALESCE(dl.dealerterritory, 'Unknown') AS dealer_territory
                FROM {CALL_DATA} cd
                JOIN {CALL_TABLE} ct ON cd.call_id = ct.call_id
                LEFT JOIN {DEALER_LOOKUP} dl ON cd.pacode = dl.pacode
                WHERE {base_where}
                  AND ct.summary IS NOT NULL
                ORDER BY cd.call_date DESC
                LIMIT 500
            """  # nosec B608
            cursor.execute(query, params)
            rows = cursor.fetchall()

        # Get total calls for percentage
        total_params = {"date_from": args.date_from, "date_to": args.date_to}
        total_filters = [
            "DATE(cd.call_date) >= :date_from",
            "DATE(cd.call_date) <= :date_to",
        ]
        if args.vehicle:
            total_params["vehicle"] = f"%{args.vehicle}%"
            total_filters.append("LOWER(cd.modelvehicleline) LIKE LOWER(:vehicle)")
        if args.state:
            total_params["state"] = f"%{args.state}%"
            total_filters.append("LOWER(ct.Agent_Team) LIKE LOWER(:state)")

        with conn.cursor() as cursor:
            total_query = f"""
                SELECT COUNT(*)
                FROM {CALL_DATA} cd
                WHERE {' AND '.join(total_filters)}
            """  # nosec B608
            cursor.execute(total_query, total_params)
            total_calls = cursor.fetchone()[0]

        # Process dealer calls - group by dealer name from lookup table
        dealer_data = defaultdict(lambda: {
            'pacode': None,
            'territory': None,
            'calls': [],
            'sentiments': [],
            'issues': defaultdict(int),
            'escalations': 0,
            'vins': set()
        })

        for row in rows:
            call_id, team, summary, transcript, sentiment, aht, vehicle, vin, pacode, dealer_name, dealer_territory = row

            if not dealer_name or dealer_name == 'Unknown Dealer':
                dealer_name = "Unknown Dealer"

            # Store dealer metadata
            if not dealer_data[dealer_name]['pacode']:
                dealer_data[dealer_name]['pacode'] = pacode
                dealer_data[dealer_name]['territory'] = dealer_territory

            # Detect issues
            issues = detect_dealer_issues(summary, transcript)
            for issue in issues:
                dealer_data[dealer_name]['issues'][issue] += 1

            dealer_data[dealer_name]['calls'].append(call_id)

            if sentiment:
                dealer_data[dealer_name]['sentiments'].append(float(sentiment))

            if vin:
                dealer_data[dealer_name]['vins'].add(vin)

            # Detect escalations
            escalation_keywords = ['escalate', 'manager', 'supervisor', 'lawyer', 'lawsuit', 'buyback', 'lemon']
            text = (summary or "").lower() + " " + (transcript or "").lower()
            if any(kw in text for kw in escalation_keywords):
                dealer_data[dealer_name]['escalations'] += 1

        # Build dealer performance list
        dealer_performance = []

        for dealer_name, data in dealer_data.items():
            call_count = len(data['calls'])

            if call_count < args.min_calls:
                continue

            avg_sentiment = sum(data['sentiments']) / len(data['sentiments']) if data['sentiments'] else 0
            escalation_rate = round(data['escalations'] * 100.0 / call_count, 1) if call_count > 0 else 0
            repeat_rate = round((call_count - len(data['vins'])) * 100.0 / call_count, 1) if call_count > 0 and data['vins'] else 0

            # Get top issues
            top_issues = sorted(data['issues'].items(), key=lambda x: x[1], reverse=True)[:3]

            dealer_performance.append({
                'dealer_name': dealer_name,
                'pacode': data['pacode'],
                'territory': data['territory'],
                'call_count': call_count,
                'pct_of_dealer_calls': round(call_count * 100.0 / total_dealer_calls, 1) if total_dealer_calls > 0 else 0,
                'avg_sentiment': round(avg_sentiment, 2),
                'primary_complaints': [{'issue': issue, 'count': count} for issue, count in top_issues],
                'escalation_rate': escalation_rate,
                'repeat_customer_rate': repeat_rate,
                'unique_vehicles': len(data['vins']),
                'risk_level': classify_risk_level(avg_sentiment, escalation_rate, call_count)
            })

        # Sort based on sort parameter
        if args.sort == 'volume':
            # HIGHEST OCCURRENCE FIRST (default priority)
            dealer_performance.sort(key=lambda x: x['call_count'], reverse=True)
        elif args.sort == 'sentiment':
            # Worst sentiment first
            dealer_performance.sort(key=lambda x: x['avg_sentiment'])
        elif args.sort == 'escalation':
            # Highest escalation rate first
            dealer_performance.sort(key=lambda x: x['escalation_rate'], reverse=True)

        # Calculate insights
        insights = {}
        if dealer_performance:
            worst_sentiment = min(dealer_performance, key=lambda x: x['avg_sentiment'])
            highest_volume = max(dealer_performance, key=lambda x: x['call_count'])
            highest_escalation = max(dealer_performance, key=lambda x: x['escalation_rate'])
            high_risk_count = sum(1 for d in dealer_performance if d['risk_level'] == 'high')

            insights = {
                'worst_sentiment_dealer': f"{worst_sentiment['dealer_name']} ({worst_sentiment['avg_sentiment']} avg)",
                'highest_volume_dealer': f"{highest_volume['dealer_name']} ({highest_volume['call_count']} calls)",
                'highest_escalation_dealer': f"{highest_escalation['dealer_name']} ({highest_escalation['escalation_rate']}% rate)",
                'dealers_at_risk': high_risk_count
            }

        # Issue breakdown
        all_issues = defaultdict(int)
        for data in dealer_data.values():
            for issue, count in data['issues'].items():
                all_issues[issue] += count

        result = {
            'date_range': f"{args.date_from} to {args.date_to}",
            'vehicle_filter': args.vehicle or "all",
            'region_filter': args.state or "all",
            'sort_by': args.sort,
            'total_dealer_mentions': total_dealer_calls,
            'pct_of_total_calls': round(total_dealer_calls * 100.0 / total_calls, 1) if total_calls > 0 else 0,
            'dealers_analyzed': len(dealer_performance),
            'dealer_performance': dealer_performance[:args.limit],
            'insights': insights,
            'issue_breakdown': dict(all_issues)
        }

        print(json.dumps(result, indent=2, default=serialize))


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)
