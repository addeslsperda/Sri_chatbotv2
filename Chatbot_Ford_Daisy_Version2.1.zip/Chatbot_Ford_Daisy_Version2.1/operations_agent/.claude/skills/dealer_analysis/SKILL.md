---
name: dealer_analysis
display_name: Dealer Performance & Complaint Analysis
description: Analyzes which dealers generate most customer complaints, service issues, and escalations. Use for "which dealers have issues", "dealer complaint rate", "problem dealers", "dealer performance", "which dealer has worst sentiment", "dealer service quality".
signals:
  - dealer
  - dealership
  - service center
  - which dealer
  - dealer complaint
  - dealer issue
  - dealer performance
  - dealer quality
  - service quality
requires:
  - date range
not_good_for: General dealership flag counts (use flag_counts), vehicle issues (use other skills)
---

# Dealer Performance & Complaint Analysis

## What this script does
Analyzes dealer-level performance to identify problem dealers:
- **Dealer complaint rate**: Which dealers generate most customer calls
- **Service quality issues**: Repair failures, warranty denials, refused service
- **Customer sentiment by dealer**: Which dealers have angry customers
- **Escalation rate by dealer**: Dealers causing legal/management escalations
- **Regional patterns**: Geographic clustering of problem dealers
- **Repeat customer issues**: Same customers calling about same dealer

Returns dealer rankings sorted by call volume (highest first).

## How to run it

```bash
python .claude/skills/dealer_analysis/scripts/dealer_analysis.py --from 2026-01-01 --to 2026-01-31
```

## Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--from` | Yes | — | Start date YYYY-MM-DD |
| `--to` | Yes | — | End date YYYY-MM-DD |
| `--vehicle` | No | all | Filter by vehicle model |
| `--state` | No | all | Filter by state (e.g., "TX", "CA", "MI") |
| `--min-calls` | No | `20` | Minimum calls for dealer to be included |
| `--sort` | No | `volume` | Sort: `volume` (most calls), `sentiment` (worst first), `escalation` |
| `--issue-type` | No | all | Filter: `refused_service`, `repair_failure`, `warranty_denial`, `all` |
| `--limit` | No | `30` | Max dealers to return |

## Example calls

```bash
# Top dealers by call volume
python .claude/skills/dealer_analysis/scripts/dealer_analysis.py --from 2026-01-01 --to 2026-01-31

# Problem dealers (worst sentiment first)
python .claude/skills/dealer_analysis/scripts/dealer_analysis.py --from 2026-01-01 --to 2026-01-31 --sort sentiment

# Texas dealers only
python .claude/skills/dealer_analysis/scripts/dealer_analysis.py --from 2026-01-01 --to 2026-01-31 --state "TX"

# F-150 dealer issues
python .claude/skills/dealer_analysis/scripts/dealer_analysis.py --from 2026-01-01 --to 2026-01-31 --vehicle "F-150"

# Dealers refusing service
python .claude/skills/dealer_analysis/scripts/dealer_analysis.py --from 2026-01-01 --to 2026-01-31 --issue-type refused_service

# California dealers with high escalation rate
python .claude/skills/dealer_analysis/scripts/dealer_analysis.py --from 2026-01-01 --to 2026-01-31 --state "CA" --sort escalation
```

## Output format

```json
{
  "date_range": "2026-01-01 to 2026-01-31",
  "vehicle_filter": "all",
  "state_filter": "all",
  "sort_by": "volume",
  "total_dealer_mentions": 12450,
  "pct_of_total_calls": 8.6,
  "unique_dealers": 850,
  "dealers_analyzed": 30,
  "dealer_performance": [
    {
      "dealer_code": "12345",
      "dealer_name": "Bob's Ford - Houston",
      "city": "Houston",
      "state": "TX",
      "call_count": 285,
      "pct_of_dealer_calls": 2.3,
      "avg_sentiment": -0.62,
      "sentiment_rank": "bottom_10_pct",
      "primary_complaints": [
        {"issue": "Repair not fixed", "count": 95},
        {"issue": "Refused service", "count": 62},
        {"issue": "Parts delay", "count": 48}
      ],
      "escalation_rate": 12.5,
      "repeat_customer_rate": 8.2,
      "avg_handle_time": 1250,
      "risk_level": "high"
    }
  ],
  "insights": {
    "worst_sentiment_dealer": "Bob's Ford - Houston (-0.62 avg)",
    "highest_volume_dealer": "XYZ Ford - Detroit (285 calls)",
    "highest_escalation_dealer": "ABC Ford - Los Angeles (15.2% escalation rate)",
    "dealers_at_risk": 8
  },
  "issue_breakdown": {
    "refused_service": 820,
    "repair_failure": 2450,
    "warranty_denial": 680,
    "parts_unavailable": 1250,
    "overcharge": 420
  },
  "geographic_clusters": [
    {
      "state": "TX",
      "dealer_count": 85,
      "total_calls": 2850,
      "avg_sentiment": -0.45
    },
    {
      "state": "CA",
      "dealer_count": 92,
      "total_calls": 2620,
      "avg_sentiment": -0.38
    }
  ]
}
```

## Risk Level Classification

**High Risk** (Action Required):
- Sentiment < -0.5
- Escalation rate > 10%
- Repeat customer rate > 5%
- Volume trending up week-over-week

**Medium Risk** (Monitor):
- Sentiment -0.3 to -0.5
- Escalation rate 5-10%
- Above-average complaint volume

**Low Risk** (Normal):
- Sentiment > -0.3
- Escalation rate < 5%
- Below-average complaint volume

## Sorting Options

**`--sort volume`** (DEFAULT):
- Most customer calls = highest priority
- Use for: "Which dealers generate most complaints?"

**`--sort sentiment`**:
- Worst sentiment first (most negative)
- Use for: "Which dealers have angriest customers?"

**`--sort escalation`**:
- Highest escalation rate first
- Use for: "Which dealers cause legal issues?"

## Error output
If something goes wrong, the script prints `{"error": "..."}` to stderr and exits with code 1.

## Notes
- **Use cases**: 
  - Identify problem dealers requiring intervention
  - Regional performance comparison (which states have issues)
  - Service quality tracking (refused service, repair failures)
  - Escalation hotspots (legal/buyback triggers)
  - Training needs (dealers with knowledge gaps)
- **Default sort = volume** (most calls = highest priority)
- Dealers with < 20 calls excluded by default (insufficient data)
- Dealer names extracted from transcripts/summaries (keyword matching)
- Combine with escalation_tracking to see dealer-driven escalations
- Use with regional_analysis for state-level patterns
- Cross-reference with customer_journey_analysis for repeat dealer issues
