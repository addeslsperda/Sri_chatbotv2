"""
Enhanced team routing and transfer analysis with privacy protection.
Analyzes which teams handle which issues and transfer patterns WITHOUT revealing agent names.

Usage:
    python team_routing_analysis.py --from 2026-01-01 --to 2026-01-31
    python team_routing_analysis.py --from 2026-01-01 --to 2026-01-31 --topic "FordPass"
    python team_routing_analysis.py --from 2026-01-01 --to 2026-01-31 --analysis-type transfers

Output: JSON with team routing or transfer analysis
"""
import argparse
import json
import os
import sys
from collections import defaultdict
from decimal import Decimal
from databricks import sql
import requests
from dotenv import load_dotenv

load_dotenv(override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


def serialize(v):
    if isinstance(v, Decimal):
        return float(v)
    if hasattr(v, "isoformat"):
        return str(v)
    return v


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--from", dest="date_from", required=True, help="Start date YYYY-MM-DD")
    parser.add_argument("--to", dest="date_to", required=True, help="End date YYYY-MM-DD")
    parser.add_argument("--topic", default=None, help="Filter by topic/issue")
    parser.add_argument("--team", default=None, help="Focus on specific team")
    parser.add_argument("--analysis-type", dest="analysis_type", choices=["routing", "transfers"],
                        default="routing", help="Analysis type")
    parser.add_argument("--min-calls", dest="min_calls", type=int, default=10,
                        help="Minimum calls for team inclusion")
    parser.add_argument("--limit", type=int, default=500, help="Max results to return")
    args, _ = parser.parse_known_args()

    # Build parameters
    params = {
        "date_from": args.date_from,
        "date_to": args.date_to,
        "min_calls": args.min_calls,
        "limit": args.limit
    }

    # Build filters
    filters = [
        "v.date_of_call >= :date_from",
        "v.date_of_call <= :date_to",
        "v.agent_team IS NOT NULL"
    ]

    # Enhanced topic filtering using all data sources
    if args.topic:
        params["topic"] = f"%{args.topic}%"
        # Topic filtering using available columns in WHERE context
        # Note: We'll use a subquery approach or EXISTS for complex topic filtering
        params["topic_subquery"] = f"%{args.topic}%"
        filters.append("""(
            UPPER(v.program_name) LIKE UPPER(:topic)
            OR EXISTS (
                SELECT 1 FROM text_analytics.nlp_dashboard.case_metadata cm_sub
                WHERE cm_sub.casenumber = cd.casenumber
                AND (UPPER(cm_sub.caseclassificationlevel1) LIKE UPPER(:topic_subquery)
                     OR UPPER(cm_sub.caseclassificationlevel2) LIKE UPPER(:topic_subquery))
            )
        )""")

    # Team filtering
    if args.team:
        params["team"] = f"%{args.team}%"
        filters.append("UPPER(v.agent_team) LIKE UPPER(:team)")

    where_clause = " AND ".join(filters)

    with get_connection() as conn:
        with conn.cursor() as cursor:
            if args.analysis_type == "routing":
                # TEAM ROUTING ANALYSIS
                query = f"""
                    WITH team_routing_data AS (
                        SELECT
                            v.agent_team,
                            v.center_name,
                            v.program_name,
                            v.department_name,

                            -- Volume metrics
                            COUNT(*) as total_calls,
                            COUNT(DISTINCT v.transaction_id) as unique_calls,

                            -- Performance metrics (from call_data)
                            AVG(cd.handle_time) as avg_handle_time_seconds,
                            AVG(cd.complexity) as avg_complexity,
                            AVG(cd.number_of_transfers) as avg_transfers,

                            -- Transfer analysis
                            SUM(CASE WHEN cd.number_of_transfers > 0 THEN 1 ELSE 0 END) as calls_with_transfers,

                            -- Case management metrics
                            COUNT(DISTINCT cm.casenumber) as unique_cases,
                            COUNT(DISTINCT cm.owner) as case_owners,
                            COUNT(DISTINCT cm.caseclassificationlevel1) as classification_types,

                            -- Enhanced topic and issue analysis
                            COUNT(DISTINCT pu.parts_features) as parts_features_count,
                            COUNT(DISTINCT pu.parts_concern) as parts_concerns_count,
                            COUNT(DISTINCT tx.topic_id) as unique_topics,
                            COUNT(DISTINCT td.topic_category) as topic_categories,
                            COUNT(DISTINCT td.topic_level1) as topic_level1_types,
                            COUNT(DISTINCT td.topic_level2) as topic_level2_types

                        FROM dwh_prod.ovprod_o.verint_transcription v

                        -- Performance data join
                        LEFT JOIN text_analytics.nlp_analytics.call_data cd
                            ON v.transaction_id = cd.call_id

                        -- Case management join
                        LEFT JOIN text_analytics.nlp_dashboard.case_metadata cm
                            ON cd.casenumber = cm.casenumber

                        -- Parts join
                        LEFT JOIN text_analytics.nlp_analytics.parts_unfiltered pu
                            ON cd.call_id = pu.call_id

                        -- Topic joins for comprehensive issue analysis
                        LEFT JOIN text_analytics.nlp_analytics.topic_xwalk tx
                            ON cd.call_id = tx.call_id
                        LEFT JOIN text_analytics.nlp_configs.topic_detail td
                            ON tx.topic_id = td.topic_id

                        WHERE {where_clause}

                        GROUP BY v.agent_team, v.center_name, v.program_name, v.department_name
                        HAVING COUNT(*) >= :min_calls
                    ),

                    team_metrics AS (
                        SELECT *,
                            -- Calculated metrics
                            ROUND(avg_handle_time_seconds / 60.0, 2) as avg_handle_time_minutes,
                            ROUND(calls_with_transfers * 100.0 / total_calls, 2) as transfer_rate_pct,
                            ROUND(unique_cases * 100.0 / total_calls, 1) as case_coverage_pct,

                            -- Specialization indicators
                            CASE
                                WHEN (calls_with_transfers * 100.0 / total_calls) <= 5 AND classification_types >= 3 THEN 'Highly Specialized'
                                WHEN (calls_with_transfers * 100.0 / total_calls) <= 15 THEN 'Moderately Specialized'
                                ELSE 'Generalist'
                            END as specialization_level,

                            -- Rankings
                            ROW_NUMBER() OVER (ORDER BY total_calls DESC) as volume_rank,
                            ROW_NUMBER() OVER (ORDER BY (calls_with_transfers * 100.0 / total_calls) ASC) as efficiency_rank

                        FROM team_routing_data
                    )

                    SELECT
                        agent_team,
                        center_name,
                        program_name,
                        department_name,
                        total_calls,
                        avg_handle_time_minutes,
                        avg_complexity,
                        avg_transfers,
                        transfer_rate_pct,
                        unique_cases,
                        case_coverage_pct,
                        case_owners,
                        classification_types,
                        parts_features_count,
                        parts_concerns_count,
                        unique_topics,
                        topic_categories,
                        topic_level1_types,
                        topic_level2_types,
                        specialization_level,
                        volume_rank,
                        efficiency_rank

                    FROM team_metrics
                    ORDER BY total_calls DESC
                    LIMIT :limit
                """

                cursor.execute(query, params)
                rows = cursor.fetchall()
                columns = [d[0] for d in cursor.description]

                team_routing = [dict(zip(columns, [serialize(val) for val in row])) for row in rows]

                # Calculate total for percentages
                total_calls = sum(row.get('total_calls', 0) for row in team_routing)

                # Add percentage of total
                for team in team_routing:
                    team['pct_of_total_calls'] = round(team['total_calls'] * 100.0 / total_calls, 1) if total_calls > 0 else 0

                # Get top issues/topics by team for detailed specialization analysis
                team_issues_query = f"""
                    WITH team_issue_analysis AS (
                        SELECT
                            v.agent_team,

                            -- Case classifications
                            cm.caseclassificationlevel1 as issue_type,
                            'case_classification' as source_type,
                            COUNT(*) as issue_count
                        FROM dwh_prod.ovprod_o.verint_transcription v
                        LEFT JOIN text_analytics.nlp_analytics.call_data cd ON v.transaction_id = cd.call_id
                        LEFT JOIN text_analytics.nlp_dashboard.case_metadata cm ON cd.casenumber = cm.casenumber
                        WHERE {where_clause}
                            AND cm.caseclassificationlevel1 IS NOT NULL
                        GROUP BY v.agent_team, cm.caseclassificationlevel1

                        UNION ALL

                        SELECT
                            v.agent_team,

                            -- Topic level 1
                            td.topic_level1 as issue_type,
                            'topic_level1' as source_type,
                            COUNT(*) as issue_count
                        FROM dwh_prod.ovprod_o.verint_transcription v
                        JOIN text_analytics.nlp_analytics.call_data cd ON v.transaction_id = cd.call_id
                        JOIN text_analytics.nlp_analytics.topic_xwalk tx ON cd.call_id = tx.call_id
                        JOIN text_analytics.nlp_configs.topic_detail td ON tx.topic_id = td.topic_id
                        WHERE {where_clause}
                            AND td.topic_level1 IS NOT NULL
                        GROUP BY v.agent_team, td.topic_level1

                        UNION ALL

                        SELECT
                            v.agent_team,

                            -- Parts concerns
                            pu.parts_concern as issue_type,
                            'parts_concern' as source_type,
                            COUNT(*) as issue_count
                        FROM dwh_prod.ovprod_o.verint_transcription v
                        JOIN text_analytics.nlp_analytics.call_data cd ON v.transaction_id = cd.call_id
                        JOIN text_analytics.nlp_analytics.parts_unfiltered pu ON cd.call_id = pu.call_id
                        WHERE {where_clause}
                            AND pu.parts_concern IS NOT NULL
                        GROUP BY v.agent_team, pu.parts_concern
                    ),

                    ranked_issues AS (
                        SELECT
                            agent_team,
                            issue_type,
                            source_type,
                            issue_count,
                            ROW_NUMBER() OVER (PARTITION BY agent_team ORDER BY issue_count DESC) as rank
                        FROM team_issue_analysis
                        WHERE issue_count >= 5
                    )

                    SELECT
                        agent_team,
                        issue_type,
                        source_type,
                        issue_count
                    FROM ranked_issues
                    WHERE rank <= 5
                    ORDER BY agent_team, issue_count DESC
                """

                cursor.execute(team_issues_query, params)
                issue_rows = cursor.fetchall()

                # Group issues by team
                from collections import defaultdict
                team_issues = defaultdict(list)

                for issue_row in issue_rows:
                    team_name = issue_row[0]
                    issue_type = issue_row[1]
                    source_type = issue_row[2]
                    issue_count = issue_row[3]

                    team_issues[team_name].append({
                        'issue_type': issue_type,
                        'source': source_type,
                        'count': issue_count
                    })

                # Add top issues to each team
                for team in team_routing:
                    team_name = team['agent_team']
                    team['top_issues'] = team_issues.get(team_name, [])

                # Find insights
                insights = {}
                if team_routing:
                    highest_volume = max(team_routing, key=lambda x: x['total_calls'])
                    most_efficient = min(team_routing, key=lambda x: x['transfer_rate_pct'])
                    highly_specialized = [t for t in team_routing if t['specialization_level'] == 'Highly Specialized']

                    insights = {
                        'highest_volume_team': highest_volume['agent_team'],
                        'highest_volume_calls': highest_volume['total_calls'],
                        'most_efficient_team': most_efficient['agent_team'],
                        'lowest_transfer_rate': most_efficient['transfer_rate_pct'],
                        'highly_specialized_teams': len(highly_specialized),
                        'teams_needing_support': [
                            {
                                'team': t['agent_team'],
                                'transfer_rate': t['transfer_rate_pct'],
                                'reason': 'high_transfers'
                            }
                            for t in team_routing if t['transfer_rate_pct'] > 20
                        ]
                    }

                result = {
                    'metadata': {
                        'date_range': f"{args.date_from} to {args.date_to}",
                        'analysis_type': 'routing',
                        'topic_filter': args.topic or "all",
                        'team_filter': args.team or "all",
                        'min_calls_threshold': args.min_calls
                    },
                    'summary': {
                        'total_calls_analyzed': total_calls,
                        'teams_analyzed': len(team_routing),
                        'data_sources': [
                            'dwh_prod.ovprod_o.verint_transcription (primary)',
                            'text_analytics.nlp_analytics.call_data (performance)',
                            'text_analytics.nlp_dashboard.case_metadata (case classifications)',
                            'text_analytics.nlp_analytics.parts_unfiltered (parts/features)',
                            'text_analytics.nlp_analytics.topic_xwalk (topic mapping)',
                            'text_analytics.nlp_configs.topic_detail (topic hierarchy)'
                        ]
                    },
                    'team_routing': team_routing,
                    'insights': insights
                }

            else:
                # TRANSFER ANALYSIS
                query = f"""
                    WITH transfer_analysis AS (
                        SELECT
                            v.agent_team,
                            v.center_name,
                            v.program_name,

                            -- Transfer metrics
                            COUNT(*) as total_calls,
                            SUM(CASE WHEN cd.number_of_transfers > 0 THEN 1 ELSE 0 END) as calls_with_transfers,
                            SUM(cd.number_of_transfers) as total_transfer_count,
                            AVG(cd.number_of_transfers) as avg_transfers_per_call,
                            MAX(cd.number_of_transfers) as max_transfers,

                            -- Performance context
                            AVG(cd.handle_time) / 60.0 as avg_handle_time_minutes,
                            AVG(cd.complexity) as avg_complexity,

                            -- Case context
                            COUNT(DISTINCT cm.casenumber) as cases_with_data,
                            COUNT(DISTINCT cm.caseclassificationlevel1) as issue_types

                        FROM dwh_prod.ovprod_o.verint_transcription v
                        JOIN text_analytics.nlp_analytics.call_data cd ON v.transaction_id = cd.call_id
                        LEFT JOIN text_analytics.nlp_dashboard.case_metadata cm ON cd.casenumber = cm.casenumber
                        WHERE {where_clause}
                        GROUP BY v.agent_team, v.center_name, v.program_name
                        HAVING COUNT(*) >= :min_calls
                    ),

                    transfer_metrics AS (
                        SELECT *,
                            ROUND(calls_with_transfers * 100.0 / total_calls, 2) as transfer_rate_pct,
                            ROUND(avg_handle_time_minutes, 2) as avg_aht_minutes,

                            -- Transfer intensity categories
                            CASE
                                WHEN calls_with_transfers * 100.0 / total_calls > 20 THEN 'High Transfer'
                                WHEN calls_with_transfers * 100.0 / total_calls > 10 THEN 'Medium Transfer'
                                ELSE 'Low Transfer'
                            END as transfer_category

                        FROM transfer_analysis
                    )

                    SELECT
                        agent_team,
                        center_name,
                        program_name,
                        total_calls,
                        calls_with_transfers,
                        total_transfer_count,
                        transfer_rate_pct,
                        avg_transfers_per_call,
                        max_transfers,
                        avg_aht_minutes,
                        avg_complexity,
                        cases_with_data,
                        issue_types,
                        transfer_category

                    FROM transfer_metrics
                    ORDER BY transfer_rate_pct DESC
                    LIMIT :limit
                """

                cursor.execute(query, params)
                rows = cursor.fetchall()
                columns = [d[0] for d in cursor.description]

                transfer_data = [dict(zip(columns, [serialize(val) for val in row])) for row in rows]

                # Calculate summary statistics
                if transfer_data:
                    total_calls = sum(row['total_calls'] for row in transfer_data)
                    total_transfers = sum(row['calls_with_transfers'] for row in transfer_data)
                    overall_transfer_rate = round(total_transfers * 100.0 / total_calls, 2) if total_calls > 0 else 0

                    highest_transfer_team = max(transfer_data, key=lambda x: x['transfer_rate_pct'])
                    lowest_transfer_team = min(transfer_data, key=lambda x: x['transfer_rate_pct'])

                    result = {
                        'metadata': {
                            'date_range': f"{args.date_from} to {args.date_to}",
                            'analysis_type': 'transfers',
                            'topic_filter': args.topic or "all",
                            'team_filter': args.team or "all",
                            'min_calls_threshold': args.min_calls
                        },
                        'summary': {
                            'total_calls_analyzed': total_calls,
                            'total_calls_with_transfers': total_transfers,
                            'overall_transfer_rate_pct': overall_transfer_rate,
                            'teams_analyzed': len(transfer_data)
                        },
                        'transfer_analysis': transfer_data,
                        'transfer_insights': {
                            'highest_transfer_team': {
                                'team': highest_transfer_team['agent_team'],
                                'transfer_rate': highest_transfer_team['transfer_rate_pct'],
                                'calls': highest_transfer_team['total_calls']
                            },
                            'most_efficient_team': {
                                'team': lowest_transfer_team['agent_team'],
                                'transfer_rate': lowest_transfer_team['transfer_rate_pct'],
                                'calls': lowest_transfer_team['total_calls']
                            },
                            'high_transfer_teams': [
                                t['agent_team'] for t in transfer_data
                                if t['transfer_category'] == 'High Transfer'
                            ]
                        }
                    }
                else:
                    result = {
                        'metadata': {
                            'date_range': f"{args.date_from} to {args.date_to}",
                            'analysis_type': 'transfers',
                            'error': 'No transfer data found matching criteria'
                        }
                    }

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)