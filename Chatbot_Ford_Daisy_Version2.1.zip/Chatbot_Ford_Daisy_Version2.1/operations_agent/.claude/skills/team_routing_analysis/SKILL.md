---
name: team_routing_analysis
display_name: Team Routing & Transfer Analysis
description: Analyzes which teams handle which issues, transfer patterns, and routing optimization with privacy protection. Use for "which teams took these calls", "what teams handle password resets", "transfer patterns", "routing analysis", "which team handles X", "transfer into/out of team". NO AGENT NAMES REVEALED.
signals:
  - which teams
  - what teams handle
  - which team handles
  - transfer patterns
  - routing analysis
  - transferred to
  - transferred from
  - team assignment
  - team specialization
  - routing optimization
requires:
  - date range
not_good_for: Team volume only (use team_volume), agent pain points (use agent_pain_points)
---

# Team Routing & Transfer Analysis

## What this script does
Analyzes team assignments and transfer patterns to identify:
- **Which teams handle which issues**: Topic-to-team mapping
- **Transfer patterns**: Which teams transfer to which teams
- **Routing optimization**: Identify misrouted calls
- **Specialization**: Teams' primary responsibilities
- **Transfer hotspots**: Teams with high incoming/outgoing transfers

Returns team routing breakdown with transfer flow analysis.

## How to run it

```bash
python .claude/skills/team_routing_analysis/scripts/team_routing_analysis.py --from 2026-01-01 --to 2026-01-31
```

## Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--from` | Yes | — | Start date YYYY-MM-DD |
| `--to` | Yes | — | End date YYYY-MM-DD |
| `--topic` | No | all | Filter by topic/issue (e.g., "FordPass", "authentication", "charging") |
| `--team` | No | all | Focus on specific team |
| `--analysis-type` | No | `routing` | Type: `routing` (who handles what), `transfers` (transfer patterns) |
| `--min-calls` | No | `10` | Minimum calls for team to be included |
| `--limit` | No | `100` | Max teams/patterns to return (ensures sufficient data for analysis) |

## Example calls

```bash
# Overall team routing for January
python .claude/skills/team_routing_analysis/scripts/team_routing_analysis.py --from 2026-01-01 --to 2026-01-31

# Which teams handle FordPass issues
python .claude/skills/team_routing_analysis/scripts/team_routing_analysis.py --from 2026-01-01 --to 2026-01-31 --topic "FordPass"

# Transfer patterns analysis
python .claude/skills/team_routing_analysis/scripts/team_routing_analysis.py --from 2026-01-01 --to 2026-01-31 --analysis-type transfers

# Specific team focus (BEV Inbound)
python .claude/skills/team_routing_analysis/scripts/team_routing_analysis.py --from 2026-01-01 --to 2026-01-31 --team "BEV"

# Who handles password resets
python .claude/skills/team_routing_analysis/scripts/team_routing_analysis.py --from 2026-01-01 --to 2026-01-31 --topic "password"

# Authentication routing
python .claude/skills/team_routing_analysis/scripts/team_routing_analysis.py --from 2026-01-01 --to 2026-01-31 --topic "authentication"
```

## Output format

### Routing Analysis:
```json
{
  "date_range": "2026-01-01 to 2026-01-31",
  "analysis_type": "routing",
  "topic_filter": "FordPass",
  "total_calls": 23963,
  "teams_analyzed": 25,
  "team_routing": [
    {
      "team": "FM-MSS-BAC-Dearborn-5236-FordPass-FPTm08",
      "call_count": 3850,
      "pct_of_topic": 16.1,
      "avg_aht": 645.5,
      "avg_complexity": 42.3,
      "transfer_rate": 12.5,
      "primary_issues": [
        {"issue": "connectivity", "count": 1250},
        {"issue": "remote start", "count": 850},
        {"issue": "phone as a key", "count": 620}
      ],
      "specialization_score": 0.85
    }
  ],
  "routing_insights": {
    "most_specialized_team": "FM-MSS-BAC-Dearborn-5236-FordPass-FPTm08",
    "highest_volume_team": "FM-MSS-CRC-Houston-5508-Truck-InquiryTm02",
    "teams_needing_support": [
      {"team": "FM-MSS-CRC-Melbourne-0813-LinConc", "transfer_rate": 28.5, "reason": "high_transfers"}
    ]
  }
}
```

### Transfer Analysis:
```json
{
  "date_range": "2026-01-01 to 2026-01-31",
  "analysis_type": "transfers",
  "total_transfers": 11618,
  "transfer_rate": 8.1,
  "transfer_patterns": [
    {
      "from_team": "FM-MSS-CRC-Houston-5508-Truck-InquiryTm02",
      "to_team": "FM-MSS-CRC-Houston-5508-ConcernTm13",
      "transfer_count": 850,
      "pct_of_transfers": 7.3,
      "common_reasons": [
        "Technical escalation",
        "Warranty concern",
        "Buyback request"
      ],
      "avg_time_before_transfer": 425.5
    }
  ],
  "transfer_hotspots": {
    "highest_outgoing": {
      "team": "FM-MSS-CRC-Houston-5508-Truck-InquiryTm02",
      "outgoing_transfers": 2450,
      "outgoing_rate": 18.2
    },
    "highest_incoming": {
      "team": "FM-MSS-BAC-Dearborn-5236-FordPass-FPTm08",
      "incoming_transfers": 1950,
      "pct_from_transfers": 35.8
    }
  }
}
```

## Specialization Score

Teams receive a specialization score (0-1) based on:
- **Focus**: Do they handle a narrow set of issues? (higher = more focused)
- **Expertise**: Low transfer rate out (higher = handle issues well)
- **Consistency**: Similar AHT/complexity across calls (higher = well-defined scope)

Score > 0.8: Highly specialized team  
Score 0.5-0.8: Moderately specialized  
Score < 0.5: Generalist team

## Error output
If something goes wrong, the script prints `{"error": "..."}` to stderr and exits with code 1.

## Notes
- **Use cases**: 
  - Optimize routing (ensure right calls go to right teams)
  - Identify training needs (teams with high transfers)
  - Load balancing (redistribute work from overloaded teams)
  - Specialization tracking (ensure experts handle complex issues)
- **Transfer patterns** show which teams work together most
- High transfer rate may indicate:
  1. Misrouting (calls going to wrong team initially)
  2. Escalation needs (complex issues requiring specialists)
  3. Training gaps (team lacks knowledge for certain topics)
- Teams with < 50 calls excluded by default (insufficient data)
- Use with agent_pain_points to identify both routing and skill gaps
- Combine with temporal_comparison to track routing changes over time
