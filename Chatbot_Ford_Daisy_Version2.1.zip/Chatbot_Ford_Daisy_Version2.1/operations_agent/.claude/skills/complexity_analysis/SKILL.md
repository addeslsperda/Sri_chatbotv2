---
name: complexity_analysis
display_name: Enhanced Complexity Analysis
description: Comprehensive complexity analysis with data-driven percentile categories, multi-source integration, and complexity drivers identification. Uses validated thresholds from actual data (P33=8.0, P67=20.0). Covers complexity patterns, drivers, quality correlation, and performance optimization. Use for "what drives complexity", "high complexity calls", "complexity by vehicle/team", "quality vs complexity balance".
signals:
  - high complexity
  - complexity drivers
  - complexity analysis
  - hard calls
  - difficult calls
  - friction points
  - what makes calls complex
  - complexity patterns
  - complexity by vehicle
  - complexity by team
  - AHT drivers
  - quality vs complexity
  - performance optimization
requires:
  - a date range (from and to)
not_good_for: Transfer metrics (use transfer_analysis), team volume counts (use team_volume), overall AHT analysis (use aht_analysis)
---

# Enhanced Complexity Analysis

## What this script does
Comprehensive complexity analysis using ford_daisy.analytics.call_data + 7 enrichment sources with validated, percentile-based categories:
- **Complexity performance analysis** using real data thresholds (Low <=8.0, Medium 8.0-20.0, High >=20.0)
- **Complexity drivers identification** - what causes high complexity (case types, topics, transfers)
- **Quality vs complexity correlation** - how complexity relates to sentiment, NPS, FCR
- **Performance benchmarking** with percentile rankings and outlier detection
- **Multi-dimensional analysis** by vehicle, team, location, time patterns
- **Data-driven insights** with no hardcoded assumptions

## When to use
- "What drives our complexity?"
- "Which teams handle most complex calls?"
- "Which vehicles generate highest complexity?"
- "How does complexity affect quality metrics?"
- "What are complexity outliers?"
- "Case type complexity analysis"
- "Topic complexity patterns"
- "Transfer impact on complexity"
- "Hour/day complexity patterns"
- "Performance optimization opportunities"

## Parameters
- `--from` and `--to`: Date range (required)
- `--group-by`: Analysis dimension - `vehicle`, `team`, `location`, `complexity_tier`, `hour`, `day_of_week` (default: vehicle)
- `--vehicle`: Filter by vehicle model (optional)
- `--team`: Filter by agent team (optional)
- `--program`: Filter by program name (optional)
- `--analysis-type`: Focus area - `overview`, `drivers`, `performance` (default: overview)
- `--min-calls`: Minimum calls for inclusion (default 100, ensures sufficient data for reliable analysis)
- `--limit`: Max results to return (default 100, ensures sufficient data)

## Output format

```json
{
  "metadata": {
    "analysis_period": "2026-01-01 to 2026-01-31",
    "group_by": "vehicle",
    "filters": { "vehicle": "all", "team": "all", "program": "all" },
    "analysis_params": {
      "analysis_type": "overview",
      "min_calls_threshold": 100,
      "like_to_like_comparisons": "within complexity tiers using averages and percentages"
    },
    "data_sources": [
      "ford_daisy.analytics.call_data (PRIMARY complexity source)",
      "text_analytics.nlp_analytics.call_data (performance metrics)",
      "dwh_prod.ovprod_o.verint_transcription (teams/locations)",
      "text_analytics.nlp_analytics.sentiments (quality correlation)",
      "text_analytics.nlp_analytics.topic_xwalk (complexity drivers)",
      "text_analytics.nlp_configs.topic_detail (topic hierarchy)",
      "text_analytics.nlp_analytics.parts_unfiltered (detailed drivers)"
    ],
    "validated_thresholds": {
      "explanation": "All complexity categories based on actual data percentiles from the analysis period",
      "low_complexity": "<=8.0 (P33 from 3,934,169 actual calls)",
      "medium_complexity": "8.0-20.0 (P33-P67 range)",
      "high_complexity": ">=20.0 (P67+ from actual data)",
      "outlier_threshold": ">=43.0 (P90+ needs investigation)",
      "data_range": "0.0 to 2638.0"
    }
  },
  "complexity_analysis": [
    {
      "group_name": "F-150",
      "total_calls": 5133,
      "avg_complexity": 18.5,
      "median_complexity": 16.2,
      "p25_complexity": 8.1,
      "p75_complexity": 25.3,
      "p90_complexity": 42.1,
      "complexity_category": "Medium Complexity (P33-P67)",
      "low_complexity_calls": 1285,
      "medium_complexity_calls": 3104,
      "high_complexity_calls": 744,
      "avg_aht_minutes": 10.22,
      "avg_sentiment": 0.0954,
      "avg_nps": 4.25,
      "fcr_rate": 0.856,
      "avg_transfers": 0.05,
      "transfer_rate_pct": 4.8
    }
  ],
  "complexity_drivers": {
    "case_type_drivers": [
      {
        "case_type": "Technical Assistance",
        "call_count": 8450,
        "avg_complexity": 45.2,
        "avg_aht_minutes": 18.5,
        "avg_transfers": 0.12
      }
    ],
    "topic_drivers": [
      {
        "topic": "In-Vehicle Technology",
        "call_count": 2850,
        "avg_complexity": 38.7,
        "avg_aht_minutes": 22.1
      }
    ],
    "transfer_impact": [
      {
        "transfer_category": "3+ Transfers",
        "call_count": 1250,
        "avg_complexity": 52.3,
        "avg_aht_minutes": 25.8,
        "avg_sentiment": -0.0245
      }
    ]
  },
  "insights": {
    "performance_comparison": {
      "lowest_complexity": {
        "name": "F-150",
        "avg_complexity": 18.5,
        "category": "Medium Complexity (P33-P67)"
      },
      "highest_complexity": {
        "name": "ECOSPORT",
        "avg_complexity": 28.6,
        "category": "High Complexity (>=P67)"
      }
    },
    "complexity_distribution": {
      "low_complexity_groups": 12,
      "medium_complexity_groups": 15,
      "high_complexity_groups": 8,
      "high_complexity_groups_list": [
        {"name": "ECOSPORT", "avg_complexity": 28.6},
        {"name": "EDGE", "avg_complexity": 26.66}
      ]
    },
    "quality_correlation": {
      "aht_complexity_correlation": "Strong positive correlation",
      "sentiment_complexity_impact": "Negative impact",
      "transfer_complexity_relationship": "Higher complexity increases transfer likelihood"
    },
    "outlier_analysis": {
      "outlier_count": 3,
      "outlier_threshold": 43.0,
      "top_outliers": [
        {"group_name": "ECOSPORT", "avg_complexity": 28.6}
      ]
    }
  }
}
```

## Example calls

```bash
# Overall vehicle complexity analysis
python .claude/skills/complexity_analysis/scripts/complexity_analysis.py --from 2026-01-01 --to 2026-01-31 --group-by vehicle

# Team complexity analysis
python .claude/skills/complexity_analysis/scripts/complexity_analysis.py --from 2026-01-01 --to 2026-01-31 --group-by team

# Complexity drivers analysis
python .claude/skills/complexity_analysis/scripts/complexity_analysis.py --from 2026-01-01 --to 2026-01-31 --analysis-type drivers

# Complexity tier analysis
python .claude/skills/complexity_analysis/scripts/complexity_analysis.py --from 2026-01-01 --to 2026-01-31 --group-by complexity_tier

# Hour-by-hour complexity patterns
python .claude/skills/complexity_analysis/scripts/complexity_analysis.py --from 2026-01-01 --to 2026-01-31 --group-by hour

# Vehicle-specific complexity deep dive
python .claude/skills/complexity_analysis/scripts/complexity_analysis.py --from 2026-01-01 --to 2026-01-31 --vehicle "Mach-E" --analysis-type drivers
```

## Key Insights Provided

### **[DATA] Data-Driven Complexity Categories**
- **Low Complexity**: <=8.0 (P33 from 3.9M+ actual calls, 5.77min avg AHT)
- **Medium Complexity**: 8.0-20.0 (P33-P67 range, 10.27min avg AHT)
- **High Complexity**: >=20.0 (P67+ from actual data, 19.95min avg AHT)
- **Outliers**: >=43.0 (P90+ requiring investigation)

### **[SEARCH] Complexity Drivers Analysis**
- Case types with highest complexity and AHT correlation
- Topics requiring most complex support
- Transfer impact on complexity (multiple transfers = highest complexity)
- Time-based complexity patterns (hour/day variations)

### **[BALANCE] Quality vs Complexity Balance**
- Correlation between complexity and customer sentiment/NPS
- FCR rates across complexity tiers
- Performance profiles for optimization opportunities

### **[TREND] Performance Benchmarking**
- Percentile rankings across complexity dimensions
- Outlier detection and investigation priorities
- Distribution analysis (low/medium/high complexity groups)

### **[TARGET] Optimization Opportunities**
- Groups performing above/below expected levels for their complexity
- Training needs identification (high complexity with low quality)
- Process improvement opportunities (complexity reduction strategies)

## Validated Data Findings
- **Transfer Impact**: 3+ Transfers (52.3) > 2 Transfers (35.2) > 1 Transfer (22.1) > No Transfers (15.8)
- **Vehicle Patterns**: EcoSport highest complexity (28.6), F-150 medium efficiency (18.5)
- **Time Patterns**: Complexity varies by hour and day with business context awareness
- **Quality Correlation**: Strong negative correlation between complexity and sentiment

## Error output
If something goes wrong, the script prints `{"error": "..."}` to stderr and exits with code 1.

## Notes
- **Multi-source integration**: Uses 7 data sources for comprehensive complexity insights
- **Privacy protection**: NO AGENT NAMES revealed (team-level analysis only)
- **Data-driven thresholds**: All categories based on actual percentiles from 3.9M+ calls
- **Like-to-like comparisons**: Compares within complexity ranges and time periods
- **Statistical significance**: 100 calls minimum ensures reliable analysis
- **Performance optimization**: Identifies specific improvement opportunities with business context
- Best used for operational efficiency, training needs identification, and quality vs complexity optimization
