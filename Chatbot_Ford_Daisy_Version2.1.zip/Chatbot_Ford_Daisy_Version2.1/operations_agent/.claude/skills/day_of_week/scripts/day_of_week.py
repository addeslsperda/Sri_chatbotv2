"""
Enhanced day-of-week analysis with comprehensive multi-dimensional insights.
Covers ALL day-of-week questions with business context awareness (weekends vs weekdays).

Usage:
    python day_of_week.py --from 2026-01-01 --to 2026-01-31
    python day_of_week.py --from 2026-01-01 --to 2026-01-31 --vehicle "F-150"
    python day_of_week.py --from 2026-01-01 --to 2026-01-31 --team "Technical"

Output: JSON with comprehensive day-of-week breakdown with business insights
"""
import argparse
import json
import os
import sys
from decimal import Decimal
from collections import defaultdict
from databricks import sql
import requests
from dotenv import load_dotenv

load_dotenv(override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


def serialize(v):
    if isinstance(v, Decimal):
        return float(v)
    if hasattr(v, "isoformat"):
        return str(v)
    return v


def get_daily_data(conn, date_from, date_to, vehicle=None, team=None, program=None, min_calls=5):
    """Get comprehensive day-of-week analysis with multi-source integration"""

    params = {
        "date_from": date_from,
        "date_to": date_to,
        "min_calls": min_calls
    }

    # Build filters
    filters = [
        "fdc.call_date >= :date_from",
        "fdc.call_date <= :date_to"
    ]

    if vehicle:
        params["vehicle"] = f"%{vehicle}%"
        filters.append("UPPER(fdc.ModelVehicleLine) LIKE UPPER(:vehicle)")

    if team:
        params["team"] = f"%{team}%"
        filters.append("UPPER(v.agent_team) LIKE UPPER(:team)")

    if program:
        params["program"] = f"%{program}%"
        filters.append("UPPER(fdc.program_name) LIKE UPPER(:program)")

    where_clause = " AND ".join(filters)

    query = f"""
        WITH daily_base_data AS (
            SELECT
                -- DAY DIMENSION
                DAYOFWEEK(fdc.call_date) as day_number,
                CASE DAYOFWEEK(fdc.call_date)
                    WHEN 1 THEN 'Sunday'
                    WHEN 2 THEN 'Monday'
                    WHEN 3 THEN 'Tuesday'
                    WHEN 4 THEN 'Wednesday'
                    WHEN 5 THEN 'Thursday'
                    WHEN 6 THEN 'Friday'
                    WHEN 7 THEN 'Saturday'
                END as day_name,

                -- BUSINESS CONTEXT
                CASE
                    WHEN DAYOFWEEK(fdc.call_date) IN (1,7) THEN 'Weekend'
                    ELSE 'Weekday'
                END as business_period,

                CASE
                    WHEN DAYOFWEEK(fdc.call_date) = 1 THEN 'Sunday'
                    WHEN DAYOFWEEK(fdc.call_date) = 7 THEN 'Saturday'
                    WHEN DAYOFWEEK(fdc.call_date) = 2 THEN 'Monday'
                    WHEN DAYOFWEEK(fdc.call_date) = 6 THEN 'Friday'
                    ELSE 'Mid-Week'
                END as day_category,

                -- IDENTIFIERS
                fdc.call_id,

                -- CORE METRICS (ford_daisy - best coverage)
                fdc.sentiment as fd_sentiment,
                fdc.complexity as fd_complexity,
                fdc.nps,
                fdc.fcr,
                fdc.brand_trust,

                -- CLASSIFICATIONS
                fdc.case_class_l1,
                fdc.program_name,
                fdc.ModelVehicleLine,
                fdc.business_process_name,

                -- TEAM DIMENSIONS (verint_transcription)
                v.agent_team,
                v.center_name,
                v.department_name,

                -- PERFORMANCE METRICS (call_data)
                cd.handle_time,
                cd.number_of_transfers,
                cd.worktime,
                cd.agent_tenure,
                cd.holdtime,

                -- DETAILED SENTIMENT (sentiments)
                s.customer_sentiment,
                s.agent_sentiment,
                s.overall_sentiment,

                -- TOPIC HIERARCHY (topic tables)
                td.topic_level1,
                td.topic_level2,

                -- PARTS/FEATURES (parts_unfiltered)
                pu.parts_concern

            FROM ford_daisy.analytics.call_data fdc

            -- ENRICH: Agent teams and geographic info
            LEFT JOIN dwh_prod.ovprod_o.verint_transcription v
                ON fdc.call_id = v.transaction_id

            -- ENRICH: Performance metrics (AHT, transfers)
            LEFT JOIN text_analytics.nlp_analytics.call_data cd
                ON fdc.call_id = cd.call_id

            -- ENRICH: Detailed sentiment breakdown
            LEFT JOIN text_analytics.nlp_analytics.sentiments s
                ON fdc.call_id = s.call_id

            -- ENRICH: Topic hierarchy
            LEFT JOIN text_analytics.nlp_analytics.topic_xwalk tx
                ON fdc.call_id = tx.call_id
            LEFT JOIN text_analytics.nlp_configs.topic_detail td
                ON tx.topic_id = td.topic_id

            -- ENRICH: Parts and features
            LEFT JOIN text_analytics.nlp_analytics.parts_unfiltered pu
                ON fdc.call_id = pu.call_id

            WHERE {where_clause}
        ),

        daily_aggregated AS (
            SELECT
                day_number,
                day_name,
                business_period,
                day_category,

                -- VOLUME METRICS
                COUNT(*) as total_calls,
                COUNT(DISTINCT agent_team) as unique_teams,
                COUNT(DISTINCT ModelVehicleLine) as unique_vehicles,
                COUNT(DISTINCT center_name) as unique_locations,

                -- PERFORMANCE METRICS
                ROUND(AVG(handle_time) / 60.0, 2) as avg_handle_time_minutes,
                ROUND(AVG(holdtime) / 60.0, 2) as avg_hold_time_minutes,
                ROUND(AVG(fd_complexity), 2) as avg_complexity,
                ROUND(AVG(worktime), 2) as avg_worktime,
                ROUND(AVG(agent_tenure), 1) as avg_agent_tenure,

                -- QUALITY METRICS
                ROUND(AVG(fd_sentiment), 4) as avg_sentiment,
                ROUND(AVG(nps), 2) as avg_nps,
                ROUND(AVG(fcr), 3) as avg_fcr,
                ROUND(AVG(brand_trust), 3) as avg_brand_trust,

                -- DETAILED SENTIMENT
                ROUND(AVG(customer_sentiment), 4) as avg_customer_sentiment,
                ROUND(AVG(agent_sentiment), 4) as avg_agent_sentiment,
                ROUND(AVG(overall_sentiment), 4) as avg_overall_sentiment,

                -- TRANSFER METRICS
                ROUND(AVG(number_of_transfers), 3) as avg_transfers_per_call,
                SUM(CASE WHEN number_of_transfers > 0 THEN 1 ELSE 0 END) as calls_with_transfers,
                ROUND(SUM(CASE WHEN number_of_transfers > 0 THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) as transfer_rate_pct,

                -- COMPLEXITY DISTRIBUTION
                SUM(CASE WHEN fd_complexity <= 20 THEN 1 ELSE 0 END) as low_complexity_calls,
                SUM(CASE WHEN fd_complexity > 20 AND fd_complexity <= 40 THEN 1 ELSE 0 END) as medium_complexity_calls,
                SUM(CASE WHEN fd_complexity > 40 THEN 1 ELSE 0 END) as high_complexity_calls,

                -- ISSUE DIVERSITY
                COUNT(DISTINCT case_class_l1) as unique_case_types,
                COUNT(DISTINCT topic_level1) as unique_topics,
                COUNT(DISTINCT parts_concern) as unique_parts_concerns,

                -- DATA COVERAGE
                ROUND(COUNT(handle_time) * 100.0 / COUNT(*), 1) as performance_coverage_pct,
                ROUND(COUNT(customer_sentiment) * 100.0 / COUNT(*), 1) as sentiment_coverage_pct,
                ROUND(COUNT(nps) * 100.0 / COUNT(*), 1) as nps_coverage_pct

            FROM daily_base_data
            GROUP BY day_number, day_name, business_period, day_category
            HAVING COUNT(*) >= :min_calls
        ),

        daily_with_rankings AS (
            SELECT *,
                -- RANKINGS ACROSS DAYS
                ROW_NUMBER() OVER (ORDER BY total_calls DESC) as volume_rank,
                ROW_NUMBER() OVER (ORDER BY avg_handle_time_minutes ASC) as efficiency_rank,
                ROW_NUMBER() OVER (ORDER BY avg_overall_sentiment DESC) as satisfaction_rank,
                ROW_NUMBER() OVER (ORDER BY transfer_rate_pct ASC) as transfer_performance_rank,

                -- PERCENTILES
                ROUND(total_calls * 100.0 / SUM(total_calls) OVER(), 2) as pct_of_weekly_volume,

                -- PERFORMANCE CATEGORIES (based on actual data ranges)
                CASE
                    WHEN avg_handle_time_minutes <= 10 THEN 'Fast'
                    WHEN avg_handle_time_minutes <= 20 THEN 'Average'
                    ELSE 'Slow'
                END as aht_category,

                CASE
                    WHEN avg_overall_sentiment >= 0.2 THEN 'Positive'
                    WHEN avg_overall_sentiment >= 0.0 THEN 'Neutral'
                    ELSE 'Negative'
                END as sentiment_category,

                CASE
                    WHEN transfer_rate_pct <= 3 THEN 'Low Transfers'
                    WHEN transfer_rate_pct <= 8 THEN 'Normal Transfers'
                    ELSE 'High Transfers'
                END as transfer_category,

                -- STAFFING INDICATORS (adjusted for weekend expectations)
                CASE
                    WHEN business_period = 'Weekend' AND total_calls > AVG(CASE WHEN business_period = 'Weekend' THEN total_calls END) OVER() * 1.2 THEN 'High Weekend Activity'
                    WHEN business_period = 'Weekday' AND total_calls > AVG(CASE WHEN business_period = 'Weekday' THEN total_calls END) OVER() * 1.3 THEN 'Peak Weekday'
                    WHEN business_period = 'Weekday' AND total_calls > AVG(CASE WHEN business_period = 'Weekday' THEN total_calls END) OVER() THEN 'Above Average Weekday'
                    WHEN business_period = 'Weekend' THEN 'Normal Weekend'
                    ELSE 'Normal Weekday'
                END as staffing_recommendation

            FROM daily_aggregated
        )

        SELECT
            day_number,
            day_name,
            business_period,
            day_category,
            total_calls,
            pct_of_weekly_volume,
            unique_teams,
            unique_vehicles,
            unique_locations,
            avg_handle_time_minutes,
            avg_hold_time_minutes,
            aht_category,
            avg_complexity,
            avg_worktime,
            avg_agent_tenure,
            avg_sentiment,
            avg_nps,
            avg_fcr,
            avg_brand_trust,
            avg_customer_sentiment,
            avg_agent_sentiment,
            avg_overall_sentiment,
            sentiment_category,
            avg_transfers_per_call,
            calls_with_transfers,
            transfer_rate_pct,
            transfer_category,
            low_complexity_calls,
            medium_complexity_calls,
            high_complexity_calls,
            unique_case_types,
            unique_topics,
            unique_parts_concerns,
            performance_coverage_pct,
            sentiment_coverage_pct,
            nps_coverage_pct,
            volume_rank,
            efficiency_rank,
            satisfaction_rank,
            transfer_performance_rank,
            staffing_recommendation
        FROM daily_with_rankings
        ORDER BY day_number
    """

    with conn.cursor() as cursor:
        cursor.execute(query, params)
        rows = cursor.fetchall()
        columns = [d[0] for d in cursor.description]

        return [dict(zip(columns, [serialize(val) for val in row])) for row in rows]


def get_daily_issues_breakdown(conn, date_from, date_to, vehicle=None, team=None, program=None):
    """Get top issues by day of week for pattern analysis"""

    params = {
        "date_from": date_from,
        "date_to": date_to
    }

    filters = [
        "fdc.call_date >= :date_from",
        "fdc.call_date <= :date_to"
    ]

    if vehicle:
        params["vehicle"] = f"%{vehicle}%"
        filters.append("UPPER(fdc.ModelVehicleLine) LIKE UPPER(:vehicle)")

    if team:
        params["team"] = f"%{team}%"
        filters.append("UPPER(v.agent_team) LIKE UPPER(:team)")

    if program:
        params["program"] = f"%{program}%"
        filters.append("UPPER(fdc.program_name) LIKE UPPER(:program)")

    where_clause = " AND ".join(filters)

    query = f"""
        SELECT
            DAYOFWEEK(fdc.call_date) as day_number,
            CASE DAYOFWEEK(fdc.call_date)
                WHEN 1 THEN 'Sunday'
                WHEN 2 THEN 'Monday'
                WHEN 3 THEN 'Tuesday'
                WHEN 4 THEN 'Wednesday'
                WHEN 5 THEN 'Thursday'
                WHEN 6 THEN 'Friday'
                WHEN 7 THEN 'Saturday'
            END as day_name,
            COALESCE(fdc.case_class_l1, 'Unknown') as issue_type,
            COUNT(*) as issue_count,
            ROUND(AVG(fdc.sentiment), 4) as avg_sentiment_for_issue,
            ROUND(AVG(cd.handle_time) / 60.0, 2) as avg_aht_for_issue,
            ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (PARTITION BY DAYOFWEEK(fdc.call_date)), 1) as pct_of_day_calls
        FROM ford_daisy.analytics.call_data fdc
        LEFT JOIN dwh_prod.ovprod_o.verint_transcription v ON fdc.call_id = v.transaction_id
        LEFT JOIN text_analytics.nlp_analytics.call_data cd ON fdc.call_id = cd.call_id
        WHERE {where_clause}
            AND fdc.case_class_l1 IS NOT NULL
        GROUP BY DAYOFWEEK(fdc.call_date), fdc.case_class_l1
        HAVING COUNT(*) >= 3
        ORDER BY day_number, issue_count DESC
    """

    with conn.cursor() as cursor:
        cursor.execute(query, params)
        rows = cursor.fetchall()
        columns = [d[0] for d in cursor.description]

        # Group by day
        issues_by_day = defaultdict(list)
        for row in rows:
            issue_dict = dict(zip(columns, [serialize(val) for val in row]))
            day_num = issue_dict['day_number']
            issues_by_day[day_num].append({
                'issue_type': issue_dict['issue_type'],
                'issue_count': issue_dict['issue_count'],
                'pct_of_day_calls': issue_dict['pct_of_day_calls'],
                'avg_sentiment_for_issue': issue_dict['avg_sentiment_for_issue'],
                'avg_aht_for_issue': issue_dict['avg_aht_for_issue']
            })

        # Keep top 5 issues per day
        for day in issues_by_day:
            issues_by_day[day] = issues_by_day[day][:5]

        return dict(issues_by_day)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--from", dest="date_from", required=True, help="Start date YYYY-MM-DD")
    parser.add_argument("--to", dest="date_to", required=True, help="End date YYYY-MM-DD")
    parser.add_argument("--vehicle", default=None, help="Filter by vehicle model")
    parser.add_argument("--team", default=None, help="Filter by agent team")
    parser.add_argument("--program", default=None, help="Filter by program name")
    parser.add_argument("--analysis-type", choices=["overview", "issues", "business"],
                       default="overview", help="Analysis focus")
    parser.add_argument("--min-calls", type=int, default=5, help="Minimum calls per day")
    args, _ = parser.parse_known_args()

    with get_connection() as conn:
        # Get main daily data
        daily_data = get_daily_data(conn, args.date_from, args.date_to,
                                   args.vehicle, args.team, args.program, args.min_calls)

        # Get issues breakdown
        issues_by_day = get_daily_issues_breakdown(conn, args.date_from, args.date_to,
                                                  args.vehicle, args.team, args.program)

        # Add issues to daily data
        for day_data in daily_data:
            day_num = day_data['day_number']
            day_data['top_issues'] = issues_by_day.get(day_num, [])

        # Calculate business insights with proper context-aware comparisons
        if daily_data:
            weekdays = [d for d in daily_data if d['business_period'] == 'Weekday']
            weekends = [d for d in daily_data if d['business_period'] == 'Weekend']

            # OVERALL VOLUME COMPARISONS (cross-context for staffing)
            busiest_day_overall = max(daily_data, key=lambda x: x['total_calls'])
            quietest_day_overall = min(daily_data, key=lambda x: x['total_calls'])

            # CONTEXT-AWARE PERFORMANCE COMPARISONS
            # Best/worst AHT within weekdays
            if weekdays:
                best_weekday_aht = min(weekdays, key=lambda x: x['avg_handle_time_minutes'] or float('inf'))
                worst_weekday_aht = max(weekdays, key=lambda x: x['avg_handle_time_minutes'] or 0)
                busiest_weekday = max(weekdays, key=lambda x: x['total_calls'])
                quietest_weekday = min(weekdays, key=lambda x: x['total_calls'])
            else:
                best_weekday_aht = worst_weekday_aht = busiest_weekday = quietest_weekday = None

            # Best/worst AHT within weekends
            if weekends:
                best_weekend_aht = min(weekends, key=lambda x: x['avg_handle_time_minutes'] or float('inf'))
                worst_weekend_aht = max(weekends, key=lambda x: x['avg_handle_time_minutes'] or 0)
                busiest_weekend = max(weekends, key=lambda x: x['total_calls'])
                quietest_weekend = min(weekends, key=lambda x: x['total_calls'])
            else:
                best_weekend_aht = worst_weekend_aht = busiest_weekend = quietest_weekend = None

            total_calls = sum(d['total_calls'] for d in daily_data)
            weekday_calls = sum(d['total_calls'] for d in weekdays)
            weekend_calls = sum(d['total_calls'] for d in weekends)

            # Business context calculations
            if weekdays and weekends:
                avg_weekday_calls = weekday_calls / len(weekdays) if weekdays else 0
                avg_weekend_calls = weekend_calls / len(weekends) if weekends else 0
                weekend_vs_weekday_ratio = (avg_weekend_calls / avg_weekday_calls) if avg_weekday_calls > 0 else 0

                # Context-aware averages
                avg_weekday_aht = sum(d['avg_handle_time_minutes'] for d in weekdays) / len(weekdays) if weekdays else 0
                avg_weekend_aht = sum(d['avg_handle_time_minutes'] for d in weekends) / len(weekends) if weekends else 0
            else:
                avg_weekday_calls = avg_weekend_calls = weekend_vs_weekday_ratio = 0
                avg_weekday_aht = avg_weekend_aht = 0

        else:
            busiest_day_overall = quietest_day_overall = None
            best_weekday_aht = worst_weekday_aht = busiest_weekday = quietest_weekday = None
            best_weekend_aht = worst_weekend_aht = busiest_weekend = quietest_weekend = None
            total_calls = weekday_calls = weekend_calls = 0
            weekdays = weekends = []
            avg_weekday_calls = avg_weekend_calls = weekend_vs_weekday_ratio = 0
            avg_weekday_aht = avg_weekend_aht = 0

    # Build comprehensive result
    result = {
        'metadata': {
            'analysis_period': f"{args.date_from} to {args.date_to}",
            'filters': {
                'vehicle': args.vehicle or "all",
                'team': args.team or "all",
                'program': args.program or "all"
            },
            'analysis_params': {
                'analysis_type': args.analysis_type,
                'min_calls_per_day': args.min_calls
            },
            'data_sources': [
                'ford_daisy.analytics.call_data (primary metrics)',
                'dwh_prod.ovprod_o.verint_transcription (teams/locations)',
                'text_analytics.nlp_analytics.call_data (performance)',
                'text_analytics.nlp_analytics.sentiments (detailed sentiment)',
                'text_analytics.nlp_analytics.topic_xwalk (topics)',
                'text_analytics.nlp_configs.topic_detail (topic hierarchy)',
                'text_analytics.nlp_analytics.parts_unfiltered (parts/features)'
            ]
        },
        'daily_analysis': daily_data,
        'business_insights': {
            'total_calls_analyzed': total_calls,
            'days_with_sufficient_data': len(daily_data),
            'weekday_vs_weekend': {
                'weekday_calls': weekday_calls,
                'weekend_calls': weekend_calls,
                'avg_weekday_calls': avg_weekday_calls,
                'avg_weekend_calls': avg_weekend_calls,
                'weekend_vs_weekday_ratio': round(weekend_vs_weekday_ratio, 3),
                'weekend_percentage': round((weekend_calls / total_calls * 100), 1) if total_calls > 0 else 0
            },
            'overall_volume': {
                'busiest_day': {
                    'day_name': busiest_day_overall['day_name'] if busiest_day_overall else None,
                    'day_category': busiest_day_overall['day_category'] if busiest_day_overall else None,
                    'business_period': busiest_day_overall['business_period'] if busiest_day_overall else None,
                    'call_count': busiest_day_overall['total_calls'] if busiest_day_overall else None,
                    'pct_of_weekly_volume': busiest_day_overall['pct_of_weekly_volume'] if busiest_day_overall else None
                } if busiest_day_overall else None,
                'quietest_day': {
                    'day_name': quietest_day_overall['day_name'] if quietest_day_overall else None,
                    'day_category': quietest_day_overall['day_category'] if quietest_day_overall else None,
                    'business_period': quietest_day_overall['business_period'] if quietest_day_overall else None,
                    'call_count': quietest_day_overall['total_calls'] if quietest_day_overall else None
                } if quietest_day_overall else None
            },
            'weekday_performance': {
                'avg_weekday_aht': round(avg_weekday_aht, 2),
                'best_weekday_aht': {
                    'day_name': best_weekday_aht['day_name'] if best_weekday_aht else None,
                    'avg_handle_time_minutes': best_weekday_aht['avg_handle_time_minutes'] if best_weekday_aht else None
                } if best_weekday_aht else None,
                'worst_weekday_aht': {
                    'day_name': worst_weekday_aht['day_name'] if worst_weekday_aht else None,
                    'avg_handle_time_minutes': worst_weekday_aht['avg_handle_time_minutes'] if worst_weekday_aht else None
                } if worst_weekday_aht else None,
                'busiest_weekday': {
                    'day_name': busiest_weekday['day_name'] if busiest_weekday else None,
                    'call_count': busiest_weekday['total_calls'] if busiest_weekday else None
                } if busiest_weekday else None,
                'quietest_weekday': {
                    'day_name': quietest_weekday['day_name'] if quietest_weekday else None,
                    'call_count': quietest_weekday['total_calls'] if quietest_weekday else None
                } if quietest_weekday else None
            },
            'weekend_performance': {
                'avg_weekend_aht': round(avg_weekend_aht, 2),
                'best_weekend_aht': {
                    'day_name': best_weekend_aht['day_name'] if best_weekend_aht else None,
                    'avg_handle_time_minutes': best_weekend_aht['avg_handle_time_minutes'] if best_weekend_aht else None
                } if best_weekend_aht else None,
                'worst_weekend_aht': {
                    'day_name': worst_weekend_aht['day_name'] if worst_weekend_aht else None,
                    'avg_handle_time_minutes': worst_weekend_aht['avg_handle_time_minutes'] if worst_weekend_aht else None
                } if worst_weekend_aht else None,
                'busiest_weekend': {
                    'day_name': busiest_weekend['day_name'] if busiest_weekend else None,
                    'call_count': busiest_weekend['total_calls'] if busiest_weekend else None
                } if busiest_weekend else None,
                'quietest_weekend': {
                    'day_name': quietest_weekend['day_name'] if quietest_weekend else None,
                    'call_count': quietest_weekend['total_calls'] if quietest_weekend else None
                } if quietest_weekend else None
            },
            'staffing_recommendations': [
                {
                    'day_name': d['day_name'],
                    'business_period': d['business_period'],
                    'staffing_recommendation': d['staffing_recommendation'],
                    'call_volume': d['total_calls']
                } for d in daily_data
            ]
        }
    }

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)