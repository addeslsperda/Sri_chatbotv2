---
name: day_of_week
display_name: Enhanced Day-of-Week Analysis
description: Comprehensive day-of-week analysis with business context awareness (weekends vs weekdays). Multi-source data integration covering volume patterns, performance variations, quality metrics, and staffing optimization. Recognizes that weekends and holidays naturally have lower call volumes. Use for "are Mondays busier", "weekend vs weekday comparison", "staffing by day", "which day performs best".
signals:
  - day of week
  - busiest day
  - monday
  - friday
  - weekend calls
  - weekday
  - which day has the most
  - day-specific
  - weekday vs weekend
  - weekend patterns
  - business day analysis
requires:
  - a date range (from and to)
not_good_for: Hour-by-hour patterns (use hour_of_day), monthly trends (use trend_analysis)
---

# Enhanced Day-of-Week Analysis

## What this script does
Comprehensive day-of-week analysis using ford_daisy.analytics.call_data + 6 enrichment sources with business context awareness:
- **Weekday vs Weekend patterns** with proper volume expectations
- **Busiest days identification** for staffing optimization  
- **Performance variations** (AHT, complexity, sentiment) by day
- **Issue distribution** across days (which problems occur when)
- **Quality metrics** (NPS, FCR, brand trust) by day of week
- **Transfer patterns** and resolution rates by day
- **Business context insights** recognizing weekend/holiday volume differences

## When to use
- "Are Mondays busier than Fridays?"
- "What day of the week has the most calls?"
- "Do weekend calls take longer?"
- "Which day has the hardest calls?"
- "How does weekday vs weekend performance compare?"
- "Are customers happier on certain days?" 
- "Which days need the most staff?"
- "Do specific issues cluster on certain days?"
- "How should weekend vs weekday staffing differ?"

## Parameters
- `--from` and `--to`: Date range (required)
- `--vehicle`: Filter by vehicle model (optional)
- `--team`: Filter by agent team (optional)
- `--program`: Filter by program name (optional)
- `--analysis-type`: Focus area - `overview`, `issues`, `business` (default: overview)
- `--min-calls`: Minimum calls per day to include (default 5, ensures sufficient data)

## Output format

```json
{
  "metadata": {
    "analysis_period": "2026-01-01 to 2026-01-31",
    "filters": { "vehicle": "all", "team": "all", "program": "all" },
    "data_sources": [
      "ford_daisy.analytics.call_data (primary metrics)",
      "dwh_prod.ovprod_o.verint_transcription (teams/locations)",
      "text_analytics.nlp_analytics.call_data (performance)",
      "text_analytics.nlp_analytics.sentiments (detailed sentiment)",
      "text_analytics.nlp_analytics.topic_xwalk (topics)",
      "text_analytics.nlp_configs.topic_detail (topic hierarchy)",
      "text_analytics.nlp_analytics.parts_unfiltered (parts/features)"
    ]
  },
  "daily_analysis": [
    {
      "day_number": 2,
      "day_name": "Monday",
      "business_period": "Weekday",
      "day_category": "Monday",
      "total_calls": 12450,
      "pct_of_weekly_volume": 18.5,
      "avg_handle_time_minutes": 13.2,
      "aht_category": "Average",
      "avg_complexity": 21.8,
      "avg_sentiment": 0.0982,
      "avg_nps": 4.15,
      "avg_fcr": 1.42,
      "avg_customer_sentiment": -0.0654,
      "avg_agent_sentiment": 0.2156,
      "sentiment_category": "Neutral",
      "transfer_rate_pct": 7.2,
      "transfer_category": "Normal Transfers",
      "staffing_recommendation": "Peak Weekday",
      "top_issues": [
        {"issue_type": "Technical Assistance", "issue_count": 1850, "pct_of_day_calls": 14.9}
      ]
    }
  ],
  "business_insights": {
    "weekday_vs_weekend": {
      "weekday_calls": 58420,
      "weekend_calls": 8950,
      "avg_weekday_calls": 11684,
      "avg_weekend_calls": 4475,
      "weekend_vs_weekday_ratio": 0.383,
      "weekend_percentage": 13.3
    },
    "busiest_day": {
      "day_name": "Tuesday",
      "day_category": "Mid-Week",
      "call_count": 13250,
      "pct_of_weekly_volume": 19.6
    },
    "staffing_recommendations": [
      {"day_name": "Monday", "staffing_recommendation": "Peak Weekday", "call_volume": 12450},
      {"day_name": "Saturday", "staffing_recommendation": "Normal Weekend", "call_volume": 4200}
    ]
  }
}
```

## Example calls

```bash
# Overall day-of-week analysis for January
python .claude/skills/day_of_week/scripts/day_of_week.py --from 2026-01-01 --to 2026-01-31

# Vehicle-specific day patterns
python .claude/skills/day_of_week/scripts/day_of_week.py --from 2026-01-01 --to 2026-01-31 --vehicle "F-150"

# Team workload by day
python .claude/skills/day_of_week/scripts/day_of_week.py --from 2026-01-01 --to 2026-01-31 --team "Technical"

# Business context focus
python .claude/skills/day_of_week/scripts/day_of_week.py --from 2026-01-01 --to 2026-01-31 --analysis-type business

# Issues breakdown by day
python .claude/skills/day_of_week/scripts/day_of_week.py --from 2026-01-01 --to 2026-01-31 --analysis-type issues
```

## Key Insights Provided

### **[DATA] Business Context Awareness**
- Weekday vs Weekend volume comparison with proper expectations
- Weekend-vs-weekday performance ratio (typically 30-40% of weekday volume)
- Business period classification (Weekend, Monday, Friday, Mid-Week)

### **[TREND] Volume & Staffing Patterns**
- Busiest and quietest days with staffing recommendations
- Peak weekday identification for resource allocation
- Weekend staffing optimization based on actual patterns

### **[FAST] Performance Variations**
- AHT, complexity, and quality variations by day
- Best and worst performing days identification
- Transfer patterns and resolution rates by day

### **😊 Quality Metrics by Day**  
- Customer and agent sentiment variations
- NPS and FCR performance across weekdays
- Day-specific satisfaction patterns

### **[SEARCH] Issue Analysis by Day**
- Top issues by day with prevalence percentages
- Which problems cluster on specific days
- Day-specific issue sentiment and AHT patterns

### **💼 Staffing Optimization**
- Context-aware staffing recommendations
- Peak Weekday vs Normal Weekend classifications
- Volume-based resource allocation guidance

## Business Context Notes
- **Weekend Awareness**: Recognizes weekends and holidays naturally have 60-70% lower volumes than weekdays
- **Monday/Friday Effects**: Accounts for start-of-week and end-of-week volume patterns
- **Staffing Reality**: Provides realistic staffing recommendations based on business context
- **Performance Expectations**: Adjusts performance baselines for weekend vs weekday operations

## Error output
If something goes wrong, the script prints `{"error": "..."}` to stderr and exits with code 1.

## Notes
- **Multi-source integration**: Uses 7 data sources for comprehensive daily insights
- **Privacy protection**: NO AGENT NAMES revealed (team-level analysis only)
- **Business context**: Recognizes weekends have lower volume by design
- **Sufficient data**: Default limit 5 calls/day ensures reliable statistics
- **Realistic comparisons**: Compares weekdays to weekdays, weekends to weekends
- Best used for workforce planning, staffing optimization, and understanding natural business cycles