---
name: agent_pain_points
display_name: Agent Pain Points with Semantic Intelligence
description: Advanced analysis of what makes specific topics difficult for agents using Qwen 0.6B embeddings + multi-table intelligence. Identifies agent struggles, actual agent language, and pain points for BlueCruise, connectivity, premium features, etc. Shows what agents say when struggling with specific topics.
signals:
  - agent pain points
  - agent friction
  - what makes calls hard
  - agent struggle
  - BlueCruise agent pain
  - connectivity agent issues
  - premium connectivity pain
  - agent knowledge gaps
  - hardest topics for agents
  - agent difficulties
requires:
  - topic (specific area to analyze)
  - date range
not_good_for: Customer pain points (use vehicle_pain_points), general AHT analysis (use aht_analysis), topic trends (use topic_trends)
---

# Agent Pain Points with Semantic Intelligence - PRODUCTION VERSION

## What this script does
Advanced semantic analysis using Qwen 0.6B embeddings to identify and analyze what makes specific topics difficult for agents. Provides comprehensive agent struggle intelligence including:

- **Semantic Topic Discovery**: Finds calls about specific topics (BlueCruise, connectivity, etc.) using AI embeddings
- **Agent Struggle Detection**: Identifies calls where agents struggle (high AHT/complexity/negative sentiment)
- **Actual Agent Language**: Extracts complete agent utterances showing real pain points
- **Struggle Pattern Analysis**: Common phrases agents use when struggling ("let me check", "transfer", etc.)
- **Multi-Dimensional Metrics**: AHT, complexity, sentiment combined with actual agent voice
- **Team-Specific Insights**: Which teams struggle most with specific topics

## How to run it

```bash
python .claude/skills/agent_pain_points/scripts/agent_pain_points.py --topic "premium connectivity" --from 2026-01-01 --to 2026-01-31
```

## Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--topic` | Yes | — | Topic to analyze agent pain points for (e.g., "BlueCruise", "premium connectivity") |
| `--from` | Yes | — | Start date YYYY-MM-DD |
| `--to` | Yes | — | End date YYYY-MM-DD |
| `--team` | No | all | Filter by agent team |
| `--vehicle` | No | all | Filter by vehicle model |
| `--similarity-threshold` | No | `0.4` | Semantic similarity threshold (0.0-1.0) |
| `--semantic-limit` | No | `5000` | Max semantic matches to analyze |
| `--limit` | No | `15` | Max agent pain points to return |

## Example calls

```bash
# BlueCruise agent pain points
python .claude/skills/agent_pain_points/scripts/agent_pain_points.py --topic "BlueCruise" --from 2026-01-01 --to 2026-01-31

# Premium connectivity subscription struggles
python .claude/skills/agent_pain_points/scripts/agent_pain_points.py --topic "premium connectivity subscription" --from 2026-01-01 --to 2026-01-31

# Connected navigation issues for agents
python .claude/skills/agent_pain_points/scripts/agent_pain_points.py --topic "connected navigation" --from 2026-01-01 --to 2026-01-31

# FordPass app agent difficulties
python .claude/skills/agent_pain_points/scripts/agent_pain_points.py --topic "FordPass app" --from 2026-01-01 --to 2026-01-31

# BEV team's pain points with charging
python .claude/skills/agent_pain_points/scripts/agent_pain_points.py --topic "charging issues" --from 2026-01-01 --to 2026-01-31 --team "BEV"

# Mach-E specific agent struggles
python .claude/skills/agent_pain_points/scripts/agent_pain_points.py --topic "over the air updates" --from 2026-01-01 --to 2026-01-31 --vehicle "Mach-E"

# High precision analysis
python .claude/skills/agent_pain_points/scripts/agent_pain_points.py --topic "subscription management" --from 2026-01-01 --to 2026-01-31 --similarity-threshold 0.5
```

## Enhanced Output Format

```json
{
  "status": "success",
  "analysis_type": "agent_pain_points_semantic",
  "parameters": {
    "topic": "premium connectivity subscription",
    "search_method": "qwen_embeddings_cosine_similarity",
    "embedding_model": "Qwen/Qwen3-Embedding-0.6B",
    "similarity_threshold": 0.4,
    "semantic_limit": 5000,
    "date_range": {"from": "2026-01-01", "to": "2026-01-31"}
  },
  "results": {
    "topic_calls_found": 1250,
    "struggling_calls_found": 89,
    "agent_turns_analyzed": 445
  },
  "baseline_metrics": {
    "total_calls": 1250,
    "avg_aht": 892.5,
    "avg_complexity": 28.7,
    "avg_agent_sentiment": -0.05
  },
  "agent_pain_points": [
    {
      "pain_point": "MUS-CRC_BEV_10",
      "topic_context": "premium connectivity subscription",
      "call_count": 25,
      "pct_of_topic_calls": 2.0,
      "avg_aht_minutes": 1847.5,
      "aht_vs_baseline": "+107%",
      "avg_complexity": 58.2,
      "complexity_vs_baseline": "+103%",
      "avg_agent_sentiment": -0.185,
      "difficulty_score": 8.9,
      "why_difficult": [
        "AHT 2.1x baseline (1847 min vs 892 min)",
        "Complexity 2.0x baseline - extremely difficult",
        "Very negative agent sentiment (-0.185)"
      ],
      "top_struggle_phrases": [
        "let me check (12x)",
        "transfer (8x)",
        "not sure (6x)",
        "technical support (4x)"
      ],
      "agent_struggle_examples": [
        {
          "call_id": "abc123",
          "sentiment": 0.442,
          "agent_text": "Let me check with technical support because I'm not sure how to activate the premium connectivity on this vehicle. The system isn't responding as expected..."
        },
        {
          "call_id": "def456", 
          "sentiment": 0.458,
          "agent_text": "I need to transfer you to our connectivity specialist. This subscription issue is beyond what I can troubleshoot from here..."
        }
      ]
    }
  ]
}
```

## Difficulty Score Calculation

Each pain point gets a **difficulty_score** (0-10) based on:
- **AHT multiplier**: How much longer than baseline (weight: 35%)
- **Complexity multiplier**: How much harder than baseline (weight: 35%)
- **Transfer rate multiplier**: How often transferred (weight: 30%)

Score interpretation:
- **9-10**: Extreme friction - immediate attention needed
- **7-8.9**: High friction - training/process improvement needed
- **5-6.9**: Moderate friction - monitor and optimize
- **Below 5**: Manageable - standard difficulty

## Why_Difficult Insights

The script automatically identifies why each topic is difficult:
- **"AHT Xx baseline"**: Call takes X times longer than average
- **"Complexity Xx baseline"**: Call is X times harder than average
- **"High transfer rate"**: Requires escalation/specialist
- **"Knowledge gap"**: Agents lack information/tools
- **"Legal/escalation required"**: Sensitive/legal topic
- **"Multi-system issue"**: Requires coordination across systems

## Error output
If something goes wrong, the script prints `{"error": "..."}` to stderr and exits with code 1.

## Notes
- **Different from customer pain points**: This focuses on what's hard for *agents*, not what customers complain about most
- High call volume ≠ agent pain point (e.g., 10,000 easy password reset calls vs 50 hard buyback calls)
- Sorted by difficulty_score (hardest first), not call volume
- Use `--min-calls` to filter out statistical noise from rare issues
- Includes example summaries to understand context
- **Key insight**: A topic with low volume but extreme AHT/complexity is a bigger agent pain point than high-volume easy calls
