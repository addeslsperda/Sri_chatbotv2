"""
Agent Pain Points Analysis using Semantic Intelligence + Multi-Table Analysis
Identifies what makes calls difficult for agents on specific topics using embeddings + agent struggle metrics.

Usage:
    python agent_pain_points.py --topic "premium connectivity" --from 2026-01-01 --to 2026-01-31

Output: JSON with agent pain points based on semantic discovery, AHT, complexity, agent sentiment, and actual agent language
"""
import argparse
import json
import os
import sys
from decimal import Decimal
from pathlib import Path
from databricks import sql
import requests
from dotenv import load_dotenv
import numpy as np
from sentence_transformers import SentenceTransformer

load_dotenv(Path(__file__).resolve().parents[5] / ".env", override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


# Table configurations
CATALOG = os.environ.get("DATABRICKS_CATALOG", "text_analytics")
SCHEMA = os.environ.get("DATABRICKS_SCHEMA", "nlp_analytics")
CALL_DATA = f"{CATALOG}.{SCHEMA}.call_data"
CALL_TABLE = f"{CATALOG}.{SCHEMA}.call_table"
SENTIMENTS = f"{CATALOG}.{SCHEMA}.sentiments"
TURN_TABLE = f"{CATALOG}.{SCHEMA}.turn_table"
MODELS = f"{CATALOG}.{SCHEMA}.models"
EMBEDDING_TABLE = f"{CATALOG}.nlp_agent.call_summary_qwen06b"


def serialize(v):
    if isinstance(v, Decimal):
        return float(v)
    if hasattr(v, "isoformat"):
        return str(v)
    return v


def _get_embedding(query_text):
    """Generate embedding for topic search using Qwen model"""
    try:
        # Try Databricks endpoint first
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute(f"""
            SELECT ai_query(
                'qwen3-embedding-06b',
                '{query_text}'
            )
        """)
        result = cursor.fetchone()
        cursor.close()
        conn.close()

        if result and result[0]:
            embedding_data = json.loads(result[0])
            if 'data' in embedding_data and len(embedding_data['data']) > 0:
                return embedding_data['data'][0]['embedding']
    except Exception as e:
        print(f"Databricks Qwen embedding failed: {e}", file=sys.stderr)

    # Fallback to local Qwen model
    try:
        model = SentenceTransformer("Qwen/Qwen3-Embedding-0.6B", trust_remote_code=True)
        embedding = model.encode(query_text, normalize_embeddings=True)
        return embedding.tolist()
    except Exception as e:
        print(f"Local Qwen embedding failed: {e}", file=sys.stderr)
        raise Exception("Failed to generate embedding with both Databricks and local methods")


def get_semantic_call_ids(topic_query, similarity_threshold=0.4, limit=5000, date_from=None, date_to=None):
    """Find call_ids related to specific topic using semantic search"""
    print(f"Generating query embedding for: {topic_query}", file=sys.stderr)

    # Generate query embedding
    query_embedding = _get_embedding(topic_query)
    if not query_embedding:
        raise Exception("Failed to generate query embedding")

    print(f"Query embedding generated (dimension: {len(query_embedding)})", file=sys.stderr)

    with get_connection() as conn:
        with conn.cursor() as cursor:
            # Fetch embeddings and calculate similarity
            print("Fetching embeddings for similarity calculation...", file=sys.stderr)

            date_filter = ""
            if date_from and date_to:
                date_filter = f"AND call_id IN (SELECT call_id FROM {CALL_DATA} WHERE DATE(call_date) >= '{date_from}' AND DATE(call_date) <= '{date_to}')"

            # Process in batches to avoid memory issues
            batch_size = 1000
            offset = 0
            similar_call_ids = []
            max_batches = 10  # Limit batches for speed (same as keyword_search)

            batch_count = 0
            while len(similar_call_ids) < limit and batch_count < max_batches:
                batch_query = f"""
                    SELECT call_id, embeddings
                    FROM {EMBEDDING_TABLE}
                    WHERE embeddings IS NOT NULL
                    {date_filter}
                    LIMIT {batch_size} OFFSET {offset}
                """

                cursor.execute(batch_query)
                batch_rows = cursor.fetchall()

                if not batch_rows:
                    break

                batch_count += 1
                print(f"Processing batch {batch_count}: {len(batch_rows)} embeddings", file=sys.stderr)

                batch_similarities = []
                for row in batch_rows:
                    call_id, embedding_str = row
                    if not embedding_str:
                        continue

                    try:
                        # Parse embedding
                        if isinstance(embedding_str, str):
                            embedding = json.loads(embedding_str)
                        else:
                            embedding = embedding_str

                        # Calculate cosine similarity
                        similarity = np.dot(query_embedding, embedding) / (
                            np.linalg.norm(query_embedding) * np.linalg.norm(embedding)
                        )

                        if similarity >= similarity_threshold:
                            batch_similarities.append((call_id, similarity))

                    except (json.JSONDecodeError, ValueError, TypeError) as e:
                        continue

                # Sort batch by similarity and add to results
                batch_similarities.sort(key=lambda x: x[1], reverse=True)
                batch_call_ids = [call_id for call_id, sim in batch_similarities]
                similar_call_ids.extend(batch_call_ids)

                print(f"Found {len(batch_call_ids)} similar calls in batch (total: {len(similar_call_ids)})", file=sys.stderr)

                offset += batch_size

                # Stop if we have enough results or processed too many batches
                if len(similar_call_ids) >= limit or offset >= 50000:  # Max 50K embeddings to check
                    break

            # Limit final results
            final_call_ids = similar_call_ids[:limit]
            print(f"Total semantic matches found: {len(final_call_ids)} (threshold: {similarity_threshold})", file=sys.stderr)

            return final_call_ids


def get_struggling_calls_from_semantic_results(semantic_call_ids, date_from, date_to, team_filter=None, vehicle_filter=None):
    """Filter semantic results for calls where agents are struggling"""
    if not semantic_call_ids:
        return {"baseline": {}, "struggling_calls": []}

    with get_connection() as conn:
        with conn.cursor() as cursor:
            # Create call_ids parameter list
            call_ids_values = ','.join([f"'{cid}'" for cid in semantic_call_ids])

            # Get baseline metrics for semantic calls
            baseline_params = {"date_from": date_from, "date_to": date_to}
            baseline_filters = [
                "DATE(cd.call_date) >= :date_from",
                "DATE(cd.call_date) <= :date_to",
                f"cd.call_id IN ({call_ids_values})"
            ]

            if team_filter:
                baseline_params["team"] = f"%{team_filter}%"
                baseline_filters.append("(LOWER(cd.program_name) LIKE LOWER(:team) OR LOWER(ct.Agent_Team) LIKE LOWER(:team))")

            if vehicle_filter:
                baseline_params["vehicle"] = f"%{vehicle_filter}%"
                baseline_filters.append("LOWER(COALESCE(m.ModelVehicleLine, cd.modelvehicleline)) LIKE LOWER(:vehicle)")

            baseline_where = " AND ".join(baseline_filters)

            baseline_query = f"""
                SELECT
                    COUNT(*) as total_calls,
                    AVG(cd.handle_time) as avg_aht,
                    AVG(cd.complexity) as avg_complexity,
                    AVG(s.agent_sentiment) as avg_agent_sentiment
                FROM {CALL_DATA} cd
                LEFT JOIN {CALL_TABLE} ct ON cd.call_id = ct.call_id
                LEFT JOIN {SENTIMENTS} s ON cd.call_id = s.call_id
                LEFT JOIN {MODELS} m ON cd.call_id = m.call_id
                WHERE {baseline_where}
                  AND cd.handle_time IS NOT NULL
                  AND cd.complexity IS NOT NULL
                  AND s.agent_sentiment IS NOT NULL
            """

            cursor.execute(baseline_query, baseline_params)
            baseline_row = cursor.fetchone()

            if not baseline_row or baseline_row[0] == 0:
                return {"baseline": {}, "struggling_calls": []}

            total_calls = int(baseline_row[0])
            baseline_aht = float(baseline_row[1]) if baseline_row[1] else 700.0
            baseline_complexity = float(baseline_row[2]) if baseline_row[2] else 18.0
            baseline_agent_sentiment = float(baseline_row[3]) if baseline_row[3] else 0.0

            # Define struggling thresholds
            high_aht_threshold = baseline_aht * 1.5  # 1.5x baseline AHT
            high_complexity_threshold = baseline_complexity * 1.5  # 1.5x baseline complexity
            low_agent_sentiment_threshold = -0.05  # Slightly negative agent sentiment

            print(f"Topic baseline metrics: AHT={baseline_aht:.1f}, Complexity={baseline_complexity:.1f}, Agent Sentiment={baseline_agent_sentiment:.3f}", file=sys.stderr)
            print(f"Struggling thresholds: AHT>{high_aht_threshold:.1f}, Complexity>{high_complexity_threshold:.1f}, Agent Sentiment<{low_agent_sentiment_threshold}", file=sys.stderr)

            # Find struggling calls within semantic results
            struggling_query = f"""
                SELECT
                    cd.call_id,
                    cd.handle_time,
                    cd.complexity,
                    s.agent_sentiment,
                    cd.program_name,
                    ct.Agent_Team,
                    COALESCE(m.ModelVehicleLine, cd.modelvehicleline) as vehicle
                FROM {CALL_DATA} cd
                LEFT JOIN {CALL_TABLE} ct ON cd.call_id = ct.call_id
                LEFT JOIN {SENTIMENTS} s ON cd.call_id = s.call_id
                LEFT JOIN {MODELS} m ON cd.call_id = m.call_id
                WHERE {baseline_where}
                  AND (
                    cd.handle_time > :high_aht_threshold
                    OR cd.complexity > :high_complexity_threshold
                    OR s.agent_sentiment < :low_agent_sentiment_threshold
                  )
                  AND cd.handle_time IS NOT NULL
                  AND cd.complexity IS NOT NULL
                  AND s.agent_sentiment IS NOT NULL
                ORDER BY
                    (cd.handle_time / :baseline_aht + cd.complexity / :baseline_complexity - s.agent_sentiment) DESC
                LIMIT 500
            """

            struggling_params = {
                **baseline_params,
                "high_aht_threshold": high_aht_threshold,
                "high_complexity_threshold": high_complexity_threshold,
                "low_agent_sentiment_threshold": low_agent_sentiment_threshold,
                "baseline_aht": baseline_aht,
                "baseline_complexity": baseline_complexity
            }

            cursor.execute(struggling_query, struggling_params)
            struggling_calls = cursor.fetchall()

            print(f"Found {len(struggling_calls)} struggling calls from {total_calls} topic-related calls", file=sys.stderr)

            return {
                "baseline": {
                    "total_calls": total_calls,
                    "avg_aht": baseline_aht,
                    "avg_complexity": baseline_complexity,
                    "avg_agent_sentiment": baseline_agent_sentiment
                },
                "struggling_calls": [
                    {
                        "call_id": row[0],
                        "handle_time": serialize(row[1]),
                        "complexity": serialize(row[2]),
                        "agent_sentiment": serialize(row[3]),
                        "program_name": row[4],
                        "agent_team": row[5],
                        "vehicle": row[6]
                    }
                    for row in struggling_calls
                ]
            }


def get_agent_turns_for_calls(call_ids, date_from, date_to):
    """Get ALL agent turns for the struggling calls to understand what they're saying"""
    if not call_ids:
        return []

    with get_connection() as conn:
        with conn.cursor() as cursor:
            # Create call_ids parameter list
            call_ids_values = ','.join([f"'{cid}'" for cid in call_ids])

            agent_turns_query = f"""
                SELECT
                    t.call_id,
                    t.text,
                    t.sentiment_score,
                    t.Agent_Team,
                    COUNT(*) OVER (PARTITION BY t.call_id) as turns_per_call
                FROM {TURN_TABLE} t
                WHERE t.call_id IN ({call_ids_values})
                  AND t.speaker_role = 'agent'
                  AND DATE(t.Date_of_Call) >= '{date_from}'
                  AND DATE(t.Date_of_Call) <= '{date_to}'
                  AND t.text IS NOT NULL
                  AND LENGTH(t.text) > 10
                ORDER BY t.call_id, t.text_order
            """

            cursor.execute(agent_turns_query)
            agent_turns = cursor.fetchall()

            print(f"Retrieved {len(agent_turns)} agent turns from {len(call_ids)} struggling calls", file=sys.stderr)

            return [
                {
                    "call_id": row[0],
                    "text": row[1],
                    "sentiment_score": serialize(row[2]),
                    "agent_team": row[3],
                    "turns_per_call": row[4]
                }
                for row in agent_turns
            ]


def analyze_agent_pain_points(struggling_calls_data, agent_turns, topic_query, limit=15):
    """Analyze agent pain points by combining struggle metrics with actual agent language"""
    baseline = struggling_calls_data["baseline"]
    struggling_calls = struggling_calls_data["struggling_calls"]

    if not struggling_calls:
        return []

    # Group by team/program for analysis
    team_analysis = {}

    # Create call_id lookup for metrics
    call_metrics = {call["call_id"]: call for call in struggling_calls}

    # Process agent turns by team
    for turn in agent_turns:
        call_id = turn["call_id"]
        team = turn["agent_team"] or call_metrics.get(call_id, {}).get("program_name", "Unknown")

        if team not in team_analysis:
            team_analysis[team] = {
                "call_count": 0,
                "call_ids": set(),
                "total_aht": 0,
                "total_complexity": 0,
                "total_agent_sentiment": 0,
                "agent_utterances": [],
                "struggle_indicators": []
            }

        # Add call metrics (once per call)
        if call_id not in team_analysis[team]["call_ids"]:
            team_analysis[team]["call_ids"].add(call_id)
            team_analysis[team]["call_count"] += 1

            if call_id in call_metrics:
                metrics = call_metrics[call_id]
                team_analysis[team]["total_aht"] += metrics["handle_time"]
                team_analysis[team]["total_complexity"] += metrics["complexity"]
                team_analysis[team]["total_agent_sentiment"] += metrics["agent_sentiment"]

        # Collect agent utterances (all turns)
        team_analysis[team]["agent_utterances"].append({
            "call_id": call_id,
            "text": turn["text"],
            "sentiment": turn["sentiment_score"]
        })

        # Identify struggle indicators in agent language
        text_lower = turn["text"].lower()
        struggle_phrases = [
            "let me check", "i'm not sure", "hold on", "let me look", "give me a moment",
            "i need to", "difficult", "complex", "challenging", "not working", "issue", "problem",
            "transfer", "escalate", "specialist", "supervisor", "manager", "technical support",
            "sorry", "apologize", "unfortunately", "can't", "unable", "won't work",
            "system down", "error", "glitch", "bug", "frozen", "crashed"
        ]

        for phrase in struggle_phrases:
            if phrase in text_lower:
                team_analysis[team]["struggle_indicators"].append({
                    "phrase": phrase,
                    "context": turn["text"],
                    "call_id": call_id,
                    "sentiment": turn["sentiment_score"]
                })

    # Calculate pain point scores and build results
    pain_points = []

    for team, data in team_analysis.items():
        if data["call_count"] < 2:  # Skip teams with too few calls
            continue

        # Calculate averages
        avg_aht = data["total_aht"] / data["call_count"]
        avg_complexity = data["total_complexity"] / data["call_count"]
        avg_agent_sentiment = data["total_agent_sentiment"] / data["call_count"]

        # Calculate ratios vs baseline
        aht_ratio = avg_aht / baseline["avg_aht"] if baseline["avg_aht"] > 0 else 1.0
        complexity_ratio = avg_complexity / baseline["avg_complexity"] if baseline["avg_complexity"] > 0 else 1.0
        sentiment_impact = abs(avg_agent_sentiment) if avg_agent_sentiment < 0 else 0

        # Calculate difficulty score
        difficulty_score = round(
            (aht_ratio - 1.0) * 3.0 +
            (complexity_ratio - 1.0) * 3.0 +
            sentiment_impact * 5.0 +
            len(data["struggle_indicators"]) * 0.05, 1
        )

        # Generate why_difficult explanations
        reasons = []
        if aht_ratio >= 2.0:
            reasons.append(f"AHT {aht_ratio:.1f}x baseline ({avg_aht:.0f} min vs {baseline['avg_aht']:.0f} min)")
        elif aht_ratio >= 1.5:
            reasons.append(f"AHT {aht_ratio:.1f}x baseline")

        if complexity_ratio >= 2.0:
            reasons.append(f"Complexity {complexity_ratio:.1f}x baseline - extremely difficult")
        elif complexity_ratio >= 1.5:
            reasons.append(f"Complexity {complexity_ratio:.1f}x baseline")

        if avg_agent_sentiment < -0.1:
            reasons.append(f"Very negative agent sentiment ({avg_agent_sentiment:.2f})")
        elif avg_agent_sentiment < 0:
            reasons.append(f"Negative agent sentiment ({avg_agent_sentiment:.2f})")

        # Most common struggle phrases
        struggle_phrase_counts = {}
        for indicator in data["struggle_indicators"]:
            phrase = indicator["phrase"]
            struggle_phrase_counts[phrase] = struggle_phrase_counts.get(phrase, 0) + 1

        top_struggles = sorted(struggle_phrase_counts.items(), key=lambda x: x[1], reverse=True)[:5]

        # Sample agent utterances showing pain points (lowest sentiment first)
        struggling_utterances = sorted(
            [u for u in data["agent_utterances"] if len(u["text"]) > 20],
            key=lambda x: x["sentiment"]
        )[:5]

        # Determine actual pain point from struggle phrases and context
        if top_struggles:
            primary_struggle = top_struggles[0][0]  # Most common struggle phrase
            pain_point_name = f"{topic_query} - {primary_struggle}"
        else:
            pain_point_name = f"{topic_query} - high AHT/complexity"

        pain_points.append({
            "pain_point": pain_point_name,
            "team_affected": team,
            "topic_context": topic_query,
            "call_count": data["call_count"],
            "pct_of_topic_calls": round(data["call_count"] * 100.0 / baseline["total_calls"], 1) if baseline["total_calls"] > 0 else 0,
            "avg_aht_minutes": round(avg_aht, 1),
            "aht_vs_baseline": f"+{round((aht_ratio - 1.0) * 100, 0):.0f}%" if aht_ratio > 1 else f"{round((aht_ratio - 1.0) * 100, 0):.0f}%",
            "avg_complexity": round(avg_complexity, 1),
            "complexity_vs_baseline": f"+{round((complexity_ratio - 1.0) * 100, 0):.0f}%" if complexity_ratio > 1 else f"{round((complexity_ratio - 1.0) * 100, 0):.0f}%",
            "avg_agent_sentiment": round(avg_agent_sentiment, 3),
            "difficulty_score": difficulty_score,
            "why_difficult": reasons if reasons else ["Above baseline difficulty for this topic"],
            "top_struggle_phrases": [f"{phrase} ({count}x)" for phrase, count in top_struggles],
            "agent_struggle_examples": [
                {
                    "call_id": u["call_id"],
                    "sentiment": u["sentiment"],
                    "agent_text": u["text"]
                }
                for u in struggling_utterances
            ]
        })

    # Sort by difficulty score and limit results
    pain_points.sort(key=lambda x: x["difficulty_score"], reverse=True)
    return pain_points[:limit]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--topic", required=True, help="Topic to analyze agent pain points for (e.g., 'premium connectivity', 'BlueCruise')")
    parser.add_argument("--from", dest="date_from", required=True)
    parser.add_argument("--to", dest="date_to", required=True)
    parser.add_argument("--team", default=None)
    parser.add_argument("--vehicle", default=None)
    parser.add_argument("--similarity-threshold", type=float, default=0.4)
    parser.add_argument("--semantic-limit", type=int, default=5000)
    parser.add_argument("--limit", type=int, default=15)
    args, _ = parser.parse_known_args()

    try:
        print(f"Analyzing agent pain points for topic: {args.topic} from {args.date_from} to {args.date_to}...", file=sys.stderr)

        # Step 1: Semantic discovery for the topic
        semantic_call_ids = get_semantic_call_ids(
            args.topic,
            similarity_threshold=args.similarity_threshold,
            limit=args.semantic_limit,
            date_from=args.date_from,
            date_to=args.date_to
        )

        if not semantic_call_ids:
            print(json.dumps({
                "status": "success",
                "message": f"No calls found about '{args.topic}' for the given criteria",
                "agent_pain_points": []
            }, indent=2))
            return

        # Step 2: Filter for struggling calls within topic
        struggling_calls_data = get_struggling_calls_from_semantic_results(
            semantic_call_ids,
            args.date_from,
            args.date_to,
            args.team,
            args.vehicle
        )

        if not struggling_calls_data["struggling_calls"]:
            print(json.dumps({
                "status": "success",
                "message": f"No struggling agent calls found for topic '{args.topic}'",
                "topic_calls_found": len(semantic_call_ids),
                "agent_pain_points": []
            }, indent=2))
            return

        # Step 3: Get agent turns for struggling calls
        struggling_call_ids = [call["call_id"] for call in struggling_calls_data["struggling_calls"]]
        agent_turns = get_agent_turns_for_calls(struggling_call_ids, args.date_from, args.date_to)

        # Step 4: Analyze agent pain points
        pain_points = analyze_agent_pain_points(struggling_calls_data, agent_turns, args.topic, args.limit)

        # Build response
        response = {
            "status": "success",
            "analysis_type": "agent_pain_points_semantic",
            "parameters": {
                "topic": args.topic,
                "search_method": "qwen_embeddings_cosine_similarity",
                "embedding_model": "Qwen/Qwen3-Embedding-0.6B",
                "similarity_threshold": args.similarity_threshold,
                "semantic_limit": args.semantic_limit,
                "date_range": {
                    "from": args.date_from,
                    "to": args.date_to
                }
            },
            "results": {
                "topic_calls_found": len(semantic_call_ids),
                "struggling_calls_found": len(struggling_calls_data["struggling_calls"]),
                "agent_turns_analyzed": len(agent_turns)
            },
            "baseline_metrics": struggling_calls_data["baseline"],
            "agent_pain_points": pain_points
        }

        print(json.dumps(response, indent=2))

    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)
