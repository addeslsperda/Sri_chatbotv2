---
name: transfer_analysis
display_name: Transfer Analysis with Semantic Intelligence
description: Advanced transfer analysis using Qwen 0.6B embeddings with multi-table intelligence. Identifies calls involving transfers, escalations, and team routing through semantic search with transcript fallback. Provides comprehensive transfer metrics, team analysis, and customer impact assessment.
signals:
  - transfers
  - transfer rate
  - transferred
  - escalated
  - routed
  - team routing
  - calls transferred
  - transfer metrics
  - escalation
requires:
  - date range (from and to)
not_good_for: AHT analysis (use aht_analysis), team volume (use team_volume), general keyword search (use keyword_search)
---

# Transfer Analysis with Semantic Intelligence - PRODUCTION VERSION

## What this script does
Advanced semantic analysis using Qwen 0.6B embeddings to identify and analyze call transfers, escalations, and team routing. Provides comprehensive business intelligence including:

- **Semantic Discovery**: Finds transfer-related calls using AI embeddings (not just keyword matching)
- **Transcript Fallback**: Uses keyword search in transcripts when semantic results are limited
- **Team Analysis**: Transfer patterns by Ford teams and programs
- **Transfer Validation**: Incorporates Verint transfer data when available
- **Ford Topic Taxonomy**: Uses Ford's official classification for transfer reasons
- **Customer Impact**: Sentiment analysis of transfer experiences
- **Multi-Table Integration**: Enriches with pain points, topics, parts, and case data

## How to run it

```bash
python .claude/skills/transfer_analysis/scripts/transfer_analysis.py --from 2026-01-01 --to 2026-01-31
```

## Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--from` | Yes |  | Start date YYYY-MM-DD |
| `--to` | Yes |  | End date YYYY-MM-DD |
| `--team` | No | all | Filter by team (e.g., "BEV", "connected", "fordpass") |
| `--vehicle` | No | all | Filter by vehicle model |
| `--similarity-threshold` | No | `0.4` | Semantic similarity threshold (0.0-1.0) |
| `--semantic-limit` | No | `5000` | Max semantic matches to analyze |
| `--include-examples` | No | `false` | Include transfer example summaries |
| `--include-transcripts` | No | `false` | Include transcript excerpts |
| `--limit` | No | `20` | Max example calls to return |

## Example calls

```bash
# General transfer analysis
python .claude/skills/transfer_analysis/scripts/transfer_analysis.py --from 2026-01-01 --to 2026-01-31

# BEV team transfer analysis
python .claude/skills/transfer_analysis/scripts/transfer_analysis.py --from 2026-01-01 --to 2026-01-31 --team "BEV"

# Connected services transfers with examples
python .claude/skills/transfer_analysis/scripts/transfer_analysis.py --from 2026-01-01 --to 2026-01-31 --team "connected" --include-examples

# Mach-E specific transfers
python .claude/skills/transfer_analysis/scripts/transfer_analysis.py --from 2026-01-01 --to 2026-01-31 --vehicle "Mach-E" --include-transcripts

# High precision transfer detection
python .claude/skills/transfer_analysis/scripts/transfer_analysis.py --from 2026-01-01 --to 2026-01-31 --similarity-threshold 0.5
```

## Enhanced Output Format

```json
{
  "status": "success",
  "analysis_type": "semantic_transfer_analysis",
  "parameters": {
    "search_method": "semantic_with_transcript_fallback",
    "embedding_model": "Qwen/Qwen3-Embedding-0.6B",
    "similarity_threshold": 0.4,
    "date_range": {"from": "2026-01-01", "to": "2026-01-31"}
  },
  "results": {
    "total_transfer_calls": 1458,
    "pct_of_total_calls": 2.3,
    "semantic_matches": 1200,
    "transcript_fallback_matches": 258,
    "verint_validated": 890
  },
  "transfer_metrics": {
    "avg_customer_sentiment": -0.35,
    "avg_agent_sentiment": 0.12,
    "sentiment_gap": -0.47,
    "sentiment_breakdown": {
      "positive": 245,
      "neutral": 567,
      "negative": 646
    }
  },
  "team_analysis": {
    "top_sending_teams": [
      {"team": "General Inquiry", "transfers_sent": 345, "transfer_rate": 15.2},
      {"team": "FordPass Support", "transfers_sent": 289, "transfer_rate": 12.8}
    ],
    "top_receiving_teams": [
      {"team": "Connected Services", "transfers_received": 234, "specialization_score": 8.7},
      {"team": "BEV Specialists", "transfers_received": 198, "specialization_score": 9.1}
    ]
  },
  "ford_topic_analysis": {
    "top_transfer_reasons": [
      {"topic_level1": "Vehicle Maintenance", "topic_level2": "Technical Support", "topic_level3": "Specialist Required", "count": 234, "avg_sentiment": -0.42},
      {"topic_level1": "Customer Support", "topic_level2": "Account Issues", "topic_level3": "Escalation Required", "count": 189, "avg_sentiment": -0.38}
    ]
  },
  "vehicle_breakdown": [
    {"vehicle": "MUSTANG MACH-E", "transfer_calls": 198, "transfer_rate": 18.5, "avg_sentiment": -0.41},
    {"vehicle": "F-150 LIGHTNING", "transfer_calls": 156, "transfer_rate": 14.2, "avg_sentiment": -0.33}
  ],
  "business_metrics": {
    "avg_complexity": 9.2,
    "avg_handle_time_min": 21.5,
    "calls_with_multiple_transfers": 89,
    "escalation_rate": 6.1
  },
  "examples": [
    {
      "call_id": "abc123",
      "call_date": "2026-01-15",
      "vehicle": "MUSTANG MACH-E",
      "from_team": "General Inquiry",
      "to_team": "BEV Specialists",
      "transfer_reason": "Technical expertise required",
      "customer_sentiment": -0.45,
      "verint_transfers": 2,
      "summary": "Customer experiencing charging issues, transferred to BEV team for technical resolution...",
      "topic_level1": "Vehicle Maintenance",
      "topic_level2": "Electrical Systems",
      "topic_level3": "Charging Problems"
    }
  ]
}
```

## Enhanced Features

### **Semantic Intelligence**
- **True Cosine Similarity**: Uses Qwen 0.6B embeddings for precise transfer detection
- **Context Aware**: Distinguishes actual transfers from transfer mentions in other contexts
- **Natural Language**: Finds transfers described as "escalated", "routed", "sent to specialist"

### **Fallback Reliability**
- **Transcript Search**: When semantic results are limited, searches transcripts for explicit "transfer" mentions
- **Comprehensive Coverage**: Combines semantic understanding with keyword reliability
- **Adaptive Threshold**: Automatically determines when fallback is needed

### **Multi-Dimensional Analysis**
- **Team Flow Analysis**: Which teams send/receive the most transfers
- **Transfer Impact**: How transfers affect customer sentiment and call complexity
- **Reason Classification**: Uses Ford's topic taxonomy to understand why calls are transferred
- **Verint Integration**: Validates findings with actual Verint transfer counts when available

### **Business Intelligence**
- **Operational Efficiency**: Identifies teams with high transfer rates (training opportunities)
- **Specialization Patterns**: Teams that frequently receive transfers (specialist knowledge)
- **Customer Experience**: Sentiment impact of transfers and multiple handoffs
- **Issue Correlation**: Which vehicle problems require specialist intervention

## Error handling
If something goes wrong, the script prints `{"error": "..."}` to stderr and exits with code 1.

## Notes
- **Hybrid Approach**: Semantic search for context, transcript fallback for completeness
- **Team Detection**: Flexible team matching using program names and agent teams
- **Ford Integration**: Complete integration with Ford's data ecosystem and taxonomy
- **Verint Validation**: Cross-references with Verint transfer data when available
- **Scalable**: Handles large volume analysis with configurable semantic limits
- **Operations Focused**: Provides actionable insights for contact center optimization