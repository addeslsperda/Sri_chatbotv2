"""
Advanced Transfer Analysis - PRODUCTION VERSION

Semantic analysis using Qwen 0.6B embeddings to identify call transfers with comprehensive
multi-table intelligence, team analysis, and customer impact assessment.

Usage:
    python transfer_analysis.py --from 2026-01-01 --to 2026-01-31
    python transfer_analysis.py --from 2026-01-01 --to 2026-01-31 --team "BEV"
    python transfer_analysis.py --from 2026-01-01 --to 2026-01-31 --vehicle "Mach-E" --include-examples

Output: Enhanced JSON with semantic transfer analysis, team patterns, and business intelligence
"""
import argparse
import json
import os
import sys
import numpy as np
from decimal import Decimal
from pathlib import Path
from databricks import sql
import requests
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parents[5] / ".env", override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


def cosine_similarity(vec1, vec2):
    """Calculate cosine similarity between two vectors"""
    vec1 = np.array(vec1)
    vec2 = np.array(vec2)
    return np.dot(vec1, vec2) / (np.linalg.norm(vec1) * np.linalg.norm(vec2))


def _get_embedding(query_str: str) -> list[float]:
    """Get query embedding using Qwen/Qwen3-Embedding-0.6B model"""

    # Method 1: Try Databricks Qwen endpoint
    try:
        from databricks.sdk import WorkspaceClient
        w = WorkspaceClient(
            host=os.environ.get("DATABRICKS_HOST"),
            client_id=os.environ.get("DATABRICKS_CLIENT_ID"),
            client_secret=os.environ.get("DATABRICKS_CLIENT_SECRET")
        )
        response = w.serving_endpoints.query(
            name="qwen3-embedding-06b",
            instances=[query_str]
        )
        return response.predictions[0]
    except Exception as e:
        print(f"Databricks Qwen embedding failed: {e}", file=sys.stderr)

    # Method 2: Local Qwen 0.6B model
    try:
        from sentence_transformers import SentenceTransformer
        model = SentenceTransformer(
            "Qwen/Qwen3-Embedding-0.6B",
            processor_kwargs={"padding_side": "left"}
        )
        embedding = model.encode([query_str])
        return embedding[0].tolist()
    except Exception as e:
        print(f"Local Qwen 0.6B embedding failed: {e}", file=sys.stderr)
        return None


def get_semantic_call_ids(query_embedding, similarity_threshold=0.4, limit=5000, date_from="2020-01-01", date_to="2030-12-31"):
    """
    Find call_ids with embeddings similar to query_embedding using cosine similarity
    """
    semantic_call_ids = []

    with get_connection() as conn:
        with conn.cursor() as cursor:
            print(f"Fetching embeddings for similarity calculation...", file=sys.stderr)

            batch_size = 1000
            offset = 0
            max_batches = 20

            batch_count = 0
            while len(semantic_call_ids) < limit and batch_count < max_batches:
                cursor.execute(f"""
                    SELECT call_id, embeddings
                    FROM {EMBEDDING_TABLE}
                    WHERE call_date >= :date_from
                      AND call_date <= :date_to
                    ORDER BY call_date DESC
                    LIMIT {batch_size} OFFSET {offset}
                """, {"date_from": date_from, "date_to": date_to})

                batch_results = cursor.fetchall()
                if not batch_results:
                    break

                batch_count += 1
                print(f"Processing batch {batch_count}: {len(batch_results)} embeddings", file=sys.stderr)

                batch_similarities = []
                for call_id, db_embedding in batch_results:
                    try:
                        import ast
                        if db_embedding:
                            try:
                                embedding_str = str(db_embedding)
                                if embedding_str.startswith('[') and embedding_str.endswith(']'):
                                    db_emb_list = ast.literal_eval(embedding_str)
                                    embedding_array = np.array(db_emb_list)
                                else:
                                    embedding_array = np.array(db_embedding)
                            except:
                                continue

                            if len(embedding_array) == len(query_embedding):
                                similarity = cosine_similarity(query_embedding, embedding_array)
                                if similarity >= similarity_threshold:
                                    batch_similarities.append((call_id, similarity))
                    except Exception:
                        continue

                batch_similarities.sort(key=lambda x: x[1], reverse=True)
                for call_id, similarity in batch_similarities:
                    if len(semantic_call_ids) < limit:
                        semantic_call_ids.append(call_id)

                print(f"Found {len(batch_similarities)} similar calls in batch (total: {len(semantic_call_ids)})", file=sys.stderr)
                offset += batch_size

                if len(semantic_call_ids) >= limit or offset >= 100000:
                    break

    print(f"Total semantic matches found: {len(semantic_call_ids)} (threshold: {similarity_threshold})", file=sys.stderr)
    return semantic_call_ids


def get_transcript_fallback_call_ids(date_from, date_to, limit=1000):
    """
    Fallback method: search transcripts for 'transfer' keyword
    """
    transcript_call_ids = []

    with get_connection() as conn:
        with conn.cursor() as cursor:
            print("Using transcript fallback search for 'transfer' mentions...", file=sys.stderr)

            cursor.execute(f"""
                SELECT DISTINCT ct.call_id
                FROM {CALL_TABLE} ct
                JOIN {CALL_DATA} cd ON ct.call_id = cd.call_id
                WHERE DATE(cd.call_date) >= :date_from
                  AND DATE(cd.call_date) <= :date_to
                  AND LOWER(ct.transcript) LIKE '%transfer%'
                  AND ct.transcript IS NOT NULL
                LIMIT {limit}
            """, {"date_from": date_from, "date_to": date_to})

            results = cursor.fetchall()
            transcript_call_ids = [row[0] for row in results]

    print(f"Transcript fallback found: {len(transcript_call_ids)} additional calls", file=sys.stderr)
    return transcript_call_ids


def serialize(value):
    """Serialize values for JSON output"""
    if isinstance(value, Decimal):
        return float(value)
    elif hasattr(value, "isoformat"):
        return str(value)
    elif value is None:
        return None
    else:
        return value


# Enhanced table configuration
CATALOG = os.environ.get("DATABRICKS_CATALOG", "text_analytics")
SCHEMA = os.environ.get("DATABRICKS_SCHEMA", "nlp_analytics")
CALL_DATA = f"{CATALOG}.{SCHEMA}.call_data"
CALL_TABLE = f"{CATALOG}.{SCHEMA}.call_table"
MODELS = f"{CATALOG}.{SCHEMA}.models"
SENTIMENTS = f"{CATALOG}.{SCHEMA}.sentiments"
EMBEDDING_TABLE = f"{CATALOG}.nlp_agent.call_summary_qwen06b"
V_PAIN_POINTS2 = f"{CATALOG}.restensl.v_pain_points2"
TOPIC_XWALK = f"{CATALOG}.{SCHEMA}.topic_xwalk"
TOPIC_DETAIL = f"{CATALOG}.nlp_configs.topic_detail"
PARTS_UNFILTERED = f"{CATALOG}.{SCHEMA}.parts_unfiltered"
CASE_METADATA = f"{CATALOG}.nlp_dashboard.case_metadata"
VERINT_SESSIONS = "dwh_prod.ovprod_o.verint_api_sessions"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--from", dest="date_from", required=True)
    parser.add_argument("--to", dest="date_to", required=True)
    parser.add_argument("--team", default=None)
    parser.add_argument("--vehicle", default=None)
    parser.add_argument("--similarity-threshold", type=float, default=0.4)
    parser.add_argument("--semantic-limit", type=int, default=5000)
    parser.add_argument("--include-examples", action="store_true")
    parser.add_argument("--include-transcripts", action="store_true")
    parser.add_argument("--limit", type=int, default=20)
    args, _ = parser.parse_known_args()

    try:
        # Step 1: Generate query embedding for transfer detection
        print(f"Generating query embedding for transfer detection...", file=sys.stderr)

        transfer_query = "calls transferred routed escalated between teams departments specialist support"
        query_embedding = _get_embedding(transfer_query)
        if not query_embedding:
            raise Exception("Failed to generate query embedding")

        print(f"Query embedding generated (dimension: {len(query_embedding)})", file=sys.stderr)

        # Step 2: Semantic search for transfer calls
        semantic_call_ids = get_semantic_call_ids(
            query_embedding=query_embedding,
            similarity_threshold=args.similarity_threshold,
            limit=args.semantic_limit,
            date_from=args.date_from,
            date_to=args.date_to
        )

        # Step 3: Determine if transcript fallback is needed
        fallback_threshold = 50
        search_method = "semantic_only"
        all_transfer_call_ids = semantic_call_ids

        if len(semantic_call_ids) < fallback_threshold:
            print(f"Semantic results ({len(semantic_call_ids)}) below threshold, using transcript fallback", file=sys.stderr)
            transcript_call_ids = get_transcript_fallback_call_ids(args.date_from, args.date_to)
            all_transfer_call_ids = list(set(semantic_call_ids + transcript_call_ids))
            search_method = "semantic_with_transcript_fallback"

        if not all_transfer_call_ids:
            print(json.dumps({
                "status": "success",
                "analysis_type": "semantic_transfer_analysis",
                "results": {"total_transfer_calls": 0},
                "message": "No transfer calls found for the given criteria"
            }, indent=2))
            return

        print(f"Total transfer calls identified: {len(all_transfer_call_ids)}", file=sys.stderr)

        # Step 4: Build filter parameters
        params = {"date_from": args.date_from, "date_to": args.date_to}
        filters = [
            "DATE(cd.call_date) >= :date_from",
            "DATE(cd.call_date) <= :date_to"
        ]

        if args.vehicle:
            params["vehicle"] = f"%{args.vehicle}%"
            filters.append("LOWER(COALESCE(m.ModelVehicleLine, cd.modelvehicleline)) LIKE LOWER(:vehicle)")

        if args.team:
            params["team"] = f"%{args.team}%"
            filters.append("(LOWER(cd.program_name) LIKE LOWER(:team) OR LOWER(ct.Agent_Team) LIKE LOWER(:team))")

        where_clause = " AND ".join(filters)

        # Step 5: Get total calls for percentage calculation
        with get_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(f"""
                    SELECT COUNT(*)
                    FROM {CALL_DATA} cd
                    LEFT JOIN {MODELS} m ON cd.call_id = m.call_id
                    LEFT JOIN {CALL_TABLE} ct ON cd.call_id = ct.call_id
                    WHERE {where_clause}
                """, params)
                total_calls = cursor.fetchone()[0]

            # Step 6: Comprehensive analysis for transfer calls
            call_ids_values = ','.join([f"('{cid}')" for cid in all_transfer_call_ids])

            comprehensive_query = f"""
                WITH transfer_matches AS (
                    SELECT call_id FROM (VALUES {call_ids_values}) AS t(call_id)
                ),
                comprehensive_data AS (
                    SELECT
                        cd.call_id,
                        cd.call_date,
                        cd.casenumber,

                        -- Vehicle information
                        COALESCE(m.ModelVehicleLine, cd.modelvehicleline) as vehicle_model,
                        COALESCE(m.Model_Year, 'Unknown') as model_year,

                        -- Team and program info
                        cd.program_name,
                        ct.Agent_Team,

                        -- Content
                        cs.summary as call_summary,
                        ct.transcript,

                        -- Sentiment analysis
                        s.customer_sentiment,
                        s.agent_sentiment,
                        s.overall_sentiment,
                        cd.sentiment_label,

                        -- Verint transfer data (when available)
                        v.number_of_transfers as verint_transfers,

                        -- Topic classification
                        td.topic_level1,
                        td.topic_level2,
                        td.topic_level3,
                        td.topic_category,

                        -- Parts correlation
                        pf.parts_features,
                        pf.parts_concern,

                        -- Pain points
                        {f"pp.pain_point, pp.customer_feedback," if args.include_examples else "NULL as pain_point, NULL as customer_feedback,"}

                        -- Case classification
                        cm.caseclassificationlevel1,
                        cm.caseclassificationlevel2,
                        cm.caseclassificationlevel3,

                        -- Call metadata
                        cd.complexity,
                        cd.handle_time

                    FROM {CALL_DATA} cd
                    INNER JOIN transfer_matches tm ON cd.call_id = tm.call_id
                    LEFT JOIN {EMBEDDING_TABLE} cs ON cd.call_id = cs.call_id
                    LEFT JOIN {SENTIMENTS} s ON cd.call_id = s.call_id
                    LEFT JOIN {CALL_TABLE} ct ON cd.call_id = ct.call_id
                    LEFT JOIN {MODELS} m ON cd.call_id = m.call_id
                    LEFT JOIN {VERINT_SESSIONS} v ON TRY_CAST(cd.call_id AS BIGINT) = v.call_id
                    LEFT JOIN {TOPIC_XWALK} tx ON cd.call_id = tx.call_id
                    LEFT JOIN {TOPIC_DETAIL} td ON tx.topic_id = td.topic_id
                    LEFT JOIN {PARTS_UNFILTERED} pf ON cd.call_id = pf.call_id
                    {'LEFT JOIN ' + V_PAIN_POINTS2 + ' pp ON cd.call_id = pp.call_id' if args.include_examples else ''}
                    LEFT JOIN {CASE_METADATA} cm ON cd.casenumber = cm.casenumber
                    WHERE {where_clause}
                )
                SELECT * FROM comprehensive_data
                ORDER BY customer_sentiment ASC
                LIMIT 1000
            """

            with conn.cursor() as cursor:
                cursor.execute(comprehensive_query, params)
                rows = cursor.fetchall()
                columns = [d[0] for d in cursor.description]

        # Process results
        all_results = []
        for row in rows:
            row_dict = {}
            for i, value in enumerate(row):
                row_dict[columns[i]] = serialize(value)
            all_results.append(row_dict)

        if not all_results:
            print(json.dumps({
                "status": "success",
                "analysis_type": "semantic_transfer_analysis",
                "results": {"total_transfer_calls": 0},
                "message": "No results after filtering"
            }, indent=2))
            return

        total_transfer_calls = len(all_results)

        # Sentiment analysis
        sentiments = [r for r in all_results if r.get('customer_sentiment') is not None]
        avg_customer_sentiment = sum(r['customer_sentiment'] for r in sentiments) / len(sentiments) if sentiments else 0
        avg_agent_sentiment = sum(r.get('agent_sentiment', 0) for r in sentiments) / len(sentiments) if sentiments else 0

        sentiment_counts = {'positive': 0, 'neutral': 0, 'negative': 0}
        for r in all_results:
            label = (r.get('sentiment_label') or 'neutral').lower()
            sentiment_counts[label] = sentiment_counts.get(label, 0) + 1

        # Team analysis
        team_sending = {}
        team_receiving = {}
        for result in all_results:
            # For team analysis, we'll use the agent_team as a proxy
            # In reality, transfer flow analysis would need call routing data
            team = result.get('Agent_Team') or result.get('program_name') or 'Unknown'
            if team not in team_sending:
                team_sending[team] = {'calls': 0, 'sentiments': []}
            team_sending[team]['calls'] += 1
            if result.get('customer_sentiment'):
                team_sending[team]['sentiments'].append(result['customer_sentiment'])

        # Ford topic analysis
        topic_analysis = {}
        for result in all_results:
            topic_key = f"{result.get('topic_level1', 'Unknown')} > {result.get('topic_level2', 'Unknown')} > {result.get('topic_level3', 'Unknown')}"
            if topic_key not in topic_analysis:
                topic_analysis[topic_key] = {'count': 0, 'sentiments': [], 'level1': result.get('topic_level1'), 'level2': result.get('topic_level2'), 'level3': result.get('topic_level3')}
            topic_analysis[topic_key]['count'] += 1
            if result.get('customer_sentiment'):
                topic_analysis[topic_key]['sentiments'].append(result['customer_sentiment'])

        # Vehicle breakdown
        vehicle_counts = {}
        for result in all_results:
            vehicle = result.get('vehicle_model') or 'Unknown'
            if vehicle not in vehicle_counts:
                vehicle_counts[vehicle] = {'transfer_calls': 0, 'sentiments': []}
            vehicle_counts[vehicle]['transfer_calls'] += 1
            if result.get('customer_sentiment'):
                vehicle_counts[vehicle]['sentiments'].append(result['customer_sentiment'])

        # Count Verint validated transfers
        verint_validated = len([r for r in all_results if r.get('verint_transfers') is not None])

        # Build response
        response = {
            "status": "success",
            "analysis_type": "semantic_transfer_analysis",
            "parameters": {
                "search_method": search_method,
                "embedding_model": "Qwen/Qwen3-Embedding-0.6B",
                "similarity_threshold": args.similarity_threshold,
                "semantic_limit": args.semantic_limit,
                "date_range": {"from": args.date_from, "to": args.date_to}
            },
            "results": {
                "total_transfer_calls": total_transfer_calls,
                "pct_of_total_calls": round(total_transfer_calls * 100.0 / total_calls, 2) if total_calls > 0 else 0,
                "semantic_matches": len(semantic_call_ids),
                "transcript_fallback_matches": len(all_transfer_call_ids) - len(semantic_call_ids) if search_method == "semantic_with_transcript_fallback" else 0,
                "verint_validated": verint_validated
            },
            "transfer_metrics": {
                "avg_customer_sentiment": round(avg_customer_sentiment, 4),
                "avg_agent_sentiment": round(avg_agent_sentiment, 4),
                "sentiment_gap": round(avg_customer_sentiment - avg_agent_sentiment, 4),
                "sentiment_breakdown": sentiment_counts
            },
            "team_analysis": {"teams_involved": []},
            "ford_topic_analysis": {"top_transfer_reasons": []},
            "vehicle_breakdown": [],
            "examples": []
        }

        # Add team analysis
        teams_list = []
        for team, data in sorted(team_sending.items(), key=lambda x: x[1]['calls'], reverse=True)[:10]:
            avg_sentiment = sum(data['sentiments']) / len(data['sentiments']) if data['sentiments'] else None
            teams_list.append({
                "team": team,
                "transfer_calls": data['calls'],
                "avg_sentiment": round(avg_sentiment, 4) if avg_sentiment else None
            })
        response["team_analysis"]["teams_involved"] = teams_list

        # Add Ford topic analysis
        top_topics = []
        for topic_key, data in sorted(topic_analysis.items(), key=lambda x: x[1]['count'], reverse=True)[:10]:
            avg_sentiment = sum(data['sentiments']) / len(data['sentiments']) if data['sentiments'] else None
            top_topics.append({
                "topic_level1": data['level1'],
                "topic_level2": data['level2'],
                "topic_level3": data['level3'],
                "count": data['count'],
                "pct": round(data['count'] * 100.0 / total_transfer_calls, 1),
                "avg_sentiment": round(avg_sentiment, 4) if avg_sentiment else None
            })
        response["ford_topic_analysis"]["top_transfer_reasons"] = top_topics

        # Add vehicle breakdown
        vehicle_breakdown = []
        for vehicle, data in sorted(vehicle_counts.items(), key=lambda x: x[1]['transfer_calls'], reverse=True)[:10]:
            avg_sentiment = sum(data['sentiments']) / len(data['sentiments']) if data['sentiments'] else None
            vehicle_breakdown.append({
                "vehicle": vehicle,
                "transfer_calls": data['transfer_calls'],
                "avg_sentiment": round(avg_sentiment, 4) if avg_sentiment else None
            })
        response["vehicle_breakdown"] = vehicle_breakdown

        # Add examples
        if args.include_examples:
            examples = []
            for result in all_results[:args.limit]:
                example = {
                    "call_id": result.get('call_id'),
                    "call_date": str(result.get('call_date')) if result.get('call_date') else None,
                    "vehicle": result.get('vehicle_model'),
                    "team": result.get('Agent_Team') or result.get('program_name'),
                    "customer_sentiment": result.get('customer_sentiment'),
                    "verint_transfers": result.get('verint_transfers'),
                    "summary": result.get('call_summary', '')[:300] if result.get('call_summary') else None,
                    "topic_level1": result.get('topic_level1'),
                    "topic_level2": result.get('topic_level2'),
                    "topic_level3": result.get('topic_level3')
                }

                # Always include transcript excerpt since transcript is always available
                if result.get('transcript'):
                    example["transcript_excerpt"] = result.get('transcript', '')[:8000] if args.include_transcripts else None

                if result.get('pain_point'):
                    example["pain_point"] = result.get('pain_point')
                    example["customer_feedback"] = result.get('customer_feedback')

                examples.append(example)

            response["examples"] = examples

        print(json.dumps(response, indent=2))

    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)