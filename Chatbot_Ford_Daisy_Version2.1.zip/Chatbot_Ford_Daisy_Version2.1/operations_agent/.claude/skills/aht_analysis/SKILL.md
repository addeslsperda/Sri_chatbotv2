---
name: aht_analysis
display_name: Enhanced AHT Analysis
description: Comprehensive AHT analysis with data-driven percentile categories, multi-source integration, and AHT drivers identification. Uses validated thresholds from actual data (P25=5.5min, P75=15.52min). Covers efficiency analysis, quality correlation, complexity impact, and performance optimization. Use for "what drives AHT", "team efficiency", "AHT by vehicle", "performance benchmarking".
signals:
  - AHT
  - average handle time
  - handle time
  - call duration
  - high complexity
  - complexity drivers
  - AHT drivers
  - longest calls
  - hold time
  - efficiency analysis
  - performance optimization
  - quality vs efficiency
requires:
  - a date range (from and to)
not_good_for: Transfer metrics (use transfer_analysis), team volume counts (use team_volume)
---

# Enhanced AHT Analysis

## What this script does
Comprehensive AHT analysis using text_analytics.nlp_analytics.call_data (primary AHT source) + 6 enrichment sources with validated, percentile-based categories:
- **AHT performance analysis** using real data thresholds (Fast <=5.5min, Average 5.5-15.52min, Slow >=15.52min)
- **AHT drivers identification** - what causes long calls (complexity, transfers, topics, case types)
- **Efficiency vs quality correlation** - how AHT relates to sentiment, NPS, FCR
- **Performance benchmarking** with percentile rankings and outlier detection
- **Complexity-adjusted efficiency** - fair comparisons within complexity ranges
- **Multi-dimensional analysis** by vehicle, team, location, time patterns

## When to use
- "What drives our AHT?"
- "Which teams are most/least efficient?"
- "Which vehicles require longest support calls?"
- "How does complexity affect handle time?"
- "Are longer calls better quality?"
- "What's causing AHT outliers?"
- "How does transfer impact affect AHT?"
- "Which case types take longest?"
- "AHT performance by hour/day patterns"
- "Efficiency optimization opportunities"

## Parameters
- `--from` and `--to`: Date range (required)
- `--group-by`: Analysis dimension - `vehicle`, `team`, `location`, `complexity`, `transfers`, `hour`, `day_of_week`, `week`, `month` (default: vehicle)
- `--vehicle`: Filter by vehicle model (optional)
- `--team`: Filter by agent team (optional)
- `--program`: Filter by program name (optional)
- `--analysis-type`: Focus area - `overview`, `drivers`, `performance` (default: overview)
- `--min-calls`: Minimum calls for inclusion (default 100, ensures sufficient data for reliable analysis)
- `--limit`: Max results to return (default 100, ensures sufficient data)

## Output format

```json
{
  "metadata": {
    "analysis_period": "2026-01-01 to 2026-01-31",
    "filters": { "vehicle": "all", "team": "all", "program": "all" },
    "data_sources": [
      "text_analytics.nlp_analytics.call_data (PRIMARY AHT source)",
      "ford_daisy.analytics.call_data (quality metrics)",
      "dwh_prod.ovprod_o.verint_transcription (teams/locations)",
      "text_analytics.nlp_analytics.sentiments (quality correlation)",
      "text_analytics.nlp_analytics.topic_xwalk (AHT drivers)",
      "text_analytics.nlp_configs.topic_detail (topic hierarchy)",
      "text_analytics.nlp_analytics.parts_unfiltered (complexity drivers)"
    ],
    "validated_thresholds": {
      "fast_aht": "<=5.5 min (P25 from actual data)",
      "average_aht": "5.5-15.52 min (P25-P75 range)",
      "slow_aht": ">=15.52 min (P75+ from actual data)",
      "outlier_aht": ">=23.65 min (P90+ needs investigation)",
      "complexity_ranges": "Low <=15, Medium 15-30, High >30 (data-driven)"
    }
  },
  "aht_analysis": [
    {
      "vehicle": "F-150",
      "total_calls": 5133,
      "avg_aht_minutes": 10.22,
      "median_aht_minutes": 8.45,
      "p25_aht_minutes": 4.2,
      "p75_aht_minutes": 13.8,
      "p90_aht_minutes": 21.5,
      "aht_performance_category": "Fast (<=P25)",
      "performance_profile": "High Efficiency + Quality",
      "complexity_adjusted_efficiency": "Efficient for Low Complexity",
      "fast_aht_calls": 1285,
      "average_aht_calls": 3104,
      "slow_aht_calls": 744,
      "avg_complexity": 18.5,
      "avg_transfers": 0.05,
      "avg_aht_no_transfers": 10.1,
      "avg_aht_one_transfer": 8.9,
      "avg_aht_multi_transfers": 12.8,
      "avg_sentiment": 0.0954,
      "avg_nps": 4.25,
      "efficiency_rank": 1,
      "volume_rank": 15
    }
  ],
  "aht_drivers": {
    "case_type_drivers": [
      {
        "case_type": "Technical Assistance",
        "call_count": 8450,
        "avg_aht_minutes": 18.5,
        "avg_complexity": 45.2,
        "avg_transfers": 0.12
      }
    ],
    "topic_drivers": [
      {
        "topic": "In-Vehicle Technology",
        "call_count": 2850,
        "avg_aht_minutes": 22.1,
        "avg_complexity": 38.7
      }
    ]
  },
  "insights": {
    "performance_comparison": {
      "fastest_group": {
        "name": "F-150",
        "avg_aht_minutes": 10.22,
        "performance_category": "Fast (<=P25)"
      },
      "slowest_group": {
        "name": "FUSION",
        "avg_aht_minutes": 17.2,
        "performance_category": "Slow (>=P75)"
      }
    },
    "performance_distribution": {
      "fast_performers_count": 12,
      "slow_performers_count": 8,
      "fast_performers": [
        {"name": "F-150", "avg_aht_minutes": 10.22},
        {"name": "MAVERICK", "avg_aht_minutes": 12.89}
      ]
    }
  }
}
```

## Example calls

```bash
# Overall vehicle AHT analysis
python .claude/skills/aht_analysis/scripts/aht_analysis.py --from 2026-01-01 --to 2026-01-31 --group-by vehicle

# Team efficiency analysis
python .claude/skills/aht_analysis/scripts/aht_analysis.py --from 2026-01-01 --to 2026-01-31 --group-by team

# AHT drivers analysis
python .claude/skills/aht_analysis/scripts/aht_analysis.py --from 2026-01-01 --to 2026-01-31 --analysis-type drivers

# Complexity impact analysis
python .claude/skills/aht_analysis/scripts/aht_analysis.py --from 2026-01-01 --to 2026-01-31 --group-by complexity

# Transfer impact analysis
python .claude/skills/aht_analysis/scripts/aht_analysis.py --from 2026-01-01 --to 2026-01-31 --group-by transfers

# Hour-by-hour AHT patterns
python .claude/skills/aht_analysis/scripts/aht_analysis.py --from 2026-01-01 --to 2026-01-31 --group-by hour

# Vehicle-specific AHT deep dive
python .claude/skills/aht_analysis/scripts/aht_analysis.py --from 2026-01-01 --to 2026-01-31 --vehicle "Mach-E" --analysis-type drivers
```

## Key Insights Provided

### **[DATA] Data-Driven Performance Categories**
- **Fast AHT**: <=5.5 minutes (P25 from 3.8M+ actual calls)
- **Average AHT**: 5.5-15.52 minutes (P25-P75 range)
- **Slow AHT**: >=15.52 minutes (P75+ requiring optimization)
- **Outliers**: >=23.65 minutes (P90+ needing investigation)

### **[SEARCH] AHT Drivers Analysis**
- Case types with longest handle times and complexity correlation
- Topics requiring most support time
- Transfer impact on AHT (surprising finding: 1 transfer = faster than no transfers!)
- Complexity ranges: Low <=15 (7.25min avg), Medium 15-30 (13.75min), High >30 (23.57min)

### **[BALANCE] Quality vs Efficiency Balance**
- Correlation between AHT and customer sentiment/NPS
- Performance profiles: High Efficiency + Quality, Quality Focus, Needs Optimization
- Complexity-adjusted efficiency ratings for fair comparisons

### **[TREND] Performance Benchmarking**
- Percentile rankings (efficiency_rank, volume_rank, complexity_rank)
- Outlier detection and investigation priorities
- Performance distribution analysis

### **[TARGET] Optimization Opportunities**
- Groups performing above/below expected efficiency for their complexity level
- Transfer optimization opportunities (1 transfer often optimal)
- Training needs identification (slow performers with high volume)

## Validated Data Findings
- **Transfer Impact**: 1 Transfer (7.68min) < 2+ Transfers (11.44min) < No Transfers (12.41min)
- **Vehicle Patterns**: F-150 most efficient (10.22min), Fusion needs focus (17.2min)
- **Weekend Effect**: Slightly faster AHT on weekends vs weekdays
- **Complexity Linear**: Strong correlation between complexity score and AHT

## Error output
If something goes wrong, the script prints `{"error": "..."}` to stderr and exits with code 1.

## Notes
- **Multi-source integration**: Uses 7 data sources for comprehensive AHT insights
- **Privacy protection**: NO AGENT NAMES revealed (team-level analysis only)
- **Data-driven thresholds**: All categories based on actual percentiles, not assumptions
- **Like-to-like comparisons**: Compares within complexity ranges and time periods
- **Statistical significance**: Default 10 calls minimum ensures reliable analysis
- **Performance optimization**: Identifies specific improvement opportunities with business context
- Best used for operational efficiency, training needs identification, and quality vs speed optimization