"""
Enhanced AHT analysis with comprehensive multi-dimensional insights and data-driven categories.
Covers ALL AHT questions using real percentile-based thresholds from actual data.

Usage:
    python aht_analysis.py --from 2026-01-01 --to 2026-01-31 --group-by vehicle
    python aht_analysis.py --from 2026-01-01 --to 2026-01-31 --group-by team
    python aht_analysis.py --from 2026-01-01 --to 2026-01-31 --analysis-type drivers

Output: JSON with comprehensive AHT analysis using validated data patterns
"""
import argparse
import json
import os
import sys
from decimal import Decimal
from collections import defaultdict
from databricks import sql
import requests
from dotenv import load_dotenv

load_dotenv(override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


def serialize(v):
    if isinstance(v, Decimal):
        return float(v)
    if hasattr(v, "isoformat"):
        return str(v)
    return v


def get_aht_analysis(conn, date_from, date_to, group_by="vehicle", vehicle=None, team=None, program=None, min_calls=10):
    """Get comprehensive AHT analysis with multi-source integration using validated thresholds"""

    params = {
        "date_from": date_from,
        "date_to": date_to,
        "min_calls": min_calls
    }

    # Build filters
    filters = [
        "fdc.call_date >= :date_from",
        "fdc.call_date <= :date_to"
    ]

    if vehicle:
        params["vehicle"] = f"%{vehicle}%"
        filters.append("UPPER(fdc.ModelVehicleLine) LIKE UPPER(:vehicle)")

    if team:
        params["team"] = f"%{team}%"
        filters.append("UPPER(v.agent_team) LIKE UPPER(:team)")

    if program:
        params["program"] = f"%{program}%"
        filters.append("UPPER(fdc.program_name) LIKE UPPER(:program)")

    where_clause = " AND ".join(filters)

    # Determine grouping dimension
    if group_by == "vehicle":
        group_column = "fdc.ModelVehicleLine"
        group_label = "vehicle"
        group_filter = "AND fdc.ModelVehicleLine IS NOT NULL"
    elif group_by == "team":
        group_column = "v.agent_team"
        group_label = "team"
        group_filter = "AND v.agent_team IS NOT NULL"
    elif group_by == "location":
        group_column = "v.center_name"
        group_label = "location"
        group_filter = "AND v.center_name IS NOT NULL"
    elif group_by == "complexity":
        group_column = """CASE
            WHEN cd.complexity <= 15 THEN 'Low (<=15)'
            WHEN cd.complexity <= 30 THEN 'Medium (15-30)'
            ELSE 'High (>30)'
        END"""
        group_label = "complexity_range"
        group_filter = "AND cd.complexity IS NOT NULL"
    elif group_by == "transfers":
        group_column = """CASE
            WHEN cd.number_of_transfers = 0 THEN 'No Transfers'
            WHEN cd.number_of_transfers = 1 THEN '1 Transfer'
            ELSE '2+ Transfers'
        END"""
        group_label = "transfer_category"
        group_filter = "AND cd.number_of_transfers IS NOT NULL"
    elif group_by == "hour":
        group_column = "COALESCE(cd.hod, EXTRACT(HOUR FROM fdc.call_date))"
        group_label = "hour_of_day"
        group_filter = ""
    elif group_by == "day_of_week":
        group_column = """CASE DAYOFWEEK(fdc.call_date)
            WHEN 1 THEN 'Sunday'
            WHEN 2 THEN 'Monday'
            WHEN 3 THEN 'Tuesday'
            WHEN 4 THEN 'Wednesday'
            WHEN 5 THEN 'Thursday'
            WHEN 6 THEN 'Friday'
            WHEN 7 THEN 'Saturday'
        END"""
        group_label = "day_name"
        group_filter = ""
    else:  # week or month
        if group_by == "week":
            group_column = "DATE_TRUNC('week', fdc.call_date)"
        else:
            group_column = "DATE_TRUNC('month', fdc.call_date)"
        group_label = "time_period"
        group_filter = ""

    query = f"""
        WITH aht_base_data AS (
            SELECT
                {group_column} as group_value,

                -- IDENTIFIERS
                fdc.call_id,

                -- CORE AHT METRICS (from call_data - primary source)
                cd.handle_time,
                cd.holdtime,
                cd.worktime,
                cd.number_of_transfers,
                cd.agent_tenure,

                -- CORE METRICS (ford_daisy - best coverage)
                fdc.sentiment as fd_sentiment,
                fdc.complexity as fd_complexity,
                fdc.nps,
                fdc.fcr,
                fdc.brand_trust,

                -- CLASSIFICATIONS (for driver analysis)
                fdc.case_class_l1,
                fdc.program_name,
                fdc.ModelVehicleLine,
                fdc.business_process_name,

                -- TEAM DIMENSIONS
                v.agent_team,
                v.center_name,
                v.department_name,

                -- DETAILED SENTIMENT (for quality correlation)
                s.customer_sentiment,
                s.agent_sentiment,
                s.overall_sentiment,

                -- TOPIC HIERARCHY (for AHT drivers)
                td.topic_level1,
                td.topic_level2,

                -- PARTS/FEATURES (for complexity drivers)
                pu.parts_concern

            FROM ford_daisy.analytics.call_data fdc

            -- PRIMARY JOIN: Get AHT metrics (ESSENTIAL)
            LEFT JOIN text_analytics.nlp_analytics.call_data cd
                ON fdc.call_id = cd.call_id

            -- ENRICH: Agent teams and geographic info
            LEFT JOIN dwh_prod.ovprod_o.verint_transcription v
                ON fdc.call_id = v.transaction_id

            -- ENRICH: Detailed sentiment breakdown
            LEFT JOIN text_analytics.nlp_analytics.sentiments s
                ON fdc.call_id = s.call_id

            -- ENRICH: Topic hierarchy
            LEFT JOIN text_analytics.nlp_analytics.topic_xwalk tx
                ON fdc.call_id = tx.call_id
            LEFT JOIN text_analytics.nlp_configs.topic_detail td
                ON tx.topic_id = td.topic_id

            -- ENRICH: Parts and features
            LEFT JOIN text_analytics.nlp_analytics.parts_unfiltered pu
                ON fdc.call_id = pu.call_id

            WHERE {where_clause}
                AND cd.handle_time IS NOT NULL
                AND cd.handle_time > 0
                {group_filter}
        ),

        aht_aggregated AS (
            SELECT
                group_value,

                -- VOLUME METRICS
                COUNT(*) as total_calls,
                COUNT(DISTINCT agent_team) as unique_teams,
                COUNT(DISTINCT ModelVehicleLine) as unique_vehicles,
                COUNT(DISTINCT case_class_l1) as unique_case_types,

                -- AHT CORE METRICS (minutes for readability)
                ROUND(AVG(handle_time) / 60.0, 2) as avg_aht_minutes,
                ROUND(AVG(holdtime) / 60.0, 2) as avg_hold_time_minutes,
                ROUND(AVG(worktime), 2) as avg_work_time_minutes,

                -- AHT PERCENTILES (using actual data thresholds)
                ROUND(PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY handle_time) / 60.0, 2) as p25_aht_minutes,
                ROUND(PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY handle_time) / 60.0, 2) as median_aht_minutes,
                ROUND(PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY handle_time) / 60.0, 2) as p75_aht_minutes,
                ROUND(PERCENTILE_CONT(0.9) WITHIN GROUP (ORDER BY handle_time) / 60.0, 2) as p90_aht_minutes,

                -- AHT CATEGORIES (based on actual data: P25=5.5, P75=15.52)
                SUM(CASE WHEN handle_time / 60.0 <= 5.5 THEN 1 ELSE 0 END) as fast_aht_calls,
                SUM(CASE WHEN handle_time / 60.0 > 5.5 AND handle_time / 60.0 <= 15.52 THEN 1 ELSE 0 END) as average_aht_calls,
                SUM(CASE WHEN handle_time / 60.0 > 15.52 THEN 1 ELSE 0 END) as slow_aht_calls,
                SUM(CASE WHEN handle_time / 60.0 > 23.65 THEN 1 ELSE 0 END) as outlier_aht_calls,

                -- AHT DRIVERS ANALYSIS
                ROUND(AVG(fd_complexity), 2) as avg_complexity,
                ROUND(AVG(number_of_transfers), 2) as avg_transfers,
                ROUND(AVG(agent_tenure), 1) as avg_agent_tenure,

                -- TRANSFER IMPACT
                AVG(CASE WHEN number_of_transfers = 0 THEN handle_time / 60.0 END) as avg_aht_no_transfers,
                AVG(CASE WHEN number_of_transfers = 1 THEN handle_time / 60.0 END) as avg_aht_one_transfer,
                AVG(CASE WHEN number_of_transfers >= 2 THEN handle_time / 60.0 END) as avg_aht_multi_transfers,

                -- COMPLEXITY CORRELATION
                AVG(CASE WHEN fd_complexity <= 15 THEN handle_time / 60.0 END) as avg_aht_low_complexity,
                AVG(CASE WHEN fd_complexity > 15 AND fd_complexity <= 30 THEN handle_time / 60.0 END) as avg_aht_med_complexity,
                AVG(CASE WHEN fd_complexity > 30 THEN handle_time / 60.0 END) as avg_aht_high_complexity,

                -- QUALITY METRICS (correlation with AHT)
                ROUND(AVG(fd_sentiment), 4) as avg_sentiment,
                ROUND(AVG(nps), 2) as avg_nps,
                ROUND(AVG(fcr), 3) as avg_fcr,
                ROUND(AVG(customer_sentiment), 4) as avg_customer_sentiment,
                ROUND(AVG(agent_sentiment), 4) as avg_agent_sentiment,

                -- DATA COVERAGE
                ROUND(COUNT(customer_sentiment) * 100.0 / COUNT(*), 1) as sentiment_coverage_pct,
                ROUND(COUNT(nps) * 100.0 / COUNT(*), 1) as nps_coverage_pct

            FROM aht_base_data
            GROUP BY group_value
            HAVING COUNT(*) >= :min_calls
        ),

        aht_with_rankings AS (
            SELECT *,
                -- RANKINGS (for benchmarking)
                ROW_NUMBER() OVER (ORDER BY avg_aht_minutes ASC) as efficiency_rank,
                ROW_NUMBER() OVER (ORDER BY total_calls DESC) as volume_rank,
                ROW_NUMBER() OVER (ORDER BY avg_complexity DESC) as complexity_rank,

                -- PERCENTILES WITHIN DATASET
                ROUND(total_calls * 100.0 / SUM(total_calls) OVER(), 2) as pct_of_total_volume,

                -- DATA-DRIVEN PERFORMANCE CATEGORIES
                CASE
                    WHEN avg_aht_minutes <= 5.5 THEN 'Fast (<=P25)'
                    WHEN avg_aht_minutes <= 15.52 THEN 'Average (P25-P75)'
                    ELSE 'Slow (>=P75)'
                END as aht_performance_category,

                -- EFFICIENCY INDICATORS
                CASE
                    WHEN avg_aht_minutes <= 5.5 AND avg_sentiment >= 0.1 THEN 'High Efficiency + Quality'
                    WHEN avg_aht_minutes <= 5.5 THEN 'High Efficiency'
                    WHEN avg_aht_minutes > 15.52 AND avg_sentiment >= 0.1 THEN 'Quality Focus'
                    WHEN avg_aht_minutes > 15.52 THEN 'Needs Optimization'
                    ELSE 'Balanced'
                END as performance_profile,

                -- COMPLEXITY-ADJUSTED EFFICIENCY
                CASE
                    WHEN avg_complexity <= 15 AND avg_aht_minutes <= 7.25 THEN 'Efficient for Low Complexity'
                    WHEN avg_complexity > 15 AND avg_complexity <= 30 AND avg_aht_minutes <= 13.75 THEN 'Efficient for Medium Complexity'
                    WHEN avg_complexity > 30 AND avg_aht_minutes <= 23.57 THEN 'Efficient for High Complexity'
                    ELSE 'Below Expected Efficiency'
                END as complexity_adjusted_efficiency

            FROM aht_aggregated
        )

        SELECT
            group_value as {group_label},
            total_calls,
            pct_of_total_volume,
            unique_teams,
            unique_vehicles,
            unique_case_types,
            avg_aht_minutes,
            median_aht_minutes,
            p25_aht_minutes,
            p75_aht_minutes,
            p90_aht_minutes,
            avg_hold_time_minutes,
            avg_work_time_minutes,
            fast_aht_calls,
            average_aht_calls,
            slow_aht_calls,
            outlier_aht_calls,
            avg_complexity,
            avg_transfers,
            avg_agent_tenure,
            avg_aht_no_transfers,
            avg_aht_one_transfer,
            avg_aht_multi_transfers,
            avg_aht_low_complexity,
            avg_aht_med_complexity,
            avg_aht_high_complexity,
            avg_sentiment,
            avg_nps,
            avg_fcr,
            avg_customer_sentiment,
            avg_agent_sentiment,
            sentiment_coverage_pct,
            nps_coverage_pct,
            efficiency_rank,
            volume_rank,
            complexity_rank,
            aht_performance_category,
            performance_profile,
            complexity_adjusted_efficiency
        FROM aht_with_rankings
        ORDER BY
            CASE
                WHEN '{group_by}' IN ('week', 'month', 'hour', 'day_of_week') THEN group_value
                ELSE NULL
            END,
            avg_aht_minutes DESC
    """

    with conn.cursor() as cursor:
        cursor.execute(query, params)
        rows = cursor.fetchall()
        columns = [d[0] for d in cursor.description]

        return [dict(zip(columns, [serialize(val) for val in row])) for row in rows]


def get_aht_drivers_analysis(conn, date_from, date_to, vehicle=None, team=None, program=None):
    """Get detailed AHT drivers analysis - what causes long calls"""

    params = {
        "date_from": date_from,
        "date_to": date_to
    }

    filters = [
        "fdc.call_date >= :date_from",
        "fdc.call_date <= :date_to"
    ]

    if vehicle:
        params["vehicle"] = f"%{vehicle}%"
        filters.append("UPPER(fdc.ModelVehicleLine) LIKE UPPER(:vehicle)")

    if team:
        params["team"] = f"%{team}%"
        filters.append("UPPER(v.agent_team) LIKE UPPER(:team)")

    if program:
        params["program"] = f"%{program}%"
        filters.append("UPPER(fdc.program_name) LIKE UPPER(:program)")

    where_clause = " AND ".join(filters)

    # Top case types by AHT
    case_query = f"""
        SELECT
            COALESCE(fdc.case_class_l1, 'Unknown') as case_type,
            COUNT(*) as call_count,
            ROUND(AVG(cd.handle_time) / 60.0, 2) as avg_aht_minutes,
            ROUND(PERCENTILE_CONT(0.9) WITHIN GROUP (ORDER BY cd.handle_time) / 60.0, 2) as p90_aht,
            ROUND(AVG(cd.complexity), 2) as avg_complexity,
            ROUND(AVG(cd.number_of_transfers), 2) as avg_transfers
        FROM ford_daisy.analytics.call_data fdc
        LEFT JOIN text_analytics.nlp_analytics.call_data cd ON fdc.call_id = cd.call_id
        LEFT JOIN dwh_prod.ovprod_o.verint_transcription v ON fdc.call_id = v.transaction_id
        WHERE {where_clause}
            AND cd.handle_time IS NOT NULL
            AND cd.handle_time > 0
            AND fdc.case_class_l1 IS NOT NULL
        GROUP BY fdc.case_class_l1
        HAVING COUNT(*) >= 50
        ORDER BY avg_aht_minutes DESC
        LIMIT 15
    """

    # Top topics by AHT
    topic_query = f"""
        SELECT
            COALESCE(td.topic_level1, 'Unknown') as topic,
            COUNT(*) as call_count,
            ROUND(AVG(cd.handle_time) / 60.0, 2) as avg_aht_minutes,
            ROUND(AVG(cd.complexity), 2) as avg_complexity
        FROM ford_daisy.analytics.call_data fdc
        LEFT JOIN text_analytics.nlp_analytics.call_data cd ON fdc.call_id = cd.call_id
        LEFT JOIN dwh_prod.ovprod_o.verint_transcription v ON fdc.call_id = v.transaction_id
        LEFT JOIN text_analytics.nlp_analytics.topic_xwalk tx ON fdc.call_id = tx.call_id
        LEFT JOIN text_analytics.nlp_configs.topic_detail td ON tx.topic_id = td.topic_id
        WHERE {where_clause}
            AND cd.handle_time IS NOT NULL
            AND cd.handle_time > 0
            AND td.topic_level1 IS NOT NULL
        GROUP BY td.topic_level1
        HAVING COUNT(*) >= 30
        ORDER BY avg_aht_minutes DESC
        LIMIT 10
    """

    with conn.cursor() as cursor:
        # Get case types
        cursor.execute(case_query, params)
        case_rows = cursor.fetchall()
        case_columns = [d[0] for d in cursor.description]
        case_drivers = [dict(zip(case_columns, [serialize(val) for val in row])) for row in case_rows]

        # Get topics
        cursor.execute(topic_query, params)
        topic_rows = cursor.fetchall()
        topic_columns = [d[0] for d in cursor.description]
        topic_drivers = [dict(zip(topic_columns, [serialize(val) for val in row])) for row in topic_rows]

        return {
            'case_type_drivers': case_drivers,
            'topic_drivers': topic_drivers
        }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--from", dest="date_from", required=True, help="Start date YYYY-MM-DD")
    parser.add_argument("--to", dest="date_to", required=True, help="End date YYYY-MM-DD")
    parser.add_argument("--group-by", dest="group_by",
                       choices=["vehicle", "team", "location", "complexity", "transfers", "hour", "day_of_week", "week", "month"],
                       default="team", help="Grouping dimension")
    parser.add_argument("--vehicle", default=None, help="Filter by vehicle model")
    parser.add_argument("--team", default=None, help="Filter by agent team")
    parser.add_argument("--program", default=None, help="Filter by program name")
    parser.add_argument("--analysis-type", choices=["overview", "drivers", "performance"],
                       default="overview", help="Analysis focus")
    parser.add_argument("--min-calls", type=int, default=100, help="Minimum calls for inclusion (ensures sufficient data for analysis)")
    parser.add_argument("--limit", type=int, default=500, help="Max results to return")
    args, _ = parser.parse_known_args()

    # Map group_by arg to the actual column label in SQL results
    group_label_map = {
        "vehicle": "vehicle",
        "team": "team",
        "location": "location",
        "complexity": "complexity_range",
        "transfers": "transfer_category",
        "hour": "hour_of_day",
        "day_of_week": "day_name",
        "week": "time_period",
        "month": "time_period"
    }
    result_key = group_label_map[args.group_by]

    with get_connection() as conn:
        # Get main AHT analysis
        aht_data = get_aht_analysis(conn, args.date_from, args.date_to, args.group_by,
                                   args.vehicle, args.team, args.program, args.min_calls)

        # Limit results
        aht_data = aht_data[:args.limit]

        # Get drivers analysis if requested
        drivers_data = None
        if args.analysis_type in ["drivers", "overview"]:
            drivers_data = get_aht_drivers_analysis(conn, args.date_from, args.date_to,
                                                   args.vehicle, args.team, args.program)

        # Calculate insights
        if aht_data:
            fastest_group = min(aht_data, key=lambda x: x['avg_aht_minutes'])
            slowest_group = max(aht_data, key=lambda x: x['avg_aht_minutes'])
            highest_volume = max(aht_data, key=lambda x: x['total_calls'])

            total_calls = sum(d['total_calls'] for d in aht_data)
            avg_aht_overall = sum(d['avg_aht_minutes'] * d['total_calls'] for d in aht_data) / total_calls if total_calls > 0 else 0

            # Performance distribution
            fast_groups = [d for d in aht_data if d['aht_performance_category'] == 'Fast (<=P25)']
            slow_groups = [d for d in aht_data if d['aht_performance_category'] == 'Slow (>=P75)']
        else:
            fastest_group = slowest_group = highest_volume = None
            total_calls = avg_aht_overall = 0
            fast_groups = slow_groups = []

    # Build comprehensive result
    result = {
        'metadata': {
            'analysis_period': f"{args.date_from} to {args.date_to}",
            'filters': {
                'vehicle': args.vehicle or "all",
                'team': args.team or "all",
                'program': args.program or "all"
            },
            'analysis_params': {
                'group_by': args.group_by,
                'analysis_type': args.analysis_type,
                'min_calls': args.min_calls
            },
            'data_sources': [
                'text_analytics.nlp_analytics.call_data (PRIMARY AHT source)',
                'ford_daisy.analytics.call_data (quality metrics)',
                'dwh_prod.ovprod_o.verint_transcription (teams/locations)',
                'text_analytics.nlp_analytics.sentiments (quality correlation)',
                'text_analytics.nlp_analytics.topic_xwalk (AHT drivers)',
                'text_analytics.nlp_configs.topic_detail (topic hierarchy)',
                'text_analytics.nlp_analytics.parts_unfiltered (complexity drivers)'
            ],
            'validated_thresholds': {
                'fast_aht': '<=5.5 min (P25 from actual data)',
                'average_aht': '5.5-15.52 min (P25-P75 range)',
                'slow_aht': '>=15.52 min (P75+ from actual data)',
                'outlier_aht': '>=23.65 min (P90+ needs investigation)',
                'complexity_ranges': 'Low <=15, Medium 15-30, High >30 (data-driven)'
            }
        },
        'aht_analysis': aht_data,
        'insights': {
            'overall_metrics': {
                'total_calls_analyzed': total_calls,
                'groups_analyzed': len(aht_data),
                'overall_avg_aht_minutes': round(avg_aht_overall, 2)
            },
            'performance_comparison': {
                'fastest_group': {
                    'name': fastest_group[result_key] if fastest_group else None,
                    'avg_aht_minutes': fastest_group['avg_aht_minutes'] if fastest_group else None,
                    'performance_category': fastest_group['aht_performance_category'] if fastest_group else None
                } if fastest_group else None,
                'slowest_group': {
                    'name': slowest_group[result_key] if slowest_group else None,
                    'avg_aht_minutes': slowest_group['avg_aht_minutes'] if slowest_group else None,
                    'performance_category': slowest_group['aht_performance_category'] if slowest_group else None
                } if slowest_group else None,
                'highest_volume_group': {
                    'name': highest_volume[result_key] if highest_volume else None,
                    'total_calls': highest_volume['total_calls'] if highest_volume else None,
                    'avg_aht_minutes': highest_volume['avg_aht_minutes'] if highest_volume else None
                } if highest_volume else None
            },
            'performance_distribution': {
                'fast_performers_count': len(fast_groups),
                'slow_performers_count': len(slow_groups),
                'fast_performers': [
                    {'name': d[result_key], 'avg_aht_minutes': d['avg_aht_minutes']}
                    for d in fast_groups[:5]
                ],
                'slow_performers': [
                    {'name': d[result_key], 'avg_aht_minutes': d['avg_aht_minutes']}
                    for d in slow_groups[:5]
                ]
            }
        }
    }

    # Add drivers analysis if available
    if drivers_data:
        result['aht_drivers'] = drivers_data

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)