"""
Tracks customers across multiple calls to identify repeat issues and resolution failures.
Analyzes customer journeys, serial callers, and unresolved issues.

Usage:
    python customer_journey_analysis.py --from 2026-01-01 --to 2026-01-31
    python customer_journey_analysis.py --from 2026-01-01 --to 2026-01-31 --topic "transmission"
    python customer_journey_analysis.py --from 2026-01-01 --to 2026-01-31 --analysis-type serial_callers --min-calls 3
    python customer_journey_analysis.py --from 2026-01-01 --to 2026-01-31 --customer-id "1234567890"

Output: JSON with customer journey analysis
"""
import argparse
import json
import os
import sys
from collections import defaultdict
from decimal import Decimal
from pathlib import Path
from databricks import sql
import requests
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parents[4] / ".env", override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


CATALOG = os.environ.get("DATABRICKS_CATALOG", "text_analytics")
SCHEMA = os.environ.get("DATABRICKS_SCHEMA", "nlp_analytics")
CALL_DATA = f"{CATALOG}.{SCHEMA}.call_data"
CALL_TABLE = f"{CATALOG}.{SCHEMA}.call_table"


def serialize(v):
    if isinstance(v, Decimal): return float(v)
    if hasattr(v, "isoformat"): return str(v)
    return v


def mask_customer_id(customer_id):
    """Mask customer ID for privacy"""
    if not customer_id:
        return "unknown"
    s = str(customer_id)
    if len(s) >= 8:
        return f"xxx-xxxx-{s[-4:]}"
    return "xxx-xxxx-xxxx"


def extract_topic_keywords(summary, transcript):
    """Extract main topic from summary/transcript"""
    text = (summary or "") + " " + (transcript or "")
    text_lower = text.lower()

    # Priority topics - check in order
    topics = [
        ("FordPass", ["fordpass", "ford app"]),
        ("Phone as a Key", ["phone as a key", "paak"]),
        ("BlueCruise", ["bluecruise", "hands-free"]),
        ("Charging", ["charging", "charger", "charge network"]),
        ("Remote Start", ["remote start"]),
        ("Transmission", ["transmission", "trans"]),
        ("Engine", ["engine", "motor"]),
        ("Authentication", ["password", "login", "authentication", "mfa"]),
        ("Subscription", ["subscription", "billing"]),
        ("Recall", ["recall"]),
        ("Buyback", ["buyback", "lemon"]),
    ]

    for topic_name, keywords in topics:
        if any(kw in text_lower for kw in keywords):
            return topic_name

    return "Other"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--from", dest="date_from", required=True)
    parser.add_argument("--to", dest="date_to", required=True)
    parser.add_argument("--vehicle", default=None)
    parser.add_argument("--topic", "--keyword", dest="topic", default=None,
                       help="Topic or keyword to filter by. Alias --keyword also accepted.")
    parser.add_argument("--analysis-type", dest="analysis_type",
                       choices=["repeat_calls", "serial_callers", "unresolved_issues", "journey"],
                       default="repeat_calls")
    parser.add_argument("--min-calls", dest="min_calls", type=int, default=2)
    parser.add_argument("--customer-id", dest="customer_id", default=None,
                       help="VIN or case number to analyze")
    parser.add_argument("--limit", type=int, default=500)
    args, _ = parser.parse_known_args()

    # Build base filters
    params = {"date_from": args.date_from, "date_to": args.date_to}
    base_filters = [
        "DATE(cd.call_date) >= :date_from",
        "DATE(cd.call_date) <= :date_to",
    ]

    if args.vehicle:
        params["vehicle"] = f"%{args.vehicle}%"
        base_filters.append("LOWER(cd.modelvehicleline) LIKE LOWER(:vehicle)")

    if args.topic:
        params["topic"] = f"%{args.topic}%"
        base_filters.append("(LOWER(ct.summary) LIKE LOWER(:topic) OR LOWER(ct.transcript) LIKE LOWER(:topic))")

    if args.customer_id:
        # Customer ID can be VIN or case number
        params["customer_id"] = f"%{args.customer_id}%"
        base_filters.append("(cd.vin LIKE :customer_id OR cd.casenumber LIKE :customer_id)")

    base_where = " AND ".join(base_filters)

    with get_connection() as conn:
        if args.analysis_type == "journey" and args.customer_id:
            # CUSTOMER JOURNEY (specific customer)
            with conn.cursor() as cursor:
                query = f"""
                    SELECT
                        cd.call_id,
                        cd.call_date,
                        cd.vin,
                        ct.summary,
                        ct.transcript,
                        ct.Agent_Team,
                        cd.cust_end_sent,
                        cd.handle_time,
                        cd.number_of_transfers,
                        cd.modelvehicleline
                    FROM {CALL_DATA} cd
                    JOIN {CALL_TABLE} ct ON cd.call_id = ct.call_id
                    WHERE {base_where}
                      AND cd.vin IS NOT NULL
                    ORDER BY cd.call_date ASC
                    LIMIT 500
                """  # nosec B608
                cursor.execute(query, params)
                rows = cursor.fetchall()

            if not rows:
                result = {
                    'date_range': f"{args.date_from} to {args.date_to}",
                    'analysis_type': 'journey',
                    'customer_id': mask_customer_id(args.customer_id),
                    'error': 'No calls found for this customer'
                }
            else:
                timeline = []
                total_aht = 0
                sentiments = []

                for row in rows:
                    call_id, call_date, phone, summary, transcript, team, sentiment, aht, transfers, vehicle = row

                    topic = extract_topic_keywords(summary, transcript)

                    timeline.append({
                        'call_date': str(call_date),
                        'call_id': str(call_id)[-6:],  # Last 6 chars only
                        'issue': topic,
                        'team': team or "Unknown",
                        'sentiment': float(sentiment) if sentiment else 0,
                        'aht': int(aht) if aht else 0,
                        'transferred': bool(transfers and transfers > 0),
                        'vehicle': vehicle
                    })

                    if aht:
                        total_aht += int(aht)
                    if sentiment:
                        sentiments.append(float(sentiment))

                # Calculate insights
                sentiment_trajectory = "stable"
                if len(sentiments) >= 3:
                    if sentiments[-1] < sentiments[0] - 0.2:
                        sentiment_trajectory = "declining"
                    elif sentiments[-1] > sentiments[0] + 0.2:
                        sentiment_trajectory = "improving"

                result = {
                    'date_range': f"{args.date_from} to {args.date_to}",
                    'analysis_type': 'journey',
                    'customer_id': mask_customer_id(args.customer_id),
                    'total_calls': len(timeline),
                    'first_call_date': str(rows[0][1]),
                    'last_call_date': str(rows[-1][1]),
                    'journey_timeline': timeline,
                    'journey_insights': {
                        'sentiment_trajectory': sentiment_trajectory,
                        'avg_sentiment': round(sum(sentiments) / len(sentiments), 2) if sentiments else 0,
                        'total_handle_time': total_aht,
                        'calls_with_transfers': sum(1 for t in timeline if t['transferred'])
                    }
                }

        elif args.analysis_type == "serial_callers":
            # SERIAL CALLERS (3+ calls)
            with conn.cursor() as cursor:
                query = f"""
                    SELECT
                        cd.vin,
                        COUNT(*) AS call_count,
                        MIN(cd.call_date) AS first_call,
                        MAX(cd.call_date) AS last_call,
                        AVG(cd.cust_end_sent) AS avg_sentiment,
                        cd.modelvehicleline
                    FROM {CALL_DATA} cd
                    JOIN {CALL_TABLE} ct ON cd.call_id = ct.call_id
                    WHERE {base_where}
                      AND cd.vin IS NOT NULL
                    GROUP BY cd.vin, cd.modelvehicleline
                    HAVING COUNT(*) >= {args.min_calls}
                    ORDER BY call_count DESC
                    LIMIT {args.limit}
                """  # nosec B608
                cursor.execute(query, params)
                rows = cursor.fetchall()

            # Get total stats
            with conn.cursor() as cursor:
                total_query = f"""
                    SELECT
                        COUNT(DISTINCT cd.vin) AS total_customers,
                        COUNT(*) AS total_calls
                    FROM {CALL_DATA} cd
                    JOIN {CALL_TABLE} ct ON cd.call_id = ct.call_id
                    WHERE {base_where}
                      AND cd.vin IS NOT NULL
                """  # nosec B608
                cursor.execute(total_query, params)
                total_row = cursor.fetchone()
                total_customers = int(total_row[0])
                total_calls = int(total_row[1])

            serial_callers = []
            total_serial_calls = 0

            for row in rows:
                phone, call_count, first_call, last_call, avg_sentiment, vehicle = row

                days_span = (last_call - first_call).days if first_call and last_call else 0

                serial_callers.append({
                    'customer_id': mask_customer_id(phone),
                    'call_count': int(call_count),
                    'first_call': str(first_call),
                    'last_call': str(last_call),
                    'days_span': days_span,
                    'vehicle': vehicle,
                    'avg_sentiment': round(float(avg_sentiment), 2) if avg_sentiment else 0,
                    'escalation_flag': bool(avg_sentiment and avg_sentiment < -0.6)
                })

                total_serial_calls += int(call_count)

            result = {
                'date_range': f"{args.date_from} to {args.date_to}",
                'analysis_type': 'serial_callers',
                'min_calls': args.min_calls,
                'total_customers': total_customers,
                'serial_callers_found': len(serial_callers),
                'pct_of_customers': round(len(serial_callers) * 100.0 / total_customers, 1) if total_customers > 0 else 0,
                'total_calls_from_serials': total_serial_calls,
                'pct_of_total_calls': round(total_serial_calls * 100.0 / total_calls, 1) if total_calls > 0 else 0,
                'serial_callers': serial_callers[:20]  # Top 20
            }

        else:
            # REPEAT CALLS ANALYSIS (default)
            with conn.cursor() as cursor:
                # Get customers with repeat calls
                query = f"""
                    SELECT
                        cd.vin,
                        COUNT(*) AS call_count,
                        MIN(cd.call_date) AS first_call,
                        MAX(cd.call_date) AS last_call
                    FROM {CALL_DATA} cd
                    JOIN {CALL_TABLE} ct ON cd.call_id = ct.call_id
                    WHERE {base_where}
                      AND cd.vin IS NOT NULL
                    GROUP BY cd.vin
                    HAVING COUNT(*) >= {args.min_calls}
                    ORDER BY call_count DESC
                    LIMIT 500
                """  # nosec B608
                cursor.execute(query, params)
                repeat_rows = cursor.fetchall()

            # Get total stats
            with conn.cursor() as cursor:
                total_query = f"""
                    SELECT
                        COUNT(DISTINCT cd.vin) AS total_customers,
                        COUNT(*) AS total_calls
                    FROM {CALL_DATA} cd
                    JOIN {CALL_TABLE} ct ON cd.call_id = ct.call_id
                    WHERE {base_where}
                      AND cd.vin IS NOT NULL
                """  # nosec B608
                cursor.execute(total_query, params)
                total_row = cursor.fetchone()
                total_customers = int(total_row[0])
                total_calls = int(total_row[1])

            # Calculate metrics
            repeat_customers = len(repeat_rows)
            total_repeat_calls = sum(int(row[1]) for row in repeat_rows)
            avg_calls_per_repeat = total_repeat_calls / repeat_customers if repeat_customers > 0 else 0

            # Calculate avg days between calls
            days_between = []
            for row in repeat_rows:
                phone, call_count, first_call, last_call = row
                if first_call and last_call and call_count > 1:
                    days = (last_call - first_call).days
                    days_between.append(days / (call_count - 1))  # Avg between consecutive calls

            avg_days_between = sum(days_between) / len(days_between) if days_between else 0

            result = {
                'date_range': f"{args.date_from} to {args.date_to}",
                'analysis_type': 'repeat_calls',
                'total_customers': total_customers,
                'total_calls': total_calls,
                'customers_with_repeat_calls': repeat_customers,
                'repeat_call_rate': round(repeat_customers * 100.0 / total_customers, 1) if total_customers > 0 else 0,
                'avg_calls_per_repeat_customer': round(avg_calls_per_repeat, 1),
                'avg_days_between_calls': round(avg_days_between, 1),
                'insights': {
                    'total_repeat_calls': total_repeat_calls,
                    'pct_calls_are_repeats': round(total_repeat_calls * 100.0 / total_calls, 1) if total_calls > 0 else 0
                }
            }

        print(json.dumps(result, indent=2, default=serialize))


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)
