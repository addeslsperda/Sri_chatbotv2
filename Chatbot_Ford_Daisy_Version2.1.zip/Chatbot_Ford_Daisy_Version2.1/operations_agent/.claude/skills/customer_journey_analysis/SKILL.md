---
name: customer_journey_analysis
display_name: Customer Journey & Repeat Call Analysis
description: Tracks customers across multiple calls to identify repeat issues, resolution failures, and serial callers. Use for "repeat call rate", "how many customers called back", "unresolved issues", "customer call history", "same issue multiple times", "resolution success rate".
signals:
  - repeat call
  - called back
  - multiple calls
  - same issue
  - unresolved
  - customer journey
  - serial caller
  - call history
  - how many times
  - resolution success
requires:
  - date range
not_good_for: Single call analysis (use other skills), FCR only (use resolution_analysis)
---

# Customer Journey & Repeat Call Analysis

## What this script does
Tracks individual customers across multiple calls to identify:
- **Repeat call rate**: How many customers call back about the same issue
- **Serial callers**: Customers with 3+ calls in the period
- **Unresolved issues**: Topics customers keep calling about
- **Time between calls**: How quickly customers call back
- **Resolution success**: Which issues get fixed vs recur
- **Customer lifetime value**: Call patterns by customer segment

Returns customer journey insights with repeat issue identification.

## How to run it

```bash
python .claude/skills/customer_journey_analysis/scripts/customer_journey_analysis.py --from 2026-01-01 --to 2026-01-31
```

## Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--from` | Yes | — | Start date YYYY-MM-DD |
| `--to` | Yes | — | End date YYYY-MM-DD |
| `--vehicle` | No | all | Filter by vehicle model |
| `--topic` | No | all | Filter by specific issue/topic |
| `--analysis-type` | No | `repeat_calls` | Type: `repeat_calls`, `serial_callers`, `unresolved_issues`, `journey` |
| `--min-calls` | No | `2` | Minimum calls per customer to include |
| `--customer-id` | No | none | Analyze specific customer journey (phone number or customer ID) |
| `--limit` | No | `100` | Max customers/issues to return |

## Example calls

```bash
# Overall repeat call rate for January
python .claude/skills/customer_journey_analysis/scripts/customer_journey_analysis.py --from 2026-01-01 --to 2026-01-31

# Repeat calls about transmission issues
python .claude/skills/customer_journey_analysis/scripts/customer_journey_analysis.py --from 2026-01-01 --to 2026-01-31 --topic "transmission"

# Serial callers (3+ calls)
python .claude/skills/customer_journey_analysis/scripts/customer_journey_analysis.py --from 2026-01-01 --to 2026-01-31 --analysis-type serial_callers --min-calls 3

# Unresolved issues (what keeps coming back)
python .claude/skills/customer_journey_analysis/scripts/customer_journey_analysis.py --from 2026-01-01 --to 2026-01-31 --analysis-type unresolved_issues

# Specific customer journey
python .claude/skills/customer_journey_analysis/scripts/customer_journey_analysis.py --from 2026-01-01 --to 2026-01-31 --customer-id "1234567890"

# Mach-E repeat charging calls
python .claude/skills/customer_journey_analysis/scripts/customer_journey_analysis.py --from 2026-01-01 --to 2026-01-31 --vehicle "Mach-E" --topic "charging"
```

## Output format

### Repeat Calls Analysis:
```json
{
  "date_range": "2026-01-01 to 2026-01-31",
  "analysis_type": "repeat_calls",
  "total_customers": 98450,
  "total_calls": 143985,
  "customers_with_repeat_calls": 15620,
  "repeat_call_rate": 15.9,
  "avg_calls_per_repeat_customer": 2.8,
  "avg_days_between_calls": 8.5,
  "repeat_patterns": [
    {
      "topic": "FordPass connectivity",
      "repeat_customers": 2850,
      "pct_of_repeats": 18.2,
      "avg_calls_per_customer": 3.2,
      "avg_days_between": 5.8,
      "resolution_success_rate": 35.5,
      "examples": [
        {
          "customer_id": "xxx-xxxx-1234",
          "call_count": 5,
          "first_call": "2026-01-03",
          "last_call": "2026-01-28",
          "days_span": 25,
          "issue_summary": "FordPass won't connect, repeated authentication failures"
        }
      ]
    },
    {
      "topic": "Transmission",
      "repeat_customers": 1850,
      "pct_of_repeats": 11.8,
      "avg_calls_per_customer": 2.5,
      "avg_days_between": 12.3,
      "resolution_success_rate": 18.2
    }
  ],
  "insights": {
    "highest_repeat_topic": "FordPass connectivity",
    "lowest_resolution_rate": "Transmission (18.2%)",
    "fastest_callbacks": "Phone as a Key (3.2 days avg)"
  }
}
```

### Serial Callers Analysis:
```json
{
  "date_range": "2026-01-01 to 2026-01-31",
  "analysis_type": "serial_callers",
  "min_calls": 3,
  "serial_callers_found": 2450,
  "pct_of_customers": 2.5,
  "total_calls_from_serials": 9850,
  "pct_of_total_calls": 6.8,
  "serial_callers": [
    {
      "customer_id": "xxx-xxxx-5678",
      "call_count": 8,
      "first_call": "2026-01-02",
      "last_call": "2026-01-30",
      "days_span": 28,
      "vehicle": "F-150",
      "primary_issues": [
        {"topic": "BlueOval Charge Network", "count": 5},
        {"topic": "FordPass", "count": 2},
        {"topic": "Billing", "count": 1}
      ],
      "avg_sentiment": -0.72,
      "escalation_flag": true,
      "resolution_status": "unresolved"
    }
  ],
  "common_serial_issues": [
    {"topic": "Subscription billing", "serial_customer_count": 850},
    {"topic": "Charging network", "serial_customer_count": 620},
    {"topic": "Remote start", "serial_customer_count": 485}
  ]
}
```

### Unresolved Issues Analysis:
```json
{
  "date_range": "2026-01-01 to 2026-01-31",
  "analysis_type": "unresolved_issues",
  "unresolved_issues": [
    {
      "topic": "Phone as a Key",
      "repeat_customers": 1250,
      "total_calls": 4850,
      "avg_calls_per_customer": 3.9,
      "avg_days_between": 3.2,
      "resolution_rate": 12.5,
      "severity": "high",
      "trend": "increasing",
      "customer_sentiment_decline": -0.35,
      "business_impact": "High churn risk - customers calling 3-4 times unresolved"
    }
  ]
}
```

### Customer Journey (Specific Customer):
```json
{
  "date_range": "2026-01-01 to 2026-01-31",
  "analysis_type": "journey",
  "customer_id": "xxx-xxxx-1234",
  "total_calls": 5,
  "first_call_date": "2026-01-05",
  "last_call_date": "2026-01-28",
  "journey_timeline": [
    {
      "call_date": "2026-01-05",
      "call_id": "abc123",
      "issue": "FordPass won't connect to vehicle",
      "team": "FordPass-FPTm02",
      "sentiment": -0.45,
      "aht": 850,
      "resolution": "Attempted pairing reset",
      "transferred": false
    },
    {
      "call_date": "2026-01-08",
      "call_id": "def456",
      "issue": "Same issue - still can't connect",
      "team": "FordPass-FPTm02",
      "sentiment": -0.68,
      "aht": 920,
      "resolution": "Module update recommended",
      "transferred": true
    },
    {
      "call_date": "2026-01-15",
      "call_id": "ghi789",
      "issue": "Module update didn't work",
      "team": "ConcernTm14",
      "sentiment": -0.82,
      "aht": 1150,
      "resolution": "Escalated to engineering",
      "transferred": true
    },
    {
      "call_date": "2026-01-22",
      "call_id": "jkl012",
      "issue": "Still no resolution, wants buyback info",
      "team": "ConcernTm14",
      "sentiment": -0.95,
      "aht": 1450,
      "resolution": "Buyback packet sent",
      "transferred": false
    },
    {
      "call_date": "2026-01-28",
      "call_id": "mno345",
      "issue": "Following up on buyback status",
      "team": "ConcernTm14",
      "sentiment": -0.88,
      "aht": 680,
      "resolution": "Under review",
      "transferred": false
    }
  ],
  "journey_insights": {
    "resolution_status": "unresolved",
    "sentiment_trajectory": "declining",
    "escalation_reached": true,
    "days_to_escalation": 17,
    "total_handle_time": 5050,
    "business_impact": "High - likely buyback candidate"
  }
}
```

## Resolution Success Rate

Calculated as: (Customers who didn't call back / Total customers with this issue) * 100

- **>80%**: Issue is being resolved well
- **50-80%**: Moderate resolution, some callbacks
- **<50%**: Poor resolution, many repeat calls (CRITICAL)

## Error output
If something goes wrong, the script prints `{"error": "..."}` to stderr and exits with code 1.

## Notes
- **Use cases**: 
  - Identify systemic issues (low resolution rates)
  - Find "serial callers" at risk of churn
  - Measure true customer pain (not just call volume)
  - Prioritize fixes (issues with most repeat calls)
  - Track customer escalation paths
- **Resolution success** = customers who DON'T call back within the time period
- **Serial callers** (3+ calls) often indicate systemic issues or poor service
- **Days between calls** indicates urgency (2-3 days = urgent, 20+ days = moderate)
- Customers are identified by phone number (if available) or customer ID
- Use with sentiment_deep_dive to see emotional impact of unresolved issues
- Combine with escalation tracking to identify buyback candidates
- **Privacy**: Output masks customer IDs (xxx-xxxx-1234 format)
