"""
Enhanced regional analysis using actual Ford CRC locations and verint_transcription data.
Returns call metrics by actual geographic regions based on center_name values.

Usage:
    python regional_analysis.py --from 2026-01-01 --to 2026-01-31
    python regional_analysis.py --from 2026-01-01 --to 2026-01-31 --region US-Southeast
    python regional_analysis.py --from 2026-01-01 --to 2026-01-31 --group-by country
    python regional_analysis.py --from 2026-01-01 --to 2026-01-31 --brand lincoln

Output: JSON with regional breakdown and performance metrics
"""
import argparse
import json
import os
import sys
from decimal import Decimal
from pathlib import Path
from databricks import sql
import numpy as np
import requests
from dotenv import load_dotenv

load_dotenv(override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


# Lincoln vehicle models based on actual database data
LINCOLN_MODELS = ['NAVIGATOR', 'AVIATOR', 'NAUTILUS', 'CORSAIR', 'CONTINENTAL',
                  'MKX', 'MKZ', 'MKC', 'MKS', 'MKT', 'TOWN CAR', 'ZEPHYR',
                  'MARINER', 'MOUNTAINEER', 'LS', 'MARK LT', 'MARK VIII',
                  'BLACKWOOD', 'MONTEREY', 'NAVIGATOR L']


def serialize(v):
    if isinstance(v, Decimal):
        return float(v)
    if hasattr(v, "isoformat"):
        return str(v)
    if isinstance(v, np.ndarray):
        return v.tolist()
    if isinstance(v, (list, tuple)):
        return [serialize(i) for i in v]
    return v


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--from", dest="date_from", required=True, help="Start date YYYY-MM-DD")
    parser.add_argument("--to", dest="date_to", required=True, help="End date YYYY-MM-DD")
    parser.add_argument("--region", default=None, help="Filter by specific region")
    parser.add_argument("--location", default=None, help="Filter by specific location/center")
    parser.add_argument("--brand", choices=["ford", "lincoln"], default=None, help="Filter by brand")
    parser.add_argument("--group-by", dest="group_by",
                        choices=["region", "country", "location", "brand"],
                        default="region", help="How to group results")
    parser.add_argument("--min-calls", type=int, default=100, help="Minimum calls for inclusion")
    parser.add_argument("--sort-by", choices=["volume", "aht", "sentiment"],
                        default="volume", help="Sort results by")
    args, _ = parser.parse_known_args()

    # Build parameters
    params = {
        "date_from": args.date_from,
        "date_to": args.date_to,
        "min_calls": args.min_calls
    }

    # Build filters
    filters = [
        "v.date_of_call >= :date_from",
        "v.date_of_call <= :date_to",
        "v.center_name IS NOT NULL"
    ]

    # Add brand filter if specified
    if args.brand:
        if args.brand.lower() == "lincoln":
            lincoln_list = "', '".join(LINCOLN_MODELS)
            filters.append(f"UPPER(cd.modelvehicleline) IN ('{lincoln_list}')")
        else:  # ford
            lincoln_list = "', '".join(LINCOLN_MODELS)
            filters.append(f"(cd.modelvehicleline IS NULL OR UPPER(cd.modelvehicleline) NOT IN ('{lincoln_list}'))")

    # Add region/location filters if specified
    if args.region:
        params["region"] = f"%{args.region}%"
        # Map region to actual center patterns
        if args.region.lower() == "us":
            filters.append("v.center_name LIKE '%, US'")
        elif args.region.lower() == "canada":
            filters.append("v.center_name LIKE '%, CA'")
        elif args.region.lower() == "asia":
            filters.append("v.center_name LIKE '%PH%'")
        else:
            filters.append("v.center_name LIKE :region")

    if args.location:
        params["location"] = f"%{args.location}%"
        filters.append("v.center_name LIKE :location")

    # Determine grouping dimension
    if args.group_by == "country":
        dimension_clause = """
        CASE
            WHEN v.center_name LIKE '%, US' THEN 'United States'
            WHEN v.center_name LIKE '%, CA' THEN 'Canada'
            WHEN v.center_name LIKE '%PH%' THEN 'Philippines'
            ELSE 'Other'
        END"""
        dimension_label = "country"
    elif args.group_by == "location":
        dimension_clause = "v.center_name"
        dimension_label = "location"
    elif args.group_by == "brand":
        lincoln_list = "', '".join(LINCOLN_MODELS)
        dimension_clause = f"""
        CASE
            WHEN UPPER(cd.modelvehicleline) IN ('{lincoln_list}') THEN 'Lincoln'
            WHEN cd.modelvehicleline IS NOT NULL THEN 'Ford'
            ELSE 'Unknown Brand'
        END"""
        dimension_label = "brand"
    else:  # region
        dimension_clause = """
        CASE
            WHEN v.center_name = 'Houston, TX, US' THEN 'US-South'
            WHEN v.center_name = 'Melbourne, FL, US' THEN 'US-Southeast'
            WHEN v.center_name = 'Dearborn, MI, US' THEN 'US-Midwest'
            WHEN v.center_name = 'Asheville, NC, US' THEN 'US-Southeast'
            WHEN v.center_name = 'Manila, PH' THEN 'Asia-Pacific'
            WHEN v.center_name = 'Oakville, ON, CA' THEN 'Canada'
            WHEN v.center_name = 'Melbourne' THEN 'US-Southeast-Alt'
            WHEN v.center_name = 'IPCC' THEN 'Corporate'
            ELSE 'Other'
        END"""
        dimension_label = "region"

    # Build sort clause
    if args.sort_by == "aht":
        sort_clause = "avg_handle_time_minutes ASC"
    elif args.sort_by == "sentiment":
        sort_clause = "avg_sentiment DESC"
    else:
        sort_clause = "total_calls DESC"

    where_clause = " AND ".join(filters)

    # Enhanced query using verint_transcription as primary source with performance joins
    query = f"""
        WITH base_regional_data AS (
            SELECT
                {dimension_clause} as dimension,
                v.center_name as location_detail,
                v.program_name,
                v.agent_team,

                -- VOLUME METRICS
                COUNT(*) as total_calls,
                COUNT(DISTINCT v.agent_name) as unique_agents,

                -- PERFORMANCE METRICS (from call_data where available)
                COUNT(cd.call_id) as calls_with_performance_data,
                AVG(cd.handle_time) as avg_handle_time_seconds,
                AVG(cd.complexity) as avg_complexity,
                AVG(cd.number_of_transfers) as avg_transfers,

                -- QUALITY METRICS (from sentiments table)
                COUNT(s.call_id) as calls_with_sentiment_data,
                AVG(s.customer_sentiment) as avg_customer_sentiment,
                AVG(s.agent_sentiment) as avg_agent_sentiment,
                AVG(s.overall_sentiment) as avg_overall_sentiment,

                -- VEHICLE DATA (when available)
                COUNT(DISTINCT cd.modelvehicleline) as unique_vehicle_models,

                -- CASE MANAGEMENT METRICS (from case_metadata where available)
                COUNT(DISTINCT cm.casenumber) as unique_cases,
                COUNT(cm.nps_score) as nps_data_points,
                AVG(cm.nps_score) as avg_nps_score,
                COUNT(cm.fcr_score) as fcr_data_points,
                AVG(cm.fcr_score) as avg_fcr_score,
                COUNT(DISTINCT cm.owner) as unique_case_owners,
                COUNT(DISTINCT cm.caseclassificationlevel1) as unique_classifications,

                -- DATA QUALITY INDICATORS
                ROUND(COUNT(cd.call_id) * 100.0 / COUNT(*), 1) as performance_data_coverage_pct,
                ROUND(COUNT(s.call_id) * 100.0 / COUNT(*), 1) as sentiment_data_coverage_pct,
                ROUND(COUNT(cm.casenumber) * 100.0 / COUNT(*), 1) as case_data_coverage_pct

            FROM dwh_prod.ovprod_o.verint_transcription v

            -- JOIN 1: verint -> call_data (transaction_id = call_id)
            LEFT JOIN text_analytics.nlp_analytics.call_data cd
                ON v.transaction_id = cd.call_id

            -- JOIN 2: verint -> sentiments (transaction_id = call_id)
            LEFT JOIN text_analytics.nlp_analytics.sentiments s
                ON v.transaction_id = s.call_id

            -- JOIN 3: call_data -> case_metadata (casenumber = casenumber)
            LEFT JOIN text_analytics.nlp_dashboard.case_metadata cm
                ON cd.casenumber = cm.casenumber

            WHERE {where_clause}

            GROUP BY
                {dimension_clause},
                v.center_name,
                v.program_name,
                v.agent_team
        ),

        aggregated_regional_data AS (
            SELECT
                dimension,

                -- VOLUME METRICS
                SUM(total_calls) as total_calls,
                SUM(unique_agents) as total_agents,
                ROUND(SUM(total_calls) * 1.0 / NULLIF(SUM(unique_agents), 0), 1) as calls_per_agent,

                -- PERFORMANCE METRICS
                ROUND(AVG(avg_handle_time_seconds) / 60.0, 2) as avg_handle_time_minutes,
                ROUND(AVG(avg_complexity), 2) as avg_complexity,
                ROUND(AVG(avg_transfers), 2) as avg_transfers,

                -- QUALITY METRICS
                ROUND(AVG(avg_customer_sentiment), 3) as avg_customer_sentiment,
                ROUND(AVG(avg_agent_sentiment), 3) as avg_agent_sentiment,
                ROUND(AVG(avg_overall_sentiment), 3) as avg_overall_sentiment,

                -- VEHICLE DIVERSITY
                SUM(unique_vehicle_models) as total_vehicle_models,

                -- CASE MANAGEMENT AGGREGATES
                SUM(unique_cases) as total_cases,
                SUM(nps_data_points) as total_nps_responses,
                ROUND(AVG(avg_nps_score), 2) as avg_nps_score,
                SUM(fcr_data_points) as total_fcr_responses,
                ROUND(AVG(avg_fcr_score), 3) as avg_fcr_score,
                SUM(unique_case_owners) as total_case_owners,
                SUM(unique_classifications) as total_classifications,

                -- DATA COVERAGE
                ROUND(AVG(performance_data_coverage_pct), 1) as avg_performance_coverage_pct,
                ROUND(AVG(sentiment_data_coverage_pct), 1) as avg_sentiment_coverage_pct,
                ROUND(AVG(case_data_coverage_pct), 1) as avg_case_coverage_pct,

                -- LOCATION DETAILS
                COUNT(DISTINCT location_detail) as locations_count,
                COLLECT_LIST(DISTINCT location_detail) as locations,
                COUNT(DISTINCT program_name) as programs_count,

                -- PERFORMANCE CATEGORIES
                CASE
                    WHEN AVG(avg_handle_time_seconds)/60.0 <= 8 THEN 'Fast'
                    WHEN AVG(avg_handle_time_seconds)/60.0 <= 15 THEN 'Average'
                    ELSE 'Slow'
                END as aht_category,

                CASE
                    WHEN AVG(avg_overall_sentiment) >= 0.6 THEN 'Positive'
                    WHEN AVG(avg_overall_sentiment) >= 0.4 THEN 'Neutral'
                    ELSE 'Negative'
                END as sentiment_category

            FROM base_regional_data
            GROUP BY dimension
            HAVING SUM(total_calls) >= :min_calls
        ),

        final_with_rankings AS (
            SELECT *,
                -- RANKINGS
                ROW_NUMBER() OVER (ORDER BY total_calls DESC) as volume_rank,
                ROW_NUMBER() OVER (ORDER BY avg_handle_time_minutes ASC) as efficiency_rank,
                ROW_NUMBER() OVER (ORDER BY avg_overall_sentiment DESC) as satisfaction_rank,

                -- PERCENTAGE OF TOTAL
                ROUND(total_calls * 100.0 / SUM(total_calls) OVER(), 2) as pct_of_total_calls

            FROM aggregated_regional_data
        )

        SELECT
            dimension as {dimension_label},
            total_calls,
            pct_of_total_calls,
            total_agents,
            calls_per_agent,
            avg_handle_time_minutes,
            aht_category,
            avg_complexity,
            avg_transfers,
            avg_customer_sentiment,
            avg_agent_sentiment,
            avg_overall_sentiment,
            sentiment_category,
            total_vehicle_models,
            total_cases,
            total_nps_responses,
            avg_nps_score,
            total_fcr_responses,
            avg_fcr_score,
            total_case_owners,
            total_classifications,
            locations_count,
            locations,
            programs_count,
            avg_performance_coverage_pct,
            avg_sentiment_coverage_pct,
            avg_case_coverage_pct,
            volume_rank,
            efficiency_rank,
            satisfaction_rank

        FROM final_with_rankings
        ORDER BY {sort_clause}
    """

    # Second query: Get top case classifications by dimension
    case_breakdown_query = f"""
        SELECT
            {dimension_clause} as dimension,
            cm.caseclassificationlevel1,
            cm.caseclassificationlevel2,
            COUNT(DISTINCT cm.casenumber) as cases_count,
            ROUND(COUNT(DISTINCT cm.casenumber) * 100.0 / SUM(COUNT(DISTINCT cm.casenumber)) OVER (PARTITION BY {dimension_clause}), 1) as pct_of_dimension_cases
        FROM dwh_prod.ovprod_o.verint_transcription v
        LEFT JOIN text_analytics.nlp_analytics.call_data cd ON v.transaction_id = cd.call_id
        LEFT JOIN text_analytics.nlp_dashboard.case_metadata cm ON cd.casenumber = cm.casenumber
        WHERE {where_clause}
            AND cm.caseclassificationlevel1 IS NOT NULL
        GROUP BY {dimension_clause}, cm.caseclassificationlevel1, cm.caseclassificationlevel2
        HAVING COUNT(DISTINCT cm.casenumber) >= 1
        ORDER BY dimension, cases_count DESC
    """

    with get_connection() as conn:
        with conn.cursor() as cursor:
            # Execute main query
            cursor.execute(query, params)
            rows = cursor.fetchall()
            columns = [d[0] for d in cursor.description]

            result_data = [dict(zip(columns, [serialize(val) for val in row])) for row in rows]

            # Execute case breakdown query
            cursor.execute(case_breakdown_query, params)
            case_rows = cursor.fetchall()
            case_columns = [d[0] for d in cursor.description]

            # Group case classifications by dimension
            from collections import defaultdict
            case_breakdown_by_dimension = defaultdict(list)

            for case_row in case_rows:
                case_dict = dict(zip(case_columns, [serialize(val) for val in case_row]))
                dimension_value = case_dict['dimension']
                if dimension_value:
                    case_breakdown_by_dimension[str(dimension_value)].append({
                        'classification_level1': case_dict['caseclassificationlevel1'],
                        'classification_level2': case_dict['caseclassificationlevel2'],
                        'cases_count': case_dict['cases_count'],
                        'pct_of_dimension_cases': case_dict['pct_of_dimension_cases']
                    })

            # Add case breakdown to each result
            for result in result_data:
                dimension_key = str(result.get(dimension_label, ''))
                result['case_classifications'] = case_breakdown_by_dimension.get(dimension_key, [])[:10]  # Top 10 per dimension

    # Add metadata about the analysis
    metadata = {
        "query_params": {
            "date_range": f"{args.date_from} to {args.date_to}",
            "filters": {
                "region": args.region or "all",
                "location": args.location or "all",
                "brand": args.brand or "all"
            },
            "group_by": args.group_by,
            "min_calls": args.min_calls,
            "sort_by": args.sort_by
        },
        "result_count": len(result_data),
        "total_calls": sum(row.get("total_calls", 0) for row in result_data),
        "data_sources": [
            "dwh_prod.ovprod_o.verint_transcription (primary)",
            "text_analytics.nlp_analytics.call_data (performance metrics)",
            "text_analytics.nlp_analytics.sentiments (quality metrics)",
            "text_analytics.nlp_dashboard.case_metadata (case management)"
        ]
    }

    output = {
        "metadata": metadata,
        "results": result_data
    }

    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)