---
name: regional_analysis
display_name: Enhanced Regional Analysis
description: Analyzes call metrics by actual Ford CRC geographic locations using verint_transcription data. Returns volume, performance, and sentiment metrics across real center locations with data-driven classification.
signals:
  - regional analysis
  - by region
  - by location
  - by country
  - geographic analysis
  - center analysis
  - Houston analysis
  - Melbourne analysis
  - Dearborn analysis
  - Manila analysis
  - Canada analysis
  - Oakville analysis
  - Asheville analysis
  - ford vs lincoln
  - brand analysis
  - lincoln calls
  - ford calls
  - location comparison
  - center performance
  - geographic breakdown
requires:
  - a date range (from and to)
capabilities:
  - Real geographic analysis using actual center_name values
  - Data-driven regional classification (US-South, US-Southeast, US-Midwest, Asia-Pacific, Canada, Corporate)
  - Brand analysis (Ford vs Lincoln with comprehensive model lists)
  - Performance metrics (AHT, complexity, transfers, sentiment)
  - Case management integration (NPS, FCR, case owners, classifications)
  - Multi-source data integration (verint_transcription + call_data + sentiments + case_metadata)
  - Data coverage indicators for transparency
  - Statistical significance filtering
  - Flexible grouping (region, country, location, brand)
not_good_for: Team-specific analysis (use team_volume), individual agent performance, detailed vehicle analysis (use vehicle_agent), deep sentiment trends (use sentiment_agent)
---

# Enhanced Regional Analysis

## What this script does
Provides comprehensive geographic analysis using Ford's actual CRC locations from verint_transcription. Combines volume metrics with performance data and sentiment analysis across real Ford locations with data-driven regional classification.

## How to run it

```bash
python .claude/skills/regional_analysis/scripts/regional_analysis.py --from 2026-01-01 --to 2026-01-31
```

## Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--from` | Yes | — | Start date YYYY-MM-DD |
| `--to` | Yes | — | End date YYYY-MM-DD |
| `--region` | No | all | Filter by region (US-South, US-Southeast, etc.) |
| `--location` | No | all | Filter by specific center/location |
| `--brand` | No | all | Filter by brand: `ford`, `lincoln` |
| `--group-by` | No | `region` | Group by: `region`, `country`, `location`, `brand` |
| `--min-calls` | No | `100` | Minimum calls for statistical significance |
| `--sort-by` | No | `volume` | Sort by: `volume`, `aht`, `sentiment` |

## Example calls

```bash
# Overall regional breakdown
python .claude/skills/regional_analysis/scripts/regional_analysis.py --from 2026-01-01 --to 2026-01-31

# US Southeast region analysis
python .claude/skills/regional_analysis/scripts/regional_analysis.py --from 2026-01-01 --to 2026-01-31 --region US-Southeast

# Houston location specific analysis
python .claude/skills/regional_analysis/scripts/regional_analysis.py --from 2026-01-01 --to 2026-01-31 --location Houston

# Country-level breakdown
python .claude/skills/regional_analysis/scripts/regional_analysis.py --from 2026-01-01 --to 2026-01-31 --group-by country

# Lincoln brand across all locations
python .claude/skills/regional_analysis/scripts/regional_analysis.py --from 2026-01-01 --to 2026-01-31 --brand lincoln

# All locations with performance focus
python .claude/skills/regional_analysis/scripts/regional_analysis.py --from 2026-01-01 --to 2026-01-31 --group-by location --sort-by aht

# Brand comparison
python .claude/skills/regional_analysis/scripts/regional_analysis.py --from 2026-01-01 --to 2026-01-31 --group-by brand

# Manila operations analysis
python .claude/skills/regional_analysis/scripts/regional_analysis.py --from 2026-01-01 --to 2026-01-31 --location Manila

# High-volume locations only
python .claude/skills/regional_analysis/scripts/regional_analysis.py --from 2026-01-01 --to 2026-01-31 --min-calls 1000
```

## Output format

```json
{
  "metadata": {
    "query_params": {
      "date_range": "2026-01-01 to 2026-01-31",
      "filters": {
        "region": "US-Southeast",
        "location": "all",
        "brand": "all"
      },
      "group_by": "region",
      "min_calls": 100,
      "sort_by": "volume"
    },
    "result_count": 6,
    "total_calls": 2845230,
    "data_sources": [
      "dwh_prod.ovprod_o.verint_transcription (primary)",
      "text_analytics.nlp_analytics.call_data (performance metrics)",
      "text_analytics.nlp_analytics.sentiments (quality metrics)"
    ]
  },
  "results": [
    {
      "region": "US-South",
      "total_calls": 2042259,
      "pct_of_total_calls": 71.8,
      "total_agents": 1245,
      "calls_per_agent": 1640.2,
      "avg_handle_time_minutes": 12.8,
      "aht_category": "Average",
      "avg_complexity": 15.2,
      "avg_transfers": 0.82,
      "avg_customer_sentiment": 0.445,
      "avg_agent_sentiment": 0.521,
      "avg_overall_sentiment": 0.483,
      "sentiment_category": "Neutral",
      "total_vehicle_models": 89,
      "locations_count": 1,
      "locations": ["Houston, TX, US"],
      "programs_count": 15,
      "avg_performance_coverage_pct": 78.5,
      "avg_sentiment_coverage_pct": 99.2,
      "volume_rank": 1,
      "efficiency_rank": 3,
      "satisfaction_rank": 4
    }
  ]
}
```

## Key Features

### Data-Driven Geographic Classification
- **US-South**: Houston, TX, US (2.0M+ calls)
- **US-Southeast**: Melbourne, FL, US + Asheville, NC, US (1.7M+ calls)
- **US-Midwest**: Dearborn, MI, US (967K+ calls)  
- **Asia-Pacific**: Manila, PH (33K+ calls)
- **Canada**: Oakville, ON, CA (12K+ calls)
- **Corporate**: IPCC locations

### Performance Metrics
- **Volume**: Total calls, percentage distribution, agents, capacity utilization
- **Efficiency**: AHT with categorization, complexity scoring, transfer rates
- **Quality**: Customer/agent/overall sentiment from dedicated sentiments table
- **Diversity**: Vehicle model counts, program counts, location counts

### Data Integration & Quality
- **Primary Source**: verint_transcription (5M+ records, most complete)
- **Performance Data**: call_data joins (70-80% coverage typically)
- **Sentiment Data**: sentiments table (99%+ coverage - highly reliable)
- **Case Management**: case_metadata joins (NPS, FCR, classifications, owners)
- **Coverage Indicators**: Shows data availability percentages for transparency

### Statistical Significance
- **Minimum thresholds**: Configurable minimum call counts for inclusion
- **Rankings**: Volume, efficiency, and satisfaction rankings for easy comparison
- **Categories**: AHT and sentiment categorization for quick insights

## Actual Ford CRC Locations (Based on Real Data)
1. **Houston, TX, US** - 2,042,259 calls (71.8% of total volume)
2. **Melbourne, FL, US** - 1,630,288 calls (57.3% of total volume)
3. **Dearborn, MI, US** - 967,881 calls (34.0% of total volume)
4. **Asheville, NC, US** - 125,257 calls (4.4% of total volume)
5. **Manila, PH** - 33,488 calls (1.2% of total volume)
6. **Oakville, ON, CA** - 11,827 calls (0.4% of total volume)
7. **Melbourne** - 120 calls (alternative location)
8. **IPCC** - 2 calls (corporate/internal)

## Brand Analysis
- **Lincoln Models**: NAVIGATOR, AVIATOR, NAUTILUS, CORSAIR, CONTINENTAL, MKX, MKZ, MKC, MKS, MKT, TOWN CAR, ZEPHYR, plus historical models
- **Ford Models**: All other vehicle models (F-SERIES, ESCAPE, EXPLORER, MUSTANG MACH-E, BRONCO, etc.)

## Use Cases

### Geographic Operations Analysis
- "How do Houston and Melbourne compare?"
- "Which region has the best AHT?"
- "Manila operations performance review"

### Brand Performance Analysis  
- "Lincoln calls across all locations"
- "Ford vs Lincoln regional breakdown"
- "Brand satisfaction by location"

### Location Planning
- "Highest volume locations needing resources"
- "Cross-location performance benchmarking"
- "Regional capacity utilization analysis"

### Quality Analysis
- "Which locations have best customer satisfaction?"
- "Sentiment performance by region"
- "Transfer rates across locations"

## Error output
If something goes wrong, the script prints `{"error": "..."}` to stderr and exits with code 1.

## Data Sources & Join Strategy
- **Primary**: dwh_prod.ovprod_o.verint_transcription (organizational data)
- **Performance**: text_analytics.nlp_analytics.call_data (AHT, complexity, transfers)
- **Quality**: text_analytics.nlp_analytics.sentiments (customer satisfaction)
- **Join Method**: verint_transcription.transaction_id -> call_data.call_id / sentiments.call_id

## Notes
- Uses actual Ford CRC locations from database, not hardcoded assumptions
- Performance data coverage varies by location (shown in coverage percentages)
- Sentiment data has excellent coverage (99%+) from dedicated sentiments table
- Minimum call thresholds ensure statistical significance
- Rankings provide easy cross-location comparison
- Regional classification is based on actual geographic patterns in the data