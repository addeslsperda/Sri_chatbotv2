"""
Comprehensive Data Discovery & Coverage Analysis
===============================================

Discovers data availability across ALL Ford database tables including verint_transcription,
call_data, call_table, models, sentiments, parts_unfiltered, embedding tables, topic hierarchy,
case_metadata, and more. Provides complete coverage statistics and data quality assessment.

Usage:
    python data_discovery.py
    python data_discovery.py --check coverage --detailed
    python data_discovery.py --table verint_transcription
    python data_discovery.py --check quality --detailed

Output: Comprehensive JSON with complete ecosystem data discovery
"""
import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path
from databricks import sql
import requests
from dotenv import load_dotenv
from decimal import Decimal

load_dotenv(Path(__file__).resolve().parents[5] / ".env", override=True)

def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]

def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )

def serialize(v):
    """Convert various types to JSON-serializable format"""
    if isinstance(v, Decimal):
        return float(v)
    if hasattr(v, "isoformat"):
        return str(v)
    return v

# === COMPREHENSIVE TABLE CONFIGURATION ===
TABLE_DEFINITIONS = {
    "call_data": {
        "catalog": "text_analytics",
        "schema": "nlp_analytics",
        "full_name": "text_analytics.nlp_analytics.call_data",
        "description": "Primary call center data with VIN, vehicle, and core call information",
        "key_columns": ["call_id", "call_date", "vin", "modelvehicleline"]
    },
    "verint_transcription": {
        "catalog": "dwh_prod",
        "schema": "ovprod_o",
        "full_name": "dwh_prod.ovprod_o.verint_transcription",
        "description": "Operations transcription data with CRC locations and agent metadata",
        "key_columns": ["transaction_id", "callguid", "call_duration", "prw_name", "sow_name"]
    },
    "call_table": {
        "catalog": "text_analytics",
        "schema": "nlp_analytics",
        "full_name": "text_analytics.nlp_analytics.call_table",
        "description": "Extended call metadata with transcripts and agent teams",
        "key_columns": ["call_id", "transcript", "agent_team", "summary"]
    },
    "sentiments": {
        "catalog": "text_analytics",
        "schema": "nlp_analytics",
        "full_name": "text_analytics.nlp_analytics.sentiments",
        "description": "Sentiment analysis with customer/agent emotion tracking",
        "key_columns": ["call_id", "customer_sentiment", "agent_sentiment", "overall_sentiment"]
    },
    "models": {
        "catalog": "text_analytics",
        "schema": "nlp_analytics",
        "full_name": "text_analytics.nlp_analytics.models",
        "description": "Vehicle intelligence with complete model and year data",
        "key_columns": ["call_id", "ModelVehicleLine", "Model_Year"]
    },
    "call_summary_qwen06b": {
        "catalog": "text_analytics",
        "schema": "nlp_agent",
        "full_name": "text_analytics.nlp_agent.call_summary_qwen06b",
        "description": "Qwen 0.6B semantic embeddings for call summaries",
        "key_columns": ["call_id", "embeddings", "summary", "call_date"]
    },
    "topic_detail": {
        "catalog": "text_analytics",
        "schema": "nlp_configs",
        "full_name": "text_analytics.nlp_configs.topic_detail",
        "description": "3-level topic hierarchy and categorization",
        "key_columns": ["topic_id", "topic_level1", "topic_level2", "topic_level3"]
    },
    "topic_xwalk": {
        "catalog": "text_analytics",
        "schema": "nlp_analytics",
        "full_name": "text_analytics.nlp_analytics.topic_xwalk",
        "description": "Topic classification crosswalk linking calls to topics",
        "key_columns": ["call_id", "topic_id"]
    },
    "parts_unfiltered": {
        "catalog": "text_analytics",
        "schema": "nlp_analytics",
        "full_name": "text_analytics.nlp_analytics.parts_unfiltered",
        "description": "Parts and component analysis data",
        "key_columns": ["call_id", "parts_features", "parts_concern"]
    },
    "case_metadata": {
        "catalog": "text_analytics",
        "schema": "nlp_dashboard",
        "full_name": "text_analytics.nlp_dashboard.case_metadata",
        "description": "Business case classification and metadata",
        "key_columns": ["casenumber", "caseclassificationlevel1", "caseclassificationlevel2", "vin"]
    }
}

def analyze_table_coverage(table_name, table_info, conn, detailed=False):
    """Analyze individual table coverage and metrics"""
    print(f"Analyzing {table_name}...", file=sys.stderr)

    try:
        with conn.cursor() as cursor:
            # Basic record count and date range
            if table_name == "topic_detail":
                # Topic detail doesn't have call_date
                cursor.execute(f"""
                    SELECT COUNT(*) as record_count
                    FROM {table_info['full_name']}
                """)
                row = cursor.fetchone()
                result = {
                    "catalog": table_info["catalog"],
                    "schema": table_info["schema"],
                    "record_count": int(row[0]),
                    "date_range": "N/A - Configuration table",
                    "data_quality": "excellent"
                }

                # Get topic hierarchy metrics
                if detailed:
                    cursor.execute(f"""
                        SELECT
                            COUNT(DISTINCT topic_level1) as level1_count,
                            COUNT(DISTINCT topic_level2) as level2_count,
                            COUNT(DISTINCT topic_level3) as level3_count
                        FROM {table_info['full_name']}
                    """)
                    topic_row = cursor.fetchone()
                    result["key_metrics"] = {
                        "topic_hierarchy_levels": 3,
                        "level1_categories": int(topic_row[0]) if topic_row[0] else 0,
                        "level2_categories": int(topic_row[1]) if topic_row[1] else 0,
                        "level3_categories": int(topic_row[2]) if topic_row[2] else 0
                    }

            elif table_name == "verint_transcription":
                # Verint table has different structure - no call_date
                cursor.execute(f"""
                    SELECT COUNT(*) as record_count
                    FROM {table_info['full_name']}
                """)
                row = cursor.fetchone()
                result = {
                    "catalog": table_info["catalog"],
                    "schema": table_info["schema"],
                    "record_count": int(row[0]),
                    "date_range": "N/A - No date column",
                    "data_quality": "good"
                }

                # Get verint-specific metrics
                if detailed:
                    cursor.execute(f"""
                        SELECT
                            COUNT(*) as total,
                            COUNT(DISTINCT prw_name) as prw_locations,
                            COUNT(DISTINCT sow_name) as sow_categories,
                            AVG(call_duration) as avg_duration
                        FROM {table_info['full_name']}
                    """)
                    verint_row = cursor.fetchone()
                    result["key_metrics"] = {
                        "unique_prw_locations": int(verint_row[1]) if verint_row[1] else 0,
                        "unique_sow_categories": int(verint_row[2]) if verint_row[2] else 0,
                        "avg_call_duration": round(float(verint_row[3]), 2) if verint_row[3] else 0
                    }

            elif "call_date" in table_info["key_columns"]:
                cursor.execute(f"""
                    SELECT
                        COUNT(*) as record_count,
                        DATE(MIN(call_date)) as min_date,
                        DATE(MAX(call_date)) as max_date
                    FROM {table_info['full_name']}
                """)
                row = cursor.fetchone()
                result = {
                    "catalog": table_info["catalog"],
                    "schema": table_info["schema"],
                    "record_count": int(row[0]),
                    "date_range": {
                        "min_date": str(row[1]) if row[1] else None,
                        "max_date": str(row[2]) if row[2] else None
                    },
                    "data_quality": "good"
                }
            else:
                # Tables without call_date (like case_metadata)
                cursor.execute(f"""
                    SELECT COUNT(*) as record_count
                    FROM {table_info['full_name']}
                """)
                row = cursor.fetchone()
                result = {
                    "catalog": table_info["catalog"],
                    "schema": table_info["schema"],
                    "record_count": int(row[0]),
                    "date_range": "N/A - Metadata table",
                    "data_quality": "good"
                }

            # Add detailed metrics if requested
            if detailed:
                result["description"] = table_info["description"]
                result["key_columns"] = table_info["key_columns"]

                # Table-specific detailed metrics
                if table_name == "call_data":
                    cursor.execute(f"""
                        SELECT
                            COUNT(*) as total,
                            COUNT(vin) as has_vin,
                            COUNT(modelvehicleline) as has_vehicle,
                            COUNT(vin) * 100.0 / COUNT(*) as vin_pct,
                            COUNT(modelvehicleline) * 100.0 / COUNT(*) as vehicle_pct
                        FROM {table_info['full_name']}
                    """)
                    metrics_row = cursor.fetchone()
                    result["key_metrics"] = {
                        "vin_coverage": f"{float(metrics_row[3]):.1f}%" if metrics_row[3] else "0%",
                        "vehicle_coverage": f"{float(metrics_row[4]):.1f}%" if metrics_row[4] else "0%",
                        "total_records": int(metrics_row[0])
                    }

                elif table_name == "verint_transcription":
                    # Skip detailed metrics in this section since it's handled above
                    pass

                elif table_name == "sentiments":
                    cursor.execute(f"""
                        SELECT
                            COUNT(*) as total,
                            COUNT(customer_sentiment) as has_customer,
                            COUNT(agent_sentiment) as has_agent,
                            COUNT(customer_sentiment) * 100.0 / COUNT(*) as customer_pct,
                            COUNT(agent_sentiment) * 100.0 / COUNT(*) as agent_pct
                        FROM {table_info['full_name']}
                    """)
                    metrics_row = cursor.fetchone()
                    result["key_metrics"] = {
                        "customer_sentiment_coverage": f"{float(metrics_row[3]):.1f}%" if metrics_row[3] else "0%",
                        "agent_sentiment_coverage": f"{float(metrics_row[4]):.1f}%" if metrics_row[4] else "0%"
                    }

                elif table_name == "call_summary_qwen06b":
                    cursor.execute(f"""
                        SELECT
                            COUNT(*) as total,
                            COUNT(embeddings) as has_embeddings,
                            COUNT(summary) as has_summary,
                            COUNT(embeddings) * 100.0 / COUNT(*) as embedding_pct
                        FROM {table_info['full_name']}
                    """)
                    metrics_row = cursor.fetchone()
                    result["key_metrics"] = {
                        "embedding_coverage": f"{float(metrics_row[3]):.1f}%" if metrics_row[3] else "0%",
                        "embedding_dimension": 1024,
                        "summary_coverage": f"{int(metrics_row[2])/int(metrics_row[0])*100:.1f}%" if metrics_row[0] and metrics_row[2] else "0%"
                    }

            return result

    except Exception as e:
        print(f"Error analyzing {table_name}: {e}", file=sys.stderr)
        return {
            "catalog": table_info["catalog"],
            "schema": table_info["schema"],
            "record_count": 0,
            "date_range": "Error",
            "data_quality": "unavailable",
            "error": str(e)
        }

def analyze_cross_table_coverage(conn):
    """Analyze coverage relationships between tables"""
    print("Analyzing cross-table coverage...", file=sys.stderr)

    cross_analysis = {}

    try:
        with conn.cursor() as cursor:
            # Get call_data baseline
            cursor.execute("""
                SELECT COUNT(*) FROM text_analytics.nlp_analytics.call_data
            """)
            call_data_total = cursor.fetchone()[0]

            # Test major joins
            join_tests = {
                "call_data_to_sentiments": """
                    SELECT COUNT(DISTINCT cd.call_id)
                    FROM text_analytics.nlp_analytics.call_data cd
                    INNER JOIN text_analytics.nlp_analytics.sentiments s ON cd.call_id = s.call_id
                """,
                "call_data_to_call_table": """
                    SELECT COUNT(DISTINCT cd.call_id)
                    FROM text_analytics.nlp_analytics.call_data cd
                    INNER JOIN text_analytics.nlp_analytics.call_table ct ON cd.call_id = ct.call_id
                """,
                "call_data_to_models": """
                    SELECT COUNT(DISTINCT cd.call_id)
                    FROM text_analytics.nlp_analytics.call_data cd
                    INNER JOIN text_analytics.nlp_analytics.models m ON cd.call_id = m.call_id
                """,
                "call_data_to_embeddings": """
                    SELECT COUNT(DISTINCT cd.call_id)
                    FROM text_analytics.nlp_analytics.call_data cd
                    INNER JOIN text_analytics.nlp_agent.call_summary_qwen06b e ON cd.call_id = e.call_id
                """,
                "call_data_to_topics": """
                    SELECT COUNT(DISTINCT cd.call_id)
                    FROM text_analytics.nlp_analytics.call_data cd
                    INNER JOIN text_analytics.nlp_analytics.topic_xwalk tx ON cd.call_id = tx.call_id
                """,
                "call_data_to_parts": """
                    SELECT COUNT(DISTINCT cd.call_id)
                    FROM text_analytics.nlp_analytics.call_data cd
                    INNER JOIN text_analytics.nlp_analytics.parts_unfiltered pf ON cd.call_id = pf.call_id
                """
            }

            join_success_rates = {}
            for join_name, query in join_tests.items():
                try:
                    cursor.execute(query)
                    join_count = cursor.fetchone()[0]
                    success_rate = (join_count / call_data_total * 100) if call_data_total > 0 else 0
                    join_success_rates[join_name] = f"{success_rate:.1f}%"
                except Exception as e:
                    join_success_rates[join_name] = f"Error: {str(e)}"

            cross_analysis = {
                "join_success_rates": join_success_rates,
                "baseline_records": call_data_total,
                "data_completeness_score": f"{sum(float(rate.replace('%', '')) for rate in join_success_rates.values() if '%' in rate) / len(join_success_rates):.1f}%"
            }

    except Exception as e:
        cross_analysis = {"error": f"Cross-table analysis failed: {str(e)}"}

    return cross_analysis

def get_comprehensive_vehicle_analysis(conn):
    """Get comprehensive vehicle analysis across multiple tables"""
    print("Analyzing vehicle coverage across tables...", file=sys.stderr)

    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT
                    cd.modelvehicleline,
                    COUNT(*) as call_data_count,
                    COUNT(DISTINCT s.call_id) as sentiments_count,
                    COUNT(DISTINCT m.call_id) as models_count,
                    COUNT(DISTINCT ct.call_id) as call_table_count
                FROM text_analytics.nlp_analytics.call_data cd
                LEFT JOIN text_analytics.nlp_analytics.sentiments s ON cd.call_id = s.call_id
                LEFT JOIN text_analytics.nlp_analytics.models m ON cd.call_id = m.call_id
                LEFT JOIN text_analytics.nlp_analytics.call_table ct ON cd.call_id = ct.call_id
                WHERE cd.modelvehicleline IS NOT NULL
                GROUP BY cd.modelvehicleline
                ORDER BY call_data_count DESC
                LIMIT 20
            """)

            vehicles = []
            for row in cursor.fetchall():
                vehicles.append({
                    "modelvehicleline": row[0],
                    "call_count": int(row[1]),
                    "data_sources": {
                        "call_data": int(row[1]),
                        "sentiments": int(row[2]) if row[2] else 0,
                        "models": int(row[3]) if row[3] else 0,
                        "call_table": int(row[4]) if row[4] else 0
                    }
                })
            return vehicles

    except Exception as e:
        print(f"Vehicle analysis error: {e}", file=sys.stderr)
        return []

def main():
    parser = argparse.ArgumentParser(description="Comprehensive Data Discovery & Coverage Analysis")
    parser.add_argument("--check", choices=["all", "dates", "vehicles", "coverage", "quality"],
                       default="all", help="What to check")
    parser.add_argument("--detailed", action="store_true", help="Include detailed metrics")
    parser.add_argument("--table", help="Focus on specific table")
    args, _ = parser.parse_known_args()

    result = {
        "discovery_timestamp": datetime.now().isoformat(),
        "database_overview": {},
        "table_coverage": {},
    }

    with get_connection() as conn:

        # Determine which tables to analyze
        tables_to_analyze = TABLE_DEFINITIONS
        if args.table and args.table != "all":
            if args.table in TABLE_DEFINITIONS:
                tables_to_analyze = {args.table: TABLE_DEFINITIONS[args.table]}
            else:
                print(json.dumps({"error": f"Unknown table: {args.table}"}), file=sys.stderr)
                sys.exit(1)

        # Analyze each table
        if args.check in ("all", "coverage", "quality"):
            total_records = 0
            tables_analyzed = 0

            for table_name, table_info in tables_to_analyze.items():
                coverage = analyze_table_coverage(table_name, table_info, conn, args.detailed)
                result["table_coverage"][table_name] = coverage

                if coverage.get("record_count", 0) > 0:
                    total_records += coverage["record_count"]
                    tables_analyzed += 1

            result["database_overview"] = {
                "total_tables_analyzed": tables_analyzed,
                "total_records": total_records
            }

        # Vehicle analysis
        if args.check in ("all", "vehicles"):
            result["vehicle_analysis"] = get_comprehensive_vehicle_analysis(conn)

        # Cross-table analysis
        if args.check in ("all", "coverage", "quality"):
            result["cross_table_analysis"] = analyze_cross_table_coverage(conn)

        # Add recommendations for quality check
        if args.check in ("all", "quality"):
            result["recommendations"] = {
                "primary_tables": [
                    "call_data + sentiments + call_table for core analysis (99%+ coverage)",
                    "topic classification via topic_xwalk for categorization",
                    "verint_transcription for operational intelligence"
                ],
                "secondary_tables": [
                    "models for vehicle intelligence (when available)",
                    "case_metadata for business classification (moderate coverage)"
                ],
                "avoid_for_comprehensive_analysis": [
                    "call_summary_qwen06b (embedding coverage gaps)",
                    "parts_unfiltered (limited coverage)"
                ]
            }

    print(json.dumps(result, indent=2, default=serialize))

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(json.dumps({"error": f"Data discovery failed: {str(e)}"}), file=sys.stderr)
        sys.exit(1)