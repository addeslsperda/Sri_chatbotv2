---
name: data_discovery
display_name: Comprehensive Data Discovery & Coverage Analysis
description: Comprehensive data discovery across ALL Ford database tables including verint_transcription, call_data, call_table, models, sentiments, parts_unfiltered, embedding tables, topic hierarchy, case_metadata, and more. Provides complete date ranges, record counts, coverage statistics, and data quality assessment. Always use this FIRST when troubleshooting data issues or validating data availability across the entire ecosystem.
signals:
  - what data do you have
  - data availability
  - what date range
  - what vehicles are available
  - no results
  - check available data
  - what is in the database
  - latest date
  - earliest date
  - data coverage
  - table coverage
  - record counts
  - data quality check
  - verint transcription data
  - embedding coverage
  - topic data availability
  - parts data coverage
requires: []
not_good_for: Actual analysis — use this only to discover what data exists and assess coverage before running analytical skills
---

# Comprehensive Data Discovery & Coverage Analysis

## What this script does
Performs comprehensive data discovery across ALL Ford database tables and schemas. Returns date ranges, record counts, coverage statistics, and data quality assessment for the complete Ford data ecosystem including operations data (verint_transcription), call center data, vehicle intelligence, semantic embeddings, topic classifications, and business metadata.

## Enhanced Coverage
- **Operations Data**: `verint_transcription` table with CRC location and operational metadata  
- **Core Call Data**: `call_data` and `call_table` with complete call information
- **Vehicle Intelligence**: `models` table with comprehensive vehicle data
- **Semantic Data**: `call_summary_qwen06b` embedding table coverage
- **Sentiment Analysis**: `sentiments` table with emotion tracking
- **Topic Classification**: `topic_detail` and `topic_xwalk` hierarchy coverage
- **Parts Intelligence**: `parts_unfiltered` component analysis data
- **Business Metadata**: `case_metadata` classification coverage
- **Cross-Table Analysis**: Coverage overlap and join success rates

## How to run it

```bash
# Complete data discovery (recommended)
python .claude/skills/data_discovery/scripts/data_discovery.py

# Specific data checks
python .claude/skills/data_discovery/scripts/data_discovery.py --check dates
python .claude/skills/data_discovery/scripts/data_discovery.py --check vehicles  
python .claude/skills/data_discovery/scripts/data_discovery.py --check coverage
```

## Enhanced Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--check` | No | `all` | `all`, `dates`, `vehicles`, `coverage`, `quality` |
| `--detailed` | No | `false` | Include detailed coverage statistics and quality metrics |
| `--table` | No | `all` | Focus on specific table: `call_data`, `verint`, `models`, `sentiments`, etc. |

## Example Usage

```bash
# Comprehensive data discovery
python data_discovery.py

# Check only date ranges across all tables
python data_discovery.py --check dates

# Vehicle availability analysis
python data_discovery.py --check vehicles

# Data coverage assessment
python data_discovery.py --check coverage --detailed

# Data quality analysis
python data_discovery.py --check quality --detailed

# Focus on specific table
python data_discovery.py --table verint_transcription

# Focus on embedding coverage
python data_discovery.py --table embeddings --detailed
```

## Comprehensive Output Format

```json
{
  "discovery_timestamp": "2026-09-25T14:30:00Z",
  "database_overview": {
    "total_tables_analyzed": 9,
    "primary_date_range": {
      "min_date": "2023-01-01",
      "max_date": "2024-12-31",
      "total_days": 730
    },
    "total_records": 5673421,
    "data_health": "excellent"
  },
  "table_coverage": {
    "call_data": {
      "catalog": "text_analytics",
      "schema": "nlp_analytics", 
      "record_count": 3654887,
      "date_range": {
        "min_date": "2023-01-01",
        "max_date": "2024-12-31"
      },
      "key_metrics": {
        "vin_coverage": "17.9%",
        "vehicle_coverage": "18.2%",
        "sentiment_coverage": "99.8%"
      },
      "data_quality": "good"
    },
    "verint_transcription": {
      "catalog": "dwh_prod",
      "schema": "ovprod_o",
      "record_count": 156432,
      "date_range": {
        "min_date": "2024-06-01", 
        "max_date": "2024-12-31"
      },
      "key_metrics": {
        "location_coverage": "100%",
        "agent_coverage": "95.2%",
        "transcript_coverage": "89.1%"
      },
      "data_quality": "excellent"
    },
    "call_table": {
      "catalog": "text_analytics",
      "schema": "nlp_analytics",
      "record_count": 3654887,
      "coverage_vs_call_data": "100%",
      "key_metrics": {
        "transcript_coverage": "100%",
        "agent_team_coverage": "98.7%",
        "summary_coverage": "85.3%"
      },
      "data_quality": "excellent"
    },
    "sentiments": {
      "catalog": "text_analytics", 
      "schema": "nlp_analytics",
      "record_count": 3648291,
      "coverage_vs_call_data": "99.8%",
      "key_metrics": {
        "customer_sentiment_coverage": "99.8%",
        "agent_sentiment_coverage": "99.7%",
        "sentiment_journey_coverage": "95.2%"
      },
      "data_quality": "excellent"
    },
    "models": {
      "catalog": "text_analytics",
      "schema": "nlp_analytics", 
      "record_count": 2643592,
      "coverage_vs_call_data": "72.3%",
      "key_metrics": {
        "vehicle_line_coverage": "100%",
        "model_year_coverage": "99.9%",
        "complete_vehicle_data": "100%"
      },
      "data_quality": "excellent"
    },
    "call_summary_qwen06b": {
      "catalog": "text_analytics",
      "schema": "nlp_agent",
      "record_count": 1876543,
      "coverage_vs_call_data": "51.3%",
      "key_metrics": {
        "embedding_coverage": "51.3%",
        "summary_coverage": "48.9%",
        "embedding_dimension": 1024
      },
      "data_quality": "good"
    },
    "topic_detail": {
      "catalog": "text_analytics",
      "schema": "nlp_configs",
      "record_count": 2847,
      "key_metrics": {
        "topic_hierarchy_levels": 3,
        "topic_categories": 147,
        "coverage_via_xwalk": "89.2%"
      },
      "data_quality": "excellent"
    },
    "parts_unfiltered": {
      "catalog": "text_analytics",
      "schema": "nlp_analytics",
      "record_count": 987654,
      "coverage_vs_call_data": "27.0%",
      "key_metrics": {
        "parts_features_coverage": "27.0%",
        "parts_concern_coverage": "25.8%",
        "component_categories": 234
      },
      "data_quality": "moderate"
    },
    "case_metadata": {
      "catalog": "text_analytics",
      "schema": "nlp_dashboard", 
      "record_count": 1460517,
      "coverage_vs_call_data": "39.9%",
      "key_metrics": {
        "case_classification_coverage": "39.9%",
        "vin_coverage": "44.8%",
        "business_classification_levels": 3
      },
      "data_quality": "good"
    }
  },
  "vehicle_analysis": [
    {
      "modelvehicleline": "F-SERIES",
      "call_count": 892341,
      "pct_of_total": 24.4,
      "date_range": "2023-01-01 to 2024-12-31",
      "data_sources": {
        "call_data": 892341,
        "models": 634521, 
        "sentiments": 891203,
        "verint": 23451
      }
    },
    {
      "modelvehicleline": "MUSTANG MACH-E", 
      "call_count": 456789,
      "pct_of_total": 12.5,
      "date_range": "2023-01-01 to 2024-12-31",
      "data_sources": {
        "call_data": 456789,
        "models": 324567,
        "sentiments": 456123,
        "verint": 12345
      }
    }
  ],
  "cross_table_analysis": {
    "join_success_rates": {
      "call_data_to_sentiments": "99.8%",
      "call_data_to_call_table": "100%", 
      "call_data_to_models": "72.3%",
      "call_data_to_embeddings": "51.3%",
      "call_data_to_topics": "89.2%",
      "call_data_to_parts": "27.0%",
      "call_data_to_case_metadata": "39.9%"
    },
    "data_completeness_score": "78.4%",
    "recommended_primary_tables": [
      "call_data + sentiments + call_table (99.8%+ coverage)",
      "topic classification via topic_xwalk (89.2% coverage)", 
      "models for vehicle intelligence (72.3% coverage)"
    ],
    "avoid_for_primary_analysis": [
      "parts_unfiltered (27% coverage)",
      "embedding_table (51.3% coverage - gaps in recent data)",
      "case_metadata (39.9% coverage)"
    ]
  },
  "data_quality_assessment": {
    "overall_score": 8.2,
    "strengths": [
      "Excellent call_data + sentiments + call_table coverage (99.8%+)",
      "Complete topic classification hierarchy (89.2% coverage)",
      "Strong vehicle intelligence via models table (72.3%)",
      "Comprehensive verint operational data (100% location coverage)"
    ],
    "limitations": [
      "Embedding coverage gaps for recent data (51.3%)", 
      "Limited parts intelligence coverage (27%)",
      "Moderate case metadata coverage (39.9%)",
      "VIN data limited to 17.9% of calls"
    ],
    "recommendations": [
      "Use call_data + sentiments + call_table as primary foundation",
      "Leverage topic classification for comprehensive categorization",
      "Include verint_transcription for operational intelligence",
      "Use models table for vehicle correlation when available",
      "Avoid relying on parts/embedding tables for comprehensive analysis"
    ]
  },
  "operational_insights": {
    "peak_data_periods": [
      {"period": "2024-08-01 to 2024-08-31", "records": 389234, "note": "Highest volume month"},
      {"period": "2024-12-01 to 2024-12-31", "records": 356789, "note": "Recent complete data"}
    ],
    "data_gaps": [
      {"table": "call_summary_qwen06b", "gap": "2024-09-15 to 2024-12-31", "impact": "No semantic search for recent calls"},
      {"table": "parts_unfiltered", "coverage": "27%", "impact": "Limited component analysis"}
    ],
    "optimal_analysis_windows": [
      {"period": "2024-01-01 to 2024-08-31", "coverage": "95%+", "note": "Best for comprehensive analysis"},
      {"period": "2023-01-01 to 2024-12-31", "coverage": "85%+", "note": "Good for trend analysis"}
    ]
  }
}
```

## Advanced Features

### Comprehensive Table Coverage
- **Primary Data Sources**: call_data, call_table, sentiments (99.8%+ coverage)
- **Operational Intelligence**: verint_transcription with CRC locations and agent data
- **Semantic Intelligence**: call_summary_qwen06b embedding coverage assessment
- **Vehicle Intelligence**: models table with complete vehicle correlation
- **Topic Intelligence**: topic_detail + topic_xwalk hierarchy coverage
- **Parts Intelligence**: parts_unfiltered component analysis coverage
- **Business Intelligence**: case_metadata classification coverage

### Cross-Table Analysis
- **Join Success Rates**: Measure data overlap between all major tables
- **Coverage Assessment**: Identify which tables provide complete vs. partial coverage
- **Data Completeness Scoring**: Overall ecosystem health measurement
- **Optimal Analysis Windows**: Identify best periods for comprehensive analysis

### Data Quality Intelligence
- **Coverage Gaps**: Identify missing data periods and tables
- **Recommendations**: Suggest optimal table combinations for different analysis types
- **Limitations Assessment**: Clear guidance on what data is/isn't available
- **Operational Insights**: Peak periods, data gaps, and optimal analysis windows

## Use Cases

### Pre-Analysis Data Validation
- **"What data is available for Q3 2024?"** - Complete ecosystem availability check
- **"Can I do semantic analysis for recent calls?"** - Embedding table coverage assessment
- **"Which vehicles have complete data coverage?"** - Vehicle-specific data assessment

### Troubleshooting Data Issues  
- **"Why am I getting no results?"** - Comprehensive coverage and gap identification
- **"What's the best date range for analysis?"** - Optimal analysis window recommendations
- **"Which tables should I use for comprehensive analysis?"** - Data source recommendations

### System Architecture Planning
- **"What's our data completeness across all tables?"** - Ecosystem health assessment
- **"Where are the gaps in our data pipeline?"** - Coverage gap analysis
- **"What's the best approach for multi-table analysis?"** - Join success rate guidance

### Operations Intelligence
- **"What operational data do we have from verint?"** - CRC operations data discovery
- **"How complete is our vehicle intelligence?"** - Models table coverage assessment  
- **"What's our semantic search capability?"** - Embedding coverage analysis

## Business Value
Comprehensive data_discovery provides strategic data intelligence for:
- **Analysis Planning**: Understand data availability before starting complex analysis
- **System Optimization**: Identify data pipeline gaps and optimization opportunities  
- **Quality Management**: Monitor data completeness and quality across the ecosystem
- **Troubleshooting**: Quickly diagnose data availability issues and coverage gaps
- **Architecture Planning**: Make informed decisions about which tables to use for different analysis types

## Technical Features

### Multi-Schema Coverage
- **text_analytics.nlp_analytics**: Primary call center and analytics data
- **text_analytics.nlp_agent**: Semantic embeddings and AI-generated content
- **text_analytics.nlp_configs**: Configuration and topic hierarchy data
- **text_analytics.nlp_dashboard**: Business intelligence and case metadata
- **dwh_prod.ovprod_o**: Operations data warehouse with verint transcription

### Comprehensive Metrics
- **Record Counts**: Total records across all major tables
- **Date Ranges**: Min/max dates for temporal analysis planning
- **Coverage Percentages**: Cross-table join success rates and data overlap
- **Quality Scoring**: Data completeness and reliability assessment

### Production-Ready Features
- **Fast Execution**: Optimized queries for quick data discovery
- **Comprehensive Logging**: Detailed progress tracking and diagnostics  
- **Flexible Options**: Focus on specific tables or comprehensive ecosystem analysis
- **Clear Recommendations**: Actionable guidance for analysis planning

## Error Handling
Robust error handling with graceful degradation when individual tables are unavailable, comprehensive logging for troubleshooting, and detailed diagnostics for maximum reliability in production data discovery environments.