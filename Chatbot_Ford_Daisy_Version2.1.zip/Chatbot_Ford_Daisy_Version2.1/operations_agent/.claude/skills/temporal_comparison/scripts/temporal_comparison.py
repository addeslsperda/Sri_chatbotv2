"""
Enhanced temporal comparison with comprehensive multi-dimensional analysis.
Covers ALL temporal questions using ford_daisy.analytics.call_data + enrichments.

Usage:
    python temporal_comparison.py --period1-from 2026-07-01 --period1-to 2026-07-31 --period2-from 2026-08-01 --period2-to 2026-08-31
    python temporal_comparison.py --period1-from 2026-01-01 --period1-to 2026-03-31 --period2-from 2026-04-01 --period2-to 2026-06-30 --vehicle "Mach-E"

Output: JSON with comprehensive period-over-period comparison
"""
import argparse
import json
import os
import sys
from decimal import Decimal
from collections import defaultdict
from databricks import sql
import requests
from dotenv import load_dotenv

load_dotenv(override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


def serialize(v):
    if isinstance(v, Decimal):
        return float(v)
    if hasattr(v, "isoformat"):
        return str(v)
    return v


def get_enhanced_period_data(conn, date_from, date_to, vehicle=None, team=None, program=None):
    """Get comprehensive period data with all dimensions and metrics"""

    params = {
        "date_from": date_from,
        "date_to": date_to
    }

    # Build filters
    filters = [
        "fdc.call_date >= :date_from",
        "fdc.call_date <= :date_to"
    ]

    if vehicle:
        params["vehicle"] = f"%{vehicle}%"
        filters.append("UPPER(fdc.ModelVehicleLine) LIKE UPPER(:vehicle)")

    if team:
        params["team"] = f"%{team}%"
        filters.append("UPPER(v.agent_team) LIKE UPPER(:team)")

    if program:
        params["program"] = f"%{program}%"
        filters.append("UPPER(fdc.program_name) LIKE UPPER(:program)")

    where_clause = " AND ".join(filters)

    query = f"""
        WITH enhanced_data AS (
            SELECT
                -- IDENTIFIERS
                fdc.call_id,
                fdc.call_date,

                -- CORE METRICS (ford_daisy - best coverage)
                fdc.sentiment as fd_sentiment,
                fdc.complexity as fd_complexity,
                fdc.nps,
                fdc.fcr,
                fdc.brand_trust,

                -- CLASSIFICATIONS
                fdc.case_class_l1,
                fdc.case_class_l2,
                fdc.program_name,
                fdc.ModelVehicleLine,
                fdc.happiness_category_name,
                fdc.business_process_name,

                -- TEAM DIMENSIONS (verint_transcription)
                v.agent_team,
                v.center_name,
                v.department_name,
                v.program_type_name,

                -- PERFORMANCE METRICS (call_data)
                cd.handle_time,
                cd.number_of_transfers,
                cd.worktime,
                cd.agent_tenure,

                -- DETAILED SENTIMENT (sentiments)
                s.customer_sentiment,
                s.agent_sentiment,
                s.overall_sentiment,

                -- TOPIC HIERARCHY (topic tables)
                td.topic_category,
                td.topic_level1,
                td.topic_level2,
                td.topic_level3,

                -- PARTS/FEATURES (parts_unfiltered)
                pu.parts_features,
                pu.parts_concern

            FROM ford_daisy.analytics.call_data fdc

            -- ENRICH: Agent teams and geographic info
            LEFT JOIN dwh_prod.ovprod_o.verint_transcription v
                ON fdc.call_id = v.transaction_id

            -- ENRICH: Performance metrics (AHT, transfers)
            LEFT JOIN text_analytics.nlp_analytics.call_data cd
                ON fdc.call_id = cd.call_id

            -- ENRICH: Detailed sentiment breakdown
            LEFT JOIN text_analytics.nlp_analytics.sentiments s
                ON fdc.call_id = s.call_id

            -- ENRICH: Topic hierarchy
            LEFT JOIN text_analytics.nlp_analytics.topic_xwalk tx
                ON fdc.call_id = tx.call_id
            LEFT JOIN text_analytics.nlp_configs.topic_detail td
                ON tx.topic_id = td.topic_id

            -- ENRICH: Parts and features
            LEFT JOIN text_analytics.nlp_analytics.parts_unfiltered pu
                ON fdc.call_id = pu.call_id

            WHERE {where_clause}
        )

        SELECT
            -- OVERALL METRICS
            COUNT(*) as total_calls,
            COUNT(DISTINCT agent_team) as unique_teams,
            COUNT(DISTINCT ModelVehicleLine) as unique_vehicles,
            COUNT(DISTINCT program_name) as unique_programs,
            COUNT(DISTINCT center_name) as unique_locations,

            -- QUALITY METRICS
            ROUND(AVG(fd_sentiment), 4) as avg_sentiment,
            ROUND(AVG(fd_complexity), 2) as avg_complexity,
            ROUND(AVG(nps), 2) as avg_nps,
            ROUND(AVG(fcr), 3) as avg_fcr,
            ROUND(AVG(brand_trust), 3) as avg_brand_trust,

            -- PERFORMANCE METRICS
            ROUND(AVG(handle_time), 2) as avg_handle_time,
            ROUND(AVG(number_of_transfers), 3) as avg_transfers,
            ROUND(SUM(CASE WHEN number_of_transfers > 0 THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) as transfer_rate_pct,

            -- DETAILED SENTIMENT
            ROUND(AVG(customer_sentiment), 4) as avg_customer_sentiment,
            ROUND(AVG(agent_sentiment), 4) as avg_agent_sentiment,
            ROUND(AVG(overall_sentiment), 4) as avg_overall_sentiment,

            -- DATA COVERAGE
            ROUND(COUNT(handle_time) * 100.0 / COUNT(*), 1) as performance_coverage_pct,
            ROUND(COUNT(nps) * 100.0 / COUNT(*), 1) as nps_coverage_pct,
            ROUND(COUNT(customer_sentiment) * 100.0 / COUNT(*), 1) as sentiment_coverage_pct

        FROM enhanced_data
    """

    with conn.cursor() as cursor:
        cursor.execute(query, params)
        row = cursor.fetchone()
        columns = [d[0] for d in cursor.description]

        return dict(zip(columns, [serialize(val) for val in row]))


def get_dimensional_analysis(conn, date_from, date_to, dimension, vehicle=None, team=None, program=None, min_calls=10):
    """Get analysis by specific dimension (case_class_l1, topic_level1, etc.)"""

    params = {
        "date_from": date_from,
        "date_to": date_to,
        "min_calls": min_calls
    }

    # Build filters
    filters = [
        "fdc.call_date >= :date_from",
        "fdc.call_date <= :date_to"
    ]

    if vehicle:
        params["vehicle"] = f"%{vehicle}%"
        filters.append("UPPER(fdc.ModelVehicleLine) LIKE UPPER(:vehicle)")

    if team:
        params["team"] = f"%{team}%"
        filters.append("UPPER(v.agent_team) LIKE UPPER(:team)")

    if program:
        params["program"] = f"%{program}%"
        filters.append("UPPER(fdc.program_name) LIKE UPPER(:program)")

    where_clause = " AND ".join(filters)

    # Map dimension to actual column and table
    dimension_mapping = {
        'case_classifications': 'fdc.case_class_l1',
        'topic_level1': 'td.topic_level1',
        'topic_level2': 'td.topic_level2',
        'parts_concerns': 'pu.parts_concern',
        'agent_teams': 'v.agent_team',
        'locations': 'v.center_name',
        'programs': 'fdc.program_name',
        'vehicles': 'fdc.ModelVehicleLine',
        'business_processes': 'fdc.business_process_name'
    }

    if dimension not in dimension_mapping:
        return {}

    dimension_col = dimension_mapping[dimension]

    query = f"""
        SELECT
            COALESCE({dimension_col}, 'Unknown') as dimension_value,
            COUNT(*) as call_count,
            ROUND(AVG(fdc.sentiment), 4) as avg_sentiment,
            ROUND(AVG(fdc.complexity), 2) as avg_complexity,
            ROUND(AVG(fdc.nps), 2) as avg_nps,
            ROUND(AVG(cd.handle_time), 2) as avg_handle_time,
            ROUND(AVG(cd.number_of_transfers), 3) as avg_transfers,
            ROUND(AVG(s.customer_sentiment), 4) as avg_customer_sentiment

        FROM ford_daisy.analytics.call_data fdc
        LEFT JOIN dwh_prod.ovprod_o.verint_transcription v ON fdc.call_id = v.transaction_id
        LEFT JOIN text_analytics.nlp_analytics.call_data cd ON fdc.call_id = cd.call_id
        LEFT JOIN text_analytics.nlp_analytics.sentiments s ON fdc.call_id = s.call_id
        LEFT JOIN text_analytics.nlp_analytics.topic_xwalk tx ON fdc.call_id = tx.call_id
        LEFT JOIN text_analytics.nlp_configs.topic_detail td ON tx.topic_id = td.topic_id
        LEFT JOIN text_analytics.nlp_analytics.parts_unfiltered pu ON fdc.call_id = pu.call_id

        WHERE {where_clause}
            AND {dimension_col} IS NOT NULL

        GROUP BY {dimension_col}
        HAVING COUNT(*) >= :min_calls
        ORDER BY call_count DESC
    """

    with conn.cursor() as cursor:
        cursor.execute(query, params)
        rows = cursor.fetchall()
        columns = [d[0] for d in cursor.description]

        return [dict(zip(columns, [serialize(val) for val in row])) for row in rows]


def calculate_changes(period1_data, period2_data, dimension_results1, dimension_results2):
    """Calculate comprehensive changes between periods"""

    # Overall metric changes
    def safe_pct_change(old_val, new_val):
        if old_val and old_val != 0:
            return round((new_val - old_val) / old_val * 100, 1)
        elif new_val > 0:
            return 999.9  # New item
        else:
            return 0.0

    def safe_abs_change(old_val, new_val):
        return round((new_val or 0) - (old_val or 0), 4)

    overall_changes = {
        'call_volume_change_pct': safe_pct_change(period1_data['total_calls'], period2_data['total_calls']),
        'sentiment_change': safe_abs_change(period1_data['avg_sentiment'], period2_data['avg_sentiment']),
        'complexity_change': safe_abs_change(period1_data['avg_complexity'], period2_data['avg_complexity']),
        'nps_change': safe_abs_change(period1_data['avg_nps'], period2_data['avg_nps']),
        'fcr_change': safe_abs_change(period1_data['avg_fcr'], period2_data['avg_fcr']),
        'handle_time_change_pct': safe_pct_change(period1_data['avg_handle_time'], period2_data['avg_handle_time']),
        'transfer_rate_change': safe_abs_change(period1_data['transfer_rate_pct'], period2_data['transfer_rate_pct']),
        'customer_sentiment_change': safe_abs_change(period1_data['avg_customer_sentiment'], period2_data['avg_customer_sentiment'])
    }

    # Dimensional changes
    dimensional_changes = []

    # Create lookup for period2 data
    p2_lookup = {item['dimension_value']: item for item in dimension_results2}
    p1_lookup = {item['dimension_value']: item for item in dimension_results1}

    # Get all unique dimensions
    all_dimensions = set(p1_lookup.keys()) | set(p2_lookup.keys())

    for dim_value in all_dimensions:
        p1_item = p1_lookup.get(dim_value, {'call_count': 0, 'avg_sentiment': None})
        p2_item = p2_lookup.get(dim_value, {'call_count': 0, 'avg_sentiment': None})

        p1_count = p1_item['call_count']
        p2_count = p2_item['call_count']

        # Determine status
        if p1_count == 0 and p2_count > 0:
            status = "new"
            change_pct = None
        elif p1_count > 0 and p2_count == 0:
            status = "resolved"
            change_pct = -100.0
        elif p1_count > 0:
            change_pct = safe_pct_change(p1_count, p2_count)
            if change_pct > 20:
                status = "major_increase"
            elif change_pct > 10:
                status = "increasing"
            elif change_pct < -20:
                status = "major_decrease"
            elif change_pct < -10:
                status = "decreasing"
            else:
                status = "stable"
        else:
            status = "stable"
            change_pct = 0.0

        # Sentiment trend and change calculation
        p1_sent = p1_item.get('avg_sentiment')
        p2_sent = p2_item.get('avg_sentiment')

        if p1_sent is not None and p2_sent is not None:
            sent_change = p2_sent - p1_sent
            if sent_change > 0.05:
                sentiment_trend = "improving"
            elif sent_change < -0.05:
                sentiment_trend = "worsening"
            else:
                sentiment_trend = "stable"
        else:
            sent_change = None
            sentiment_trend = "n/a"

        # Priority
        if status == "new" or (change_pct and abs(change_pct) > 20):
            priority = "high"
        elif (change_pct and abs(change_pct) > 10) or sentiment_trend == "worsening":
            priority = "medium"
        else:
            priority = "low"

        dimensional_changes.append({
            'dimension_value': dim_value,
            'period1_count': p1_count,
            'period2_count': p2_count,
            'change_pct': change_pct,
            'status': status,
            'period1_sentiment': round(p1_sent, 4) if p1_sent else None,
            'period2_sentiment': round(p2_sent, 4) if p2_sent else None,
            'sentiment_change': round(sent_change, 4) if sent_change is not None else None,
            'sentiment_trend': sentiment_trend,
            'priority': priority
        })

    # Sort by absolute change
    dimensional_changes.sort(key=lambda x: abs(x['change_pct']) if x['change_pct'] else 0, reverse=True)

    return overall_changes, dimensional_changes


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--period1-from", dest="p1_from", required=True, help="Period 1 start date")
    parser.add_argument("--period1-to", dest="p1_to", required=True, help="Period 1 end date")
    parser.add_argument("--period2-from", dest="p2_from", required=True, help="Period 2 start date")
    parser.add_argument("--period2-to", dest="p2_to", required=True, help="Period 2 end date")
    parser.add_argument("--vehicle", default=None, help="Filter by vehicle model")
    parser.add_argument("--team", default=None, help="Filter by agent team")
    parser.add_argument("--program", default=None, help="Filter by program name")
    parser.add_argument("--metric", choices=["all", "volume", "sentiment", "performance"],
                       default="all", help="Focus on specific metric type")
    parser.add_argument("--dimension", choices=["case_classifications", "topic_level1", "agent_teams",
                                               "locations", "programs", "vehicles", "parts_concerns"],
                       default="case_classifications", help="Primary analysis dimension")
    parser.add_argument("--limit", type=int, default=500, help="Max items per dimension")
    parser.add_argument("--min-calls", type=int, default=10, help="Minimum calls for inclusion")
    args, _ = parser.parse_known_args()

    with get_connection() as conn:
        # Get comprehensive period data
        period1_data = get_enhanced_period_data(conn, args.p1_from, args.p1_to,
                                              args.vehicle, args.team, args.program)
        period2_data = get_enhanced_period_data(conn, args.p2_from, args.p2_to,
                                              args.vehicle, args.team, args.program)

        # Get dimensional analysis for primary dimension
        period1_dimension = get_dimensional_analysis(conn, args.p1_from, args.p1_to, args.dimension,
                                                   args.vehicle, args.team, args.program, args.min_calls)
        period2_dimension = get_dimensional_analysis(conn, args.p2_from, args.p2_to, args.dimension,
                                                   args.vehicle, args.team, args.program, args.min_calls)

        # Calculate changes
        overall_changes, dimensional_changes = calculate_changes(
            period1_data, period2_data, period1_dimension, period2_dimension
        )

        # Categorize changes
        increasing_issues = [item for item in dimensional_changes
                           if item['status'] in ['increasing', 'major_increase']][:15]
        decreasing_issues = [item for item in dimensional_changes
                           if item['status'] in ['decreasing', 'major_decrease']][:15]
        new_issues = [item for item in dimensional_changes if item['status'] == 'new'][:15]
        resolved_issues = [item for item in dimensional_changes if item['status'] == 'resolved'][:15]

        # Build comprehensive result
        result = {
            'metadata': {
                'comparison_periods': {
                    'period1': f"{args.p1_from} to {args.p1_to}",
                    'period2': f"{args.p2_from} to {args.p2_to}"
                },
                'filters': {
                    'vehicle': args.vehicle or "all",
                    'team': args.team or "all",
                    'program': args.program or "all"
                },
                'analysis_params': {
                    'primary_dimension': args.dimension,
                    'metric_focus': args.metric,
                    'min_calls_threshold': args.min_calls,
                    'max_results': args.limit
                },
                'data_sources': [
                    'ford_daisy.analytics.call_data (primary metrics)',
                    'dwh_prod.ovprod_o.verint_transcription (teams/locations)',
                    'text_analytics.nlp_analytics.call_data (performance)',
                    'text_analytics.nlp_analytics.sentiments (detailed sentiment)',
                    'text_analytics.nlp_analytics.topic_xwalk (topics)',
                    'text_analytics.nlp_configs.topic_detail (topic hierarchy)',
                    'text_analytics.nlp_analytics.parts_unfiltered (parts/features)'
                ]
            },
            'overall_comparison': {
                'period1_metrics': period1_data,
                'period2_metrics': period2_data,
                'changes': overall_changes
            },
            'dimensional_analysis': {
                'dimension_type': args.dimension,
                'total_items_analyzed': len(dimensional_changes),
                'changes': dimensional_changes[:args.limit]
            },
            'change_summary': {
                'increasing_issues': increasing_issues,
                'decreasing_issues': decreasing_issues,
                'new_issues': new_issues,
                'resolved_issues': resolved_issues
            },
            'insights': {
                'highest_impact_change': dimensional_changes[0] if dimensional_changes else None,
                'total_new_issues': len(new_issues),
                'total_resolved_issues': len(resolved_issues),
                'net_sentiment_change': overall_changes['sentiment_change'],
                'volume_trend': 'increasing' if overall_changes['call_volume_change_pct'] > 5
                              else 'decreasing' if overall_changes['call_volume_change_pct'] < -5
                              else 'stable'
            }
        }

        print(json.dumps(result, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)