---
name: temporal_comparison
display_name: Period-over-Period Comparison
description: Enhanced period-over-period comparison across ALL dimensions - topics, teams, vehicles, programs, locations. Multi-source data integration with comprehensive metrics. Use for "compare April vs May call reasons", "Q1 vs Q2 comparison", "team performance trends", "vehicle issue evolution", "has there been an uptick", "what changed between periods".
signals:
  - compare
  - comparison
  - vs
  - versus
  - compared to
  - april vs may
  - q1 vs q2
  - month over month
  - week over week
  - this month vs last month
  - has there been an uptick
  - what changed
requires:
  - two time periods to compare
not_good_for: Single period trends (use trend_analysis), simple time-series (use contact_volume_trend)
---

# Period-over-Period Comparison

## What this script does
Compares call volumes, sentiment, complexity, top issues, and topic distributions between two time periods. Identifies:
- **What's increasing**: Issues that are growing
- **What's decreasing**: Issues that are declining
- **What's new**: Issues that appeared in period 2 but not period 1
- **What's resolved**: Issues that disappeared
- **Metric changes**: Volume, AHT, sentiment, complexity shifts

Returns side-by-side comparison with change indicators.

## How to run it

```bash
python .claude/skills/temporal_comparison/scripts/temporal_comparison.py --period1-from 2026-01-01 --period1-to 2026-01-31 --period2-from 2026-02-01 --period2-to 2026-02-28
```

## Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--period1-from` | Yes | — | Period 1 start date YYYY-MM-DD |
| `--period1-to` | Yes | — | Period 1 end date YYYY-MM-DD |
| `--period2-from` | Yes | — | Period 2 start date YYYY-MM-DD |
| `--period2-to` | Yes | — | Period 2 end date YYYY-MM-DD |
| `--vehicle` | No | all | Filter by vehicle model |
| `--team` | No | all | Filter by agent team |
| `--metric` | No | `all` | Focus: `all`, `volume`, `sentiment`, `complexity` |
| `--program` | No | all | Filter by program name |
| `--dimension` | No | `case_classifications` | Analysis dimension: `case_classifications`, `topic_level1`, `agent_teams`, `locations`, `programs`, `vehicles`, `parts_concerns` |
| `--limit` | No | `100` | Max items to compare (ensures sufficient data) |
| `--min-calls` | No | `10` | Minimum calls for statistical significance |

## Example calls

```bash
# January vs February comparison
python .claude/skills/temporal_comparison/scripts/temporal_comparison.py --period1-from 2026-01-01 --period1-to 2026-01-31 --period2-from 2026-02-01 --period2-to 2026-02-28

# Q1 vs Q2 comparison
python .claude/skills/temporal_comparison/scripts/temporal_comparison.py --period1-from 2026-01-01 --period1-to 2026-03-31 --period2-from 2026-04-01 --period2-to 2026-06-30

# Week-over-week comparison
python .claude/skills/temporal_comparison/scripts/temporal_comparison.py --period1-from 2026-01-01 --period1-to 2026-01-07 --period2-from 2026-01-08 --period2-to 2026-01-14

# April vs May for specific vehicle
python .claude/skills/temporal_comparison/scripts/temporal_comparison.py --period1-from 2026-04-01 --period1-to 2026-04-30 --period2-from 2026-05-01 --period2-to 2026-05-31 --vehicle "Mach-E"

# This month vs last month (sentiment focus)
python .claude/skills/temporal_comparison/scripts/temporal_comparison.py --period1-from 2025-12-01 --period1-to 2025-12-31 --period2-from 2026-01-01 --period2-to 2026-01-31 --metric sentiment
```

## Output format

```json
{
  "comparison": {
    "period1": "2026-01-01 to 2026-01-31",
    "period2": "2026-02-01 to 2026-02-28",
    "vehicle": "all",
    "team": "all"
  },
  "overall_metrics": {
    "period1": {
      "total_calls": 143985,
      "avg_sentiment": 0.23,
      "avg_complexity": 18.7,
      "avg_aht": 630.5,
      "transfer_rate": 8.1
    },
    "period2": {
      "total_calls": 138450,
      "avg_sentiment": 0.25,
      "avg_complexity": 19.2,
      "avg_aht": 645.8,
      "transfer_rate": 8.5
    },
    "changes": {
      "call_volume_change_pct": -3.8,
      "sentiment_change": "+0.02",
      "complexity_change": "+0.5",
      "aht_change_pct": "+2.4%",
      "transfer_rate_change": "+0.4 pts"
    }
  },
  "topic_comparison": [
    {
      "topic": "FordPass connectivity issues",
      "period1_mentions": 2850,
      "period2_mentions": 3420,
      "change_pct": 20.0,
      "status": "increasing",
      "period1_sentiment": 0.15,
      "period2_sentiment": 0.12,
      "sentiment_trend": "worsening",
      "priority": "high"
    },
    {
      "topic": "BlueCruise activation",
      "period1_mentions": 1250,
      "period2_mentions": 850,
      "change_pct": -32.0,
      "status": "decreasing",
      "period1_sentiment": 0.18,
      "period2_sentiment": 0.22,
      "sentiment_trend": "improving",
      "priority": "medium"
    },
    {
      "topic": "Home charger installation",
      "period1_mentions": 0,
      "period2_mentions": 450,
      "change_pct": null,
      "status": "new",
      "period1_sentiment": null,
      "period2_sentiment": 0.10,
      "sentiment_trend": "n/a",
      "priority": "high"
    }
  ],
  "increasing_issues": [
    {"topic": "FordPass connectivity issues", "change_pct": 20.0},
    {"topic": "Tesla adapter problems", "change_pct": 15.5}
  ],
  "decreasing_issues": [
    {"topic": "BlueCruise activation", "change_pct": -32.0},
    {"topic": "Password reset", "change_pct": -18.2}
  ],
  "new_issues": [
    {"topic": "Home charger installation", "mentions": 450},
    {"topic": "NACS adapter", "mentions": 120}
  ],
  "resolved_issues": [
    {"topic": "App login timeout", "period1_mentions": 340}
  ]
}
```

## Change Indicators

### **Status Values:**
- **`increasing`**: Issue mentions grew by >10%
- **`decreasing`**: Issue mentions declined by >10%
- **`stable`**: Issue mentions changed by <10%
- **`new`**: Issue appeared in period 2, not in period 1
- **`resolved`**: Issue disappeared (present in period 1, absent in period 2)

### **Priority Levels:**
- **`high`**: New issues OR issues increasing >20%
- **`medium`**: Issues increasing 10-20% OR decreasing with worsening sentiment
- **`low`**: Stable issues OR improving issues

### **Sentiment Trend:**
- **`improving`**: Sentiment increased between periods
- **`worsening`**: Sentiment decreased between periods
- **`stable`**: Sentiment unchanged (<0.05 difference)

## Error output
If something goes wrong, the script prints `{"error": "..."}` to stderr and exits with code 1.

## Notes
- **Use cases**: Identify emerging problems, track improvement initiatives, detect seasonal patterns
- **Minimum mentions**: Topics need at least 10 mentions in either period to be included
- Sorted by change magnitude (biggest increases/decreases first)
- **"New" issues** are particularly important - they may indicate emerging problems
- **Sentiment trend** is as important as volume - increasing volume with improving sentiment = good growth
- Best used with equal-length periods for fair comparison (e.g., Jan vs Feb, not Jan vs Q2)
- Combine with issue_breakdown for deeper analysis of specific topics
