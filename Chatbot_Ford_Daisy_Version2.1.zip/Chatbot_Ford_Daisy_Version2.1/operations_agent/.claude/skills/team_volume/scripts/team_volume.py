"""
Enhanced team volume analytics with hierarchical breakdown and performance metrics.

Usage:
    python team_volume.py --from 2026-01-01 --to 2026-01-31
    python team_volume.py --from 2026-01-01 --to 2026-01-31 --program "BEV"
    python team_volume.py --from 2026-01-01 --to 2026-01-31 --location "Melbourne"
    python team_volume.py --from 2026-01-01 --to 2026-01-31 --team "LinConc" --sort-by performance

Output: JSON array with comprehensive team analytics including hierarchy, volume, and performance metrics
"""
import argparse
import json
import os
import sys
from decimal import Decimal
from pathlib import Path
from databricks import sql
import requests
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parents[4] / ".env", override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--from", dest="date_from", required=True, help="Start date YYYY-MM-DD")
    parser.add_argument("--to", dest="date_to", required=True, help="End date YYYY-MM-DD")
    parser.add_argument("--program", default="%", help="Filter by program name (supports wildcards)")
    parser.add_argument("--sow", default="%", help="Filter by SOW name (supports wildcards)")
    parser.add_argument("--location", default="%", help="Filter by location/center (supports wildcards)")
    parser.add_argument("--team", default="%", help="Filter by team name (supports wildcards)")
    parser.add_argument("--owner", default="%", help="Filter by case owner (supports wildcards)")
    parser.add_argument("--min-calls", type=int, default=10, help="Minimum calls for inclusion")
    parser.add_argument("--sort-by", choices=["volume", "performance", "agents"], default="volume", help="Sort results by")
    parser.add_argument("--group-by-time", choices=["day", "week", "month", "day_of_week"], default=None, help="Group results by time period for temporal analysis")
    parser.add_argument("--compare-periods", action="store_true", help="Compare current period with previous period")
    parser.add_argument("--limit", type=int, default=500, help="Maximum results to return")
    args, _ = parser.parse_known_args()

    # Build parameters
    params = {
        "date_from": args.date_from,
        "date_to": args.date_to,
        "program": f"%{args.program}%" if args.program != "%" else "%",
        "location": f"%{args.location}%" if args.location != "%" else "%",
        "team": f"%{args.team}%" if args.team != "%" else "%",
        "sow": f"%{args.sow}%" if args.sow != "%" else "%",
        "owner": f"%{args.owner}%" if args.owner != "%" else "%",
        "min_calls": args.min_calls,
        "limit": args.limit,
        "sort_by": args.sort_by
    }

    # Handle temporal grouping
    if args.group_by_time:
        if args.group_by_time == "day":
            time_grouping = "DATE(v.date_of_call)"
            time_label = "call_date"
        elif args.group_by_time == "week":
            time_grouping = "DATE_TRUNC('week', v.date_of_call)"
            time_label = "call_week"
        elif args.group_by_time == "day_of_week":
            time_grouping = "DATE_FORMAT(v.date_of_call, 'EEEE')"
            time_label = "day_of_week"
        else:  # month
            time_grouping = "DATE_TRUNC('month', v.date_of_call)"
            time_label = "call_month"
    else:
        time_grouping = "NULL"
        time_label = "time_period"

    # Enhanced team_volume query with temporal capabilities
    query = f"""
        WITH base_team_data AS (
            SELECT
                -- HIERARCHY (from verint_transcription - most reliable)
                COALESCE(v.program_name, 'Unknown Program') as program_name,
                COALESCE(v.sow_name, 'Unknown SOW') as sow_name,
                v.agent_team,
                COALESCE(v.center_name, 'Unknown Location') as location,
                v.department_name,

                -- TIME DIMENSION (for temporal analysis)
                {time_grouping} as time_period,

                -- CASE MANAGEMENT (from case_metadata where available)
                cm.owner as case_owner,
                cm.caseclassificationlevel1,
                cm.caseclassificationlevel2,

                -- VOLUME METRICS
                COUNT(*) as total_calls,
                COUNT(DISTINCT v.agent_name) as unique_agents,
                COUNT(DISTINCT cm.casenumber) as unique_cases,

                -- PERFORMANCE METRICS (from call_data where available)
                COUNT(cd.call_id) as calls_with_performance_data,
                AVG(cd.handle_time) as avg_handle_time_seconds,
                AVG(cd.complexity) as avg_complexity,
                AVG(cd.number_of_transfers) as avg_transfers,
                AVG(cd.sentiment) as avg_sentiment,

                -- QUALITY METRICS (from case_metadata where available)
                COUNT(cm.nps_score) as nps_data_points,
                AVG(cm.nps_score) as avg_nps,
                COUNT(cm.fcr_score) as fcr_data_points,
                AVG(cm.fcr_score) as avg_fcr,

                -- DATA QUALITY INDICATORS
                ROUND(COUNT(cd.call_id) * 100.0 / COUNT(*), 1) as performance_data_coverage_pct,
                ROUND(COUNT(cm.casenumber) * 100.0 / COUNT(*), 1) as case_data_coverage_pct

            FROM dwh_prod.ovprod_o.verint_transcription v

            -- JOIN 1: verint -> call_data (transaction_id = call_id)
            LEFT JOIN text_analytics.nlp_analytics.call_data cd
                ON v.transaction_id = cd.call_id

            -- JOIN 2: call_data -> case_metadata (casenumber = casenumber)
            LEFT JOIN text_analytics.nlp_dashboard.case_metadata cm
                ON cd.casenumber = cm.casenumber

            WHERE v.date_of_call >= :date_from
                AND v.date_of_call <= :date_to
                AND v.agent_team IS NOT NULL
                -- Optional filters
                AND (:program = '%' OR v.program_name LIKE :program)
                AND (:location = '%' OR v.center_name LIKE :location)
                AND (:team = '%' OR v.agent_team LIKE :team)
                AND (:sow = '%' OR v.sow_name LIKE :sow)
                AND (:owner = '%' OR cm.owner LIKE :owner)

            GROUP BY
                v.program_name,
                v.sow_name,
                v.agent_team,
                v.center_name,
                v.department_name,
                cm.owner,
                cm.caseclassificationlevel1,
                cm.caseclassificationlevel2,
                {time_grouping}
        ),

        final_metrics AS (
            SELECT *,
                -- CALCULATED METRICS
                ROUND(avg_handle_time_seconds/60.0, 1) as avg_handle_time_minutes,
                ROUND(total_calls * 100.0 / SUM(total_calls) OVER(), 2) as pct_of_total_calls,
                ROUND(total_calls * 1.0 / NULLIF(unique_agents, 0), 1) as calls_per_agent,

                -- PERFORMANCE CATEGORIES (based on actual data patterns)
                CASE
                    WHEN avg_handle_time_seconds/60.0 <= 8 THEN 'Fast'
                    WHEN avg_handle_time_seconds/60.0 <= 15 THEN 'Average'
                    ELSE 'Slow'
                END as aht_category,

                CASE
                    WHEN avg_complexity <= 10 THEN 'Simple'
                    WHEN avg_complexity <= 15 THEN 'Moderate'
                    ELSE 'Complex'
                END as complexity_category,

                -- RANKINGS
                ROW_NUMBER() OVER (ORDER BY total_calls DESC) as volume_rank,
                ROW_NUMBER() OVER (ORDER BY avg_handle_time_seconds ASC) as efficiency_rank

            FROM base_team_data
            WHERE total_calls >= :min_calls
        )

        SELECT
            -- CORE TEAM INFORMATION
            program_name,
            sow_name,
            agent_team,
            location,
            department_name,
            case_owner,
            caseclassificationlevel1,
            caseclassificationlevel2,

            -- TIME DIMENSION (for temporal analysis)
            time_period as {time_label},

            -- VOLUME METRICS
            total_calls,
            pct_of_total_calls,
            unique_agents,
            calls_per_agent,

            -- PERFORMANCE METRICS (when available)
            avg_handle_time_minutes,
            aht_category,
            avg_complexity,
            complexity_category,
            avg_transfers,

            -- QUALITY METRICS (when available)
            avg_nps,
            avg_fcr,
            avg_sentiment,

            -- DATA AVAILABILITY INDICATORS
            performance_data_coverage_pct,
            case_data_coverage_pct,
            nps_data_points,

            -- RANKINGS
            volume_rank,
            efficiency_rank

        FROM final_metrics
        ORDER BY
            CASE WHEN '{time_grouping}' != 'NULL' THEN time_period END ASC,
            CASE :sort_by
                WHEN 'performance' THEN avg_handle_time_minutes
                WHEN 'agents' THEN unique_agents
                ELSE total_calls
            END DESC

        LIMIT :limit
    """

    with get_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(query, params)
            rows = cursor.fetchall()
            columns = [d[0] for d in cursor.description]

    def serialize(v):
        if isinstance(v, Decimal):
            return float(v)
        if hasattr(v, "isoformat"):
            return str(v)
        return v

    result = [dict(zip(columns, [serialize(val) for val in row])) for row in rows]

    # Add metadata about the query
    metadata = {
        "query_params": {
            "date_range": f"{args.date_from} to {args.date_to}",
            "filters": {
                "program": args.program if args.program != "%" else "all",
                "location": args.location if args.location != "%" else "all",
                "team": args.team if args.team != "%" else "all",
                "sow": args.sow if args.sow != "%" else "all",
                "owner": args.owner if args.owner != "%" else "all"
            },
            "min_calls": args.min_calls,
            "sort_by": args.sort_by,
            "limit": args.limit,
            "temporal_analysis": {
                "group_by_time": args.group_by_time,
                "compare_periods": args.compare_periods
            }
        },
        "result_count": len(result),
        "total_calls": sum(row.get("total_calls", 0) for row in result),
        "analysis_type": "temporal" if args.group_by_time else "snapshot"
    }

    # If temporal grouping, add time-based summary
    if args.group_by_time and result:
        time_periods = set(row.get(time_label) for row in result if row.get(time_label))
        metadata["temporal_summary"] = {
            "time_periods_covered": len(time_periods),
            "granularity": args.group_by_time,
            "periods": sorted(list(time_periods)) if time_periods else []
        }

    output = {
        "metadata": metadata,
        "results": result
    }

    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)
