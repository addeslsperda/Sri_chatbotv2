---
name: team_volume
display_name: Comprehensive Team Analytics
description: Returns hierarchical team analytics including volume, performance, sentiment, and operational metrics across program/SOW/team/location hierarchy. Supports Ford CRC organizational structure with comprehensive drill-down capabilities.
signals:
  - team volume
  - program volume
  - SOW analysis
  - location analysis
  - team performance
  - team breakdown
  - team specialization
  - which teams
  - agent team
  - team handles
  - team capacity
  - team hierarchy
  - program breakdown
  - Melbourne teams
  - Houston teams
  - Dearborn teams
  - BEV program
  - Ford Pro teams
  - Lincoln teams
  - team owner analysis
  - case classification teams
  - team metrics
  - team structure
requires:
  - a date range (from and to)
capabilities:
  - Hierarchical drill-down (program -> SOW -> team -> location)
  - Performance metrics (AHT, complexity, transfers when available)
  - Sentiment analysis (overall sentiment tracking)
  - Case management integration (NPS, classifications, owners when available)
  - Geographic analysis across Ford locations
  - Program-level operational intelligence
  - Team capacity and utilization analysis
  - Data quality indicators for transparency
not_good_for: Deep AHT analysis (use aht_analysis), transfer patterns (use transfer_analysis), complex temporal trends (use temporal_comparison)
---

# Comprehensive Team Analytics

## What this script does
Provides comprehensive team analytics using Ford's complete organizational hierarchy from the verint_transcription system. Combines volume metrics with performance data, sentiment analysis, and case management information to deliver complete operational intelligence across programs, SOWs, teams, and locations.

## How to run it

```bash
python .claude/skills/team_volume/scripts/team_volume.py --from 2026-01-01 --to 2026-01-31
```

## Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--from` | Yes | — | Start date YYYY-MM-DD |
| `--to` | Yes | — | End date YYYY-MM-DD |
| `--program` | No | all | Filter by program name (supports wildcards) |
| `--sow` | No | all | Filter by SOW name (supports wildcards) |
| `--location` | No | all | Filter by location/center (Melbourne, Houston, etc.) |
| `--team` | No | all | Filter by team name (supports wildcards) |
| `--owner` | No | all | Filter by case owner (supports wildcards) |
| `--min-calls` | No | `10` | Minimum calls for inclusion (statistical significance) |
| `--sort-by` | No | `volume` | Sort by: volume, performance, agents |
| `--group-by-time` | No | none | Group results by time period: day, week, month, day_of_week |
| `--compare-periods` | No | false | Compare current period with previous period |
| `--limit` | No | `100` | Maximum results to return |

## Example calls

```bash
# Basic team volume analysis
python .claude/skills/team_volume/scripts/team_volume.py --from 2026-01-01 --to 2026-01-31

# BEV program analysis
python .claude/skills/team_volume/scripts/team_volume.py --from 2026-01-01 --to 2026-01-31 --program "BEV"

# Melbourne location analysis
python .claude/skills/team_volume/scripts/team_volume.py --from 2026-01-01 --to 2026-01-31 --location "Melbourne"

# Lincoln teams with performance focus
python .claude/skills/team_volume/scripts/team_volume.py --from 2026-01-01 --to 2026-01-31 --team "LinConc" --sort-by performance

# Ford Pro program with high-volume teams only
python .claude/skills/team_volume/scripts/team_volume.py --from 2026-01-01 --to 2026-01-31 --program "Ford Pro" --min-calls 50

# Case owner workload analysis
python .claude/skills/team_volume/scripts/team_volume.py --from 2026-01-01 --to 2026-01-31 --owner "Ford Pass"

# Weekly temporal analysis (week by week breakdown)
python .claude/skills/team_volume/scripts/team_volume.py --from 2026-06-01 --to 2026-08-31 --group-by-time week

# Monthly comparison (June vs July vs August)
python .claude/skills/team_volume/scripts/team_volume.py --from 2026-06-01 --to 2026-08-31 --group-by-time month --team "BEV"

# Daily analysis for specific program
python .claude/skills/team_volume/scripts/team_volume.py --from 2026-09-01 --to 2026-09-15 --group-by-time day --program "Lincoln"

# Day of week breakdown (Mon/Tue/Wed etc.)
python .claude/skills/team_volume/scripts/team_volume.py --from 2026-09-08 --to 2026-09-14 --group-by-time day_of_week
```

## Output format

```json
{
  "metadata": {
    "query_params": {
      "date_range": "2026-01-01 to 2026-01-31",
      "filters": {
        "program": "BEV",
        "location": "all",
        "team": "all"
      },
      "min_calls": 10,
      "sort_by": "volume"
    },
    "result_count": 15,
    "total_calls": 45230
  },
  "results": [
    {
      "program_name": "BEV - Inbound",
      "sow_name": "Electric Vehicle Support",
      "agent_team": "FM-MSS-CRC-Melbourne-0813-BEV-BEVTm02",
      "location": "Melbourne, AU",
      "department_name": "Customer Support",
      "case_owner": "BEV Support Team",
      "caseclassificationlevel1": "Technical Support",
      "caseclassificationlevel2": "Charging Issues",
      "total_calls": 2341,
      "pct_of_total_calls": 18.4,
      "unique_agents": 12,
      "calls_per_agent": 195.1,
      "avg_handle_time_minutes": 8.5,
      "aht_category": "Average",
      "avg_complexity": 12.3,
      "complexity_category": "Moderate",
      "avg_transfers": 0.8,
      "avg_nps": 4.2,
      "avg_fcr": 0.85,
      "avg_sentiment": 0.512,
      "performance_data_coverage_pct": 78.5,
      "case_data_coverage_pct": 45.2,
      "nps_data_points": 1058,
      "volume_rank": 1,
      "efficiency_rank": 5
    }
  ]
}
```

## Key Features

### Hierarchical Analysis
- **Program Level**: BEV, Ford Pro, Lincoln, etc.
- **SOW Level**: Statement of Work breakdown
- **Team Level**: Individual team performance
- **Location Level**: Geographic analysis (Melbourne, Houston, Dearborn)

### Performance Metrics
- **Volume**: Call counts, percentages, agents, capacity utilization
- **Efficiency**: AHT, complexity, transfers (when data available)
- **Quality**: NPS, FCR, sentiment (when data available)

### Data Transparency
- **Coverage Indicators**: Shows data availability percentages
- **Quality Metrics**: Indicates reliability of performance data
- **Statistical Significance**: Minimum call thresholds for valid comparisons

### Flexible Filtering
- **Program Filtering**: Focus on specific business units
- **Geographic Filtering**: Location-based analysis
- **Team Pattern Matching**: Wildcard support for team names
- **Case Owner Analysis**: Workload distribution insights

## Use Cases

### Volume Analysis
- "How many calls for the BEV program?"
- "Which teams handle the most calls?"
- "Team capacity utilization analysis"

### Geographic Analysis  
- "Melbourne vs Houston operations"
- "Ford of Canada team breakdown"
- "Manila operations analysis"

### Program Analysis
- "BEV program team structure"
- "Ford Pro teams and volumes"
- "Lincoln program performance"

### Operational Intelligence
- "Teams needing additional resources"
- "Program-level capacity planning"  
- "Cross-location performance comparison"

### Temporal Analysis
- "Week by week team performance"
- "Compare June to August volumes"
- "Monthly team trends"
- "Day by day analysis for specific periods"
- "Calls per day of the week"
- "Seasonal patterns by team"

## Error output
If something goes wrong, the script prints `{"error": "..."}` to stderr and exits with code 1.

## Data Sources
- **Primary**: dwh_prod.ovprod_o.verint_transcription (organizational hierarchy)
- **Performance**: text_analytics.nlp_analytics.call_data (AHT, complexity, sentiment)
- **Case Management**: text_analytics.nlp_dashboard.case_metadata (NPS, FCR, classifications)

## Notes
- Uses tested join strategy: verint_transcription.transaction_id -> call_data.call_id -> case_metadata.casenumber
- Performance and case data availability varies by team (shown in coverage percentages)
- Minimum call threshold ensures statistical significance
- Rankings provide easy comparison across teams and programs
