---
name: callback_analysis
display_name: Enhanced Callback Analysis with Intelligent Detection
description: Comprehensive callback analysis using embedding-based detection + multi-source integration with validated thresholds. Goes beyond simple recall_flag with intelligent pattern recognition, pain point correlation, and predictive insights. Uses data-driven categories (P25/P75 thresholds). Use for "callback patterns", "callback prevention", "callback root causes", "quality vs callbacks".
signals:
  - callback
  - callbacks
  - callback rate
  - callback patterns
  - repeat calls
  - subsequent calls
  - callback prevention
  - callback drivers
  - callback analysis
  - quality vs callbacks
  - pain point callbacks
  - callback correlation
  - callback insights
requires:
  - a date range (from and to)
not_good_for: Vehicle recall campaigns (use recall_analysis in flags_agent), first call resolution (use resolution_analysis), single call metrics (use aht_analysis)
---

# Enhanced Callback Analysis with Intelligent Detection

## What this script does
Comprehensive callback analysis using embedding-based detection + 9 enrichment sources with validated, percentile-based categories:
- **Intelligent callback detection** beyond simple recall_flag using embedding patterns and pain point correlation
- **Callback drivers identification** - what causes callbacks (complexity, transfers, sentiment, topics, case types)
- **Quality vs callback correlation** - how callbacks relate to AHT, sentiment, NPS, FCR
- **Pain point analysis** - process breakdowns and agent friction leading to callbacks
- **Performance benchmarking** with data-driven callback rate thresholds
- **Multi-dimensional analysis** by vehicle, team, location, time patterns
- **Prevention insights** with actionable recommendations for callback reduction

## When to use
- "What drives our callback rate?"
- "Which teams prevent callbacks best?"
- "Which vehicles generate most callbacks?"
- "How do pain points correlate with callbacks?"
- "What topics lead to repeat calls?"
- "Callback prevention opportunities?"
- "Quality impact on callbacks?"
- "Transfer correlation with callbacks?"
- "Time-based callback patterns?"
- "Root cause analysis for callbacks"

## Parameters
- `--from` and `--to`: Date range (required)
- `--group-by`: Analysis dimension - `vehicle`, `team`, `location`, `hour`, `day_of_week` (default: vehicle)
- `--vehicle`: Filter by vehicle model (optional)
- `--team`: Filter by agent team (optional)
- `--program`: Filter by program name (optional)
- `--analysis-type`: Focus area - `overview`, `drivers`, `performance` (default: overview)
- `--min-calls`: Minimum calls for inclusion (default 100, ensures sufficient data for reliable analysis)
- `--limit`: Max results to return (default 100, ensures sufficient data)

## Output format

```json
{
  "metadata": {
    "analysis_period": "2026-01-01 to 2026-01-31",
    "group_by": "vehicle",
    "filters": { "vehicle": "all", "team": "all", "program": "all" },
    "analysis_params": {
      "analysis_type": "overview",
      "min_calls_threshold": 100,
      "like_to_like_comparisons": "week-to-week using averages and percentages"
    },
    "data_sources": [
      "ford_daisy.analytics.call_data (PRIMARY callback source)",
      "text_analytics.nlp_analytics.call_data (performance metrics)",
      "text_analytics.nlp_analytics.call_table (traditional callback flags)",
      "dwh_prod.ovprod_o.verint_transcription (teams/locations)",
      "text_analytics.nlp_analytics.sentiments (quality correlation)",
      "text_analytics.nlp_analytics.topic_xwalk (callback drivers)",
      "text_analytics.nlp_configs.topic_detail (topic hierarchy)",
      "embedding_tables (intelligent callback detection)",
      "pain_points_tables (root cause analysis)"
    ],
    "enhanced_detection": {
      "explanation": "Uses embedding-based pattern recognition + pain point correlation beyond simple recall_flag",
      "detection_criteria": [
        "Traditional recall_flag indicators",
        "High complexity + negative sentiment patterns",
        "Multiple transfer scenarios (>2 transfers)",
        "Long handle time + poor sentiment correlation",
        "Pain point indicators from process breakdowns"
      ]
    },
    "validated_thresholds": {
      "explanation": "All callback categories based on actual data percentiles from the analysis period",
      "low_callback_rate": "<=5.2% (P25 from analyzed groups)",
      "medium_callback_rate": "5.2-12.8% (P25-P75 range)",
      "high_callback_rate": ">=12.8% (P75+ from actual data)",
      "outlier_threshold": ">=22.5% (P90+ needs investigation)",
      "data_range": "0.5% to 45.2%"
    }
  },
  "callback_detection": {
    "total_calls": 142333,
    "traditional_callbacks": 8542,
    "enhanced_callbacks": 12847,
    "pain_point_callbacks": 6234,
    "total_detected_callbacks": 15623,
    "callback_rate_pct": 10.98
  },
  "callback_analysis": [
    {
      "group_name": "F-150",
      "total_calls": 5133,
      "callback_count": 342,
      "callback_rate_pct": 6.66,
      "callback_category": "Medium Callback Rate (P25-P75)",
      "avg_aht_minutes": 12.45,
      "avg_complexity": 18.5,
      "avg_sentiment": 0.0954,
      "avg_nps": 4.25,
      "fcr_rate": 0.856,
      "avg_transfers": 0.08,
      "transfer_rate_pct": 7.8
    }
  ],
  "callback_drivers": {
    "case_type_drivers": [
      {
        "case_type": "Technical Assistance",
        "call_count": 8450,
        "callback_count": 1534,
        "callback_rate_pct": 18.15,
        "avg_aht_minutes": 18.5
      }
    ],
    "topic_drivers": [
      {
        "topic": "In-Vehicle Technology",
        "call_count": 2850,
        "callback_count": 524,
        "callback_rate_pct": 18.39
      }
    ],
    "pain_point_correlation": [
      {
        "pain_point_category": "Multiple Transfers (3+)",
        "call_count": 1250,
        "callback_count": 387,
        "callback_rate_pct": 30.96,
        "avg_sentiment": -0.0245
      }
    ]
  },
  "insights": {
    "performance_comparison": {
      "lowest_callback_rate": {
        "name": "F-150",
        "callback_rate_pct": 6.66,
        "category": "Medium Callback Rate (P25-P75)"
      },
      "highest_callback_rate": {
        "name": "ECOSPORT",
        "callback_rate_pct": 18.52,
        "category": "High Callback Rate (>=P75)"
      }
    },
    "callback_distribution": {
      "low_callback_groups": 12,
      "medium_callback_groups": 15,
      "high_callback_groups": 8,
      "high_callback_groups_list": [
        {"name": "ECOSPORT", "callback_rate_pct": 18.52},
        {"name": "EDGE", "callback_rate_pct": 16.84}
      ]
    },
    "quality_correlation": {
      "aht_callback_correlation": "Strong negative correlation",
      "sentiment_callback_impact": "Negative impact",
      "transfer_callback_relationship": "Higher callbacks correlate with more transfers"
    },
    "prevention_opportunities": {
      "high_callback_count": 8,
      "potential_reduction": "Up to 2,450 callbacks could be prevented",
      "top_opportunities": [
        {"name": "ECOSPORT", "callback_count": 387}
      ]
    }
  }
}
```

## Example calls

```bash
# Overall vehicle callback analysis
python .claude/skills/callback_analysis/scripts/callback_analysis.py --from 2026-01-01 --to 2026-01-31 --group-by vehicle

# Team callback performance
python .claude/skills/callback_analysis/scripts/callback_analysis.py --from 2026-01-01 --to 2026-01-31 --group-by team

# Callback drivers analysis
python .claude/skills/callback_analysis/scripts/callback_analysis.py --from 2026-01-01 --to 2026-01-31 --analysis-type drivers

# Hour-by-hour callback patterns
python .claude/skills/callback_analysis/scripts/callback_analysis.py --from 2026-01-01 --to 2026-01-31 --group-by hour

# Vehicle-specific callback deep dive
python .claude/skills/callback_analysis/scripts/callback_analysis.py --from 2026-01-01 --to 2026-01-31 --vehicle "Mach-E" --analysis-type drivers
```

## Key Insights Provided

### **[DATA] Data-Driven Callback Categories**
- **Low Callback Rate**: <=P25 (efficient teams/vehicles with minimal repeat calls)
- **Medium Callback Rate**: P25-P75 (normal operational range)
- **High Callback Rate**: >=P75 (needs improvement, prevention opportunities)
- **Outliers**: >=P90 (critical intervention needed)

### **[SEARCH] Intelligent Callback Detection**
- Traditional recall_flag indicators from call_table
- High complexity + negative sentiment patterns (unresolved issues)
- Multiple transfer scenarios (>2 transfers indicate process breakdowns)
- Long handle time + poor sentiment correlation (quality gaps)
- Pain point indicators from process friction and agent difficulties

### **[INFO] Callback Drivers Analysis**
- Case types with highest callback rates and prevention opportunities
- Topics generating repeat calls (technology, warranty, service)
- Pain point correlation (transfers, complexity, sentiment impact)
- Time-based callback patterns (hour/day variations)

### **[BALANCE] Quality vs Callback Correlation**
- AHT impact on callback likelihood (longer calls = higher callback risk)
- Sentiment correlation with repeat calls (poor experience = callbacks)
- FCR vs callback relationship (first call resolution effectiveness)
- NPS impact on callback patterns (satisfaction correlation)

### **[TARGET] Prevention Opportunities**
- Teams with lowest callback rates (best practices identification)
- Process optimization opportunities (transfer reduction)
- Training needs identification (high callback groups)
- Quality improvement focus areas (sentiment, complexity management)

## Validated Data Principles
- **Embedding-based detection**: Intelligent pattern recognition beyond simple flags
- **Pain point integration**: Root cause analysis from process breakdowns
- **No hardcoded thresholds**: All categories based on actual data percentiles
- **Like-to-like comparisons**: Week-to-week callback trends using percentages
- **Statistical significance**: 100 calls minimum for reliable analysis
- **Multi-source enrichment**: 9 data sources for comprehensive insights

## Error output
If something goes wrong, the script prints `{"error": "..."}` to stderr and exits with code 1.

## Notes
- **Intelligent detection**: Goes beyond recall_flag with embedding-based pattern recognition
- **Privacy protection**: NO AGENT NAMES revealed (team-level analysis only)
- **Pain point correlation**: Identifies process breakdowns leading to callbacks
- **Data-driven categories**: All thresholds based on actual percentiles from analysis period
- **Prevention focus**: Actionable insights for callback reduction and quality improvement
- **Comprehensive coverage**: 35+ callback questions across 8 analytical categories
- Best used for quality management, process optimization, and customer experience improvement
