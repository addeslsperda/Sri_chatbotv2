"""
Enhanced hour-of-day analysis with comprehensive multi-dimensional insights.
Covers ALL hourly questions using ford_daisy.analytics.call_data + enrichments.

Usage:
    python hour_of_day.py --from 2026-01-01 --to 2026-01-31
    python hour_of_day.py --from 2026-01-01 --to 2026-01-31 --vehicle "F-150"
    python hour_of_day.py --from 2026-01-01 --to 2026-01-31 --team "Technical"

Output: JSON with comprehensive hourly breakdown and staffing insights
"""
import argparse
import json
import os
import sys
from decimal import Decimal
from collections import defaultdict
from databricks import sql
import requests
from dotenv import load_dotenv

load_dotenv(override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


def serialize(v):
    if isinstance(v, Decimal):
        return float(v)
    if hasattr(v, "isoformat"):
        return str(v)
    return v


def get_hourly_data(conn, date_from, date_to, vehicle=None, team=None, program=None, min_calls=10):
    """Get comprehensive hourly analysis with multi-source integration"""

    params = {
        "date_from": date_from,
        "date_to": date_to,
        "min_calls": min_calls
    }

    # Build filters
    filters = [
        "fdc.call_date >= :date_from",
        "fdc.call_date <= :date_to"
    ]

    if vehicle:
        params["vehicle"] = f"%{vehicle}%"
        filters.append("UPPER(fdc.ModelVehicleLine) LIKE UPPER(:vehicle)")

    if team:
        params["team"] = f"%{team}%"
        filters.append("UPPER(v.agent_team) LIKE UPPER(:team)")

    if program:
        params["program"] = f"%{program}%"
        filters.append("UPPER(fdc.program_name) LIKE UPPER(:program)")

    where_clause = " AND ".join(filters)

    query = f"""
        WITH hourly_base_data AS (
            SELECT
                -- TIME DIMENSION - use cd.hod if available, else extract from call_date
                COALESCE(cd.hod, EXTRACT(HOUR FROM fdc.call_date)) as hour_of_day,

                -- IDENTIFIERS
                fdc.call_id,

                -- CORE METRICS (ford_daisy - best coverage)
                fdc.sentiment as fd_sentiment,
                fdc.complexity as fd_complexity,
                fdc.nps,
                fdc.fcr,
                fdc.brand_trust,

                -- CLASSIFICATIONS
                fdc.case_class_l1,
                fdc.program_name,
                fdc.ModelVehicleLine,
                fdc.business_process_name,

                -- TEAM DIMENSIONS (verint_transcription)
                v.agent_team,
                v.center_name,
                v.department_name,

                -- PERFORMANCE METRICS (call_data)
                cd.handle_time,
                cd.number_of_transfers,
                cd.worktime,
                cd.agent_tenure,
                cd.holdtime,

                -- DETAILED SENTIMENT (sentiments)
                s.customer_sentiment,
                s.agent_sentiment,
                s.overall_sentiment,

                -- TOPIC HIERARCHY (topic tables)
                td.topic_level1,
                td.topic_level2,

                -- PARTS/FEATURES (parts_unfiltered)
                pu.parts_concern

            FROM ford_daisy.analytics.call_data fdc

            -- ENRICH: Agent teams and geographic info
            LEFT JOIN dwh_prod.ovprod_o.verint_transcription v
                ON fdc.call_id = v.transaction_id

            -- ENRICH: Performance metrics (AHT, transfers)
            LEFT JOIN text_analytics.nlp_analytics.call_data cd
                ON fdc.call_id = cd.call_id

            -- ENRICH: Detailed sentiment breakdown
            LEFT JOIN text_analytics.nlp_analytics.sentiments s
                ON fdc.call_id = s.call_id

            -- ENRICH: Topic hierarchy
            LEFT JOIN text_analytics.nlp_analytics.topic_xwalk tx
                ON fdc.call_id = tx.call_id
            LEFT JOIN text_analytics.nlp_configs.topic_detail td
                ON tx.topic_id = td.topic_id

            -- ENRICH: Parts and features
            LEFT JOIN text_analytics.nlp_analytics.parts_unfiltered pu
                ON fdc.call_id = pu.call_id

            WHERE {where_clause}
                AND COALESCE(cd.hod, EXTRACT(HOUR FROM fdc.call_date)) IS NOT NULL
        ),

        hourly_aggregated AS (
            SELECT
                hour_of_day,

                -- VOLUME METRICS
                COUNT(*) as total_calls,
                COUNT(DISTINCT agent_team) as unique_teams,
                COUNT(DISTINCT ModelVehicleLine) as unique_vehicles,
                COUNT(DISTINCT center_name) as unique_locations,

                -- PERFORMANCE METRICS
                ROUND(AVG(handle_time) / 60.0, 2) as avg_handle_time_minutes,
                ROUND(AVG(fd_complexity), 2) as avg_complexity,
                ROUND(AVG(worktime), 2) as avg_worktime,
                ROUND(AVG(agent_tenure), 1) as avg_agent_tenure,

                -- QUALITY METRICS
                ROUND(AVG(fd_sentiment), 4) as avg_sentiment,
                ROUND(AVG(nps), 2) as avg_nps,
                ROUND(AVG(fcr), 3) as avg_fcr,
                ROUND(AVG(brand_trust), 3) as avg_brand_trust,

                -- DETAILED SENTIMENT
                ROUND(AVG(customer_sentiment), 4) as avg_customer_sentiment,
                ROUND(AVG(agent_sentiment), 4) as avg_agent_sentiment,
                ROUND(AVG(overall_sentiment), 4) as avg_overall_sentiment,

                -- TRANSFER METRICS
                ROUND(AVG(number_of_transfers), 3) as avg_transfers_per_call,
                SUM(CASE WHEN number_of_transfers > 0 THEN 1 ELSE 0 END) as calls_with_transfers,
                ROUND(SUM(CASE WHEN number_of_transfers > 0 THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) as transfer_rate_pct,

                -- COMPLEXITY DISTRIBUTION
                SUM(CASE WHEN fd_complexity <= 20 THEN 1 ELSE 0 END) as low_complexity_calls,
                SUM(CASE WHEN fd_complexity > 20 AND fd_complexity <= 40 THEN 1 ELSE 0 END) as medium_complexity_calls,
                SUM(CASE WHEN fd_complexity > 40 THEN 1 ELSE 0 END) as high_complexity_calls,

                -- TOP ISSUES BY HOUR
                COUNT(DISTINCT case_class_l1) as unique_case_types,
                COUNT(DISTINCT topic_level1) as unique_topics,
                COUNT(DISTINCT parts_concern) as unique_parts_concerns,

                -- DATA COVERAGE
                ROUND(COUNT(handle_time) * 100.0 / COUNT(*), 1) as performance_coverage_pct,
                ROUND(COUNT(customer_sentiment) * 100.0 / COUNT(*), 1) as sentiment_coverage_pct,
                ROUND(COUNT(nps) * 100.0 / COUNT(*), 1) as nps_coverage_pct

            FROM hourly_base_data
            GROUP BY hour_of_day
            HAVING COUNT(*) >= :min_calls
        ),

        hourly_with_rankings AS (
            SELECT *,
                -- RANKINGS ACROSS HOURS
                ROW_NUMBER() OVER (ORDER BY total_calls DESC) as volume_rank,
                ROW_NUMBER() OVER (ORDER BY avg_handle_time_minutes ASC) as efficiency_rank,
                ROW_NUMBER() OVER (ORDER BY avg_overall_sentiment DESC) as satisfaction_rank,
                ROW_NUMBER() OVER (ORDER BY transfer_rate_pct ASC) as transfer_performance_rank,

                -- PERCENTILES
                ROUND(total_calls * 100.0 / SUM(total_calls) OVER(), 2) as pct_of_daily_volume,

                -- PERFORMANCE CATEGORIES (based on actual data ranges)
                CASE
                    WHEN avg_handle_time_minutes <= 10 THEN 'Fast'
                    WHEN avg_handle_time_minutes <= 20 THEN 'Average'
                    ELSE 'Slow'
                END as aht_category,

                CASE
                    WHEN avg_overall_sentiment >= 0.2 THEN 'Positive'
                    WHEN avg_overall_sentiment >= 0.0 THEN 'Neutral'
                    ELSE 'Negative'
                END as sentiment_category,

                CASE
                    WHEN transfer_rate_pct <= 3 THEN 'Low Transfers'
                    WHEN transfer_rate_pct <= 8 THEN 'Normal Transfers'
                    ELSE 'High Transfers'
                END as transfer_category,

                -- TIME PERIOD CLASSIFICATION
                CASE
                    WHEN hour_of_day BETWEEN 6 AND 11 THEN 'Morning Peak'
                    WHEN hour_of_day BETWEEN 12 AND 17 THEN 'Afternoon Peak'
                    WHEN hour_of_day BETWEEN 18 AND 22 THEN 'Evening'
                    ELSE 'Off Hours'
                END as business_period,

                -- STAFFING INDICATORS
                CASE
                    WHEN total_calls > AVG(total_calls) OVER() * 1.5 THEN 'High Staffing Needed'
                    WHEN total_calls > AVG(total_calls) OVER() * 1.2 THEN 'Above Average Staffing'
                    WHEN total_calls < AVG(total_calls) OVER() * 0.7 THEN 'Reduced Staffing'
                    ELSE 'Normal Staffing'
                END as staffing_recommendation

            FROM hourly_aggregated
        )

        SELECT
            hour_of_day,
            total_calls,
            pct_of_daily_volume,
            unique_teams,
            unique_vehicles,
            unique_locations,
            avg_handle_time_minutes,
            aht_category,
            avg_complexity,
            avg_worktime,
            avg_agent_tenure,
            avg_sentiment,
            avg_nps,
            avg_fcr,
            avg_brand_trust,
            avg_customer_sentiment,
            avg_agent_sentiment,
            avg_overall_sentiment,
            sentiment_category,
            avg_transfers_per_call,
            calls_with_transfers,
            transfer_rate_pct,
            transfer_category,
            low_complexity_calls,
            medium_complexity_calls,
            high_complexity_calls,
            unique_case_types,
            unique_topics,
            unique_parts_concerns,
            performance_coverage_pct,
            sentiment_coverage_pct,
            nps_coverage_pct,
            volume_rank,
            efficiency_rank,
            satisfaction_rank,
            transfer_performance_rank,
            business_period,
            staffing_recommendation
        FROM hourly_with_rankings
        ORDER BY hour_of_day
    """

    with conn.cursor() as cursor:
        cursor.execute(query, params)
        rows = cursor.fetchall()
        columns = [d[0] for d in cursor.description]

        hourly_data = [dict(zip(columns, [serialize(val) for val in row])) for row in rows]

        # Add human-readable time labels
        for item in hourly_data:
            hour = item['hour_of_day']
            if hour == 0:
                item['time_label'] = '12:00 AM - 12:59 AM'
            elif hour < 12:
                item['time_label'] = f'{hour}:00 AM - {hour}:59 AM'
            elif hour == 12:
                item['time_label'] = '12:00 PM - 12:59 PM'
            else:
                item['time_label'] = f'{hour-12}:00 PM - {hour-12}:59 PM'

        return hourly_data


def get_hourly_issues_breakdown(conn, date_from, date_to, vehicle=None, team=None, program=None):
    """Get top issues by hour for pattern analysis"""

    params = {
        "date_from": date_from,
        "date_to": date_to
    }

    filters = [
        "fdc.call_date >= :date_from",
        "fdc.call_date <= :date_to"
    ]

    if vehicle:
        params["vehicle"] = f"%{vehicle}%"
        filters.append("UPPER(fdc.ModelVehicleLine) LIKE UPPER(:vehicle)")

    if team:
        params["team"] = f"%{team}%"
        filters.append("UPPER(v.agent_team) LIKE UPPER(:team)")

    if program:
        params["program"] = f"%{program}%"
        filters.append("UPPER(fdc.program_name) LIKE UPPER(:program)")

    where_clause = " AND ".join(filters)

    query = f"""
        SELECT
            COALESCE(cd.hod, EXTRACT(HOUR FROM fdc.call_date)) as hour_of_day,
            COALESCE(fdc.case_class_l1, 'Unknown') as issue_type,
            COUNT(*) as issue_count,
            ROUND(AVG(fdc.sentiment), 4) as avg_sentiment_for_issue,
            ROUND(AVG(cd.handle_time) / 60.0, 2) as avg_aht_for_issue,
            ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (PARTITION BY COALESCE(cd.hod, EXTRACT(HOUR FROM fdc.call_date))), 1) as pct_of_hour_calls
        FROM ford_daisy.analytics.call_data fdc
        LEFT JOIN dwh_prod.ovprod_o.verint_transcription v ON fdc.call_id = v.transaction_id
        LEFT JOIN text_analytics.nlp_analytics.call_data cd ON fdc.call_id = cd.call_id
        WHERE {where_clause}
            AND fdc.case_class_l1 IS NOT NULL
            AND COALESCE(cd.hod, EXTRACT(HOUR FROM fdc.call_date)) IS NOT NULL
        GROUP BY COALESCE(cd.hod, EXTRACT(HOUR FROM fdc.call_date)), fdc.case_class_l1
        HAVING COUNT(*) >= 5
        ORDER BY hour_of_day, issue_count DESC
    """

    with conn.cursor() as cursor:
        cursor.execute(query, params)
        rows = cursor.fetchall()
        columns = [d[0] for d in cursor.description]

        # Group by hour
        issues_by_hour = defaultdict(list)
        for row in rows:
            issue_dict = dict(zip(columns, [serialize(val) for val in row]))
            hour = issue_dict['hour_of_day']
            issues_by_hour[hour].append({
                'issue_type': issue_dict['issue_type'],
                'issue_count': issue_dict['issue_count'],
                'pct_of_hour_calls': issue_dict['pct_of_hour_calls'],
                'avg_sentiment_for_issue': issue_dict['avg_sentiment_for_issue'],
                'avg_aht_for_issue': issue_dict['avg_aht_for_issue']
            })

        # Keep top 5 issues per hour
        for hour in issues_by_hour:
            issues_by_hour[hour] = issues_by_hour[hour][:5]

        return dict(issues_by_hour)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--from", dest="date_from", required=True, help="Start date YYYY-MM-DD")
    parser.add_argument("--to", dest="date_to", required=True, help="End date YYYY-MM-DD")
    parser.add_argument("--vehicle", default=None, help="Filter by vehicle model")
    parser.add_argument("--team", default=None, help="Filter by agent team")
    parser.add_argument("--program", default=None, help="Filter by program name")
    parser.add_argument("--analysis-type", choices=["overview", "issues", "staffing"],
                       default="overview", help="Analysis focus")
    parser.add_argument("--min-calls", type=int, default=10, help="Minimum calls per hour")
    args, _ = parser.parse_known_args()

    with get_connection() as conn:
        # Get main hourly data
        hourly_data = get_hourly_data(conn, args.date_from, args.date_to,
                                     args.vehicle, args.team, args.program, args.min_calls)

        # Get issues breakdown
        issues_by_hour = get_hourly_issues_breakdown(conn, args.date_from, args.date_to,
                                                   args.vehicle, args.team, args.program)

        # Add issues to hourly data
        for hour_data in hourly_data:
            hour = hour_data['hour_of_day']
            hour_data['top_issues'] = issues_by_hour.get(hour, [])

        # Calculate insights
        if hourly_data:
            peak_hour = max(hourly_data, key=lambda x: x['total_calls'])
            lowest_hour = min(hourly_data, key=lambda x: x['total_calls'])
            best_aht_hour = min(hourly_data, key=lambda x: x['avg_handle_time_minutes'] or float('inf'))
            worst_aht_hour = max(hourly_data, key=lambda x: x['avg_handle_time_minutes'] or 0)
            best_sentiment_hour = max(hourly_data, key=lambda x: x['avg_overall_sentiment'] or 0)
            worst_sentiment_hour = min(hourly_data, key=lambda x: x['avg_overall_sentiment'] or float('inf'))

            total_calls = sum(h['total_calls'] for h in hourly_data)
            peak_hours = [h for h in hourly_data if h['pct_of_daily_volume'] >= 8.0]  # Hours with 8%+ of daily volume
            high_transfer_hours = [h for h in hourly_data if h['transfer_rate_pct'] >= 15.0]
        else:
            peak_hour = lowest_hour = best_aht_hour = worst_aht_hour = None
            best_sentiment_hour = worst_sentiment_hour = None
            total_calls = 0
            peak_hours = high_transfer_hours = []

    # Build comprehensive result
    result = {
        'metadata': {
            'analysis_period': f"{args.date_from} to {args.date_to}",
            'filters': {
                'vehicle': args.vehicle or "all",
                'team': args.team or "all",
                'program': args.program or "all"
            },
            'analysis_params': {
                'analysis_type': args.analysis_type,
                'min_calls_per_hour': args.min_calls
            },
            'data_sources': [
                'ford_daisy.analytics.call_data (primary metrics)',
                'dwh_prod.ovprod_o.verint_transcription (teams/locations)',
                'text_analytics.nlp_analytics.call_data (performance)',
                'text_analytics.nlp_analytics.sentiments (detailed sentiment)',
                'text_analytics.nlp_analytics.topic_xwalk (topics)',
                'text_analytics.nlp_configs.topic_detail (topic hierarchy)',
                'text_analytics.nlp_analytics.parts_unfiltered (parts/features)'
            ]
        },
        'hourly_analysis': hourly_data,
        'insights': {
            'total_calls_analyzed': total_calls,
            'hours_with_sufficient_data': len(hourly_data),
            'peak_volume_hour': {
                'hour': peak_hour['hour_of_day'] if peak_hour else None,
                'time_label': peak_hour['time_label'] if peak_hour else None,
                'call_count': peak_hour['total_calls'] if peak_hour else None,
                'pct_of_daily_volume': peak_hour['pct_of_daily_volume'] if peak_hour else None
            } if peak_hour else None,
            'lowest_volume_hour': {
                'hour': lowest_hour['hour_of_day'] if lowest_hour else None,
                'time_label': lowest_hour['time_label'] if lowest_hour else None,
                'call_count': lowest_hour['total_calls'] if lowest_hour else None
            } if lowest_hour else None,
            'best_performance_hour': {
                'hour': best_aht_hour['hour_of_day'] if best_aht_hour else None,
                'time_label': best_aht_hour['time_label'] if best_aht_hour else None,
                'avg_handle_time_minutes': best_aht_hour['avg_handle_time_minutes'] if best_aht_hour else None
            } if best_aht_hour else None,
            'worst_performance_hour': {
                'hour': worst_aht_hour['hour_of_day'] if worst_aht_hour else None,
                'time_label': worst_aht_hour['time_label'] if worst_aht_hour else None,
                'avg_handle_time_minutes': worst_aht_hour['avg_handle_time_minutes'] if worst_aht_hour else None
            } if worst_aht_hour else None,
            'best_satisfaction_hour': {
                'hour': best_sentiment_hour['hour_of_day'] if best_sentiment_hour else None,
                'time_label': best_sentiment_hour['time_label'] if best_sentiment_hour else None,
                'avg_overall_sentiment': best_sentiment_hour['avg_overall_sentiment'] if best_sentiment_hour else None
            } if best_sentiment_hour else None,
            'worst_satisfaction_hour': {
                'hour': worst_sentiment_hour['hour_of_day'] if worst_sentiment_hour else None,
                'time_label': worst_sentiment_hour['time_label'] if worst_sentiment_hour else None,
                'avg_overall_sentiment': worst_sentiment_hour['avg_overall_sentiment'] if worst_sentiment_hour else None
            } if worst_sentiment_hour else None,
            'peak_hours_for_staffing': [
                {
                    'hour': h['hour_of_day'],
                    'time_label': h['time_label'],
                    'call_count': h['total_calls'],
                    'staffing_recommendation': h['staffing_recommendation']
                } for h in peak_hours
            ],
            'high_transfer_hours': [
                {
                    'hour': h['hour_of_day'],
                    'time_label': h['time_label'],
                    'transfer_rate_pct': h['transfer_rate_pct']
                } for h in high_transfer_hours
            ]
        }
    }

    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)