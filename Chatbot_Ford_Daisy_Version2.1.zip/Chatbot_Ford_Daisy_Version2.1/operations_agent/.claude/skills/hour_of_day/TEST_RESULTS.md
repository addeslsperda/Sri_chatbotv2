# hour_of_day Skill - Test Results

## [OK] Test 1: Peak Hours Identification (January 2026)
**Command:** `python hour_of_day.py --from 2026-01-01 --to 2026-01-31 --min-calls 1000`

**Results:**
Top 5 peak hours:
1. **3:00 PM - 3:59 PM**: 17,039 calls (AHT: 622 min, complexity: 18.2, sentiment: 0.222)
2. **2:00 PM - 2:59 PM**: 16,970 calls (AHT: 616 min, complexity: 18.2, sentiment: 0.224)
3. **12:00 PM - 12:59 PM**: 16,300 calls (AHT: 614 min, complexity: 17.9, sentiment: 0.216)
4. **1:00 PM - 1:59 PM**: 15,846 calls (AHT: 635 min, complexity: 18.5, sentiment: 0.221)
5. **11:00 AM - 11:59 AM**: 15,737 calls (AHT: 632 min, complexity: 18.4, sentiment: 0.223)

**Insight:** Midday (11 AM - 3 PM) is peak load period with 66K+ calls

---

## [OK] Test 2: Vehicle-Specific Analysis (Escape, January 2026)
**Command:** `python hour_of_day.py --from 2026-01-01 --to 2026-01-31 --vehicle "ESCAPE" --min-calls 20`

**Results:**
- Total hours with 20+ Escape calls: 12
- Peak: **3:00 PM** with 401 calls
- AHT range: 771-843 minutes
- Complexity range: 23.4-24.8 (higher than overall average)

**Insight:** Escape calls cluster in afternoon hours and are more complex than average

---

## [OK] Test 3: Staffing Optimization Analysis
**Segmentation:** Morning (7-11 AM), Midday (12-3 PM), Evening (4-8 PM)

| Period | Total Calls | Avg AHT (min) | Avg Complexity |
|--------|-------------|---------------|----------------|
| Morning | 40,756 | 649 | 18.7 |
| Midday | 66,155 | 622 | 18.2 |
| Evening | 36,591 | 647 | 20.9 |

**Insights:**
- Midday needs 62% more staff than evening (volume-based)
- Evening calls are 15% more complex despite lower volume
- Morning and evening have similar AHT (~648 min avg)

---

## [OK] Test 4: Transfer Pattern Analysis
**Sample hour (8 AM, January 2026):**
- 2,790 calls
- 300 calls with transfers (10.75% transfer rate)
- 0.108 average transfers per call

**Across all hours:** Transfer rates range from 0% (early morning) to ~11% (business hours)

---

## Data Quality Validation

[OK] **Column names verified:**
- `call_data.hod` (0-23 format)
- `call_data.handle_time` (not handle_time_mins)
- `call_data.holdtime_min` (not hold_time_mins)
- `call_data.number_of_transfers` (not transfer boolean)

[OK] **Join integrity:**
- Successfully joins `call_data` + `call_table` for team/transfer metrics
- No missing hour values (0-23 all present where call_count >= threshold)

[OK] **Filtering works:**
- `--min-calls` threshold filters low-volume noise (default 50)
- Vehicle filter (LIKE pattern matching)
- Team filter (join to call_table.Agent_Team)
- Date range filtering

---

## Coverage Analysis

**Questions this skill now answers:**
1. "What time of day do we get the most calls?" [OK]
2. "When is AHT highest during the day?" [OK]
3. "What are our peak hours?" [OK]
4. "Show me call volume by hour" [OK]
5. "When should we have more staff scheduled?" [OK]
6. "Are morning calls harder than afternoon calls?" [OK]
7. "What hours have the worst sentiment?" [OK]
8. "When do we see the most transfers?" [OK]

**Estimated questions unlocked from CSV:** 5-8 questions related to time-of-day patterns

---

## Performance

- Query execution time: ~3-5 seconds for full month
- Response includes 14-24 hours (depending on min-calls filter)
- Handles vehicle/team filters without significant slowdown
- No timeout issues observed

---

## Next Steps

[OK] Skill is production-ready
[OK] Added to operations_agent system prompt
[OK] Documentation complete (SKILL.md)
[OK] Real data validation passed

**Deployment:** Ready to use in operations_agent
