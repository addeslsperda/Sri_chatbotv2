---
name: hour_of_day
display_name: Enhanced Hour-of-Day Analysis
description: Comprehensive hourly analysis with multi-source data integration. Covers call volume patterns, performance trends, sentiment variations, transfer patterns, complexity distribution, and staffing optimization across 24 hours. Use for "peak call hours", "staffing optimization", "hourly performance trends", "when are calls most complex", "customer satisfaction by hour".
signals:
  - hour of day
  - peak hours
  - time of day
  - busiest time
  - what time do we get the most calls
  - morning vs afternoon
  - staffing by hour
  - call volume by hour
  - hourly performance
  - when are calls hardest
  - customer satisfaction by hour
requires:
  - a date range (from and to)
not_good_for: Day-of-week patterns (use day_of_week), monthly trends (use trend_analysis)
---

# Enhanced Hour-of-Day Analysis

## What this script does
Comprehensive hourly analysis using ford_daisy.analytics.call_data + 6 enrichment sources to identify:
- **Peak call volume hours** for staffing optimization
- **Performance patterns** (AHT, complexity, sentiment) throughout the day  
- **Transfer rates and patterns** by time of day
- **Issue distribution** across hours (which problems occur when)
- **Staffing recommendations** based on volume and complexity
- **Quality variations** (NPS, FCR, brand trust) by hour
- **Geographic and team workload** distribution

## When to use
- "What time of day do we get the most calls?"
- "When is AHT highest/lowest during the day?"  
- "What are our peak hours for staffing?"
- "Are morning calls harder than afternoon calls?"
- "What hours have the worst/best customer sentiment?"
- "When do we need the most agents?"
- "Which hours have the highest transfer rates?"
- "What time do technical issues peak?"
- "How does call complexity vary throughout the day?"
- "When are customers happiest with our service?"

## Parameters
- `--from` and `--to`: Date range (required)
- `--vehicle`: Filter by vehicle model (optional) 
- `--team`: Filter by agent team (optional)
- `--program`: Filter by program name (optional)
- `--analysis-type`: Focus area - `overview`, `issues`, `staffing` (default: overview)
- `--min-calls`: Minimum calls per hour to include (default 10, ensures sufficient data)

## Output format

```json
{
  "metadata": {
    "analysis_period": "2026-01-01 to 2026-01-31",
    "filters": { "vehicle": "all", "team": "all", "program": "all" },
    "data_sources": [
      "ford_daisy.analytics.call_data (primary metrics)",
      "dwh_prod.ovprod_o.verint_transcription (teams/locations)", 
      "text_analytics.nlp_analytics.call_data (performance)",
      "text_analytics.nlp_analytics.sentiments (detailed sentiment)",
      "text_analytics.nlp_analytics.topic_xwalk (topics)",
      "text_analytics.nlp_configs.topic_detail (topic hierarchy)",
      "text_analytics.nlp_analytics.parts_unfiltered (parts/features)"
    ]
  },
  "hourly_analysis": [
    {
      "hour_of_day": 14,
      "time_label": "2:00 PM - 2:59 PM", 
      "total_calls": 8450,
      "pct_of_daily_volume": 12.5,
      "avg_handle_time_minutes": 11.8,
      "aht_category": "Average",
      "avg_complexity": 22.4,
      "avg_sentiment": 0.1254,
      "avg_nps": 4.2,
      "avg_fcr": 1.32,
      "avg_customer_sentiment": -0.0523,
      "avg_agent_sentiment": 0.2145,
      "sentiment_category": "Neutral",
      "transfer_rate_pct": 8.5,
      "transfer_category": "Normal Transfers",
      "business_period": "Afternoon Peak",
      "staffing_recommendation": "High Staffing Needed",
      "top_issues": [
        {"issue_type": "FordPass", "issue_count": 1250, "pct_of_hour_calls": 14.8}
      ]
    }
  ],
  "insights": {
    "peak_volume_hour": {
      "hour": 14,
      "time_label": "2:00 PM - 2:59 PM", 
      "call_count": 8450,
      "pct_of_daily_volume": 12.5
    },
    "best_performance_hour": {
      "hour": 8,
      "time_label": "8:00 AM - 8:59 AM",
      "avg_handle_time_minutes": 9.2
    },
    "peak_hours_for_staffing": [
      {"hour": 13, "time_label": "1:00 PM - 1:59 PM", "staffing_recommendation": "High Staffing Needed"},
      {"hour": 14, "time_label": "2:00 PM - 2:59 PM", "staffing_recommendation": "High Staffing Needed"}
    ]
  }
}
```

## Example calls

```bash
# Overall hourly analysis for January
python .claude/skills/hour_of_day/scripts/hour_of_day.py --from 2026-01-01 --to 2026-01-31

# Vehicle-specific hourly patterns  
python .claude/skills/hour_of_day/scripts/hour_of_day.py --from 2026-01-01 --to 2026-01-31 --vehicle "F-150"

# Team workload by hour
python .claude/skills/hour_of_day/scripts/hour_of_day.py --from 2026-01-01 --to 2026-01-31 --team "Technical"

# Staffing focus analysis
python .claude/skills/hour_of_day/scripts/hour_of_day.py --from 2026-01-01 --to 2026-01-31 --analysis-type staffing

# Issues breakdown by hour
python .claude/skills/hour_of_day/scripts/hour_of_day.py --from 2026-01-01 --to 2026-01-31 --analysis-type issues
```

## Key Insights Provided

### **[DATA] Volume & Staffing**
- Peak call hours with staffing recommendations
- Volume distribution across 24 hours  
- Business period classification (Morning Peak, Afternoon Peak, Evening, Off Hours)

### **[FAST] Performance Patterns**
- AHT variations by hour (Fast/Average/Slow categories)
- Complexity distribution throughout the day
- Transfer rate patterns and problem hours

### **😊 Quality Variations**  
- Customer sentiment by hour (Positive/Neutral/Negative)
- NPS and FCR performance across hours
- Agent sentiment patterns

### **[SEARCH] Issue Analysis**
- Top issues by hour with prevalence percentages
- Which problems occur at which times
- Issue-specific sentiment and AHT patterns

## Error output
If something goes wrong, the script prints `{"error": "..."}` to stderr and exits with code 1.

## Notes
- **Multi-source integration**: Uses 7 data sources for comprehensive hourly insights
- **Privacy protection**: NO AGENT NAMES revealed (team-level analysis only)  
- **Sufficient data**: Default limit 10 calls/hour ensures reliable statistics
- **Staffing optimization**: Provides specific recommendations for workforce planning
- **Issue tracking**: Identifies when specific problems peak for proactive management
- Best used for operational planning, staffing decisions, and quality improvement initiatives
