---
description: >
  Analyzes customer satisfaction, sentiment scores, NPS, positive feedback,
  what went well, customer delight, frustration levels, defection risk,
  first call resolution (FCR), and agent vs customer sentiment comparisons.
  Use for "sentiment", "what went well", "delight", "positive feedback",
  "NPS", "defection", "frustrated", "upset customers", "customer satisfaction",
  "differences in sentiment", "FCR", "resolution rate".

routing_examples:
  - question: "What went well yesterday?"
    reason: "Tricky — no sentiment word but IS positive sentiment, not vehicle_agent"
  - question: "What favorable feedback has been received?"
    reason: "Tricky phrasing — 'favorable feedback' = positive sentiment, not vehicle_agent"
  - question: "What have customers been happy about?"
    reason: "Positive sentiment — goes here not vehicle_agent even though no 'sentiment' keyword"
  - question: "Which vehicle model has the highest defection rate?"
    reason: "Defection = satisfaction metric — goes here not vehicle_agent"
  - question: "What is the customers sentiment when they learn their buyback request has been denied?"
    reason: "Counter-example: has 'buyback' but is asking about SENTIMENT, not flags"
  - question: "Daisy, show me differences in sentiment between agents and customers when discussing charging failures"
    reason: "Agent vs customer sentiment — goes here not operations_agent"

skills:
  sentiment_deep_dive: "Overall sentiment analysis, satisfaction levels, negative themes, what frustrates customers"
  positive_feedback: "What is working well, customer praise, delights, happy experiences, favorable feedback"
  resolution_analysis: "First call resolution (FCR), whether issues got resolved, resolution effectiveness"
  sentiment_by_vehicle: "Sentiment analysis for a specific vehicle model"
  nps_trend: "Net Promoter Score trends over time"
  agent_customer_sentiment: "Compare agent sentiment vs customer sentiment on the same calls"
  data_discovery: "Schema and available fields"

stage2_prompt: |
  You are selecting the best skill for a SENTIMENT question in Ford's CRC analytics tool (called Daisy).

  Available skills:
  - sentiment_deep_dive: Overall sentiment, negative themes, frustration, what upsets or angers customers
  - positive_feedback: What is working well, customer praise, delights, happy experiences, favorable feedback
  - resolution_analysis: First call resolution (FCR), whether issues got resolved, resolution rate
  - sentiment_by_vehicle: Sentiment analysis for a specific vehicle model
  - nps_trend: Net Promoter Score trends over time
  - agent_customer_sentiment: Compare agent sentiment vs customer sentiment on the same calls
  - data_discovery: What sentiment data is available, schema, fields, date range

  Decision rules (apply in order):
  1. "What data" / "what is available" / "what fields" / "schema" / "what do you have" -> data_discovery  (check FIRST — before catch-all rule)
  2. "What went well" / "delight" / "positive" / "happy" / "praise" / "favorable" / "what customers like" -> positive_feedback
  3. "Negative sentiment" / "frustration" / "upset" / "angry" / "defection" / "bad sentiment" / "most negative" / "driving negative" -> sentiment_deep_dive
  4. "FCR" / "first call resolution" / "resolution" / "resolved" -> resolution_analysis
  5. "NPS" / "net promoter" -> nps_trend
  6. "Agent vs customer" / "difference in sentiment" / "compare agent and customer sentiment" -> agent_customer_sentiment
  7. "Sentiment for [vehicle]" / vehicle name + sentiment -> sentiment_by_vehicle
  8. "Sentiment across all vehicle models" / "sentiment by vehicle" / "sentiment for each model" / comparing sentiment across multiple vehicles -> sentiment_by_vehicle
  9. General sentiment question -> sentiment_deep_dive

  Date parsing:
  - "last week" = 7 days ago to today
  - "past month" / "last month" = 30 days ago to today
  - "yesterday" = yesterday to yesterday
  - "April" = 2026-04-01 to 2026-04-30

  Params to extract: vehicle, date_from (YYYY-MM-DD), date_to (YYYY-MM-DD), team, topic (sentiment focus area)

  Return ONLY valid JSON: {"skill": "<skill_name>", "params": {<extracted_params>}, "reason": "<brief>"}
---

# Sentiment Agent

Routes questions about customer satisfaction, NPS, positive feedback, defection risk,
agent vs customer sentiment comparisons, and first call resolution rates.
