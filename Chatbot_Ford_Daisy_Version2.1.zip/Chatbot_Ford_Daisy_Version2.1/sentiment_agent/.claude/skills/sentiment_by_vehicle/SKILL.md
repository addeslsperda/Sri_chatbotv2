---
name: sentiment_by_vehicle
display_name: Comprehensive Sentiment Analysis by Vehicle Model and Year
description: Analyzes customer sentiment segregated by vehicle model and model year with comprehensive search across summaries, topics, cases, parts. Use for "which vehicle model year has worst sentiment", "F-150 2024 vs 2023 sentiment", "charging issues by vehicle", "transmission problems by model year", "sentiment breakdown by vehicle and year".
signals:
  - sentiment by vehicle
  - sentiment by vehicle model
  - sentiment by model year
  - which vehicle has worst sentiment
  - vehicle model year sentiment comparison
  - F-150 2024 sentiment vs 2023
  - Mach-E sentiment by year
  - charging issues by vehicle
  - transmission problems by model
  - sentiment breakdown by vehicle and year
  - negative sentiment by vehicle
  - customer degradation by vehicle model
  - vehicle quality issues sentiment
requires:
  - date range (from and to)
not_good_for: Overall sentiment trends (use sentiment_trend), NPS scores (use nps_trend), agent vs customer comparison (use agent_customer_sentiment)
---

# Comprehensive Sentiment Analysis by Vehicle Model and Year

## What Questions This Skill Answers

### 🚗 **Vehicle Performance Comparison**
- *"Which vehicle model has the worst customer sentiment?"*
- *"Compare sentiment between F-150 2024 vs F-150 2023"*  
- *"Show me sentiment breakdown for all Mustang Mach-E model years"*
- *"Which Ford vehicles are getting the most negative feedback?"*

### 📊 **Model Year Analysis**
- *"Are 2024 models performing worse than 2023 models?"*
- *"What's the sentiment difference between new and older model years?"*
- *"Which model years have the highest customer degradation rates?"*

### 🔍 **Issue-Specific Vehicle Analysis**
- *"Which vehicles have the worst charging-related sentiment?"*
- *"Show me transmission issues by vehicle model and year"*
- *"F-150 buyback sentiment by model year"*
- *"Mach-E battery problems by model year"*

### 📈 **Quality & Severity Assessment**
- *"Which vehicle-year combinations are CRITICAL priority?"*
- *"Show me vehicles with highest customer degradation rates"*
- *"Which models have the worst sentiment gaps with agents?"*

## How This Script Works

Segregates sentiment analysis by **both vehicle model AND model year** with comprehensive search across:
- **Call summaries**: Full AI-generated call content
- **Topic levels**: All 3 topic classification levels  
- **Case classifications**: All 3 case hierarchy levels
- **Parts information**: Both parts features and concerns
- **Contextual data**: Teams, programs, complexity, outcomes

Returns vehicle-year combinations with detailed sentiment metrics, issue patterns, and severity indicators.

## How to Run It

```bash
# Basic vehicle sentiment analysis by model and year
python .claude/skills/sentiment_by_vehicle/scripts/sentiment_by_vehicle.py --from 2026-01-01 --to 2026-12-31

# Compare specific vehicle models
python .claude/skills/sentiment_by_vehicle/scripts/sentiment_by_vehicle.py --from 2026-01-01 --to 2026-12-31 --vehicle "F-150"

# Analyze specific model year
python .claude/skills/sentiment_by_vehicle/scripts/sentiment_by_vehicle.py --from 2026-01-01 --to 2026-12-31 --model-year 2024

# Search for charging issues by vehicle
python .claude/skills/sentiment_by_vehicle/scripts/sentiment_by_vehicle.py --from 2026-01-01 --to 2026-12-31 --search "charging"

# Find critical severity vehicles only
python .claude/skills/sentiment_by_vehicle/scripts/sentiment_by_vehicle.py --from 2026-01-01 --to 2026-12-31 --severity CRITICAL

# Analyze transmission problems by vehicle-year  
python .claude/skills/sentiment_by_vehicle/scripts/sentiment_by_vehicle.py --from 2026-01-01 --to 2026-12-31 --search "transmission"
```

## Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--from` | Yes | — | Start date YYYY-MM-DD |
| `--to` | Yes | — | End date YYYY-MM-DD |
| `--search` | No | — | Search keyword across summaries, topics, cases, parts (e.g., "charging", "transmission", "buyback") |
| `--vehicle` | No | all | Filter by vehicle model (e.g., "F-150", "Mach-E", "Bronco") |
| `--model-year` | No | all | Filter by model year (e.g., "2024", "2023") |
| `--severity` | No | all | Filter by severity level: CRITICAL, HIGH, MEDIUM, LOW |
| `--min-calls` | No | 5 | Minimum call count to include a vehicle-year combination |
| `--limit` | No | 1000 | Maximum number of vehicle-year results to return |

## Search Capabilities

The script searches across these 9 data sources simultaneously:

### Call Content
1. **call_summary**: Full AI-generated call summaries

### Topic Classification (3 levels)  
2. **topic_level1**: Broadest topic category
3. **topic_level2**: Mid-level topic classification
4. **topic_level3**: Most specific topic details

### Case Classification (3 levels)
5. **caseclassificationlevel1**: High-level case category
6. **caseclassificationlevel2**: Detailed case classification  
7. **caseclassificationlevel3**: Specific case subcategory

### Parts Information (2 fields)
8. **parts_features**: Vehicle parts and features mentioned
9. **parts_concern**: Specific parts concerns and issues

## Example Usage Scenarios

### 1. Vehicle Model Comparison
```bash
python sentiment_by_vehicle.py --from 2026-01-01 --to 2026-12-31 --limit 10
```
**Finds**: Top 10 worst-performing vehicle-year combinations
**Use case**: *"Which vehicle models need immediate attention?"*

### 2. Charging Infrastructure by Vehicle
```bash
python sentiment_by_vehicle.py --from 2026-01-01 --to 2026-12-31 --search "charging" --vehicle "Mach-E"
```
**Finds**: Mach-E charging sentiment by model year
**Use case**: *"How do charging issues affect Mach-E sentiment across model years?"*

### 3. F-150 Model Year Analysis  
```bash
python sentiment_by_vehicle.py --from 2026-01-01 --to 2026-12-31 --vehicle "F-150" --model-year 2024
```
**Finds**: 2024 F-150 specific sentiment analysis
**Use case**: *"Are 2024 F-150s performing worse than previous years?"*

### 4. Critical Issues Identification
```bash
python sentiment_by_vehicle.py --from 2026-01-01 --to 2026-12-31 --severity CRITICAL --search "buyback"
```
**Finds**: Critical vehicles with buyback-related sentiment issues
**Use case**: *"Which vehicle-year combinations have critical buyback sentiment?"*

### 5. Transmission Problems Analysis
```bash
python sentiment_by_vehicle.py --from 2026-01-01 --to 2026-12-31 --search "transmission"
```
**Finds**: Vehicles with transmission-related sentiment issues  
**Use case**: *"Which vehicles have transmission problems affecting sentiment?"*

## Output Format

```json
{
  "metadata": {
    "query_info": {
      "date_range": "2026-01-01 to 2026-12-31",
      "search_term": "charging",
      "vehicle_filter": "Mach-E",
      "model_year_filter": null,
      "min_calls": 5,
      "result_count": 3,
      "search_sources": [
        "call_summary (full text)",
        "topic_level1", "topic_level2", "topic_level3",
        "caseclassificationlevel1", "caseclassificationlevel2", "caseclassificationlevel3",
        "parts_features", "parts_concern"
      ]
    }
  },
  "results": [
    {
      "vehicle_model": "MUSTANG MACH-E",
      "model_year": "2024",
      "vehicle_model_year": "MUSTANG MACH-E - 2024",
      "total_calls": 156,
      "calls_with_summaries": 142,
      "avg_customer_sentiment": -0.23,
      "avg_agent_sentiment": 0.45,
      "avg_sentiment_gap": -0.68,
      "avg_customer_start_sentiment": -0.15,
      "avg_customer_end_sentiment": -0.31,
      "avg_customer_sentiment_change": -0.16,
      "positive_calls": 23,
      "negative_calls": 105,
      "neutral_calls": 28,
      "negative_percentage": 67.31,
      "customers_improved": 12,
      "customers_degraded": 89,
      "customers_stable": 55,
      "degradation_percentage": 57.05,
      "high_gap_calls": 98,
      "moderate_gap_calls": 45,
      "low_gap_calls": 13,
      "high_gap_percentage": 62.82,
      "avg_complexity_score": 8.5,
      "high_complexity_calls": 78,
      "medium_complexity_calls": 56,
      "low_complexity_calls": 22,
      "confidence_level": "High Confidence",
      "severity_level": "CRITICAL"
    }
  ]
}
```

## Severity Levels

**CRITICAL**: Average customer end sentiment < -0.3 AND ≥30 calls  
**HIGH**: Average customer end sentiment < -0.1 AND ≥20 calls  
**MEDIUM**: Average customer end sentiment < 0.1 AND ≥10 calls  
**LOW**: All other combinations

## Business Value

1. **Product Quality Monitoring**: Identify specific model years with quality issues
2. **Issue Prioritization**: Focus resources on critical vehicle-year combinations  
3. **Model Year Comparison**: Compare performance across different model years
4. **Feature-Specific Analysis**: Track how specific issues (charging, transmission) affect different vehicles
5. **Customer Experience**: Understand which vehicles are causing the most customer frustration
6. **Proactive Intervention**: Address issues before they become widespread quality problems

## Data Sources Used

- **text_analytics.nlp_analytics.sentiments**: Primary sentiment scores
- **text_analytics.nlp_analytics.call_data**: Call details and sentiment journey  
- **text_analytics.nlp_agent.call_summary_qwen06b**: Full call summaries
- **text_analytics.nlp_analytics.call_table**: Agent team information
- **text_analytics.nlp_analytics.models**: Vehicle model and year details (critical for segregation)
- **text_analytics.nlp_dashboard.case_metadata**: Case classifications (3 levels)
- **text_analytics.nlp_analytics.topic_xwalk**: Topic assignments
- **text_analytics.nlp_configs.topic_detail**: Topic hierarchy (3 levels)  
- **text_analytics.nlp_analytics.parts_unfiltered**: Parts and features data

## Error Handling
- Returns empty result set if no vehicle-year combinations match criteria
- Handles missing model year data gracefully
- Validates date ranges and parameters
- Provides clear error messages for invalid inputs
- Filters out low-confidence results automatically
