"""
Comprehensive Sentiment Analysis by Vehicle Model and Year

Analyzes customer sentiment segregated by vehicle model and model year with comprehensive search
capabilities across summaries, topics, cases, parts, and contextual data.

Usage:
    python sentiment_by_vehicle.py --from 2026-01-01 --to 2026-12-31
    python sentiment_by_vehicle.py --from 2026-01-01 --to 2026-12-31 --search "transmission"
    python sentiment_by_vehicle.py --from 2026-01-01 --to 2026-12-31 --vehicle "F-150" --model-year 2024
    python sentiment_by_vehicle.py --from 2026-01-01 --to 2026-12-31 --search "charging" --min-calls 20

Output: JSON array with vehicle-year combinations sorted by worst sentiment first
"""
import argparse
import json
import os
import sys
from decimal import Decimal
from pathlib import Path
from databricks import sql
import requests
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parents[5] / ".env", override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


CATALOG = os.environ.get("DATABRICKS_CATALOG", "text_analytics")
SCHEMA = os.environ.get("DATABRICKS_SCHEMA", "nlp_analytics")
CALL_DATA = f"{CATALOG}.{SCHEMA}.call_data"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--from", dest="date_from", required=True)
    parser.add_argument("--to", dest="date_to", required=True)
    parser.add_argument("--search", dest="search_term", default=None,
                        help="Search keyword across summaries, topics, cases, parts")
    parser.add_argument("--vehicle", dest="vehicle", default=None,
                        help="Filter by vehicle model (e.g., F-150, Mach-E)")
    parser.add_argument("--model-year", dest="model_year", default=None,
                        help="Filter by model year (e.g., 2024, 2023)")
    parser.add_argument("--min-calls", dest="min_calls", type=int, default=5,
                        help="Minimum call count to include a vehicle-year (default: 5)")
    parser.add_argument("--limit", type=int, default=1000,
                        help="Maximum number of vehicle-year combinations to return")
    parser.add_argument("--severity", dest="severity", default=None,
                        help="Filter by severity level: CRITICAL, HIGH, MEDIUM, LOW")
    args, _ = parser.parse_known_args()

    # Build parameters
    params = {
        "date_from": args.date_from,
        "date_to": args.date_to,
        "min_calls": args.min_calls
    }

    # Base WHERE conditions
    where_conditions = [
        "DATE(cd.call_date) >= :date_from",
        "DATE(cd.call_date) <= :date_to",
        "s.customer_sentiment IS NOT NULL",
        "cd.cust_end_sent IS NOT NULL"
    ]

    # Add search filter across all 9 sources
    if args.search_term:
        search_conditions = [
            # Call summaries (full text search)
            "LOWER(cs.summary) LIKE LOWER(:search_pattern)",
            # Topic levels (all 3 levels)
            "LOWER(td.topic_level1) LIKE LOWER(:search_pattern)",
            "LOWER(td.topic_level2) LIKE LOWER(:search_pattern)",
            "LOWER(td.topic_level3) LIKE LOWER(:search_pattern)",
            # Case classification levels (all 3 levels)
            "LOWER(cm.caseclassificationlevel1) LIKE LOWER(:search_pattern)",
            "LOWER(cm.caseclassificationlevel2) LIKE LOWER(:search_pattern)",
            "LOWER(cm.caseclassificationlevel3) LIKE LOWER(:search_pattern)",
            # Parts information (both fields)
            "LOWER(pf.parts_features) LIKE LOWER(:search_pattern)",
            "LOWER(pf.parts_concern) LIKE LOWER(:search_pattern)"
        ]
        where_conditions.append(f"({' OR '.join(search_conditions)})")
        params["search_pattern"] = f"%{args.search_term}%"

    # Add vehicle filter
    if args.vehicle:
        where_conditions.append("LOWER(COALESCE(m.ModelVehicleLine, cd.modelvehicleline)) LIKE LOWER(:vehicle_pattern)")
        params["vehicle_pattern"] = f"%{args.vehicle}%"

    # Add model year filter
    if args.model_year:
        where_conditions.append("COALESCE(m.Model_Year, '') LIKE :model_year_pattern")
        params["model_year_pattern"] = f"%{args.model_year}%"

    where_clause = " AND ".join(where_conditions)

    # Build comprehensive query with model-year segregation
    query = f"""
    -- SENTIMENT BY VEHICLE MODEL AND YEAR WITH COMPREHENSIVE ANALYSIS
    -- Segregated by model year and vehicle model for detailed analysis

    SELECT
        -- === VEHICLE IDENTIFICATION (SEGREGATED BY MODEL & YEAR) ===
        COALESCE(m.ModelVehicleLine, cd.modelvehicleline, 'Unknown Vehicle') AS vehicle_model,
        COALESCE(m.Model_Year, 'Unknown Year') AS model_year,
        CONCAT(COALESCE(m.ModelVehicleLine, cd.modelvehicleline, 'Unknown Vehicle'), ' - ', COALESCE(m.Model_Year, 'Unknown Year')) AS vehicle_model_year,

        -- === CALL VOLUME METRICS ===
        COUNT(DISTINCT s.call_id) AS total_calls,
        COUNT(DISTINCT CASE WHEN cs.summary IS NOT NULL THEN s.call_id END) AS calls_with_summaries,

        -- === PRIMARY SENTIMENT METRICS ===
        ROUND(AVG(s.customer_sentiment), 4) AS avg_customer_sentiment,
        ROUND(AVG(s.agent_sentiment), 4) AS avg_agent_sentiment,
        ROUND(AVG(s.overall_sentiment), 4) AS avg_overall_sentiment,
        ROUND(AVG(s.customer_sentiment - s.agent_sentiment), 4) AS avg_sentiment_gap,

        -- === SENTIMENT JOURNEY ANALYSIS ===
        ROUND(AVG(cd.cust_beg_sent), 4) AS avg_customer_start_sentiment,
        ROUND(AVG(cd.cust_end_sent), 4) AS avg_customer_end_sentiment,
        ROUND(AVG(cd.cust_end_sent - cd.cust_beg_sent), 4) AS avg_customer_sentiment_change,
        ROUND(AVG(cd.agent_beg_sent), 4) AS avg_agent_start_sentiment,
        ROUND(AVG(cd.agent_end_sent), 4) AS avg_agent_end_sentiment,
        ROUND(AVG(cd.agent_end_sent - cd.agent_beg_sent), 4) AS avg_agent_sentiment_change,

        -- === SENTIMENT DISTRIBUTION ===
        SUM(CASE WHEN cd.sentiment_label = 'Positive' THEN 1 ELSE 0 END) AS positive_calls,
        SUM(CASE WHEN cd.sentiment_label = 'Negative' THEN 1 ELSE 0 END) AS negative_calls,
        SUM(CASE WHEN cd.sentiment_label = 'Neutral' THEN 1 ELSE 0 END) AS neutral_calls,
        ROUND(100.0 * SUM(CASE WHEN cd.sentiment_label = 'Negative' THEN 1 ELSE 0 END) / COUNT(*), 2) AS negative_percentage,

        -- === CUSTOMER OUTCOME ANALYSIS ===
        SUM(CASE WHEN cd.cust_end_sent - cd.cust_beg_sent > 0.2 THEN 1 ELSE 0 END) AS customers_improved,
        SUM(CASE WHEN cd.cust_end_sent - cd.cust_beg_sent < -0.2 THEN 1 ELSE 0 END) AS customers_degraded,
        SUM(CASE WHEN cd.cust_end_sent - cd.cust_beg_sent BETWEEN -0.2 AND 0.2 THEN 1 ELSE 0 END) AS customers_stable,
        ROUND(100.0 * SUM(CASE WHEN cd.cust_end_sent - cd.cust_beg_sent < -0.2 THEN 1 ELSE 0 END) / COUNT(*), 2) AS degradation_percentage,

        -- === SENTIMENT GAP CATEGORIES ===
        SUM(CASE WHEN ABS(s.customer_sentiment - s.agent_sentiment) > 0.3 THEN 1 ELSE 0 END) AS high_gap_calls,
        SUM(CASE WHEN ABS(s.customer_sentiment - s.agent_sentiment) BETWEEN 0.1 AND 0.3 THEN 1 ELSE 0 END) AS moderate_gap_calls,
        SUM(CASE WHEN ABS(s.customer_sentiment - s.agent_sentiment) <= 0.1 THEN 1 ELSE 0 END) AS low_gap_calls,
        ROUND(100.0 * SUM(CASE WHEN ABS(s.customer_sentiment - s.agent_sentiment) > 0.3 THEN 1 ELSE 0 END) / COUNT(*), 2) AS high_gap_percentage,

        -- === COMPLEXITY METRICS ===
        ROUND(AVG(cd.complexity), 4) AS avg_complexity_score,
        SUM(CASE WHEN cd.complexity_label = 'High' THEN 1 ELSE 0 END) AS high_complexity_calls,
        SUM(CASE WHEN cd.complexity_label = 'Medium' THEN 1 ELSE 0 END) AS medium_complexity_calls,
        SUM(CASE WHEN cd.complexity_label = 'Low' THEN 1 ELSE 0 END) AS low_complexity_calls,

        -- === CONFIDENCE & QUALITY METRICS ===
        CASE
            WHEN COUNT(DISTINCT s.call_id) >= 100 THEN 'High Confidence'
            WHEN COUNT(DISTINCT s.call_id) >= 30 THEN 'Medium Confidence'
            ELSE 'Low Confidence'
        END AS confidence_level,

        -- === SEVERITY INDICATORS ===
        CASE
            WHEN AVG(cd.cust_end_sent) < -0.3 AND COUNT(*) >= 30 THEN 'CRITICAL'
            WHEN AVG(cd.cust_end_sent) < -0.1 AND COUNT(*) >= 20 THEN 'HIGH'
            WHEN AVG(cd.cust_end_sent) < 0.1 AND COUNT(*) >= 10 THEN 'MEDIUM'
            ELSE 'LOW'
        END AS severity_level

    FROM {CATALOG}.{SCHEMA}.sentiments s

        -- === CORE JOINS ===
        INNER JOIN {CATALOG}.{SCHEMA}.call_data cd ON s.call_id = cd.call_id

        -- === CALL SUMMARIES ===
        LEFT JOIN {CATALOG}.nlp_agent.call_summary_qwen06b cs ON s.call_id = cs.call_id

        -- === TEAM INFORMATION ===
        LEFT JOIN {CATALOG}.{SCHEMA}.call_table ct ON s.call_id = ct.call_id

        -- === VEHICLE MODEL (CRITICAL FOR MODEL/YEAR SEGREGATION) ===
        LEFT JOIN {CATALOG}.{SCHEMA}.models m ON s.call_id = m.call_id

        -- === CASE CLASSIFICATION ===
        LEFT JOIN {CATALOG}.nlp_dashboard.case_metadata cm ON cd.casenumber = cm.casenumber

        -- === TOPICS ===
        LEFT JOIN {CATALOG}.{SCHEMA}.topic_xwalk tx ON s.call_id = tx.call_id
        LEFT JOIN {CATALOG}.nlp_configs.topic_detail td ON tx.topic_id = td.topic_id

        -- === PARTS ===
        LEFT JOIN {CATALOG}.{SCHEMA}.parts_unfiltered pf ON s.call_id = pf.call_id

    WHERE {where_clause}

    GROUP BY
        -- SEGREGATE BY BOTH MODEL AND YEAR
        COALESCE(m.ModelVehicleLine, cd.modelvehicleline, 'Unknown Vehicle'),
        COALESCE(m.Model_Year, 'Unknown Year')

    HAVING
        -- Minimum call threshold for statistical significance
        COUNT(DISTINCT s.call_id) >= :min_calls

    ORDER BY
        -- Sort by worst performing model-year combinations first
        avg_customer_end_sentiment ASC,
        avg_sentiment_gap DESC,
        negative_percentage DESC,
        total_calls DESC

    LIMIT {args.limit}
    """

    try:
        with get_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(query, params)
                rows = cursor.fetchall()
                columns = [d[0] for d in cursor.description]

        def serialize(v):
            if isinstance(v, Decimal): return float(v)
            if hasattr(v, "isoformat"): return str(v)
            return v

        result = [dict(zip(columns, [serialize(val) for val in row])) for row in rows]

        # Add metadata
        metadata = {
            "query_info": {
                "date_range": f"{args.date_from} to {args.date_to}",
                "search_term": args.search_term,
                "vehicle_filter": args.vehicle,
                "model_year_filter": args.model_year,
                "severity_filter": args.severity,
                "min_calls": args.min_calls,
                "result_count": len(result),
                "search_sources": [
                    "call_summary (full text)",
                    "topic_level1", "topic_level2", "topic_level3",
                    "caseclassificationlevel1", "caseclassificationlevel2", "caseclassificationlevel3",
                    "parts_features", "parts_concern"
                ] if args.search_term else []
            }
        }

        # Apply severity filter if specified
        if args.severity:
            result = [r for r in result if r.get('severity_level') == args.severity.upper()]
            metadata["query_info"]["filtered_by_severity"] = len(result)

        output = {
            "metadata": metadata,
            "results": result
        }

        print(json.dumps(output, indent=2))

    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)
