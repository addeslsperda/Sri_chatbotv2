---
name: data_discovery
display_name: Comprehensive Data Discovery for Ford CRC Analytics
description: Complete discovery of all available data dimensions across the Ford CRC analytics database including dates, vehicles, teams, programs, topics, cases, parts, and data quality metrics. Always use this FIRST when queries return no results, when exploring what data exists, or when searching for specific terms across all dimensions.
signals:
  - what data do you have
  - what data is available
  - what date range
  - what vehicles are available
  - what teams exist
  - what programs are available
  - what topics are covered
  - no results
  - check available data
  - what is in the database
  - latest date
  - earliest date
  - search for BEV
  - search for Ford Pro
  - data quality
  - data coverage
requires: []
not_good_for: Actual sentiment/NPS analysis - use this only to discover what data exists before running analysis skills
---

# Comprehensive Data Discovery for Ford CRC Analytics

## What Questions This Skill Answers

### **Data Availability Questions**
- *"What data do you have access to?"*
- *"What is the date range you're referencing?"*
- *"What is the latest call date you have access to?"*
- *"What time period is this data from?"*
- *"What is the earliest and latest records in this analysis?"*

### **Vehicle Discovery Questions**
- *"What vehicles are available in the database?"*
- *"What vehicle models have the most calls?"*
- *"Can you provide a count by vehicle line?"*
- *"What model years are available?"*

### **Team & Program Discovery Questions**
- *"What teams are available?"*
- *"What BEV teams exist?"*
- *"What Ford Pro programs are there?"*
- *"Which teams handle the most calls?"*

### **Content Discovery Questions**
- *"What topics are covered in the data?"*
- *"What case types exist?"*
- *"What parts and features are mentioned?"*
- *"Search for charging across all dimensions"*
- *"Find all mentions of transmission"*

### **Data Quality Questions**
- *"How complete is the data?"*
- *"What percentage of calls have sentiment data?"*
- *"Data coverage and quality metrics"*

## How This Script Works

Provides **comprehensive discovery** across all Ford CRC analytics dimensions:

### **🗓️ Date & Temporal Discovery**
- Date ranges and temporal coverage
- Call volumes by time period
- Recent activity metrics
- Year-over-year data availability

### **🚗 Vehicle Discovery**
- Complete vehicle model and year combinations
- Call volumes by vehicle-year
- Vehicle data coverage and completeness

### **👥 Team & Program Discovery**
- All agent teams and their call volumes
- Program names and classifications
- Team performance and coverage

### **📋 Topic & Case Discovery**
- Complete topic hierarchies (3 levels)
- Case classification systems (3 levels)
- Content categorization and coverage

### **🔧 Parts & Features Discovery**
- All parts and features mentioned in calls
- Parts concerns and issues
- Technical component coverage

### **📊 Data Quality Metrics**
- Coverage percentages for all data dimensions
- Data completeness and quality indicators
- Missing data analysis

### **🔍 Cross-Dimensional Search**
- Search any term across all dimensions simultaneously
- Find teams, programs, vehicles, topics containing search terms
- Comprehensive content discovery

## How to Run It

```bash
# Complete comprehensive discovery (all dimensions)
python .claude/skills/data_discovery/scripts/data_discovery.py

# Specific dimension discovery
python .claude/skills/data_discovery/scripts/data_discovery.py --check dates
python .claude/skills/data_discovery/scripts/data_discovery.py --check vehicles
python .claude/skills/data_discovery/scripts/data_discovery.py --check teams
python .claude/skills/data_discovery/scripts/data_discovery.py --check topics
python .claude/skills/data_discovery/scripts/data_discovery.py --check cases
python .claude/skills/data_discovery/scripts/data_discovery.py --check parts
python .claude/skills/data_discovery/scripts/data_discovery.py --check quality

# Cross-dimensional search
python .claude/skills/data_discovery/scripts/data_discovery.py --search "BEV"
python .claude/skills/data_discovery/scripts/data_discovery.py --search "Ford Pro"
python .claude/skills/data_discovery/scripts/data_discovery.py --search "charging"
python .claude/skills/data_discovery/scripts/data_discovery.py --search "transmission"
```

## Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--check` | No | `all` | Discovery scope: `all`, `dates`, `vehicles`, `teams`, `topics`, `cases`, `parts`, `quality` |
| `--search` | No | - | Search term to find across all dimensions (teams, programs, vehicles, topics) |

## Discovery Dimensions

### **🗓️ Dates Discovery (`--check dates`)**
```json
{
  "dates": {
    "min_date": "2024-01-01",
    "max_date": "2026-12-31", 
    "total_calls": 1847293,
    "unique_days": 730,
    "calls_last_30_days": 45821,
    "calls_last_7_days": 12043,
    "calls_by_year": {
      "2026": 234567,
      "2025": 892341,
      "2024": 720385
    }
  }
}
```

### **🚗 Vehicles Discovery (`--check vehicles`)**
```json
{
  "vehicles": [
    {
      "vehicle_model": "F-150",
      "model_year": "2024",
      "call_count": 48221,
      "unique_calls": 48221,
      "earliest_call": "2024-01-02",
      "latest_call": "2026-12-30"
    }
  ]
}
```

### **👥 Teams & Programs Discovery (`--check teams`)**
```json
{
  "teams_programs": {
    "teams": [
      {
        "agent_team": "FM-MSS-CRC-Houston-5508-BEV-Team",
        "call_count": 15234,
        "unique_calls": 15234,
        "earliest_call": "2024-01-01",
        "latest_call": "2026-12-31"
      }
    ],
    "programs": [
      {
        "program_name": "Ford Pro Charging Model E - US", 
        "call_count": 8932,
        "unique_calls": 8932,
        "earliest_call": "2024-03-15",
        "latest_call": "2026-12-28"
      }
    ]
  }
}
```

### **📋 Topics Discovery (`--check topics`)**
```json
{
  "topics": [
    {
      "topic_broad": "Vehicle Maintenance and Support",
      "topic_mid": "Charging and Energy Management",
      "topic_specific": "Public charging station issues and troubleshooting",
      "topic_category": "naive_processing",
      "call_count": 12456,
      "earliest_call": "2024-01-01",
      "latest_call": "2026-12-31"
    }
  ]
}
```

### **📊 Data Quality Discovery (`--check quality`)**
```json
{
  "data_quality": {
    "total_unique_calls": 1847293,
    "total_cases": 1234567,
    "data_coverage": {
      "sentiment": {
        "calls_with_data": 1678543,
        "coverage_percentage": 90.86
      },
      "summaries": {
        "calls_with_data": 1798234,
        "coverage_percentage": 97.34
      },
      "nps": {
        "calls_with_data": 456789,
        "coverage_percentage": 24.73
      },
      "vehicle": {
        "calls_with_data": 1598234,
        "coverage_percentage": 86.52
      },
      "team": {
        "calls_with_data": 1834567,
        "coverage_percentage": 99.31
      }
    }
  }
}
```

### **🔍 Cross-Dimensional Search (`--search "BEV"`)**
```json
{
  "search_results": [
    {
      "dimension": "Agent Team",
      "value": "FM-MSS-CRC-Houston-5508-BEV-Team", 
      "call_count": 15234
    },
    {
      "dimension": "Program Name",
      "value": "BEV Support - Inbound",
      "call_count": 8932
    },
    {
      "dimension": "Vehicle Model", 
      "value": "F-150 Lightning",
      "call_count": 23456
    },
    {
      "dimension": "Topic Level 1",
      "value": "BEV Infrastructure and Support", 
      "call_count": 18765
    }
  ]
}
```

## Example Usage Scenarios

### 1. Complete Data Discovery
```bash
python data_discovery.py
```
**Use case**: *"What data do you have access to?"* - Get comprehensive overview of all available data

### 2. Date Range Validation
```bash  
python data_discovery.py --check dates
```
**Use case**: *"What is the latest call date you have?"* - Validate date ranges before analysis

### 3. Vehicle Model Discovery
```bash
python data_discovery.py --check vehicles
```  
**Use case**: *"What vehicles are available?"* - Find correct vehicle names and model years

### 4. BEV Team Discovery
```bash
python data_discovery.py --search "BEV"
```
**Use case**: *"What BEV teams exist?"* - Find all BEV-related teams, programs, and data

### 5. Ford Pro Program Discovery  
```bash
python data_discovery.py --search "Ford Pro"
```
**Use case**: *"What Ford Pro programs are there?"* - Discover Ford Pro teams and programs

### 6. Charging Infrastructure Discovery
```bash
python data_discovery.py --search "charging"  
```
**Use case**: *"Find all charging-related data"* - Comprehensive charging content discovery

### 7. Data Quality Assessment
```bash
python data_discovery.py --check quality
```
**Use case**: *"How complete is the data?"* - Assess data coverage and quality metrics

## Business Value

1. **Query Validation**: Validate date ranges, vehicle names, team names before analysis
2. **Content Discovery**: Find what topics, cases, parts are available for analysis  
3. **Team Discovery**: Identify all agent teams and programs for targeted analysis
4. **Data Quality**: Assess data completeness and coverage before making decisions
5. **Search Capability**: Quickly find all data related to specific terms or concepts
6. **Onboarding**: Help new users understand what data dimensions are available

## Data Sources Used

- **text_analytics.nlp_analytics.call_data**: Primary call records and metadata
- **text_analytics.nlp_analytics.sentiments**: Sentiment data coverage  
- **text_analytics.nlp_agent.call_summary_qwen06b**: Call summary coverage
- **text_analytics.nlp_analytics.call_table**: Agent team information
- **text_analytics.nlp_analytics.models**: Vehicle model and year data
- **text_analytics.nlp_dashboard.case_metadata**: Case classifications  
- **text_analytics.nlp_analytics.topic_xwalk**: Topic assignments
- **text_analytics.nlp_configs.topic_detail**: Topic hierarchy details
- **text_analytics.nlp_analytics.parts_unfiltered**: Parts and features data

## Error Handling
- Returns empty result sets gracefully when no data matches criteria
- Handles missing data with appropriate labels and coverage metrics
- Provides clear error messages for database connection issues
- Validates search terms and dimension parameters
- Includes data quality indicators in all discovery results
