---
name: resolution_analysis
display_name: Comprehensive First Call Resolution Analysis with Intelligent Team Detection
description: Advanced FCR analysis with intelligent team/program detection for "calls" queries, comprehensive search across summaries/topics/cases/parts, resolution pattern discovery, and team performance analysis. Use for "BEV calls FCR", "Ford Pro resolution rates", "charging resolution analysis", "FCR by team", "resolution performance optimization".
signals:
  - first call resolution
  - FCR
  - resolution rate
  - resolved on first call
  - call resolution
  - is the issue getting resolved
  - how often are issues fixed first try
  - BEV calls FCR
  - Ford Pro resolution
  - charging resolution analysis
  - FCR by team
  - resolution performance
  - team resolution excellence
  - why cases not resolved
requires:
  - date range (from and to)
not_good_for: Pure sentiment analysis (use sentiment_deep_dive), NPS trends (use nps_trend), positive feedback (use positive_feedback)
---

# Comprehensive First Call Resolution Analysis with Intelligent Team Detection

## What Questions This Skill Answers

### **Team & Program Resolution Performance (Intelligent "Calls" Detection)**
- *"What's the FCR for BEV calls?"*
- *"Ford Pro calls resolution rates"*
- *"How well do truck calls get resolved?"*
- *"Charging calls resolution performance"*
- *"Which teams have the best FCR rates?"*

### **Issue-Specific Resolution Analysis**
- *"Charging resolution success rates"*
- *"Transmission FCR performance"*
- *"BlueCruise resolution patterns"*
- *"Recall resolution effectiveness"*
- *"Buyback request resolution rates"*

### **Resolution Performance Optimization**
- *"Why were cases not resolved by agents?"*
- *"What makes first call resolution successful?"*
- *"Which issues require multiple calls?"*
- *"Resolution training opportunities"*
- *"Team resolution excellence comparison"*

### **Business Intelligence & Training**
- *"FCR correlation with complexity"*
- *"Resolution impact on customer sentiment"*
- *"Simple issues needing multiple calls"*
- *"Resolution patterns by vehicle model"*

## How This Script Works

Provides **comprehensive FCR analysis** with corrected understanding that **FCR=1 is BEST** (not 0-1 scale):
- **FCR Scale**: 1=First Call, 2=Second Call, 3=Third Call, 4+=Multiple Calls
- **Performance**: LOWER FCR values = BETTER resolution performance

**Intelligent search across:**
- **Call summaries**: Full AI-generated call content for resolution context
- **Topic levels**: All 3 topic classification levels for issue identification
- **Case classifications**: All 3 case hierarchy levels for resolution patterns
- **Parts information**: Both parts features and concerns for technical resolution analysis
- **Team data**: Agent teams and program names (prioritized for "calls" queries)
- **Resolution metrics**: FCR correlation with sentiment, complexity, NPS

**Intelligent Team/Program Detection**: When users mention "BEV calls FCR", "Ford Pro resolution", etc., automatically prioritizes searching agent team names and program names.

Returns either **summary analysis** (FCR rates, team comparisons) or **individual call details** with complete resolution context.

## How to Run It

```bash
# Basic FCR analysis
python .claude/skills/resolution_analysis/scripts/resolution_analysis.py --from 2026-01-01 --to 2026-12-31

# Intelligent team detection for "calls" queries
python .claude/skills/resolution_analysis/scripts/resolution_analysis.py --search "BEV calls FCR" --from 2026-01-01 --to 2026-12-31

# Ford Pro resolution performance
python .claude/skills/resolution_analysis/scripts/resolution_analysis.py --search "Ford Pro calls resolution" --from 2026-01-01 --to 2026-12-31

# Issue-specific resolution analysis
python .claude/skills/resolution_analysis/scripts/resolution_analysis.py --search "charging resolution" --vehicle "Mach-E" --from 2026-01-01 --to 2026-12-31

# Team performance comparison
python .claude/skills/resolution_analysis/scripts/resolution_analysis.py --group-by team --from 2026-01-01 --to 2026-12-31

# Vehicle resolution analysis
python .claude/skills/resolution_analysis/scripts/resolution_analysis.py --group-by vehicle --from 2026-01-01 --to 2026-12-31

# First call resolution details
python .claude/skills/resolution_analysis/scripts/resolution_analysis.py --resolution-filter first-call --detail-level calls --from 2026-01-01 --to 2026-12-31

# Failed resolution analysis
python .claude/skills/resolution_analysis/scripts/resolution_analysis.py --resolution-filter failed --detail-level calls --limit 100 --from 2026-01-01 --to 2026-12-31
```

## Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--from` | Yes | - | Start date YYYY-MM-DD |
| `--to` | Yes | - | End date YYYY-MM-DD |
| `--search` | No | - | Search keyword across summaries, topics, cases, parts, teams, programs |
| `--vehicle` | No | all | Filter by vehicle model (e.g., "F-150", "Mach-E") |
| `--team` | No | all | Filter by agent team (e.g., "BEV", "Ford Pro") |
| `--program` | No | all | Filter by program name |
| `--group-by` | No | summary | Group by: `vehicle`, `team`, `program`, `resolution` |
| `--detail-level` | No | `summary` | Return `summary` (aggregated) or `calls` (individual records) |
| `--resolution-filter` | No | all | Filter by: `first-call`, `multi-call`, `failed` |
| `--limit` | No | 1000 | Maximum number of results to return |
| `--min-calls` | No | 5 | Minimum call count to include a group |

## Search Capabilities

The script searches across these **11 data sources** simultaneously:

### Call Content
1. **call_summary**: Full AI-generated call summaries for resolution context

### Topic Classification (3 levels)
2. **topic_level1**: Broadest topic category
3. **topic_level2**: Mid-level topic classification
4. **topic_level3**: Most specific topic details

### Case Classification (3 levels)
5. **caseclassificationlevel1**: High-level case category
6. **caseclassificationlevel2**: Detailed case classification
7. **caseclassificationlevel3**: Specific case subcategory

### Parts Information (2 fields)
8. **parts_features**: Vehicle parts and features mentioned
9. **parts_concern**: Specific parts concerns and issues

### Team & Program Data (2 fields - PRIORITIZED for "calls" queries)
10. **agent_team**: Agent team names (e.g., BEV teams, Ford Pro teams)
11. **program_name**: Program types (e.g., "BEV Support", "Ford Pro Charging")

## FCR Scale Understanding (CORRECTED)

### **FCR Values (Lower = Better):**
- **FCR = 1**: First Call Resolution (EXCELLENT - 100% success rate)
- **FCR = 2**: Second Call Resolution (GOOD - required follow-up)
- **FCR = 3**: Third Call Resolution (POOR - multiple attempts)
- **FCR ≥ 4**: Multiple Calls Required (FAILED - significant resolution issues)

### **Performance Metrics:**
- **FCR Rate Percentage**: `% of calls with FCR = 1`
- **Average FCR Calls**: `Lower average = better team performance`
- **Resolution Quality Distribution**: Excellent → Good → Poor → Failed

## Intelligent "Calls" Detection Examples

### **"What's the FCR for BEV calls?"**
**Searches**: Agent teams like "MUS-CRC_BEV_10", Programs like "BEV - Inbound"
**Query Logic**: Prioritizes `LOWER(ct.Agent_Team) LIKE '%bev%' OR LOWER(cd.program_name) LIKE '%bev%'`

### **"Ford Pro calls resolution rates"**
**Searches**: Agent teams with "Ford Pro" in names, Programs like "Ford Pro Service"
**Query Logic**: Prioritizes `LOWER(ct.Agent_Team) LIKE '%ford pro%' OR LOWER(cd.program_name) LIKE '%ford pro%'`

### **"How well do truck calls get resolved?"**
**Searches**: Agent teams like truck inquiry teams, Programs like "Truck Concern - Inbound"
**Query Logic**: Prioritizes `LOWER(ct.Agent_Team) LIKE '%truck%' OR LOWER(cd.program_name) LIKE '%truck%'`

## Example Usage Scenarios

### 1. BEV Team Resolution Excellence
```bash
python resolution_analysis.py --search "BEV calls FCR" --from 2026-01-01 --to 2026-12-31
```
**Finds**: BEV team FCR performance with resolution patterns
**Use case**: *"How effectively do BEV teams resolve issues on first contact?"*

### 2. Charging Resolution Analysis
```bash
python resolution_analysis.py --search "charging resolution" --vehicle "Mach-E" --group-by team --from 2026-01-01 --to 2026-12-31
```
**Finds**: Mach-E charging resolution by team performance
**Use case**: *"Which teams best resolve Mach-E charging issues?"*

### 3. Failed Resolution Investigation
```bash
python resolution_analysis.py --resolution-filter failed --detail-level calls --limit 50 --from 2026-01-01 --to 2026-12-31
```
**Finds**: Individual calls requiring 4+ contacts with full context
**Use case**: *"Why were these cases not resolved? What patterns exist?"*

### 4. Team Performance Comparison
```bash
python resolution_analysis.py --group-by team --from 2026-01-01 --to 2026-12-31
```
**Finds**: All teams ranked by FCR performance
**Use case**: *"Which teams have the best resolution rates? Training opportunities?"*

### 5. Vehicle Resolution Patterns
```bash
python resolution_analysis.py --search "transmission" --group-by vehicle --from 2026-01-01 --to 2026-12-31
```
**Finds**: Transmission resolution success by vehicle model
**Use case**: *"Which vehicles have transmission issues that are hard to resolve?"*

## Output Format

### **Summary Analysis Output**
```json
{
  "metadata": {
    "query_info": {
      "date_range": "2026-01-01 to 2026-12-31",
      "search_term": "BEV calls FCR",
      "intelligent_team_search": true,
      "team_search_term": "bev",
      "group_by": "team",
      "detail_level": "summary",
      "result_count": 3,
      "search_sources": [
        "agent_team (prioritized for 'calls' queries)",
        "program_name (prioritized for 'calls' queries)",
        "call_summary (full text)",
        "topic_level1", "topic_level2", "topic_level3",
        "caseclassificationlevel1", "caseclassificationlevel2", "caseclassificationlevel3",
        "parts_features", "parts_concern"
      ]
    },
    "fcr_analysis": {
      "best_fcr_rate": 78.5,
      "worst_fcr_rate": 45.2,
      "avg_fcr_rate": 63.4,
      "total_groups": 3
    }
  },
  "results": [
    {
      "agent_team": "MUS-CRC_BEV_10",
      "total_calls": 1523,
      "avg_fcr_calls": 1.35,
      "first_call_resolved": 1195,
      "fcr_rate_percentage": 78.5,
      "excellent_resolution": 1195,
      "good_resolution": 234,
      "poor_resolution": 67,
      "failed_resolution": 27,
      "avg_customer_sentiment": 0.45,
      "avg_customer_end_sentiment": 0.52,
      "avg_complexity": 15.3,
      "avg_nps": 3.8
    }
  ]
}
```

### **Call-Level Details Output**
```json
{
  "metadata": {
    "query_info": {
      "search_term": "charging resolution",
      "detail_level": "calls",
      "result_count": 156
    }
  },
  "results": [
    {
      "call_id": "2026032417020118002469322343403101",
      "casenumber": "CXH-08234567-B5D0Q2",
      "call_date": "2026-03-24",
      "call_summary": "Customer called about home charging station not working. Agent walked through troubleshooting steps, identified faulty breaker, customer resolved issue immediately. Perfect first call resolution...",
      "vehicle_model": "F-150 LIGHTNING",
      "model_year": "2024",
      "agent_team": "MUS-CRC_BEV_10",
      "program_name": "BEV - Inbound",
      "topic_broad": "Vehicle Maintenance and Support",
      "topic_mid": "Charging and Energy Management",
      "topic_specific": "Home charging troubleshooting and setup",
      "parts_features": "Charging System",
      "parts_concern": "Home charging station connectivity",
      "fcr_calls_needed": 1,
      "resolution_category": "First Call Resolution",
      "first_call_resolved": 1,
      "resolution_quality": "Excellent Resolution",
      "customer_sentiment": 0.67,
      "customer_end_sentiment": 0.83,
      "customer_sentiment_change": 0.45,
      "resolution_experience": "Perfect Experience",
      "complexity_score": 8.5,
      "complexity_resolution_pattern": "Simple Issue, Quick Resolution",
      "nps_score": 5,
      "nps_category": "Promoter"
    }
  ]
}
```

## Resolution Classifications

### **Resolution Quality:**
- **Excellent Resolution** (FCR=1): Issue resolved on first contact
- **Good Resolution** (FCR=2): Required one follow-up call
- **Poor Resolution** (FCR=3): Required two follow-up calls
- **Failed Resolution** (FCR≥4): Required multiple follow-up calls

### **Resolution Experience:**
- **Perfect Experience**: FCR=1 + High customer satisfaction
- **Resolved but Unhappy**: FCR=1 + Low customer satisfaction
- **Multi-Call but Satisfied**: FCR>1 + High customer satisfaction
- **Multi-Call and Frustrated**: FCR>1 + Low customer satisfaction

### **Complexity Resolution Patterns:**
- **Simple Issue, Quick Resolution**: Low complexity + FCR=1
- **Complex Issue, Excellent Handling**: High complexity + FCR=1
- **Simple Issue, Poor Resolution**: Low complexity + FCR>1 (training opportunity)
- **Complex Issue, Expected Multi-Call**: High complexity + FCR>1

## Business Value

1. **Team Excellence Identification**: Discover which teams achieve highest FCR rates
2. **Training Gap Analysis**: Find simple issues requiring multiple calls (skill gaps)
3. **Issue Complexity Insights**: Understand which problems are inherently complex
4. **Resolution Pattern Discovery**: Learn what makes first call resolution successful
5. **Customer Experience Optimization**: Correlate FCR with sentiment and satisfaction
6. **Resource Allocation**: Prioritize training and support for poor-performing areas

## Data Sources Used

- **text_analytics.nlp_analytics.call_data**: Primary FCR scores and resolution data
- **text_analytics.nlp_analytics.sentiments**: Sentiment correlation with resolution success
- **text_analytics.nlp_agent.call_summary_qwen06b**: Full call summaries for resolution context
- **text_analytics.nlp_analytics.call_table**: Agent team information (key for intelligent detection)
- **text_analytics.nlp_analytics.models**: Vehicle model and year details
- **text_analytics.nlp_dashboard.case_metadata**: Case classifications (3 levels)
- **text_analytics.nlp_analytics.topic_xwalk**: Topic assignments
- **text_analytics.nlp_configs.topic_detail**: Topic hierarchy (3 levels)
- **text_analytics.nlp_analytics.parts_unfiltered**: Parts and features data

## Error Handling
- Returns empty result set if no FCR data matches criteria
- Handles missing data gracefully with appropriate labels
- Validates date ranges and FCR parameters
- Provides clear error messages for invalid inputs
- Includes comprehensive search source tracking in metadata
- Filters out invalid FCR values (< 1) automatically