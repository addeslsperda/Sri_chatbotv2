"""
Comprehensive First Call Resolution Analysis with Intelligent Team/Program Detection

Analyzes FCR performance, resolution patterns, and team excellence with comprehensive search
across summaries, topics, cases, parts, teams, and programs. Includes intelligent detection
for "calls" queries that prioritize team/program search.

Usage:
    python resolution_analysis.py --from 2026-01-01 --to 2026-12-31
    python resolution_analysis.py --search "BEV calls FCR" --from 2026-01-01 --to 2026-12-31
    python resolution_analysis.py --search "Ford Pro calls resolution" --from 2026-01-01 --to 2026-12-31
    python resolution_analysis.py --search "charging resolution" --vehicle "Mach-E" --from 2026-01-01 --to 2026-12-31
    python resolution_analysis.py --group-by team --from 2026-01-01 --to 2026-12-31

Output: JSON with comprehensive FCR analysis and resolution intelligence
"""
import argparse
import json
import os
import sys
from decimal import Decimal
from pathlib import Path
from databricks import sql
import requests
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parents[5] / ".env", override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


CATALOG = os.environ.get("DATABRICKS_CATALOG", "text_analytics")
SCHEMA = os.environ.get("DATABRICKS_SCHEMA", "nlp_analytics")


def serialize(v):
    """Convert Decimal and datetime objects to JSON-serializable formats"""
    if isinstance(v, Decimal):
        return float(v)
    if hasattr(v, "isoformat"):
        return str(v)
    return v


def build_search_conditions(args, params):
    """Dynamically build search conditions based on user input - NO HARDCODING"""

    if not args.search_term:
        return []

    # Check if the search term contains "calls" - indicating team/program focus
    if "calls" in args.search_term.lower():
        # Extract the prefix before "calls" for team/program search
        search_parts = args.search_term.lower().split("calls")[0].strip()

        # Primary search: Focus on team/program names for "X calls" queries
        search_conditions = [
            "LOWER(ct.Agent_Team) LIKE LOWER(:team_search_pattern)",
            "LOWER(cd.program_name) LIKE LOWER(:program_search_pattern)",
            "LOWER(cs.summary) LIKE LOWER(:search_pattern)",
            "LOWER(td.topic_level1) LIKE LOWER(:search_pattern)",
            "LOWER(td.topic_level2) LIKE LOWER(:search_pattern)",
            "LOWER(td.topic_level3) LIKE LOWER(:search_pattern)",
            "LOWER(cm.caseclassificationlevel1) LIKE LOWER(:search_pattern)",
            "LOWER(cm.caseclassificationlevel2) LIKE LOWER(:search_pattern)",
            "LOWER(cm.caseclassificationlevel3) LIKE LOWER(:search_pattern)",
            "LOWER(pf.parts_features) LIKE LOWER(:search_pattern)",
            "LOWER(pf.parts_concern) LIKE LOWER(:search_pattern)"
        ]

        # Dynamic parameters based on user input
        params["team_search_pattern"] = f"%{search_parts}%"
        params["program_search_pattern"] = f"%{search_parts}%"
        params["search_pattern"] = f"%{args.search_term}%"

    else:
        # Standard search across all sources for non-"calls" queries
        search_conditions = [
            "LOWER(cs.summary) LIKE LOWER(:search_pattern)",
            "LOWER(td.topic_level1) LIKE LOWER(:search_pattern)",
            "LOWER(td.topic_level2) LIKE LOWER(:search_pattern)",
            "LOWER(td.topic_level3) LIKE LOWER(:search_pattern)",
            "LOWER(cm.caseclassificationlevel1) LIKE LOWER(:search_pattern)",
            "LOWER(cm.caseclassificationlevel2) LIKE LOWER(:search_pattern)",
            "LOWER(cm.caseclassificationlevel3) LIKE LOWER(:search_pattern)",
            "LOWER(pf.parts_features) LIKE LOWER(:search_pattern)",
            "LOWER(pf.parts_concern) LIKE LOWER(:search_pattern)",
            "LOWER(ct.Agent_Team) LIKE LOWER(:search_pattern)",
            "LOWER(cd.program_name) LIKE LOWER(:search_pattern)"
        ]

        # Dynamic parameter based on user input
        params["search_pattern"] = f"%{args.search_term}%"

    return search_conditions


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--from", dest="date_from", required=True)
    parser.add_argument("--to", dest="date_to", required=True)
    parser.add_argument("--search", dest="search_term", default=None,
                        help="Search keyword across summaries, topics, cases, parts, teams, programs")
    parser.add_argument("--vehicle", dest="vehicle", default=None,
                        help="Filter by vehicle model (e.g., F-150, Mach-E)")
    parser.add_argument("--team", dest="team", default=None,
                        help="Filter by agent team (e.g., BEV, Ford Pro)")
    parser.add_argument("--program", dest="program", default=None,
                        help="Filter by program name")
    parser.add_argument("--group-by", dest="group_by",
                        choices=["vehicle", "team", "program", "resolution"], default=None,
                        help="Group results by dimension")
    parser.add_argument("--detail-level", dest="detail_level",
                        choices=["summary", "calls"], default="summary",
                        help="Return summary analysis or individual call details")
    parser.add_argument("--resolution-filter", dest="resolution_filter",
                        choices=["first-call", "multi-call", "failed"], default=None,
                        help="Filter by resolution performance")
    parser.add_argument("--limit", type=int, default=1000,
                        help="Maximum number of results to return")
    parser.add_argument("--min-calls", dest="min_calls", type=int, default=5,
                        help="Minimum call count to include a group (default: 5)")
    args, _ = parser.parse_known_args()

    # Build parameters
    params = {
        "date_from": args.date_from,
        "date_to": args.date_to,
    }

    # Base WHERE conditions
    where_conditions = [
        "DATE(cd.call_date) >= :date_from",
        "DATE(cd.call_date) <= :date_to",
        "cd.fcr IS NOT NULL",
        "cd.fcr >= 1"  # Valid FCR values
    ]

    # Add dynamic search conditions
    search_conditions = build_search_conditions(args, params)
    if search_conditions:
        where_conditions.append(f"({' OR '.join(search_conditions)})")

    # Add vehicle filter
    if args.vehicle:
        where_conditions.append("LOWER(COALESCE(m.ModelVehicleLine, cd.modelvehicleline)) LIKE LOWER(:vehicle_pattern)")
        params["vehicle_pattern"] = f"%{args.vehicle}%"

    # Add team filter
    if args.team:
        where_conditions.append("LOWER(ct.Agent_Team) LIKE LOWER(:team_pattern)")
        params["team_pattern"] = f"%{args.team}%"

    # Add program filter
    if args.program:
        where_conditions.append("LOWER(cd.program_name) LIKE LOWER(:program_pattern)")
        params["program_pattern"] = f"%{args.program}%"

    # Add resolution filter
    if args.resolution_filter:
        if args.resolution_filter == "first-call":
            where_conditions.append("cd.fcr = 1")
        elif args.resolution_filter == "multi-call":
            where_conditions.append("cd.fcr > 1")
        elif args.resolution_filter == "failed":
            where_conditions.append("cd.fcr >= 4")

    where_clause = " AND ".join(where_conditions)

    # Determine if we need call-level details or summary analysis
    if args.detail_level == "calls":
        # CALL-LEVEL DETAILS QUERY
        query = f"""
        SELECT
            s.call_id,
            cd.casenumber,
            DATE(cd.call_date) AS call_date,
            cs.summary AS call_summary,
            COALESCE(m.ModelVehicleLine, cd.modelvehicleline, 'Unknown Vehicle') AS vehicle_model,
            COALESCE(m.Model_Year, 'Unknown Year') AS model_year,
            COALESCE(ct.Agent_Team, 'Unknown Team') AS agent_team,
            COALESCE(cd.program_name, 'Unknown Program') AS program_name,
            COALESCE(cm.caseclassificationlevel1, 'No Case Data') AS case_level1,
            COALESCE(cm.caseclassificationlevel2, 'No Case Data') AS case_level2,
            COALESCE(cm.caseclassificationlevel3, 'No Case Data') AS case_level3,
            COALESCE(td.topic_level1, 'No Topic Data') AS topic_broad,
            COALESCE(td.topic_level2, 'No Topic Data') AS topic_mid,
            COALESCE(td.topic_level3, 'No Topic Data') AS topic_specific,
            COALESCE(td.topic_category, 'No Topic Category') AS topic_category,
            COALESCE(pf.parts_features, 'No Parts Data') AS parts_features,
            COALESCE(pf.parts_concern, 'No Parts Concern') AS parts_concern,

            -- FCR & RESOLUTION ANALYSIS (CORRECTED SCALE: 1=BEST)
            cd.fcr AS fcr_calls_needed,
            CASE
                WHEN cd.fcr = 1 THEN 'First Call Resolution'
                WHEN cd.fcr = 2 THEN 'Second Call Resolution'
                WHEN cd.fcr = 3 THEN 'Third Call Resolution'
                WHEN cd.fcr >= 4 THEN 'Multiple Calls Required'
            END AS resolution_category,

            CASE WHEN cd.fcr = 1 THEN 1 ELSE 0 END AS first_call_resolved,
            CASE
                WHEN cd.fcr = 1 THEN 'Excellent Resolution'
                WHEN cd.fcr = 2 THEN 'Good Resolution'
                WHEN cd.fcr = 3 THEN 'Poor Resolution'
                WHEN cd.fcr >= 4 THEN 'Failed Resolution'
            END AS resolution_quality,

            -- SENTIMENT & RESOLUTION CORRELATION
            ROUND(s.customer_sentiment, 4) AS customer_sentiment,
            ROUND(s.agent_sentiment, 4) AS agent_sentiment,
            ROUND(cd.cust_end_sent, 4) AS customer_end_sentiment,
            ROUND(cd.cust_end_sent - cd.cust_beg_sent, 4) AS customer_sentiment_change,

            CASE
                WHEN cd.fcr = 1 AND cd.cust_end_sent > 0.3 THEN 'Perfect Experience'
                WHEN cd.fcr = 1 AND cd.cust_end_sent <= 0.3 THEN 'Resolved but Unhappy'
                WHEN cd.fcr > 1 AND cd.cust_end_sent > 0.3 THEN 'Multi-Call but Satisfied'
                WHEN cd.fcr > 1 AND cd.cust_end_sent <= 0.3 THEN 'Multi-Call and Frustrated'
                ELSE 'Mixed Outcome'
            END AS resolution_experience,

            -- COMPLEXITY & RESOLUTION CORRELATION
            ROUND(cd.complexity, 4) AS complexity_score,
            cd.complexity_label,
            CASE
                WHEN cd.fcr = 1 AND cd.complexity < 10 THEN 'Simple Issue, Quick Resolution'
                WHEN cd.fcr = 1 AND cd.complexity >= 10 THEN 'Complex Issue, Excellent Handling'
                WHEN cd.fcr > 1 AND cd.complexity < 10 THEN 'Simple Issue, Poor Resolution'
                WHEN cd.fcr > 1 AND cd.complexity >= 10 THEN 'Complex Issue, Expected Multi-Call'
                ELSE 'Standard Resolution'
            END AS complexity_resolution_pattern,

            -- NPS CORRELATION
            cd.nps AS nps_score,
            CASE
                WHEN cd.nps = 5 THEN 'Promoter'
                WHEN cd.nps = 4 THEN 'Passive'
                WHEN cd.nps IN (1,2,3) THEN 'Detractor'
                ELSE 'No NPS'
            END AS nps_category

        FROM {CATALOG}.{SCHEMA}.sentiments s
            INNER JOIN {CATALOG}.{SCHEMA}.call_data cd ON s.call_id = cd.call_id
            LEFT JOIN {CATALOG}.nlp_agent.call_summary_qwen06b cs ON s.call_id = cs.call_id
            LEFT JOIN {CATALOG}.{SCHEMA}.call_table ct ON s.call_id = ct.call_id
            LEFT JOIN {CATALOG}.{SCHEMA}.models m ON s.call_id = m.call_id
            LEFT JOIN {CATALOG}.nlp_dashboard.case_metadata cm ON cd.casenumber = cm.casenumber
            LEFT JOIN {CATALOG}.{SCHEMA}.topic_xwalk tx ON s.call_id = tx.call_id
            LEFT JOIN {CATALOG}.nlp_configs.topic_detail td ON tx.topic_id = td.topic_id
            LEFT JOIN {CATALOG}.{SCHEMA}.parts_unfiltered pf ON s.call_id = pf.call_id

        WHERE {where_clause}

        ORDER BY
            cd.fcr ASC,
            cd.cust_end_sent DESC,
            cd.call_date DESC

        LIMIT {args.limit}
        """

    else:
        # SUMMARY ANALYSIS QUERY
        if args.group_by:
            if args.group_by == "vehicle":
                group_expr = "COALESCE(m.ModelVehicleLine, cd.modelvehicleline, 'Unknown Vehicle')"
                label = "vehicle_model"
            elif args.group_by == "team":
                group_expr = "COALESCE(ct.Agent_Team, 'Unknown Team')"
                label = "agent_team"
            elif args.group_by == "program":
                group_expr = "COALESCE(cd.program_name, 'Unknown Program')"
                label = "program_name"
            elif args.group_by == "resolution":
                group_expr = "CASE WHEN cd.fcr = 1 THEN 'First Call' WHEN cd.fcr = 2 THEN 'Second Call' WHEN cd.fcr = 3 THEN 'Third Call' ELSE 'Multiple Calls' END"
                label = "resolution_category"

            query = f"""
            SELECT
                {group_expr} AS {label},
                COUNT(*) AS total_calls,

                -- FCR METRICS (1=BEST, LOWER=BETTER)
                ROUND(AVG(cd.fcr), 2) AS avg_fcr_calls,
                SUM(CASE WHEN cd.fcr = 1 THEN 1 ELSE 0 END) AS first_call_resolved,
                ROUND(100.0 * SUM(CASE WHEN cd.fcr = 1 THEN 1 ELSE 0 END) / COUNT(*), 2) AS fcr_rate_percentage,

                -- RESOLUTION QUALITY DISTRIBUTION
                SUM(CASE WHEN cd.fcr = 1 THEN 1 ELSE 0 END) AS excellent_resolution,
                SUM(CASE WHEN cd.fcr = 2 THEN 1 ELSE 0 END) AS good_resolution,
                SUM(CASE WHEN cd.fcr = 3 THEN 1 ELSE 0 END) AS poor_resolution,
                SUM(CASE WHEN cd.fcr >= 4 THEN 1 ELSE 0 END) AS failed_resolution,

                -- SENTIMENT CORRELATION
                ROUND(AVG(s.customer_sentiment), 4) AS avg_customer_sentiment,
                ROUND(AVG(cd.cust_end_sent), 4) AS avg_customer_end_sentiment,

                -- COMPLEXITY CORRELATION
                ROUND(AVG(cd.complexity), 2) AS avg_complexity,

                -- NPS CORRELATION
                ROUND(AVG(cd.nps), 2) AS avg_nps

            FROM {CATALOG}.{SCHEMA}.sentiments s
                INNER JOIN {CATALOG}.{SCHEMA}.call_data cd ON s.call_id = cd.call_id
                LEFT JOIN {CATALOG}.nlp_agent.call_summary_qwen06b cs ON s.call_id = cs.call_id
                LEFT JOIN {CATALOG}.{SCHEMA}.call_table ct ON s.call_id = ct.call_id
                LEFT JOIN {CATALOG}.{SCHEMA}.models m ON s.call_id = m.call_id
                LEFT JOIN {CATALOG}.nlp_dashboard.case_metadata cm ON cd.casenumber = cm.casenumber
                LEFT JOIN {CATALOG}.{SCHEMA}.topic_xwalk tx ON s.call_id = tx.call_id
                LEFT JOIN {CATALOG}.nlp_configs.topic_detail td ON tx.topic_id = td.topic_id
                LEFT JOIN {CATALOG}.{SCHEMA}.parts_unfiltered pf ON s.call_id = pf.call_id

            WHERE {where_clause}

            GROUP BY {group_expr}
            HAVING COUNT(*) >= {args.min_calls}
            ORDER BY fcr_rate_percentage DESC, avg_fcr_calls ASC
            LIMIT {args.limit}
            """
        else:
            # Overall summary
            query = f"""
            SELECT
                COUNT(*) AS total_calls,
                ROUND(AVG(cd.fcr), 2) AS avg_fcr_calls,
                SUM(CASE WHEN cd.fcr = 1 THEN 1 ELSE 0 END) AS first_call_resolved,
                ROUND(100.0 * SUM(CASE WHEN cd.fcr = 1 THEN 1 ELSE 0 END) / COUNT(*), 2) AS fcr_rate_percentage,

                -- RESOLUTION QUALITY DISTRIBUTION
                SUM(CASE WHEN cd.fcr = 1 THEN 1 ELSE 0 END) AS excellent_resolution,
                SUM(CASE WHEN cd.fcr = 2 THEN 1 ELSE 0 END) AS good_resolution,
                SUM(CASE WHEN cd.fcr = 3 THEN 1 ELSE 0 END) AS poor_resolution,
                SUM(CASE WHEN cd.fcr >= 4 THEN 1 ELSE 0 END) AS failed_resolution,

                -- SENTIMENT CORRELATION
                ROUND(AVG(s.customer_sentiment), 4) AS avg_customer_sentiment,
                ROUND(AVG(cd.cust_end_sent), 4) AS avg_customer_end_sentiment,

                -- COMPLEXITY CORRELATION
                ROUND(AVG(cd.complexity), 2) AS avg_complexity,

                -- NPS CORRELATION
                ROUND(AVG(cd.nps), 2) AS avg_nps

            FROM {CATALOG}.{SCHEMA}.sentiments s
                INNER JOIN {CATALOG}.{SCHEMA}.call_data cd ON s.call_id = cd.call_id
                LEFT JOIN {CATALOG}.nlp_agent.call_summary_qwen06b cs ON s.call_id = cs.call_id
                LEFT JOIN {CATALOG}.{SCHEMA}.call_table ct ON s.call_id = ct.call_id
                LEFT JOIN {CATALOG}.{SCHEMA}.models m ON s.call_id = m.call_id
                LEFT JOIN {CATALOG}.nlp_dashboard.case_metadata cm ON cd.casenumber = cm.casenumber
                LEFT JOIN {CATALOG}.{SCHEMA}.topic_xwalk tx ON s.call_id = tx.call_id
                LEFT JOIN {CATALOG}.nlp_configs.topic_detail td ON tx.topic_id = td.topic_id
                LEFT JOIN {CATALOG}.{SCHEMA}.parts_unfiltered pf ON s.call_id = pf.call_id

            WHERE {where_clause}
            """

    try:
        with get_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(query, params)
                rows = cursor.fetchall()
                columns = [d[0] for d in cursor.description]

        result = [dict(zip(columns, [serialize(val) for val in row])) for row in rows]

        # Detect if intelligent team/program search was used
        calls_based_search = "calls" in args.search_term.lower() if args.search_term else False
        search_prefix = args.search_term.lower().split("calls")[0].strip() if calls_based_search else None

        # Add metadata
        metadata = {
            "query_info": {
                "date_range": f"{args.date_from} to {args.date_to}",
                "search_term": args.search_term,
                "intelligent_team_search": calls_based_search,
                "team_search_term": search_prefix if calls_based_search else None,
                "group_by": args.group_by,
                "detail_level": args.detail_level,
                "vehicle_filter": args.vehicle,
                "team_filter": args.team,
                "program_filter": args.program,
                "resolution_filter": args.resolution_filter,
                "result_count": len(result),
                "search_sources": [
                    "call_summary (full text)",
                    "topic_level1", "topic_level2", "topic_level3",
                    "caseclassificationlevel1", "caseclassificationlevel2", "caseclassificationlevel3",
                    "parts_features", "parts_concern",
                    "agent_team (prioritized for 'calls' queries)" if calls_based_search else "agent_team",
                    "program_name (prioritized for 'calls' queries)" if calls_based_search else "program_name"
                ] if args.search_term else []
            }
        }

        # Calculate summary statistics for grouped results
        if args.detail_level == "summary" and result:
            if args.group_by:
                fcr_rates = [r.get('fcr_rate_percentage', 0) for r in result if r.get('fcr_rate_percentage') is not None]
                metadata["fcr_analysis"] = {
                    "best_fcr_rate": max(fcr_rates) if fcr_rates else 0,
                    "worst_fcr_rate": min(fcr_rates) if fcr_rates else 0,
                    "avg_fcr_rate": round(sum(fcr_rates) / len(fcr_rates), 2) if fcr_rates else 0,
                    "total_groups": len(result)
                }
            else:
                # Single summary result
                if result:
                    r = result[0]
                    metadata["fcr_analysis"] = {
                        "fcr_rate_percentage": r.get('fcr_rate_percentage', 0),
                        "resolution_distribution": {
                            "excellent": r.get('excellent_resolution', 0),
                            "good": r.get('good_resolution', 0),
                            "poor": r.get('poor_resolution', 0),
                            "failed": r.get('failed_resolution', 0)
                        }
                    }

        output = {
            "metadata": metadata,
            "results": result if args.group_by or args.detail_level == "calls" else result[0] if result else {}
        }

        print(json.dumps(output, indent=2))

    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()