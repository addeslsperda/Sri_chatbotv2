"""
Comprehensive Positive Feedback Analysis with Intelligent Team/Program Detection

Discovers what customers love and praise across all dimensions with comprehensive search
across summaries, topics, cases, parts, teams, and programs. Includes intelligent detection
for "calls" queries that prioritize team/program search.

Usage:
    python positive_feedback.py --from 2026-01-01 --to 2026-01-31
    python positive_feedback.py --search "BEV calls" --from 2026-01-01 --to 2026-12-31
    python positive_feedback.py --search "Ford Pro calls" --from 2026-01-01 --to 2026-12-31
    python positive_feedback.py --search "charging" --vehicle "Mach-E" --from 2026-01-01 --to 2026-12-31
    python positive_feedback.py --vehicle "F-150" --min-sentiment 0.5 --from 2026-01-01 --to 2026-12-31

Output: JSON with comprehensive positive feedback analysis and success patterns
"""
import argparse
import json
import os
import sys
from decimal import Decimal
from pathlib import Path
from databricks import sql
import requests
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parents[5] / ".env", override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


CATALOG = os.environ.get("DATABRICKS_CATALOG", "text_analytics")
SCHEMA = os.environ.get("DATABRICKS_SCHEMA", "nlp_analytics")


def serialize(v):
    """Convert Decimal and datetime objects to JSON-serializable formats"""
    if isinstance(v, Decimal):
        return float(v)
    if hasattr(v, "isoformat"):
        return str(v)
    return v


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--from", dest="date_from", required=True)
    parser.add_argument("--to", dest="date_to", required=True)
    parser.add_argument("--search", dest="search_term", default=None,
                        help="Search keyword across summaries, topics, cases, parts, teams, programs")
    parser.add_argument("--vehicle", dest="vehicle", default=None,
                        help="Filter by vehicle model (e.g., F-150, Mach-E)")
    parser.add_argument("--team", dest="team", default=None,
                        help="Filter by agent team (e.g., BEV, Ford Pro)")
    parser.add_argument("--program", dest="program", default=None,
                        help="Filter by program name")
    parser.add_argument("--category", dest="category",
                        choices=["features", "service", "products", "agents", "all"], default="all",
                        help="Category filter for positive feedback")
    parser.add_argument("--min-sentiment", dest="min_sentiment", type=float, default=0.1,
                        help="Minimum positive sentiment threshold (0.1 = slightly positive and above)")
    parser.add_argument("--limit", type=int, default=1000,
                        help="Maximum number of results to return")
    args, _ = parser.parse_known_args()

    # Build parameters
    params = {
        "date_from": args.date_from,
        "date_to": args.date_to,
        "min_sentiment": args.min_sentiment
    }

    # Base WHERE conditions
    where_conditions = [
        "DATE(cd.call_date) >= :date_from",
        "DATE(cd.call_date) <= :date_to",
        "s.customer_sentiment IS NOT NULL",
        "s.customer_sentiment >= :min_sentiment",
        "cd.cust_end_sent >= :min_sentiment",
        "(cd.cust_end_sent - cd.cust_beg_sent) >= -0.2"
    ]

    # Add comprehensive search filter across all 11 sources
    if args.search_term:
        # Check if the search term contains "calls" - indicating team/program focus
        if "calls" in args.search_term.lower():
            # Extract the prefix before "calls" for team/program search
            search_parts = args.search_term.lower().split("calls")[0].strip()

            # Primary search: Focus on team/program names for "X calls" queries
            search_conditions = [
                "LOWER(ct.Agent_Team) LIKE LOWER(:team_search_pattern)",
                "LOWER(cd.program_name) LIKE LOWER(:program_search_pattern)",
                "LOWER(cs.summary) LIKE LOWER(:search_pattern)",
                "LOWER(td.topic_level1) LIKE LOWER(:search_pattern)",
                "LOWER(td.topic_level2) LIKE LOWER(:search_pattern)",
                "LOWER(td.topic_level3) LIKE LOWER(:search_pattern)",
                "LOWER(cm.caseclassificationlevel1) LIKE LOWER(:search_pattern)",
                "LOWER(cm.caseclassificationlevel2) LIKE LOWER(:search_pattern)",
                "LOWER(cm.caseclassificationlevel3) LIKE LOWER(:search_pattern)",
                "LOWER(pf.parts_features) LIKE LOWER(:search_pattern)",
                "LOWER(pf.parts_concern) LIKE LOWER(:search_pattern)"
            ]
            params["team_search_pattern"] = f"%{search_parts}%"
            params["program_search_pattern"] = f"%{search_parts}%"
            params["search_pattern"] = f"%{args.search_term}%"
        else:
            # Standard search across all sources for non-"calls" queries
            search_conditions = [
                "LOWER(cs.summary) LIKE LOWER(:search_pattern)",
                "LOWER(td.topic_level1) LIKE LOWER(:search_pattern)",
                "LOWER(td.topic_level2) LIKE LOWER(:search_pattern)",
                "LOWER(td.topic_level3) LIKE LOWER(:search_pattern)",
                "LOWER(cm.caseclassificationlevel1) LIKE LOWER(:search_pattern)",
                "LOWER(cm.caseclassificationlevel2) LIKE LOWER(:search_pattern)",
                "LOWER(cm.caseclassificationlevel3) LIKE LOWER(:search_pattern)",
                "LOWER(pf.parts_features) LIKE LOWER(:search_pattern)",
                "LOWER(pf.parts_concern) LIKE LOWER(:search_pattern)",
                "LOWER(ct.Agent_Team) LIKE LOWER(:search_pattern)",
                "LOWER(cd.program_name) LIKE LOWER(:search_pattern)"
            ]
            params["search_pattern"] = f"%{args.search_term}%"

        where_conditions.append(f"({' OR '.join(search_conditions)})")

    # Add vehicle filter
    if args.vehicle:
        where_conditions.append("LOWER(COALESCE(m.ModelVehicleLine, cd.modelvehicleline)) LIKE LOWER(:vehicle_pattern)")
        params["vehicle_pattern"] = f"%{args.vehicle}%"

    # Add team filter
    if args.team:
        where_conditions.append("LOWER(ct.Agent_Team) LIKE LOWER(:team_pattern)")
        params["team_pattern"] = f"%{args.team}%"

    # Add program filter
    if args.program:
        where_conditions.append("LOWER(cd.program_name) LIKE LOWER(:program_pattern)")
        params["program_pattern"] = f"%{args.program}%"

    where_clause = " AND ".join(where_conditions)

    # Build comprehensive query
    query = f"""
    SELECT
        s.call_id,
        cd.casenumber,
        DATE(cd.call_date) AS call_date,
        cs.summary AS call_summary,
        COALESCE(m.ModelVehicleLine, cd.modelvehicleline, 'Unknown Vehicle') AS vehicle_model,
        COALESCE(m.Model_Year, 'Unknown Year') AS model_year,
        COALESCE(ct.Agent_Team, 'Unknown Team') AS agent_team,
        COALESCE(cd.program_name, 'Unknown Program') AS program_name,
        COALESCE(cm.caseclassificationlevel1, 'No Case Data') AS case_level1,
        COALESCE(cm.caseclassificationlevel2, 'No Case Data') AS case_level2,
        COALESCE(cm.caseclassificationlevel3, 'No Case Data') AS case_level3,
        COALESCE(td.topic_level1, 'No Topic Data') AS topic_broad,
        COALESCE(td.topic_level2, 'No Topic Data') AS topic_mid,
        COALESCE(td.topic_level3, 'No Topic Data') AS topic_specific,
        COALESCE(td.topic_category, 'No Topic Category') AS topic_category,
        COALESCE(pf.parts_features, 'No Parts Data') AS parts_features,
        COALESCE(pf.parts_concern, 'No Parts Concern') AS parts_concern,
        ROUND(s.agent_sentiment, 4) AS agent_sentiment,
        ROUND(s.customer_sentiment, 4) AS customer_sentiment,
        ROUND(s.overall_sentiment, 4) AS overall_sentiment,
        ROUND(s.customer_sentiment - s.agent_sentiment, 4) AS sentiment_gap,
        ROUND(cd.cust_beg_sent, 4) AS customer_start_sentiment,
        ROUND(cd.cust_end_sent, 4) AS customer_end_sentiment,
        ROUND(cd.cust_end_sent - cd.cust_beg_sent, 4) AS customer_sentiment_change,
        CASE
            WHEN cd.cust_end_sent - cd.cust_beg_sent > 0.3 THEN 'Major Improvement'
            WHEN cd.cust_end_sent - cd.cust_beg_sent > 0.1 THEN 'Moderate Improvement'
            WHEN cd.cust_end_sent - cd.cust_beg_sent >= -0.1 THEN 'Stable Positive'
            ELSE 'Declined During Call'
        END AS positive_outcome,
        CASE
            WHEN s.customer_sentiment >= 0.7 THEN 'Extremely Positive'
            WHEN s.customer_sentiment >= 0.5 THEN 'Very Positive'
            WHEN s.customer_sentiment >= 0.3 THEN 'Moderately Positive'
            WHEN s.customer_sentiment >= 0.1 THEN 'Slightly Positive'
            ELSE 'Not Positive'
        END AS praise_level,
        CASE
            WHEN cd.cust_end_sent >= 0.8 AND (cd.cust_end_sent - cd.cust_beg_sent) > 0.1 THEN 'Outstanding Success'
            WHEN cd.cust_end_sent >= 0.6 AND (cd.cust_end_sent - cd.cust_beg_sent) >= 0 THEN 'Strong Success'
            WHEN cd.cust_end_sent >= 0.4 THEN 'Moderate Success'
            ELSE 'Basic Positive'
        END AS success_level,
        ROUND(cd.complexity, 4) AS complexity_score,
        cd.complexity_label,
        cd.nps AS nps_score,
        CASE
            WHEN cd.nps = 5 THEN 'Promoter'
            WHEN cd.nps = 4 THEN 'Passive'
            WHEN cd.nps IN (1,2,3) THEN 'Detractor'
            ELSE 'No NPS'
        END AS nps_category

    FROM {CATALOG}.{SCHEMA}.sentiments s
        INNER JOIN {CATALOG}.{SCHEMA}.call_data cd ON s.call_id = cd.call_id
        LEFT JOIN {CATALOG}.nlp_agent.call_summary_qwen06b cs ON s.call_id = cs.call_id
        LEFT JOIN {CATALOG}.{SCHEMA}.call_table ct ON s.call_id = ct.call_id
        LEFT JOIN {CATALOG}.{SCHEMA}.models m ON s.call_id = m.call_id
        LEFT JOIN {CATALOG}.nlp_dashboard.case_metadata cm ON cd.casenumber = cm.casenumber
        LEFT JOIN {CATALOG}.{SCHEMA}.topic_xwalk tx ON s.call_id = tx.call_id
        LEFT JOIN {CATALOG}.nlp_configs.topic_detail td ON tx.topic_id = td.topic_id
        LEFT JOIN {CATALOG}.{SCHEMA}.parts_unfiltered pf ON s.call_id = pf.call_id

    WHERE {where_clause}

    ORDER BY
        s.customer_sentiment DESC,
        cd.cust_end_sent DESC,
        (cd.cust_end_sent - cd.cust_beg_sent) DESC,
        cd.call_date DESC

    LIMIT {args.limit}
    """

    try:
        with get_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(query, params)
                rows = cursor.fetchall()
                columns = [d[0] for d in cursor.description]

        result = [dict(zip(columns, [serialize(val) for val in row])) for row in rows]

        # Detect if intelligent team/program search was used
        calls_based_search = "calls" in args.search_term.lower() if args.search_term else False
        search_prefix = args.search_term.lower().split("calls")[0].strip() if calls_based_search else None

        # Add metadata
        metadata = {
            "query_info": {
                "date_range": f"{args.date_from} to {args.date_to}",
                "search_term": args.search_term,
                "intelligent_team_search": calls_based_search,
                "team_search_term": search_prefix if calls_based_search else None,
                "vehicle_filter": args.vehicle,
                "team_filter": args.team,
                "program_filter": args.program,
                "category_filter": args.category,
                "min_sentiment": args.min_sentiment,
                "result_count": len(result),
                "search_sources": [
                    "call_summary (full text)",
                    "topic_level1", "topic_level2", "topic_level3",
                    "caseclassificationlevel1", "caseclassificationlevel2", "caseclassificationlevel3",
                    "parts_features", "parts_concern",
                    "agent_team (prioritized for 'calls' queries)" if calls_based_search else "agent_team",
                    "program_name (prioritized for 'calls' queries)" if calls_based_search else "program_name"
                ] if args.search_term else []
            }
        }

        # Calculate summary statistics
        if result:
            sentiments = [r['customer_sentiment'] for r in result if r['customer_sentiment'] is not None]
            improvements = [r['customer_sentiment_change'] for r in result if r['customer_sentiment_change'] is not None]

            # Praise level distribution
            praise_dist = {}
            for level in ['Extremely Positive', 'Very Positive', 'Moderately Positive', 'Slightly Positive']:
                count = len([r for r in result if r.get('praise_level') == level])
                praise_dist[level] = {
                    "count": count,
                    "percentage": round(count * 100.0 / len(result), 2) if len(result) > 0 else 0
                }

            # Success level distribution
            success_dist = {}
            for level in ['Outstanding Success', 'Strong Success', 'Moderate Success', 'Basic Positive']:
                count = len([r for r in result if r.get('success_level') == level])
                success_dist[level] = {
                    "count": count,
                    "percentage": round(count * 100.0 / len(result), 2) if len(result) > 0 else 0
                }

            metadata["positive_analysis"] = {
                "avg_customer_sentiment": round(sum(sentiments) / len(sentiments), 4) if sentiments else 0,
                "avg_customer_improvement": round(sum(improvements) / len(improvements), 4) if improvements else 0,
                "praise_level_distribution": praise_dist,
                "success_level_distribution": success_dist,
                "most_positive_call": max(sentiments) if sentiments else None,
                "best_improvement": max(improvements) if improvements else None
            }

        output = {
            "metadata": metadata,
            "results": result
        }

        print(json.dumps(output, indent=2))

    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()