---
name: positive_feedback
display_name: Comprehensive Positive Feedback Analysis with Intelligent Team Detection
description: Advanced positive feedback analysis with intelligent team/program detection for "calls" queries, comprehensive search across summaries/topics/cases/parts, and success pattern identification. Use for "BEV calls positive feedback", "Ford Pro success stories", "what customers love about charging", "positive feedback by team", "what's working well".
signals:
  - what went well
  - what delights
  - positive feedback
  - what customers love
  - what's working
  - favorable feedback
  - success stories
  - what customers are happy about
  - good experiences
  - praise
  - BEV calls positive feedback
  - Ford Pro success stories
  - charging positive feedback
  - positive feedback by team
  - what customers praise
requires:
  - date range (from and to)
not_good_for: Negative sentiment analysis (use sentiment_deep_dive), pain points (use other skills), NPS trends (use nps_trend)
---

# Comprehensive Positive Feedback Analysis with Intelligent Team Detection

## What Questions This Skill Answers

### **Team & Program Success Analysis (Intelligent "Calls" Detection)**
- *"What positive feedback do we get from BEV calls?"*
- *"Ford Pro calls success stories"*
- *"What are truck calls customers praising?"*
- *"Charging calls positive experiences"*
- *"What's working well for recall team calls?"*

### **Feature & Service Excellence**
- *"What customers love about BlueCruise"*
- *"Positive feedback about charging"*
- *"What features are customers praising?"*
- *"FordPass positive experiences"*
- *"What's delighting Mach-E customers?"*

### **Success Pattern Identification**
- *"What went well this month?"*
- *"Success stories for F-150"*
- *"What makes customers extremely positive?"*
- *"Which teams generate the most positive feedback?"*
- *"Outstanding success cases"*

### **Agent & Service Excellence**
- *"What agents are doing right?"*
- *"Best customer service experiences"*
- *"Problem resolution success stories"*
- *"Helpful agent interactions"*

## How This Script Works

Provides **comprehensive positive feedback analysis** with intelligent search across:
- **Call summaries**: Full AI-generated call content for positive quote extraction
- **Topic levels**: All 3 topic classification levels for positive topic identification
- **Case classifications**: All 3 case hierarchy levels for success pattern analysis
- **Parts information**: Both parts features and concerns for positive product feedback
- **Team data**: Agent teams and program names (prioritized for "calls" queries)
- **Success metrics**: Sentiment journey, complexity, NPS correlation

**Intelligent Team/Program Detection**: When users mention "BEV calls", "Ford Pro calls", etc., automatically prioritizes searching agent team names and program names.

Returns individual positive calls with complete context, success levels, and improvement tracking.

## How to Run It

```bash
# Basic positive feedback analysis
python .claude/skills/positive_feedback/scripts/positive_feedback.py --from 2026-01-01 --to 2026-12-31

# Intelligent team detection for "calls" queries
python .claude/skills/positive_feedback/scripts/positive_feedback.py --search "BEV calls" --from 2026-01-01 --to 2026-12-31

# Ford Pro success stories
python .claude/skills/positive_feedback/scripts/positive_feedback.py --search "Ford Pro calls" --from 2026-01-01 --to 2026-12-31

# Charging positive feedback by vehicle
python .claude/skills/positive_feedback/scripts/positive_feedback.py --search "charging" --vehicle "Mach-E" --from 2026-01-01 --to 2026-12-31

# Very positive experiences only
python .claude/skills/positive_feedback/scripts/positive_feedback.py --min-sentiment 0.5 --from 2026-01-01 --to 2026-12-31

# Outstanding success cases
python .claude/skills/positive_feedback/scripts/positive_feedback.py --min-sentiment 0.7 --limit 100 --from 2026-01-01 --to 2026-12-31
```

## Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--from` | Yes | - | Start date YYYY-MM-DD |
| `--to` | Yes | - | End date YYYY-MM-DD |
| `--search` | No | - | Search keyword across summaries, topics, cases, parts, teams, programs |
| `--vehicle` | No | all | Filter by vehicle model (e.g., "F-150", "Mach-E") |
| `--team` | No | all | Filter by agent team (e.g., "BEV", "Ford Pro") |
| `--program` | No | all | Filter by program name |
| `--category` | No | all | Category: `features`, `service`, `products`, `agents`, `all` |
| `--min-sentiment` | No | 0.1 | Minimum positive sentiment threshold (0.1 = slightly positive and above) |
| `--limit` | No | 1000 | Maximum number of positive calls to return |

## Search Capabilities

The script searches across these **11 data sources** simultaneously:

### Call Content
1. **call_summary**: Full AI-generated call summaries for positive quote extraction

### Topic Classification (3 levels)
2. **topic_level1**: Broadest topic category
3. **topic_level2**: Mid-level topic classification
4. **topic_level3**: Most specific topic details

### Case Classification (3 levels)
5. **caseclassificationlevel1**: High-level case category
6. **caseclassificationlevel2**: Detailed case classification
7. **caseclassificationlevel3**: Specific case subcategory

### Parts Information (2 fields)
8. **parts_features**: Vehicle parts and features mentioned
9. **parts_concern**: Specific parts concerns and issues

### Team & Program Data (2 fields - PRIORITIZED for "calls" queries)
10. **agent_team**: Agent team names (e.g., BEV teams, Ford Pro teams)
11. **program_name**: Program types (e.g., "BEV Support", "Ford Pro Charging")

## Intelligent "Calls" Detection Examples

### **"What positive feedback do we get from BEV calls?"**
**Searches**: Agent teams like "MUS-CRC_BEV_10", Programs like "BEV - Inbound"
**Query Logic**: Prioritizes `LOWER(ct.Agent_Team) LIKE '%bev%' OR LOWER(cd.program_name) LIKE '%bev%'`

### **"Ford Pro calls success stories"**
**Searches**: Agent teams with "Ford Pro" in names, Programs like "Ford Pro Service"
**Query Logic**: Prioritizes `LOWER(ct.Agent_Team) LIKE '%ford pro%' OR LOWER(cd.program_name) LIKE '%ford pro%'`

### **"What are truck calls customers praising?"**
**Searches**: Agent teams like truck inquiry teams, Programs like "Truck Concern - Inbound"
**Query Logic**: Prioritizes `LOWER(ct.Agent_Team) LIKE '%truck%' OR LOWER(cd.program_name) LIKE '%truck%'`

## Example Usage Scenarios

### 1. BEV Team Success Analysis
```bash
python positive_feedback.py --search "BEV calls" --from 2026-01-01 --to 2026-12-31
```
**Finds**: Positive feedback from BEV team interactions
**Use case**: *"What are BEV customers praising about our service?"*

### 2. Charging Excellence Discovery
```bash
python positive_feedback.py --search "charging" --vehicle "Mach-E" --min-sentiment 0.5 --from 2026-01-01 --to 2026-12-31
```
**Finds**: Mach-E charging positive experiences
**Use case**: *"What charging aspects are delighting Mach-E customers?"*

### 3. Ford Pro Success Stories
```bash
python positive_feedback.py --search "Ford Pro calls" --min-sentiment 0.6 --from 2026-01-01 --to 2026-12-31
```
**Finds**: Ford Pro program positive feedback and success patterns
**Use case**: *"What makes Ford Pro customers extremely satisfied?"*

### 4. Outstanding Success Cases
```bash
python positive_feedback.py --min-sentiment 0.8 --limit 50 --from 2026-01-01 --to 2026-12-31
```
**Finds**: Extremely positive customer experiences
**Use case**: *"Show me our best customer success stories"*

### 5. Feature Excellence Analysis
```bash
python positive_feedback.py --search "BlueCruise" --from 2026-01-01 --to 2026-12-31
```
**Finds**: BlueCruise positive feedback across all data dimensions
**Use case**: *"What do customers love about BlueCruise?"*

## Output Format

```json
{
  "metadata": {
    "query_info": {
      "date_range": "2026-01-01 to 2026-12-31",
      "search_term": "BEV calls",
      "intelligent_team_search": true,
      "team_search_term": "bev",
      "vehicle_filter": null,
      "min_sentiment": 0.1,
      "result_count": 156,
      "search_sources": [
        "call_summary (full text)",
        "topic_level1", "topic_level2", "topic_level3",
        "caseclassificationlevel1", "caseclassificationlevel2", "caseclassificationlevel3",
        "parts_features", "parts_concern",
        "agent_team (prioritized for 'calls' queries)",
        "program_name (prioritized for 'calls' queries)"
      ]
    },
    "positive_analysis": {
      "avg_customer_sentiment": 0.67,
      "avg_customer_improvement": 0.23,
      "praise_level_distribution": {
        "Extremely Positive": {"count": 45, "percentage": 28.85},
        "Very Positive": {"count": 62, "percentage": 39.74},
        "Moderately Positive": {"count": 38, "percentage": 24.36},
        "Slightly Positive": {"count": 11, "percentage": 7.05}
      },
      "success_level_distribution": {
        "Outstanding Success": {"count": 34, "percentage": 21.79},
        "Strong Success": {"count": 67, "percentage": 42.95},
        "Moderate Success": {"count": 43, "percentage": 27.56},
        "Basic Positive": {"count": 12, "percentage": 7.69}
      },
      "most_positive_call": 0.95,
      "best_improvement": 0.78
    }
  },
  "results": [
    {
      "call_id": "2026032417020118002469322343403101",
      "casenumber": "CXH-08234567-B5D0Q2",
      "call_date": "2026-03-24",
      "call_summary": "Customer absolutely loves their new Lightning, charging at home is perfect and convenient. BlueCruise exceeded all expectations on recent road trip. Agent was extremely helpful with setup questions...",
      "vehicle_model": "F-150 LIGHTNING",
      "model_year": "2024", 
      "agent_team": "MUS-CRC_BEV_10",
      "program_name": "BEV - Inbound",
      "case_level1": "Inquiry",
      "case_level2": "Vehicle",
      "case_level3": "Feature Education",
      "topic_broad": "Vehicle Maintenance and Support",
      "topic_mid": "Charging and Energy Management",
      "topic_specific": "Home charging setup and optimization",
      "parts_features": "Charging System",
      "parts_concern": "Setup assistance and optimization",
      "agent_sentiment": 0.82,
      "customer_sentiment": 0.91,
      "overall_sentiment": 0.87,
      "sentiment_gap": 0.09,
      "customer_start_sentiment": 0.45,
      "customer_end_sentiment": 0.89,
      "customer_sentiment_change": 0.44,
      "positive_outcome": "Major Improvement",
      "praise_level": "Extremely Positive", 
      "success_level": "Outstanding Success",
      "complexity_score": 12.5,
      "complexity_label": "Low",
      "nps_score": 5,
      "nps_category": "Promoter"
    }
  ]
}
```

## Positive Sentiment Thresholds

**Slightly Positive** (0.1 - 0.3): Mild satisfaction, basic positive feedback
**Moderately Positive** (0.3 - 0.5): Clear satisfaction, pleased customers
**Very Positive** (0.5 - 0.7): Strong satisfaction, impressed customers
**Extremely Positive** (0.7 - 1.0): Delight, amazement, loving the experience

## Success Level Classifications

**Outstanding Success**: Customer ended extremely positive (0.8+) with major improvement during call
**Strong Success**: Customer ended very positive (0.6+) with no degradation
**Moderate Success**: Customer ended moderately positive (0.4+)
**Basic Positive**: Customer ended slightly positive (0.1+)

## Business Value

1. **Success Pattern Identification**: Understand what creates exceptional customer experiences
2. **Team Excellence**: Identify which teams and approaches generate the most positive feedback
3. **Feature Validation**: Discover which features customers genuinely love and praise
4. **Agent Training**: Learn from positive interactions to improve training programs
5. **Product Development**: Guide feature enhancement based on what customers appreciate most
6. **Marketing Insights**: Find authentic customer testimonials and success stories

## Data Sources Used

- **text_analytics.nlp_analytics.sentiments**: Primary sentiment scores and positive indicators
- **text_analytics.nlp_analytics.call_data**: Call details and sentiment journey tracking
- **text_analytics.nlp_agent.call_summary_qwen06b**: Full call summaries for positive quote extraction
- **text_analytics.nlp_analytics.call_table**: Agent team information (key for intelligent detection)
- **text_analytics.nlp_analytics.models**: Vehicle model and year details
- **text_analytics.nlp_dashboard.case_metadata**: Case classifications (3 levels)
- **text_analytics.nlp_analytics.topic_xwalk**: Topic assignments
- **text_analytics.nlp_configs.topic_detail**: Topic hierarchy (3 levels)
- **text_analytics.nlp_analytics.parts_unfiltered**: Parts and features data

## Error Handling
- Returns empty result set if no positive feedback matches criteria
- Handles missing data gracefully with appropriate labels
- Validates date ranges and sentiment parameters
- Provides clear error messages for invalid inputs
- Includes comprehensive search source tracking in metadata