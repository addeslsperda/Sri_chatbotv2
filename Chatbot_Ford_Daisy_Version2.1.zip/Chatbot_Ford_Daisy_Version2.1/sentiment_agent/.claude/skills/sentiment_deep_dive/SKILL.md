---
name: sentiment_deep_dive
display_name: Comprehensive Sentiment Deep Dive Analysis
description: Deep dive analysis of customer sentiment for specific topics, teams, programs, or issues with call-level detail. Searches across summaries, topics, cases, parts, teams, and programs. Use for "sentiment for buyback requests", "how customers feel about charging", "BEV team sentiment analysis", "Ford Pro customer emotions", "what makes customers angry about transmission", "emotional response to recalls".
signals:
  - sentiment for
  - sentiment deep dive
  - how customers feel about
  - what makes customers angry
  - what makes customers upset
  - emotional response
  - sentiment analysis by topic
  - sentiment by issue
  - sentiment by team
  - BEV team sentiment
  - Ford Pro sentiment
  - charging sentiment analysis
  - buyback emotional response
  - recall sentiment deep dive
  - transmission customer emotions
  - customer emotional reaction
requires:
  - date range (from and to)
  - search term or topic
not_good_for: Overall vehicle sentiment (use sentiment_by_vehicle), agent vs customer comparison only (use agent_customer_sentiment), aggregated metrics (this shows individual calls)
---

# Comprehensive Sentiment Deep Dive Analysis

## What Questions This Skill Answers

### **Emotional Response Analysis**
- "What makes customers angry about buyback requests?"
- "How do customers feel when their buyback is denied?"
- "What's the emotional response to charging failures?"
- "Tell me what angry or upset customers are talking about regarding Mach Es"
- "What issues are themes that are causing negative sentiment?"

### **Topic-Specific Sentiment**
- "Sentiment for buyback requests"
- "How customers feel about charging"
- "Customer sentiment about recalls"
- "Emotional response to transmission problems"
- "Summarize customer sentiment about charging concerns"
- "What was customer sentiment like on truck calls with transmission problems"

### **Team & Program Sentiment Analysis**
- "BEV team sentiment analysis"
- "Ford Pro customer emotions"
- "How are agents handling subscription calls and what are customer emotions?"
- "Sentiment analysis for charging team performance"

### **Vehicle-Specific Emotional Analysis**
- "Tell me how customers are feeling about Bronco today"
- "Summarize Transit customer sentiment"
- "Is customer sentiment high for Bronco customers in relation to FordPass app calls"

### **Comparative Emotional Analysis**
- "Surface the top three emerging topics causing negative sentiment"
- "Compare emotional responses: charging vs transmission vs recalls"
- "Which issues create the most customer frustration?"

## How This Script Works

Provides **call-level sentiment analysis** with comprehensive search across:
- **Call summaries**: Full AI-generated call content
- **Topic levels**: All 3 topic classification levels
- **Case classifications**: All 3 case hierarchy levels  
- **Parts information**: Both parts features and concerns
- **Team data**: Agent teams and program names
- **Contextual data**: Vehicle models, complexity, outcomes

Returns individual call records with complete emotional context, sentiment journey, and related data.

## How to Run It

```bash
# Basic sentiment analysis for a topic
python .claude/skills/sentiment_deep_dive/scripts/sentiment_deep_dive.py --search "buyback" --from 2026-01-01 --to 2026-12-31

# Analyze charging sentiment with full summaries
python .claude/skills/sentiment_deep_dive/scripts/sentiment_deep_dive.py --search "charging" --include-summaries --from 2026-01-01 --to 2026-12-31

# BEV team sentiment analysis
python .claude/skills/sentiment_deep_dive/scripts/sentiment_deep_dive.py --search "BEV" --team "BEV" --from 2026-01-01 --to 2026-12-31

# Ford Pro customer emotions
python .claude/skills/sentiment_deep_dive/scripts/sentiment_deep_dive.py --search "Ford Pro" --program "Ford Pro" --from 2026-01-01 --to 2026-12-31

# Very negative sentiment about transmission
python .claude/skills/sentiment_deep_dive/scripts/sentiment_deep_dive.py --search "transmission" --emotional-category "Very Negative" --include-summaries --from 2026-01-01 --to 2026-12-31

# Mach-E charging sentiment with high gaps
python .claude/skills/sentiment_deep_dive/scripts/sentiment_deep_dive.py --search "charging" --vehicle "Mach-E" --min-gap 0.3 --from 2026-01-01 --to 2026-12-31
```

## Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--from` | Yes | - | Start date YYYY-MM-DD |
| `--to` | Yes | - | End date YYYY-MM-DD |
| `--search` | Yes | - | Search keyword across summaries, topics, cases, parts, teams, programs |
| `--vehicle` | No | all | Filter by vehicle model (e.g., "F-150", "Mach-E", "Bronco") |
| `--team` | No | all | Filter by agent team (e.g., "BEV", "Ford Pro", "Charging") |
| `--program` | No | all | Filter by program name (e.g., "BEV Support", "Ford Pro Charging") |
| `--emotional-category` | No | all | Filter by: "Very Negative", "Negative", "Neutral", "Positive", "Very Positive" |
| `--min-gap` | No | 0.1 | Minimum sentiment gap threshold (agent vs customer) |
| `--include-summaries` | No | true | Always includes full call summaries in output |
| `--limit` | No | 1000 | Maximum number of call records to return |

## Search Capabilities

The script searches across these **11 data sources** simultaneously:

### Call Content
1. **call_summary**: Full AI-generated call summaries

### Topic Classification (3 levels)  
2. **topic_level1**: Broadest topic category
3. **topic_level2**: Mid-level topic classification
4. **topic_level3**: Most specific topic details

### Case Classification (3 levels)
5. **caseclassificationlevel1**: High-level case category
6. **caseclassificationlevel2**: Detailed case classification  
7. **caseclassificationlevel3**: Specific case subcategory

### Parts Information (2 fields)
8. **parts_features**: Vehicle parts and features mentioned
9. **parts_concern**: Specific parts concerns and issues

### Team & Program Data (2 fields)
10. **agent_team**: Agent team names (e.g., BEV teams, Ford Pro teams)
11. **program_name**: Program types (e.g., "BEV Support", "Ford Pro Charging")

## Example Usage Scenarios

### 1. Buyback Emotional Analysis
```bash
python sentiment_deep_dive.py --search "buyback" --emotional-category "Very Negative" --include-summaries --from 2026-01-01 --to 2026-12-31
```
**Finds**: Individual calls where customers are very upset about buyback issues
**Use case**: *"What makes customers angry about buyback requests?"*

### 2. BEV Team Performance
```bash
python sentiment_deep_dive.py --search "charging" --team "BEV" --from 2026-01-01 --to 2026-12-31
```
**Finds**: Charging-related calls handled by BEV teams with sentiment context
**Use case**: *"How are BEV teams handling charging sentiment?"*

### 3. Ford Pro Customer Emotions  
```bash
python sentiment_deep_dive.py --search "Ford Pro" --program "Ford Pro" --min-gap 0.3 --from 2026-01-01 --to 2026-12-31
```
**Finds**: Ford Pro calls with significant sentiment gaps
**Use case**: *"What are Ford Pro customers most frustrated about?"*

### 4. Vehicle-Specific Emotional Deep Dive
```bash
python sentiment_deep_dive.py --search "transmission" --vehicle "F-150" --emotional-category "Very Negative" --from 2026-01-01 --to 2026-12-31
```
**Finds**: F-150 transmission calls with very negative customer sentiment
**Use case**: *"What transmission issues make F-150 customers angriest?"*

### 5. Recall Sentiment Analysis
```bash
python sentiment_deep_dive.py --search "recall" --include-summaries --limit 500 --from 2026-01-01 --to 2026-12-31
```
**Finds**: Recall-related calls with full context and summaries
**Use case**: *"How do customers feel about recalls and what are their concerns?"*

## Output Format

```json
{
  "metadata": {
    "query_info": {
      "date_range": "2026-01-01 to 2026-12-31",
      "search_term": "buyback",
      "vehicle_filter": null,
      "team_filter": null,
      "program_filter": null,
      "emotional_category_filter": "Very Negative",
      "min_gap": 0.1,
      "include_summaries": true,
      "result_count": 45,
      "search_sources": [
        "call_summary (full text)",
        "topic_level1", "topic_level2", "topic_level3",
        "caseclassificationlevel1", "caseclassificationlevel2", "caseclassificationlevel3",
        "parts_features", "parts_concern",
        "agent_team", "program_name"
      ]
    },
    "sentiment_analysis": {
      "avg_customer_sentiment": -0.67,
      "avg_sentiment_gap": -0.89,
      "emotional_distribution": {
        "Very Negative": {"count": 28, "percentage": 62.22},
        "Negative": {"count": 12, "percentage": 26.67},
        "Neutral": {"count": 4, "percentage": 8.89},
        "Positive": {"count": 1, "percentage": 2.22},
        "Very Positive": {"count": 0, "percentage": 0.0}
      },
      "most_negative_call": -0.95,
      "most_positive_call": 0.15
    }
  },
  "results": [
    {
      "call_id": "2026032417020118002469322343403101",
      "casenumber": "CXH-08234567-B5D0Q2",
      "call_date": "2026-03-24",
      "call_summary": "Customer extremely frustrated with buyback denial after multiple transmission failures. Vehicle has been in shop 8 times in 6 months. Customer feels Ford is not honoring lemon law obligations and is considering legal action...",
      "vehicle_model": "F-150",
      "model_year": "2024",
      "agent_team": "FM-MSS-CRC-Houston-5508-ConcernTm05",
      "program_name": "BEV - Case Callbacks",
      "case_level1": "Vehicle Concern",
      "case_level2": "Buyback Request",
      "case_level3": "Denial Appeal",
      "topic_broad": "Customer Support and Rewards", 
      "topic_mid": "Buyback Process",
      "topic_specific": "Buyback denial and appeals process",
      "parts_features": "Transmission",
      "parts_concern": "Multiple transmission failures requiring repeated repairs",
      "agent_sentiment": 0.25,
      "customer_sentiment": -0.85,
      "overall_sentiment": -0.30,
      "sentiment_gap": -1.10,
      "agent_start_sentiment": 0.4,
      "agent_end_sentiment": 0.1,
      "customer_start_sentiment": -0.6,
      "customer_end_sentiment": -1.0,
      "agent_sentiment_change": -0.3,
      "customer_sentiment_change": -0.4,
      "final_sentiment_gap": -1.1,
      "overall_sentiment_label": "Negative",
      "agent_start_label": "Positive",
      "agent_end_label": "Neutral",
      "customer_start_label": "Negative", 
      "customer_end_label": "Very Negative",
      "complexity_score": 35.0,
      "complexity_label": "High",
      "customer_outcome": "Customer Degraded",
      "sentiment_gap_category": "High Sentiment Gap",
      "emotional_category": "Very Negative"
    }
  ]
}
```

## Emotional Categories

**Very Negative** (-1.0 to -0.5): Extreme frustration, anger, threats of legal action  
**Negative** (-0.5 to -0.1): Dissatisfaction, disappointment, complaints  
**Neutral** (-0.1 to 0.1): Factual discussion, no strong emotion  
**Positive** (0.1 to 0.5): Satisfaction, mild appreciation  
**Very Positive** (0.5 to 1.0): Delight, strong praise, gratitude  

## Key Insights Provided

### **Emotional Distribution Analysis**
- Percentage breakdown across all 5 emotional categories
- Identifies emotional intensity patterns
- Shows most/least negative calls in dataset

### **Individual Call Context** 
- Complete sentiment journey (beginning to end)
- Full call summaries always included
- Vehicle, team, and program context
- Related topics, cases, and parts information

### **Sentiment Gap Analysis**
- Agent vs customer sentiment differences
- Customer outcome tracking (improved/degraded/stable)
- Complexity correlation with emotional intensity

### **Comprehensive Search Results**
- Finds emotional patterns across all data sources
- Shows WHY customers feel certain ways
- Provides actionable insights for improvement

## Business Value

1. **Emotional Intelligence**: Understand what triggers strong customer emotions
2. **Team Performance**: Identify which teams handle emotional situations best
3. **Product Issues**: Find specific vehicle/parts problems causing customer upset
4. **Process Improvement**: Address topics/cases that consistently create negative emotions
5. **Training Needs**: Target emotional intelligence training for specific scenarios
6. **Customer Experience**: Improve processes that cause the most customer distress

## Data Sources Used

- **text_analytics.nlp_analytics.sentiments**: Primary sentiment scores and gaps
- **text_analytics.nlp_analytics.call_data**: Call details and sentiment journey  
- **text_analytics.nlp_agent.call_summary_qwen06b**: Full call summaries for context
- **text_analytics.nlp_analytics.call_table**: Agent team information
- **text_analytics.nlp_analytics.models**: Vehicle model and year details
- **text_analytics.nlp_dashboard.case_metadata**: Case classifications (3 levels)
- **text_analytics.nlp_analytics.topic_xwalk**: Topic assignments
- **text_analytics.nlp_configs.topic_detail**: Topic hierarchy (3 levels)  
- **text_analytics.nlp_analytics.parts_unfiltered**: Parts and features data

## Error Handling
- Returns empty result set if no calls match search criteria
- Handles missing data gracefully with appropriate labels
- Validates date ranges and emotional category parameters  
- Provides clear error messages for invalid inputs
- Includes search source tracking in metadata