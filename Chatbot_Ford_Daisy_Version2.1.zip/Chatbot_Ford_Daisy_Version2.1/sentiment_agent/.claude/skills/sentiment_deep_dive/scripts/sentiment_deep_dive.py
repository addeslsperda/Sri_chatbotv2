"""
Comprehensive Sentiment Analysis by Topic with Deep Dive Context

Analyzes customer sentiment for specific topics, teams, programs, or issues with comprehensive
search across summaries, topics, cases, parts, teams, and programs. Provides call-level detail
with full context and emotional analysis.

Usage:
    python sentiment_deep_dive.py --search "buyback" --from 2026-01-01 --to 2026-01-31
    python sentiment_deep_dive.py --search "charging" --vehicle "Mach-E" --from 2026-01-01 --to 2026-01-31
    python sentiment_deep_dive.py --search "BEV" --team "BEV" --from 2026-01-01 --to 2026-01-31
    python sentiment_deep_dive.py --search "Ford Pro" --program "Ford Pro" --from 2026-01-01 --to 2026-01-31
    python sentiment_deep_dive.py --search "transmission" --emotional-category "Very Negative" --include-summaries

Output: JSON with call-level sentiment analysis and comprehensive context
"""
import argparse
import json
import os
import sys
from decimal import Decimal
from pathlib import Path
from databricks import sql
import requests
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parents[5] / ".env", override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


CATALOG = os.environ.get("DATABRICKS_CATALOG", "text_analytics")
SCHEMA = os.environ.get("DATABRICKS_SCHEMA", "nlp_analytics")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--from", dest="date_from", required=True)
    parser.add_argument("--to", dest="date_to", required=True)
    parser.add_argument("--search", dest="search_term", default=None,
                        help="Search keyword across summaries, topics, cases, parts, teams, programs")
    parser.add_argument("--vehicle", dest="vehicle", default=None,
                        help="Filter by vehicle model (e.g., F-150, Mach-E)")
    parser.add_argument("--team", dest="team", default=None,
                        help="Filter by agent team (e.g., BEV, Ford Pro)")
    parser.add_argument("--program", dest="program", default=None,
                        help="Filter by program name")
    parser.add_argument("--emotional-category", dest="emotional_category", default=None,
                        help="Filter by emotional category: Very Negative, Negative, Neutral, Positive, Very Positive")
    parser.add_argument("--min-gap", dest="min_gap", type=float, default=0.1,
                        help="Minimum sentiment gap threshold")
    parser.add_argument("--include-summaries", dest="include_summaries", action="store_true",
                        help="Include full call summaries in output")
    parser.add_argument("--limit", type=int, default=1000,
                        help="Maximum number of results to return")
    args, _ = parser.parse_known_args()

    # Build parameters
    params = {
        "date_from": args.date_from,
        "date_to": args.date_to,
    }

    # Base WHERE conditions
    where_conditions = [
        "DATE(cd.call_date) >= :date_from",
        "DATE(cd.call_date) <= :date_to",
        "s.customer_sentiment IS NOT NULL",
        "cd.cust_end_sent IS NOT NULL"
    ]

    # Add minimum gap filter
    if args.min_gap > 0:
        where_conditions.append(f"ABS(s.customer_sentiment - s.agent_sentiment) >= {args.min_gap}")

    # Add comprehensive search filter across all 11 sources
    if args.search_term:
        # Check if the search term contains "calls" - indicating team/program focus
        if "calls" in args.search_term.lower():
            # Extract the prefix before "calls" for team/program search
            search_parts = args.search_term.lower().split("calls")[0].strip()

            # Primary search: Focus on team/program names for "X calls" queries
            search_conditions = [
                # Team & Program search (PRIMARY for "calls" queries)
                "LOWER(ct.Agent_Team) LIKE LOWER(:team_search_pattern)",
                "LOWER(cd.program_name) LIKE LOWER(:program_search_pattern)",
                # Secondary: Also search content for the term
                "LOWER(cs.summary) LIKE LOWER(:search_pattern)",
                "LOWER(td.topic_level1) LIKE LOWER(:search_pattern)",
                "LOWER(td.topic_level2) LIKE LOWER(:search_pattern)",
                "LOWER(td.topic_level3) LIKE LOWER(:search_pattern)",
                "LOWER(cm.caseclassificationlevel1) LIKE LOWER(:search_pattern)",
                "LOWER(cm.caseclassificationlevel2) LIKE LOWER(:search_pattern)",
                "LOWER(cm.caseclassificationlevel3) LIKE LOWER(:search_pattern)",
                "LOWER(pf.parts_features) LIKE LOWER(:search_pattern)",
                "LOWER(pf.parts_concern) LIKE LOWER(:search_pattern)"
            ]
            params["team_search_pattern"] = f"%{search_parts}%"
            params["program_search_pattern"] = f"%{search_parts}%"
            params["search_pattern"] = f"%{args.search_term}%"
        else:
            # Standard search across all sources for non-"calls" queries
            search_conditions = [
                # Call summaries (full text search)
                "LOWER(cs.summary) LIKE LOWER(:search_pattern)",
                # Topic levels (all 3 levels)
                "LOWER(td.topic_level1) LIKE LOWER(:search_pattern)",
                "LOWER(td.topic_level2) LIKE LOWER(:search_pattern)",
                "LOWER(td.topic_level3) LIKE LOWER(:search_pattern)",
                # Case classification levels (all 3 levels)
                "LOWER(cm.caseclassificationlevel1) LIKE LOWER(:search_pattern)",
                "LOWER(cm.caseclassificationlevel2) LIKE LOWER(:search_pattern)",
                "LOWER(cm.caseclassificationlevel3) LIKE LOWER(:search_pattern)",
                # Parts information (both fields)
                "LOWER(pf.parts_features) LIKE LOWER(:search_pattern)",
                "LOWER(pf.parts_concern) LIKE LOWER(:search_pattern)",
                # Team & Program search
                "LOWER(ct.Agent_Team) LIKE LOWER(:search_pattern)",
                "LOWER(cd.program_name) LIKE LOWER(:search_pattern)"
            ]
            params["search_pattern"] = f"%{args.search_term}%"

        where_conditions.append(f"({' OR '.join(search_conditions)})")

    # Add vehicle filter
    if args.vehicle:
        where_conditions.append("LOWER(COALESCE(m.ModelVehicleLine, cd.modelvehicleline)) LIKE LOWER(:vehicle_pattern)")
        params["vehicle_pattern"] = f"%{args.vehicle}%"

    # Add team filter
    if args.team:
        where_conditions.append("LOWER(ct.Agent_Team) LIKE LOWER(:team_pattern)")
        params["team_pattern"] = f"%{args.team}%"

    # Add program filter
    if args.program:
        where_conditions.append("LOWER(cd.program_name) LIKE LOWER(:program_pattern)")
        params["program_pattern"] = f"%{args.program}%"

    # Add emotional category filter
    if args.emotional_category:
        if args.emotional_category.lower() == "very negative":
            where_conditions.append("cd.cust_end_sent <= -0.5")
        elif args.emotional_category.lower() == "negative":
            where_conditions.append("cd.cust_end_sent > -0.5 AND cd.cust_end_sent <= -0.1")
        elif args.emotional_category.lower() == "neutral":
            where_conditions.append("cd.cust_end_sent > -0.1 AND cd.cust_end_sent <= 0.1")
        elif args.emotional_category.lower() == "positive":
            where_conditions.append("cd.cust_end_sent > 0.1 AND cd.cust_end_sent <= 0.5")
        elif args.emotional_category.lower() == "very positive":
            where_conditions.append("cd.cust_end_sent > 0.5")

    where_clause = " AND ".join(where_conditions)

    # Use full summaries always
    summary_field = "cs.summary"

    # Build comprehensive query using the enhanced structure
    query = f"""
    -- SENTIMENT DEEP DIVE WITH CALL-LEVEL DETAILS AND COMPREHENSIVE SEARCH
    -- Segregated by call_id with full summaries, team, and program search

    SELECT
        -- === CALL IDENTIFICATION ===
        s.call_id,
        cd.casenumber,
        DATE(cd.call_date) AS call_date,

        -- === CALL SUMMARY (FULL OR PREVIEW) ===
        {summary_field} AS call_summary,

        -- === VEHICLE INFORMATION ===
        COALESCE(m.ModelVehicleLine, cd.modelvehicleline, 'Unknown Vehicle') AS vehicle_model,
        COALESCE(m.Model_Year, 'Unknown Year') AS model_year,

        -- === AGENT & TEAM INFORMATION ===
        COALESCE(ct.Agent_Team, 'Unknown Team') AS agent_team,
        COALESCE(cd.program_name, 'Unknown Program') AS program_name,

        -- === CASE CLASSIFICATION (ALL 3 LEVELS) ===
        COALESCE(cm.caseclassificationlevel1, 'No Case Data') AS case_level1,
        COALESCE(cm.caseclassificationlevel2, 'No Case Data') AS case_level2,
        COALESCE(cm.caseclassificationlevel3, 'No Case Data') AS case_level3,

        -- === TOPIC INFORMATION (ALL 3 LEVELS) ===
        COALESCE(td.topic_level1, 'No Topic Data') AS topic_broad,
        COALESCE(td.topic_level2, 'No Topic Data') AS topic_mid,
        COALESCE(td.topic_level3, 'No Topic Data') AS topic_specific,
        COALESCE(td.topic_category, 'No Topic Category') AS topic_category,

        -- === PARTS INFORMATION (BOTH FIELDS) ===
        COALESCE(pf.parts_features, 'No Parts Data') AS parts_features,
        COALESCE(pf.parts_concern, 'No Parts Concern') AS parts_concern,

        -- === PRIMARY SENTIMENT SCORES ===
        ROUND(s.agent_sentiment, 4) AS agent_sentiment,
        ROUND(s.customer_sentiment, 4) AS customer_sentiment,
        ROUND(s.overall_sentiment, 4) AS overall_sentiment,
        ROUND(s.customer_sentiment - s.agent_sentiment, 4) AS sentiment_gap,

        -- === SENTIMENT JOURNEY (Beginning to End) ===
        ROUND(cd.agent_beg_sent, 4) AS agent_start_sentiment,
        ROUND(cd.agent_end_sent, 4) AS agent_end_sentiment,
        ROUND(cd.cust_beg_sent, 4) AS customer_start_sentiment,
        ROUND(cd.cust_end_sent, 4) AS customer_end_sentiment,

        -- === SENTIMENT CHANGES DURING CALL ===
        ROUND(cd.agent_end_sent - cd.agent_beg_sent, 4) AS agent_sentiment_change,
        ROUND(cd.cust_end_sent - cd.cust_beg_sent, 4) AS customer_sentiment_change,
        ROUND(cd.cust_end_sent - cd.agent_end_sent, 4) AS final_sentiment_gap,

        -- === SENTIMENT LABELS ===
        cd.sentiment_label AS overall_sentiment_label,
        cd.agent_beg_sent_label AS agent_start_label,
        cd.agent_end_sent_label AS agent_end_label,
        cd.cust_beg_sent_label AS customer_start_label,
        cd.cust_end_sent_label AS customer_end_label,

        -- === CALL COMPLEXITY ===
        ROUND(cd.complexity, 4) AS complexity_score,
        cd.complexity_label,

        -- === OUTCOME ANALYSIS ===
        CASE
            WHEN cd.cust_end_sent - cd.cust_beg_sent > 0.2 THEN 'Customer Improved'
            WHEN cd.cust_end_sent - cd.cust_beg_sent < -0.2 THEN 'Customer Degraded'
            ELSE 'Customer Stable'
        END AS customer_outcome,

        CASE
            WHEN ABS(s.customer_sentiment - s.agent_sentiment) > 0.3 THEN 'High Sentiment Gap'
            WHEN ABS(s.customer_sentiment - s.agent_sentiment) > 0.1 THEN 'Moderate Sentiment Gap'
            ELSE 'Low Sentiment Gap'
        END AS sentiment_gap_category,

        -- === EMOTIONAL CATEGORIZATION ===
        CASE
            WHEN cd.cust_end_sent <= -0.5 THEN 'Very Negative'
            WHEN cd.cust_end_sent <= -0.1 THEN 'Negative'
            WHEN cd.cust_end_sent <= 0.1 THEN 'Neutral'
            WHEN cd.cust_end_sent <= 0.5 THEN 'Positive'
            ELSE 'Very Positive'
        END AS emotional_category

    FROM {CATALOG}.{SCHEMA}.sentiments s

        -- === CORE JOINS ===
        INNER JOIN {CATALOG}.{SCHEMA}.call_data cd ON s.call_id = cd.call_id

        -- === CALL SUMMARIES (for actual call content) ===
        LEFT JOIN {CATALOG}.nlp_agent.call_summary_qwen06b cs ON s.call_id = cs.call_id

        -- === TEAM INFORMATION ===
        LEFT JOIN {CATALOG}.{SCHEMA}.call_table ct ON s.call_id = ct.call_id

        -- === VEHICLE MODEL ===
        LEFT JOIN {CATALOG}.{SCHEMA}.models m ON s.call_id = m.call_id

        -- === CASE CLASSIFICATION ===
        LEFT JOIN {CATALOG}.nlp_dashboard.case_metadata cm ON cd.casenumber = cm.casenumber

        -- === TOPICS ===
        LEFT JOIN {CATALOG}.{SCHEMA}.topic_xwalk tx ON s.call_id = tx.call_id
        LEFT JOIN {CATALOG}.nlp_configs.topic_detail td ON tx.topic_id = td.topic_id

        -- === PARTS ===
        LEFT JOIN {CATALOG}.{SCHEMA}.parts_unfiltered pf ON s.call_id = pf.call_id

    WHERE {where_clause}

    ORDER BY
        -- Show most emotionally charged calls first (worst sentiment)
        cd.cust_end_sent ASC,
        ABS(s.customer_sentiment - s.agent_sentiment) DESC,
        cd.call_date DESC

    LIMIT {args.limit}
    """

    try:
        with get_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(query, params)
                rows = cursor.fetchall()
                columns = [d[0] for d in cursor.description]

        def serialize(v):
            if isinstance(v, Decimal): return float(v)
            if hasattr(v, "isoformat"): return str(v)
            return v

        result = [dict(zip(columns, [serialize(val) for val in row])) for row in rows]

        # Detect if intelligent team/program search was used
        calls_based_search = "calls" in args.search_term.lower() if args.search_term else False
        search_prefix = args.search_term.lower().split("calls")[0].strip() if calls_based_search else None

        # Add metadata
        metadata = {
            "query_info": {
                "date_range": f"{args.date_from} to {args.date_to}",
                "search_term": args.search_term,
                "intelligent_team_search": calls_based_search,
                "team_search_term": search_prefix if calls_based_search else None,
                "vehicle_filter": args.vehicle,
                "team_filter": args.team,
                "program_filter": args.program,
                "emotional_category_filter": args.emotional_category,
                "min_gap": args.min_gap,
                "include_summaries": args.include_summaries,
                "result_count": len(result),
                "search_sources": [
                    "call_summary (full text)",
                    "topic_level1", "topic_level2", "topic_level3",
                    "caseclassificationlevel1", "caseclassificationlevel2", "caseclassificationlevel3",
                    "parts_features", "parts_concern",
                    "agent_team (prioritized for 'calls' queries)" if calls_based_search else "agent_team",
                    "program_name (prioritized for 'calls' queries)" if calls_based_search else "program_name"
                ] if args.search_term else []
            }
        }

        # Calculate summary statistics
        if result:
            sentiments = [r['customer_sentiment'] for r in result if r['customer_sentiment'] is not None]
            gaps = [r['sentiment_gap'] for r in result if r['sentiment_gap'] is not None]

            # Emotional distribution
            emotional_dist = {}
            for category in ['Very Negative', 'Negative', 'Neutral', 'Positive', 'Very Positive']:
                count = len([r for r in result if r['emotional_category'] == category])
                emotional_dist[category] = {
                    "count": count,
                    "percentage": round(count * 100.0 / len(result), 2)
                }

            metadata["sentiment_analysis"] = {
                "avg_customer_sentiment": round(sum(sentiments) / len(sentiments), 4) if sentiments else 0,
                "avg_sentiment_gap": round(sum(gaps) / len(gaps), 4) if gaps else 0,
                "emotional_distribution": emotional_dist,
                "most_negative_call": min(sentiments) if sentiments else None,
                "most_positive_call": max(sentiments) if sentiments else None
            }

        output = {
            "metadata": metadata,
            "results": result
        }

        print(json.dumps(output, indent=2))

    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()