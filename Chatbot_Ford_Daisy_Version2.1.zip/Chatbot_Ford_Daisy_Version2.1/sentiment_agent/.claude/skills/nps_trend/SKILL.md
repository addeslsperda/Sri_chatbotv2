---
name: nps_trend
display_name: Comprehensive NPS & Survey Analysis with Intelligent Team Detection
description: Advanced NPS, FCR, and brand trust analysis with intelligent team/program detection for "calls" queries, comprehensive search across summaries/topics/cases/parts, and both trend and call-level detail options. Use for "BEV calls NPS", "truck calls FCR", "Ford Pro NPS trends", "charging NPS analysis", "NPS by vehicle", "brand trust by team".
signals:
  - NPS
  - net promoter score
  - FCR
  - first call resolution
  - brand trust
  - survey score
  - NPS trend
  - NPS by vehicle
  - BEV calls NPS
  - truck calls NPS
  - Ford Pro NPS
  - charging NPS analysis
  - NPS by team
  - NPS call details
  - promoter detractor analysis
requires:
  - date range (from and to)
not_good_for: Pure sentiment analysis (use sentiment_by_vehicle), agent vs customer sentiment comparison (use agent_customer_sentiment)
---

# Comprehensive NPS & Survey Analysis with Intelligent Team Detection

## What Questions This Skill Answers

### **Team & Program NPS Analysis (Intelligent "Calls" Detection)**
- *"What's the NPS for BEV calls?"*
- *"Show me truck calls NPS trends"*
- *"Ford Pro calls brand trust scores"*  
- *"What's the FCR for charging calls?"*
- *"NPS analysis for recall team calls"*

### **NPS Trend Analysis**
- *"What is our NPS trend over time?"*
- *"Which vehicle has the lowest NPS?"*
- *"NPS by vehicle model and year"*
- *"Weekly NPS performance"*

### **Survey Metrics Correlation**  
- *"FCR by vehicle model"*
- *"Brand trust score trends"*
- *"NPS vs FCR correlation"*
- *"Promoter vs detractor breakdown"*

### **Issue-Specific NPS Analysis**
- *"Charging NPS analysis"*
- *"Transmission problem NPS impact"*
- *"Buyback request NPS scores"*
- *"Recall NPS vs regular calls"*

### **Call-Level NPS Details**
- *"Show me individual call details for low NPS"*
- *"NPS call summaries for BEV issues"*
- *"Detractor call analysis with context"*

## How This Script Works

Provides **comprehensive NPS analysis** with intelligent search across:
- **Call summaries**: Full AI-generated call content
- **Topic levels**: All 3 topic classification levels
- **Case classifications**: All 3 case hierarchy levels
- **Parts information**: Both parts features and concerns  
- **Team data**: Agent teams and program names (prioritized for "calls" queries)
- **Survey metrics**: NPS (1-5 scale), FCR, Brand Trust with proper classifications

**Intelligent Team/Program Detection**: When users mention "BEV calls", "truck calls", etc., automatically prioritizes searching agent team names and program names.

Returns either **aggregated trends** or **individual call details** based on user needs.

## How to Run It

```bash
# Basic NPS trends by week
python .claude/skills/nps_trend/scripts/nps_trend.py --from 2026-01-01 --to 2026-12-31 --group-by week

# Intelligent team detection for "calls" queries
python .claude/skills/nps_trend/scripts/nps_trend.py --search "BEV calls" --from 2026-01-01 --to 2026-12-31

# Truck calls NPS analysis  
python .claude/skills/nps_trend/scripts/nps_trend.py --search "truck calls NPS" --from 2026-01-01 --to 2026-12-31

# Ford Pro calls with call-level details
python .claude/skills/nps_trend/scripts/nps_trend.py --search "Ford Pro calls" --detail-level calls --from 2026-01-01 --to 2026-12-31

# Charging NPS analysis by vehicle
python .claude/skills/nps_trend/scripts/nps_trend.py --search "charging" --vehicle "Mach-E" --group-by vehicle --from 2026-01-01 --to 2026-12-31

# NPS trends by team
python .claude/skills/nps_trend/scripts/nps_trend.py --group-by team --from 2026-01-01 --to 2026-12-31

# Low NPS call details (detractors only)
python .claude/skills/nps_trend/scripts/nps_trend.py --max-nps 3 --detail-level calls --from 2026-01-01 --to 2026-12-31
```

## Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--from` | Yes | - | Start date YYYY-MM-DD |
| `--to` | Yes | - | End date YYYY-MM-DD |
| `--search` | No | - | Search keyword across summaries, topics, cases, parts, teams, programs |
| `--group-by` | No | `week` | Aggregation: `week`, `month`, `vehicle`, `team`, `program` |
| `--vehicle` | No | all | Filter by vehicle model (e.g., "F-150", "Mach-E") |
| `--team` | No | all | Filter by agent team (e.g., "BEV", "Ford Pro") |
| `--program` | No | all | Filter by program name |
| `--detail-level` | No | `trends` | Return `trends` (aggregated) or `calls` (individual records) |
| `--min-nps` | No | - | Filter by minimum NPS score (1-5 scale) |
| `--max-nps` | No | - | Filter by maximum NPS score (1-5 scale) |
| `--include-summaries` | No | true | Always includes full call summaries in call-level output |
| `--limit` | No | 1000 | Maximum number of results to return |

## Search Capabilities  

The script searches across these **11 data sources** simultaneously:

### Call Content
1. **call_summary**: Full AI-generated call summaries

### Topic Classification (3 levels)
2. **topic_level1**: Broadest topic category
3. **topic_level2**: Mid-level topic classification  
4. **topic_level3**: Most specific topic details

### Case Classification (3 levels)
5. **caseclassificationlevel1**: High-level case category
6. **caseclassificationlevel2**: Detailed case classification
7. **caseclassificationlevel3**: Specific case subcategory

### Parts Information (2 fields)
8. **parts_features**: Vehicle parts and features mentioned
9. **parts_concern**: Specific parts concerns and issues

### Team & Program Data (2 fields - PRIORITIZED for "calls" queries)
10. **agent_team**: Agent team names (e.g., BEV teams, Ford Pro teams)
11. **program_name**: Program types (e.g., "BEV Support", "Ford Pro Charging")

## Intelligent "Calls" Detection Examples

### **"What's the NPS for BEV calls?"**
**Searches**: Agent teams like "FM-MSS-CRC-Houston-5508-BEV-Team", Programs like "BEV Support"
**Query Logic**: Prioritizes `LOWER(ct.Agent_Team) LIKE '%bev%' OR LOWER(cd.program_name) LIKE '%bev%'`

### **"Show me truck calls NPS trends"**
**Searches**: Agent teams like "FM-MSS-CRC-Houston-5508-Truck-InquiryTm02", Programs like "Truck Concern - Inbound"
**Query Logic**: Prioritizes `LOWER(ct.Agent_Team) LIKE '%truck%' OR LOWER(cd.program_name) LIKE '%truck%'`

### **"What's the FCR for charging calls?"**
**Searches**: Agent teams like "FordProCharging-FPCTm02", Programs like "Ford Pro Charging Model E"
**Query Logic**: Prioritizes `LOWER(ct.Agent_Team) LIKE '%charging%' OR LOWER(cd.program_name) LIKE '%charging%'`

### **"Ford Pro calls brand trust scores"**
**Searches**: Agent teams with "Ford Pro" in names, Programs like "Ford Pro Service"
**Query Logic**: Prioritizes `LOWER(ct.Agent_Team) LIKE '%ford pro%' OR LOWER(cd.program_name) LIKE '%ford pro%'`

## Example Usage Scenarios

### 1. BEV Team NPS Analysis
```bash
python nps_trend.py --search "BEV calls" --from 2026-01-01 --to 2026-12-31
```
**Finds**: BEV team NPS performance with promoter/detractor breakdown
**Use case**: *"How are BEV teams performing on customer satisfaction?"*

### 2. Charging Infrastructure NPS Impact
```bash  
python nps_trend.py --search "charging" --vehicle "Mach-E" --group-by vehicle --from 2026-01-01 --to 2026-12-31
```
**Finds**: Mach-E charging NPS by vehicle model year
**Use case**: *"Do charging issues impact Mach-E NPS scores?"*

### 3. Ford Pro Customer Loyalty
```bash
python nps_trend.py --search "Ford Pro calls" --group-by program --from 2026-01-01 --to 2026-12-31  
```
**Finds**: Ford Pro program NPS and brand trust analysis
**Use case**: *"Are Ford Pro customers more loyal (higher NPS)?"*

### 4. Detractor Call Analysis
```bash
python nps_trend.py --max-nps 3 --detail-level calls --limit 50 --from 2026-01-01 --to 2026-12-31
```
**Finds**: Individual detractor calls with full context
**Use case**: *"What are detractors saying in their calls?"*

### 5. Team Performance Comparison
```bash
python nps_trend.py --group-by team --from 2026-01-01 --to 2026-12-31
```
**Finds**: NPS performance by agent team
**Use case**: *"Which teams have the highest customer satisfaction?"*

## Output Format

### **Aggregated Trends Output**
```json
{
  "metadata": {
    "query_info": {
      "date_range": "2026-01-01 to 2026-12-31",
      "search_term": "BEV calls",
      "intelligent_team_search": true,
      "team_search_term": "bev",
      "group_by": "week",
      "detail_level": "trends",
      "result_count": 52,
      "search_sources": [
        "agent_team (prioritized for 'calls' queries)",
        "program_name (prioritized for 'calls' queries)",
        "call_summary (full text)",
        "topic_level1", "topic_level2", "topic_level3",
        "caseclassificationlevel1", "caseclassificationlevel2", "caseclassificationlevel3",
        "parts_features", "parts_concern"
      ]
    },
    "nps_analysis": {
      "overall_avg_nps": 3.2,
      "best_nps": 4.1,
      "worst_nps": 2.3,
      "overall_fcr_rate": 67.8,
      "total_calls_analyzed": 1847
    }
  },
  "results": [
    {
      "time_period": "2026-01-06",
      "total_calls": 89,
      "avg_nps": 2.8,
      "promoters": 12,
      "passives": 23,
      "detractors": 54,
      "nps_score": -47.19,
      "avg_fcr": 0.652,
      "fcr_resolved": 58,
      "fcr_not_resolved": 31,
      "fcr_resolution_rate": 65.17,
      "avg_brand_trust": 2.9,
      "avg_customer_sentiment": -0.23,
      "avg_agent_sentiment": 0.45,
      "avg_sentiment_gap": -0.68
    }
  ]
}
```

### **Call-Level Details Output**
```json
{
  "metadata": {
    "query_info": {
      "search_term": "Ford Pro calls",
      "detail_level": "calls",
      "include_summaries": true,
      "result_count": 156
    }
  },
  "results": [
    {
      "call_id": "2026032417020118002469322343403101",
      "casenumber": "CXH-08234567-B5D0Q2", 
      "call_date": "2026-03-24",
      "call_summary": "Customer calling about Ford Pro charging station installation delays. Originally scheduled for last month but keeps getting rescheduled. Customer frustrated as business operations impacted...",
      "vehicle_model": "E-Transit",
      "model_year": "2024",
      "agent_team": "FordProCharging-FPCTm02",
      "program_name": "Ford Pro Charging Model E",
      "case_level1": "Vehicle Concern",
      "case_level2": "Charging Infrastructure", 
      "case_level3": "Installation Delay",
      "topic_broad": "Ford Pro Services",
      "topic_mid": "Charging Solutions",
      "topic_specific": "Installation scheduling and delays",
      "parts_features": "Charging Infrastructure",
      "parts_concern": "Installation timeline delays",
      "nps_score": 2,
      "nps_category": "Detractor",
      "fcr_score": 3,
      "fcr_status": "Not Resolved",
      "brand_trust_score": 2.1,
      "customer_sentiment": -0.67,
      "agent_sentiment": 0.15,
      "sentiment_gap": -0.82,
      "customer_outcome": "Customer Degraded"
    }
  ]
}
```

## NPS Classifications (Corrected 1-5 Scale)

**Promoters** (NPS=5): Loyal enthusiasts who will keep buying and refer others  
**Passives** (NPS=4): Satisfied but unenthusiastic customers  
**Detractors** (NPS=1,2,3): Unhappy customers who can damage brand through negative word-of-mouth

**NPS Score Calculation**: `(% Promoters - % Detractors)`

## FCR Status Classifications

**Resolved** (FCR=1): Call resolved on first contact  
**Not Resolved** (FCR=2,3,4,5): Required multiple contacts or escalation

## Business Value

1. **Team Performance**: Identify which teams excel at customer satisfaction
2. **Program Effectiveness**: Measure NPS impact of specific programs (BEV, Ford Pro, etc.)
3. **Issue Impact**: Understand how specific issues (charging, transmission) affect loyalty
4. **Customer Experience**: Correlate NPS with sentiment and complexity
5. **Proactive Intervention**: Address team/program areas with declining NPS
6. **Strategic Planning**: Use NPS trends to guide resource allocation and training

## Data Sources Used

- **text_analytics.nlp_analytics.call_data**: Primary NPS, FCR, brand trust scores
- **text_analytics.nlp_analytics.sentiments**: Sentiment correlation with NPS
- **text_analytics.nlp_agent.call_summary_qwen06b**: Full call summaries for context
- **text_analytics.nlp_analytics.call_table**: Agent team information (key for intelligent detection)
- **text_analytics.nlp_analytics.models**: Vehicle model and year details
- **text_analytics.nlp_dashboard.case_metadata**: Case classifications (3 levels)
- **text_analytics.nlp_analytics.topic_xwalk**: Topic assignments
- **text_analytics.nlp_configs.topic_detail**: Topic hierarchy (3 levels)
- **text_analytics.nlp_analytics.parts_unfiltered**: Parts and features data

## Error Handling
- Returns empty result set if no calls match search criteria
- Filters out NULL NPS values automatically (focuses on actual survey responses)
- Handles missing team/program data gracefully with appropriate labels
- Validates date ranges and NPS score parameters
- Provides clear error messages for invalid inputs
- Includes search source tracking in metadata
