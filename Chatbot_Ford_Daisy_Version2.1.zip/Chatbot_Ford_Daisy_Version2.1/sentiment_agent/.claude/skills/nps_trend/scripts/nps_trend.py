"""
Comprehensive NPS & Survey Trend Analysis with Intelligent Team/Program Detection

Analyzes NPS, FCR, and brand trust scores with comprehensive search across summaries,
topics, cases, parts, teams, and programs. Includes intelligent detection for "calls"
queries that prioritize team/program search.

Usage:
    python nps_trend.py --from 2026-01-01 --to 2026-01-31 --group-by week
    python nps_trend.py --search "BEV calls" --from 2026-01-01 --to 2026-12-31
    python nps_trend.py --search "truck calls NPS" --from 2026-01-01 --to 2026-12-31
    python nps_trend.py --search "charging" --vehicle "Mach-E" --from 2026-01-01 --to 2026-12-31
    python nps_trend.py --search "Ford Pro calls" --detail-level calls --from 2026-01-01 --to 2026-12-31

Output: JSON with NPS analysis - either aggregated trends or call-level details
"""
import argparse
import json
import os
import sys
from decimal import Decimal
from pathlib import Path
from databricks import sql
import requests
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parents[5] / ".env", override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


CATALOG = os.environ.get("DATABRICKS_CATALOG", "text_analytics")
SCHEMA = os.environ.get("DATABRICKS_SCHEMA", "nlp_analytics")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--from", dest="date_from", required=True)
    parser.add_argument("--to", dest="date_to", required=True)
    parser.add_argument("--search", dest="search_term", default=None,
                        help="Search keyword across summaries, topics, cases, parts, teams, programs")
    parser.add_argument("--group-by", dest="group_by",
                        choices=["week", "month", "vehicle", "team", "program"], default="week")
    parser.add_argument("--vehicle", dest="vehicle", default=None,
                        help="Filter by vehicle model (e.g., F-150, Mach-E)")
    parser.add_argument("--team", dest="team", default=None,
                        help="Filter by agent team (e.g., BEV, Ford Pro)")
    parser.add_argument("--program", dest="program", default=None,
                        help="Filter by program name")
    parser.add_argument("--detail-level", dest="detail_level",
                        choices=["trends", "calls"], default="trends",
                        help="Return aggregated trends or individual call details")
    parser.add_argument("--min-nps", dest="min_nps", type=float, default=None,
                        help="Filter by minimum NPS score (1-5 scale)")
    parser.add_argument("--max-nps", dest="max_nps", type=float, default=None,
                        help="Filter by maximum NPS score (1-5 scale)")
    parser.add_argument("--include-summaries", dest="include_summaries", action="store_true",
                        help="Always includes full call summaries in call-level output (kept for compatibility)")
    parser.add_argument("--limit", type=int, default=1000,
                        help="Maximum number of results to return")
    args, _ = parser.parse_known_args()

    # Build parameters
    params = {
        "date_from": args.date_from,
        "date_to": args.date_to,
    }

    # Base WHERE conditions
    where_conditions = [
        "DATE(cd.call_date) >= :date_from",
        "DATE(cd.call_date) <= :date_to",
        # Filter for actual NPS data (1-5 scale)
        "cd.nps IS NOT NULL",
        "cd.nps BETWEEN 1 AND 5"
    ]

    # Add NPS range filters
    if args.min_nps is not None:
        where_conditions.append(f"cd.nps >= {args.min_nps}")
    if args.max_nps is not None:
        where_conditions.append(f"cd.nps <= {args.max_nps}")

    # Add comprehensive search filter across all 11 sources
    if args.search_term:
        # Check if the search term contains "calls" - indicating team/program focus
        if "calls" in args.search_term.lower():
            # Extract the prefix before "calls" for team/program search
            search_parts = args.search_term.lower().split("calls")[0].strip()

            # Primary search: Focus on team/program names for "X calls" queries
            search_conditions = [
                # Team & Program search (PRIMARY for "calls" queries)
                "LOWER(ct.Agent_Team) LIKE LOWER(:team_search_pattern)",
                "LOWER(cd.program_name) LIKE LOWER(:program_search_pattern)",
                # Secondary: Also search content for the term
                "LOWER(cs.summary) LIKE LOWER(:search_pattern)",
                "LOWER(td.topic_level1) LIKE LOWER(:search_pattern)",
                "LOWER(td.topic_level2) LIKE LOWER(:search_pattern)",
                "LOWER(td.topic_level3) LIKE LOWER(:search_pattern)",
                "LOWER(cm.caseclassificationlevel1) LIKE LOWER(:search_pattern)",
                "LOWER(cm.caseclassificationlevel2) LIKE LOWER(:search_pattern)",
                "LOWER(cm.caseclassificationlevel3) LIKE LOWER(:search_pattern)",
                "LOWER(pf.parts_features) LIKE LOWER(:search_pattern)",
                "LOWER(pf.parts_concern) LIKE LOWER(:search_pattern)"
            ]
            params["team_search_pattern"] = f"%{search_parts}%"
            params["program_search_pattern"] = f"%{search_parts}%"
            params["search_pattern"] = f"%{args.search_term}%"
        else:
            # Standard search across all sources for non-"calls" queries
            search_conditions = [
                # Call summaries (full text search)
                "LOWER(cs.summary) LIKE LOWER(:search_pattern)",
                # Topic levels (all 3 levels)
                "LOWER(td.topic_level1) LIKE LOWER(:search_pattern)",
                "LOWER(td.topic_level2) LIKE LOWER(:search_pattern)",
                "LOWER(td.topic_level3) LIKE LOWER(:search_pattern)",
                # Case classification levels (all 3 levels)
                "LOWER(cm.caseclassificationlevel1) LIKE LOWER(:search_pattern)",
                "LOWER(cm.caseclassificationlevel2) LIKE LOWER(:search_pattern)",
                "LOWER(cm.caseclassificationlevel3) LIKE LOWER(:search_pattern)",
                # Parts information (both fields)
                "LOWER(pf.parts_features) LIKE LOWER(:search_pattern)",
                "LOWER(pf.parts_concern) LIKE LOWER(:search_pattern)",
                # Team & Program search
                "LOWER(ct.Agent_Team) LIKE LOWER(:search_pattern)",
                "LOWER(cd.program_name) LIKE LOWER(:search_pattern)"
            ]
            params["search_pattern"] = f"%{args.search_term}%"

        where_conditions.append(f"({' OR '.join(search_conditions)})")

    # Add vehicle filter
    if args.vehicle:
        where_conditions.append("LOWER(COALESCE(m.ModelVehicleLine, cd.modelvehicleline)) LIKE LOWER(:vehicle_pattern)")
        params["vehicle_pattern"] = f"%{args.vehicle}%"

    # Add team filter
    if args.team:
        where_conditions.append("LOWER(ct.Agent_Team) LIKE LOWER(:team_pattern)")
        params["team_pattern"] = f"%{args.team}%"

    # Add program filter
    if args.program:
        where_conditions.append("LOWER(cd.program_name) LIKE LOWER(:program_pattern)")
        params["program_pattern"] = f"%{args.program}%"

    where_clause = " AND ".join(where_conditions)

    # Determine if we need call-level details or aggregated trends
    if args.detail_level == "calls":
        # CALL-LEVEL DETAILS QUERY - Always use full summaries
        summary_field = "cs.summary"

        query = f"""
        -- NPS CALL-LEVEL ANALYSIS WITH COMPREHENSIVE SEARCH AND INTELLIGENT TEAM/PROGRAM DETECTION
        -- Individual call records with full context when users need call details

        SELECT
            -- === CALL IDENTIFICATION ===
            cd.call_id,
            cd.casenumber,
            DATE(cd.call_date) AS call_date,

            -- === CALL SUMMARY ===
            {summary_field} AS call_summary,

            -- === VEHICLE INFORMATION ===
            COALESCE(m.ModelVehicleLine, cd.modelvehicleline, 'Unknown Vehicle') AS vehicle_model,
            COALESCE(m.Model_Year, 'Unknown Year') AS model_year,

            -- === AGENT & TEAM INFORMATION ===
            COALESCE(ct.Agent_Team, 'Unknown Team') AS agent_team,
            COALESCE(cd.program_name, 'Unknown Program') AS program_name,

            -- === CASE CLASSIFICATION ===
            COALESCE(cm.caseclassificationlevel1, 'No Case Data') AS case_level1,
            COALESCE(cm.caseclassificationlevel2, 'No Case Data') AS case_level2,
            COALESCE(cm.caseclassificationlevel3, 'No Case Data') AS case_level3,

            -- === TOPIC INFORMATION ===
            COALESCE(td.topic_level1, 'No Topic Data') AS topic_broad,
            COALESCE(td.topic_level2, 'No Topic Data') AS topic_mid,
            COALESCE(td.topic_level3, 'No Topic Data') AS topic_specific,
            COALESCE(td.topic_category, 'No Topic Category') AS topic_category,

            -- === PARTS INFORMATION ===
            COALESCE(pf.parts_features, 'No Parts Data') AS parts_features,
            COALESCE(pf.parts_concern, 'No Parts Concern') AS parts_concern,

            -- === NPS METRICS (corrected for 1-5 scale) ===
            cd.nps AS nps_score,
            CASE
                WHEN cd.nps = 5 THEN 'Promoter'
                WHEN cd.nps = 4 THEN 'Passive'
                WHEN cd.nps IN (1,2,3) THEN 'Detractor'
                ELSE 'No NPS'
            END AS nps_category,

            -- === FCR & BRAND TRUST ===
            cd.fcr AS fcr_score,
            CASE
                WHEN cd.fcr = 1 THEN 'Resolved'
                WHEN cd.fcr IN (2,3,4,5) THEN 'Not Resolved'
                ELSE 'No FCR Data'
            END AS fcr_status,
            cd.brand_trust AS brand_trust_score,

            -- === SENTIMENT CORRELATION ===
            ROUND(s.customer_sentiment, 4) AS customer_sentiment,
            ROUND(s.agent_sentiment, 4) AS agent_sentiment,
            ROUND(s.customer_sentiment - s.agent_sentiment, 4) AS sentiment_gap,

            -- === CUSTOMER OUTCOME ===
            CASE
                WHEN cd.cust_end_sent - cd.cust_beg_sent > 0.2 THEN 'Customer Improved'
                WHEN cd.cust_end_sent - cd.cust_beg_sent < -0.2 THEN 'Customer Degraded'
                ELSE 'Customer Stable'
            END AS customer_outcome

        FROM {CATALOG}.{SCHEMA}.call_data cd

            -- === CORE JOINS ===
            LEFT JOIN {CATALOG}.{SCHEMA}.sentiments s ON cd.call_id = s.call_id
            LEFT JOIN {CATALOG}.nlp_agent.call_summary_qwen06b cs ON cd.call_id = cs.call_id
            LEFT JOIN {CATALOG}.{SCHEMA}.call_table ct ON cd.call_id = ct.call_id
            LEFT JOIN {CATALOG}.{SCHEMA}.models m ON cd.call_id = m.call_id
            LEFT JOIN {CATALOG}.nlp_dashboard.case_metadata cm ON cd.casenumber = cm.casenumber
            LEFT JOIN {CATALOG}.{SCHEMA}.topic_xwalk tx ON cd.call_id = tx.call_id
            LEFT JOIN {CATALOG}.nlp_configs.topic_detail td ON tx.topic_id = td.topic_id
            LEFT JOIN {CATALOG}.{SCHEMA}.parts_unfiltered pf ON cd.call_id = pf.call_id

        WHERE {where_clause}

        ORDER BY
            cd.nps ASC,  -- Show worst NPS first
            cd.call_date DESC

        LIMIT {args.limit}
        """

    else:
        # AGGREGATED TRENDS QUERY
        if args.group_by == "vehicle":
            group_expr = "COALESCE(m.ModelVehicleLine, cd.modelvehicleline, 'Unknown Vehicle')"
            label = "vehicle_model"
            order_by = "avg_nps ASC"
        elif args.group_by == "team":
            group_expr = "COALESCE(ct.Agent_Team, 'Unknown Team')"
            label = "agent_team"
            order_by = "avg_nps ASC"
        elif args.group_by == "program":
            group_expr = "COALESCE(cd.program_name, 'Unknown Program')"
            label = "program_name"
            order_by = "avg_nps ASC"
        elif args.group_by == "week":
            group_expr = "DATE_TRUNC('week', cd.call_date)"
            label = "time_period"
            order_by = "time_period ASC"
        else:  # month
            group_expr = "DATE_TRUNC('month', cd.call_date)"
            label = "time_period"
            order_by = "time_period ASC"

        query = f"""
        -- NPS TRENDS WITH INTELLIGENT TEAM/PROGRAM DETECTION
        -- Aggregated analysis by time period, vehicle, team, or program

        SELECT
            {group_expr} AS {label},
            COUNT(*) AS total_calls,

            -- === NPS ANALYSIS (corrected 1-5 scale) ===
            ROUND(AVG(cd.nps), 2) AS avg_nps,
            SUM(CASE WHEN cd.nps = 5 THEN 1 ELSE 0 END) AS promoters,
            SUM(CASE WHEN cd.nps = 4 THEN 1 ELSE 0 END) AS passives,
            SUM(CASE WHEN cd.nps IN (1,2,3) THEN 1 ELSE 0 END) AS detractors,
            ROUND(100.0 * (SUM(CASE WHEN cd.nps = 5 THEN 1 ELSE 0 END) - SUM(CASE WHEN cd.nps IN (1,2,3) THEN 1 ELSE 0 END)) / COUNT(*), 2) AS nps_score,

            -- === FCR ANALYSIS ===
            ROUND(AVG(cd.fcr), 3) AS avg_fcr,
            SUM(CASE WHEN cd.fcr = 1 THEN 1 ELSE 0 END) AS fcr_resolved,
            SUM(CASE WHEN cd.fcr IN (2,3,4,5) THEN 1 ELSE 0 END) AS fcr_not_resolved,
            ROUND(100.0 * SUM(CASE WHEN cd.fcr = 1 THEN 1 ELSE 0 END) / COUNT(CASE WHEN cd.fcr IS NOT NULL THEN 1 END), 2) AS fcr_resolution_rate,

            -- === BRAND TRUST ANALYSIS ===
            ROUND(AVG(cd.brand_trust), 2) AS avg_brand_trust,

            -- === SENTIMENT CORRELATION ===
            ROUND(AVG(s.customer_sentiment), 4) AS avg_customer_sentiment,
            ROUND(AVG(s.agent_sentiment), 4) AS avg_agent_sentiment,
            ROUND(AVG(s.customer_sentiment - s.agent_sentiment), 4) AS avg_sentiment_gap

        FROM {CATALOG}.{SCHEMA}.call_data cd

            -- === CORE JOINS ===
            LEFT JOIN {CATALOG}.{SCHEMA}.sentiments s ON cd.call_id = s.call_id
            LEFT JOIN {CATALOG}.nlp_agent.call_summary_qwen06b cs ON cd.call_id = cs.call_id
            LEFT JOIN {CATALOG}.{SCHEMA}.call_table ct ON cd.call_id = ct.call_id
            LEFT JOIN {CATALOG}.{SCHEMA}.models m ON cd.call_id = m.call_id
            LEFT JOIN {CATALOG}.nlp_dashboard.case_metadata cm ON cd.casenumber = cm.casenumber
            LEFT JOIN {CATALOG}.{SCHEMA}.topic_xwalk tx ON cd.call_id = tx.call_id
            LEFT JOIN {CATALOG}.nlp_configs.topic_detail td ON tx.topic_id = td.topic_id
            LEFT JOIN {CATALOG}.{SCHEMA}.parts_unfiltered pf ON cd.call_id = pf.call_id

        WHERE {where_clause}

        GROUP BY {group_expr}

        ORDER BY {order_by}

        LIMIT {args.limit}
        """

    try:
        with get_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(query, params)
                rows = cursor.fetchall()
                columns = [d[0] for d in cursor.description]

        def serialize(v):
            if isinstance(v, Decimal): return float(v)
            if hasattr(v, "isoformat"): return str(v)
            return v

        result = [dict(zip(columns, [serialize(val) for val in row])) for row in rows]

        # Detect if intelligent team/program search was used
        calls_based_search = "calls" in args.search_term.lower() if args.search_term else False
        search_prefix = args.search_term.lower().split("calls")[0].strip() if calls_based_search else None

        # Add metadata
        metadata = {
            "query_info": {
                "date_range": f"{args.date_from} to {args.date_to}",
                "search_term": args.search_term,
                "intelligent_team_search": calls_based_search,
                "team_search_term": search_prefix if calls_based_search else None,
                "group_by": args.group_by,
                "detail_level": args.detail_level,
                "vehicle_filter": args.vehicle,
                "team_filter": args.team,
                "program_filter": args.program,
                "nps_range": f"{args.min_nps or 1}-{args.max_nps or 5}",
                "include_summaries": True,  # Always includes full summaries
                "result_count": len(result),
                "search_sources": [
                    "call_summary (full text)",
                    "topic_level1", "topic_level2", "topic_level3",
                    "caseclassificationlevel1", "caseclassificationlevel2", "caseclassificationlevel3",
                    "parts_features", "parts_concern",
                    "agent_team (prioritized for 'calls' queries)" if calls_based_search else "agent_team",
                    "program_name (prioritized for 'calls' queries)" if calls_based_search else "program_name"
                ] if args.search_term else []
            }
        }

        # Calculate summary statistics for trends
        if args.detail_level == "trends" and result:
            nps_scores = [r.get('avg_nps', 0) for r in result if r.get('avg_nps') is not None]
            fcr_rates = [r.get('fcr_resolution_rate', 0) for r in result if r.get('fcr_resolution_rate') is not None]

            metadata["nps_analysis"] = {
                "overall_avg_nps": round(sum(nps_scores) / len(nps_scores), 2) if nps_scores else 0,
                "best_nps": max(nps_scores) if nps_scores else None,
                "worst_nps": min(nps_scores) if nps_scores else None,
                "overall_fcr_rate": round(sum(fcr_rates) / len(fcr_rates), 2) if fcr_rates else 0,
                "total_calls_analyzed": sum([r.get('total_calls', 0) for r in result])
            }

        output = {
            "metadata": metadata,
            "results": result
        }

        print(json.dumps(output, indent=2))

    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()