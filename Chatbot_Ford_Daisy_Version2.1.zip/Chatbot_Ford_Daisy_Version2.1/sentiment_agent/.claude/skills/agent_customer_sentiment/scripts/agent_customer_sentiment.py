"""
Agent vs Customer Sentiment Analysis with Comprehensive Search

Compares agent sentiment vs customer sentiment with search across:
- Full call summaries
- Topic levels 1, 2, 3
- Case classification levels 1, 2, 3
- Parts features and concerns
- Vehicle and team data

Usage:
    python agent_customer_sentiment.py --from 2026-06-01 --to 2026-06-30
    python agent_customer_sentiment.py --from 2026-06-01 --to 2026-06-30 --search charging
    python agent_customer_sentiment.py --from 2026-06-01 --to 2026-06-30 --search buyback --vehicle F-150
    python agent_customer_sentiment.py --from 2026-06-01 --to 2026-06-30 --search transmission --min-gap 0.3

Output: JSON array with individual call analysis including full summaries and sentiment gaps
"""
import argparse
import json
import os
import sys
from decimal import Decimal
from pathlib import Path
from databricks import sql
import requests
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parents[5] / ".env", override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


CATALOG = os.environ.get("DATABRICKS_CATALOG", "text_analytics")
SCHEMA = os.environ.get("DATABRICKS_SCHEMA", "nlp_analytics")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--from", dest="date_from", required=True)
    parser.add_argument("--to", dest="date_to", required=True)
    parser.add_argument("--search", dest="search_term", default=None,
                        help="Search keyword across summaries, topics, cases, parts")
    parser.add_argument("--vehicle", dest="vehicle", default=None)
    parser.add_argument("--team", dest="team", default=None)
    parser.add_argument("--min-gap", dest="min_gap", type=float, default=0.1,
                        help="Minimum sentiment gap threshold")
    parser.add_argument("--limit", type=int, default=1000)
    args, _ = parser.parse_known_args()

    # Build parameters
    params = {
        "date_from": args.date_from,
        "date_to": args.date_to,
    }

    # Base WHERE conditions
    where_conditions = [
        "DATE(cd.call_date) >= :date_from",
        "DATE(cd.call_date) <= :date_to",
        "s.agent_sentiment IS NOT NULL",
        "s.customer_sentiment IS NOT NULL"
    ]

    # Add minimum gap filter
    if args.min_gap > 0:
        where_conditions.append(f"ABS(s.customer_sentiment - s.agent_sentiment) >= {args.min_gap}")

    # Add search filter across all 9 sources
    if args.search_term:
        search_conditions = [
            # Call summaries (full text search)
            "LOWER(cs.summary) LIKE LOWER(:search_pattern)",
            # Topic levels (all 3 levels)
            "LOWER(td.topic_level1) LIKE LOWER(:search_pattern)",
            "LOWER(td.topic_level2) LIKE LOWER(:search_pattern)",
            "LOWER(td.topic_level3) LIKE LOWER(:search_pattern)",
            # Case classification levels (all 3 levels)
            "LOWER(cm.caseclassificationlevel1) LIKE LOWER(:search_pattern)",
            "LOWER(cm.caseclassificationlevel2) LIKE LOWER(:search_pattern)",
            "LOWER(cm.caseclassificationlevel3) LIKE LOWER(:search_pattern)",
            # Parts information (both fields)
            "LOWER(pf.parts_features) LIKE LOWER(:search_pattern)",
            "LOWER(pf.parts_concern) LIKE LOWER(:search_pattern)"
        ]
        where_conditions.append(f"({' OR '.join(search_conditions)})")
        params["search_pattern"] = f"%{args.search_term}%"

    # Add vehicle filter
    if args.vehicle:
        where_conditions.append("LOWER(COALESCE(m.ModelVehicleLine, cd.modelvehicleline)) LIKE LOWER(:vehicle_pattern)")
        params["vehicle_pattern"] = f"%{args.vehicle}%"

    # Add team filter
    if args.team:
        where_conditions.append("LOWER(ct.Agent_Team) LIKE LOWER(:team_pattern)")
        params["team_pattern"] = f"%{args.team}%"

    where_clause = " AND ".join(where_conditions)

    # Build the exact query you specified with search capabilities
    query = f"""
    -- AGENT vs CUSTOMER SENTIMENT WITH CALL DETAILS AND SUMMARIES
    -- Fixed to show call_id, summaries, and proper joins with comprehensive search

    SELECT
        -- === CALL IDENTIFICATION ===
        s.call_id,
        cd.casenumber,
        DATE(cd.call_date) AS call_date,

        -- === CALL SUMMARY (FULL CONTENT) ===
        cs.summary AS call_summary_preview,

        -- === VEHICLE INFORMATION (FIXED) ===
        COALESCE(m.ModelVehicleLine, cd.modelvehicleline, 'Unknown Vehicle') AS vehicle_model,
        COALESCE(m.Model_Year, 'Unknown Year') AS model_year,

        -- === AGENT & TEAM INFORMATION ===
        COALESCE(ct.Agent_Team, 'Unknown Team') AS agent_team,
        COALESCE(cd.program_name, 'Unknown Program') AS program_name,

        -- === CASE CLASSIFICATION ===
        COALESCE(cm.caseclassificationlevel1, 'No Case Data') AS case_level1,
        COALESCE(cm.caseclassificationlevel2, 'No Case Data') AS case_level2,
        COALESCE(cm.caseclassificationlevel3, 'No Case Data') AS case_level3,

        -- === TOPIC INFORMATION ===
        COALESCE(td.topic_level1, 'No Topic Data') AS topic_broad,
        COALESCE(td.topic_level2, 'No Topic Data') AS topic_mid,
        COALESCE(td.topic_level3, 'No Topic Data') AS topic_specific,
        COALESCE(td.topic_category, 'No Topic Category') AS topic_category,

        -- === PARTS INFORMATION (FIXED TABLE NAME) ===
        COALESCE(pf.parts_features, 'No Parts Data') AS parts_features,
        COALESCE(pf.parts_concern, 'No Parts Concern') AS parts_concern,

        -- === PRIMARY SENTIMENT SCORES ===
        ROUND(s.agent_sentiment, 4) AS agent_sentiment,
        ROUND(s.customer_sentiment, 4) AS customer_sentiment,
        ROUND(s.overall_sentiment, 4) AS overall_sentiment,
        ROUND(s.customer_sentiment - s.agent_sentiment, 4) AS sentiment_gap,

        -- === SENTIMENT JOURNEY (Beginning to End) ===
        ROUND(cd.agent_beg_sent, 4) AS agent_start_sentiment,
        ROUND(cd.agent_end_sent, 4) AS agent_end_sentiment,
        ROUND(cd.cust_beg_sent, 4) AS customer_start_sentiment,
        ROUND(cd.cust_end_sent, 4) AS customer_end_sentiment,

        -- === SENTIMENT CHANGES DURING CALL ===
        ROUND(cd.agent_end_sent - cd.agent_beg_sent, 4) AS agent_sentiment_change,
        ROUND(cd.cust_end_sent - cd.cust_beg_sent, 4) AS customer_sentiment_change,
        ROUND(cd.cust_end_sent - cd.agent_end_sent, 4) AS final_sentiment_gap,

        -- === SENTIMENT LABELS ===
        cd.sentiment_label AS overall_sentiment_label,
        cd.agent_beg_sent_label AS agent_start_label,
        cd.agent_end_sent_label AS agent_end_label,
        cd.cust_beg_sent_label AS customer_start_label,
        cd.cust_end_sent_label AS customer_end_label,

        -- === CALL COMPLEXITY ===
        ROUND(cd.complexity, 4) AS complexity_score,
        cd.complexity_label,

        -- === OUTCOME ANALYSIS ===
        CASE
            WHEN cd.cust_end_sent - cd.cust_beg_sent > 0.2 THEN 'Customer Improved'
            WHEN cd.cust_end_sent - cd.cust_beg_sent < -0.2 THEN 'Customer Degraded'
            ELSE 'Customer Stable'
        END AS customer_outcome,

        CASE
            WHEN ABS(s.customer_sentiment - s.agent_sentiment) > 0.3 THEN 'High Sentiment Gap'
            WHEN ABS(s.customer_sentiment - s.agent_sentiment) > 0.1 THEN 'Moderate Sentiment Gap'
            ELSE 'Low Sentiment Gap'
        END AS sentiment_gap_category

    FROM {CATALOG}.{SCHEMA}.sentiments s

        -- === CORE JOINS ===
        INNER JOIN {CATALOG}.{SCHEMA}.call_data cd ON s.call_id = cd.call_id

        -- === CALL SUMMARIES (for actual call content) ===
        LEFT JOIN {CATALOG}.nlp_agent.call_summary_qwen06b cs ON s.call_id = cs.call_id

        -- === TEAM INFORMATION ===
        LEFT JOIN {CATALOG}.{SCHEMA}.call_table ct ON s.call_id = ct.call_id

        -- === VEHICLE MODEL (try both join methods) ===
        LEFT JOIN {CATALOG}.{SCHEMA}.models m ON s.call_id = m.call_id

        -- === CASE CLASSIFICATION ===
        LEFT JOIN {CATALOG}.nlp_dashboard.case_metadata cm ON cd.casenumber = cm.casenumber

        -- === TOPICS ===
        LEFT JOIN {CATALOG}.{SCHEMA}.topic_xwalk tx ON s.call_id = tx.call_id
        LEFT JOIN {CATALOG}.nlp_configs.topic_detail td ON tx.topic_id = td.topic_id

        -- === PARTS (FIXED - using correct table name) ===
        LEFT JOIN {CATALOG}.{SCHEMA}.parts_unfiltered pf ON s.call_id = pf.call_id

    WHERE {where_clause}

    ORDER BY
        -- Show most significant sentiment gaps first
        ABS(s.customer_sentiment - s.agent_sentiment) DESC,
        cd.call_date DESC

    LIMIT {args.limit}
    """

    try:
        with get_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(query, params)
                rows = cursor.fetchall()
                columns = [d[0] for d in cursor.description]

        def serialize(v):
            if isinstance(v, Decimal): return float(v)
            if hasattr(v, "isoformat"): return str(v)
            return v

        result = [dict(zip(columns, [serialize(val) for val in row])) for row in rows]

        # Add metadata
        metadata = {
            "query_info": {
                "date_range": f"{args.date_from} to {args.date_to}",
                "search_term": args.search_term,
                "vehicle_filter": args.vehicle,
                "team_filter": args.team,
                "min_gap": args.min_gap,
                "result_count": len(result),
                "search_sources": [
                    "call_summary (full text)",
                    "topic_level1", "topic_level2", "topic_level3",
                    "caseclassificationlevel1", "caseclassificationlevel2", "caseclassificationlevel3",
                    "parts_features", "parts_concern"
                ] if args.search_term else []
            }
        }

        output = {
            "metadata": metadata,
            "results": result
        }

        print(json.dumps(output, indent=2))

    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()