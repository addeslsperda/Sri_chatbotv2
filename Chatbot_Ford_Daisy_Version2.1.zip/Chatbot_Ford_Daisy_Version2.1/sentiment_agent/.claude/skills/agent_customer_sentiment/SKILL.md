---
name: agent_customer_sentiment
display_name: Agent vs Customer Sentiment Analysis
description: Compares agent sentiment against customer sentiment with comprehensive search across vehicles, teams, topics, cases, parts, and call summaries. Use for "agent vs customer sentiment", "sentiment gap analysis", "how agents and customers feel differently", "charging sentiment gaps", "buyback sentiment analysis".
signals:
  - agent vs customer sentiment
  - agent sentiment vs customer sentiment
  - sentiment gap between agent and customer
  - how agents and customers feel differently
  - agent sentiment vs customer sentiment by vehicle
  - differences in sentiment
  - charging sentiment gaps
  - buyback sentiment analysis
  - transmission sentiment issues
requires:
  - date range (from and to)
not_good_for: Overall sentiment by vehicle only (use sentiment_by_vehicle), NPS trends (use nps_trend), positive feedback only (use positive_feedback)
---

# Agent vs Customer Sentiment Analysis

## What this script does
Compares agent sentiment against customer sentiment with comprehensive search capabilities across:
- **Call summaries**: Full text search of AI-generated call summaries
- **Topic levels**: All 3 topic levels (topic_level1, topic_level2, topic_level3) 
- **Case classifications**: All 3 case levels (caseclassificationlevel1, caseclassificationlevel2, caseclassificationlevel3)
- **Parts information**: Both parts_features and parts_concern fields
- **Vehicle and team data**: Complete agent and customer sentiment comparison

Returns individual call records with complete sentiment analysis, call summaries, and contextual data.

## Key Features
- **Individual call analysis**: Shows each call_id with detailed sentiment metrics
- **Complete call summaries**: Full call summary content for context
- **Multi-source search**: Searches across 9 different data fields simultaneously
- **Sentiment gap identification**: Highlights where agents and customers feel differently
- **Sentiment journey tracking**: Shows how sentiment changes during the call
- **Priority identification**: Identifies critical sentiment disconnects

## How to run it

```bash
# Basic agent vs customer sentiment analysis
python .claude/skills/agent_customer_sentiment/scripts/agent_customer_sentiment.py --from 2026-06-01 --to 2026-06-30

# Search for charging-related sentiment gaps
python .claude/skills/agent_customer_sentiment/scripts/agent_customer_sentiment.py --from 2026-06-01 --to 2026-06-30 --search charging

# Analyze buyback sentiment with summaries
python .claude/skills/agent_customer_sentiment/scripts/agent_customer_sentiment.py --from 2026-06-01 --to 2026-06-30 --search buyback --vehicle F-150

# Find transmission issues with high sentiment gaps
python .claude/skills/agent_customer_sentiment/scripts/agent_customer_sentiment.py --from 2026-06-01 --to 2026-06-30 --search transmission --min-gap 0.3
```

## Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--from` | Yes | — | Start date YYYY-MM-DD |
| `--to` | Yes | — | End date YYYY-MM-DD |
| `--search` | No | — | Search keyword across summaries, topics, cases, parts |
| `--vehicle` | No | all | Filter by vehicle model |
| `--team` | No | all | Filter by agent team |
| `--min-gap` | No | 0.1 | Minimum sentiment gap threshold |
| `--limit` | No | 1000 | Maximum number of results |

## Search Capabilities

The script searches across these 9 data sources:

### Call Content
1. **call_summary**: Full AI-generated call summaries

### Topic Classification (3 levels)  
2. **topic_level1**: Broadest topic category
3. **topic_level2**: Mid-level topic classification
4. **topic_level3**: Most specific topic details

### Case Classification (3 levels)
5. **caseclassificationlevel1**: High-level case category
6. **caseclassificationlevel2**: Detailed case classification  
7. **caseclassificationlevel3**: Specific case subcategory

### Parts Information (2 fields)
8. **parts_features**: Vehicle parts and features mentioned
9. **parts_concern**: Specific parts concerns and issues

## Example Usage Scenarios

### 1. Charging Infrastructure Analysis
```bash
python agent_customer_sentiment.py --from 2026-06-01 --to 2026-06-30 --search charging
```
**Finds**: All calls mentioning "charging" in summaries, topics, cases, or parts
**Use case**: "Show me agent vs customer sentiment differences when discussing charging failures"

### 2. Buyback Request Analysis  
```bash
python agent_customer_sentiment.py --from 2026-06-01 --to 2026-06-30 --search buyback --vehicle F-150
```
**Finds**: F-150 calls with "buyback" mentions across all data sources
**Use case**: "How do agents and customers feel differently about F-150 buyback requests?"

### 3. Transmission Problem Analysis
```bash
python agent_customer_sentiment.py --from 2026-06-01 --to 2026-06-30 --search transmission --min-gap 0.3
```
**Finds**: Transmission-related calls with significant sentiment gaps
**Use case**: "What transmission issues show the biggest agent-customer sentiment disconnect?"

## Output Format

```json
[
  {
    "call_id": "2026062414020118002469322343403101",
    "casenumber": "CXH-06438319-Y9B6Q9", 
    "call_date": "2026-06-24",
    "call_summary_preview": "Customer called regarding charging station installation issues with their 2024 Mach-E. Initial setup failed multiple times...",
    "vehicle_model": "MUSTANG MACH-E",
    "model_year": "2024",
    "agent_team": "FM-MSS-CRC-Houston-BEV-Team",
    "program_name": "BEV Support",
    "case_level1": "Technical Support", 
    "case_level2": "Charging Issues",
    "case_level3": "Home Charger Installation",
    "topic_broad": "Vehicle Performance",
    "topic_mid": "Charging Systems", 
    "topic_specific": "Home Charging Setup",
    "topic_category": "technical_support",
    "parts_features": "Charging Station",
    "parts_concern": "Installation failure", 
    "agent_sentiment": 0.45,
    "customer_sentiment": -0.25,
    "overall_sentiment": 0.10,
    "sentiment_gap": -0.70,
    "agent_start_sentiment": 0.4,
    "agent_end_sentiment": 0.5,
    "customer_start_sentiment": -0.1, 
    "customer_end_sentiment": -0.4,
    "agent_sentiment_change": 0.1,
    "customer_sentiment_change": -0.3,
    "final_sentiment_gap": -0.9,
    "overall_sentiment_label": "neutral",
    "agent_start_label": "positive",
    "agent_end_label": "positive", 
    "customer_start_label": "negative",
    "customer_end_label": "very_negative",
    "complexity_score": 8.5,
    "complexity_label": "high",
    "customer_outcome": "Customer Degraded",
    "sentiment_gap_category": "High Sentiment Gap"
  }
]
```

## Business Value

1. **Training Identification**: Find teams with consistent sentiment gaps needing empathy training
2. **Product Quality Issues**: Identify vehicles/parts with recurring sentiment problems
3. **Process Improvement**: Locate topics/cases where communication breaks down
4. **Customer Experience**: Track sentiment journey to improve call outcomes
5. **Issue Prioritization**: Critical sentiment gaps indicate urgent intervention needs

## Data Sources Used

- **text_analytics.nlp_analytics.sentiments**: Primary sentiment scores
- **text_analytics.nlp_analytics.call_data**: Call details and sentiment journey  
- **text_analytics.nlp_agent.call_summary_qwen06b**: Full call summaries
- **text_analytics.nlp_analytics.call_table**: Agent team information
- **text_analytics.nlp_analytics.models**: Vehicle model details
- **text_analytics.nlp_dashboard.case_metadata**: Case classifications (3 levels)
- **text_analytics.nlp_analytics.topic_xwalk**: Topic assignments
- **text_analytics.nlp_configs.topic_detail**: Topic hierarchy (3 levels)  
- **text_analytics.nlp_analytics.parts_unfiltered**: Parts and features data

## Error Handling
- Returns up to 1000 results by default
- Handles missing data gracefully with appropriate labels
- Validates date ranges and search parameters
- Provides clear error messages for invalid inputs