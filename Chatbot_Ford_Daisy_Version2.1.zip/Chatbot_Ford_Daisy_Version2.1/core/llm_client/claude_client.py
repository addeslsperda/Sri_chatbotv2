"""
Claude API Client - SEPARATE from application logic
This should eventually be moved to its own container/service.

Handles all LLM calls to Claude API (Anthropic or AWS Bedrock)
"""
import os
import json
from typing import Optional, Dict, Any

try:
    from anthropic import Anthropic
    HAS_ANTHROPIC = True
except ImportError:
    HAS_ANTHROPIC = False

try:
    import boto3
    HAS_BOTO3 = True
except ImportError:
    HAS_BOTO3 = False


class ClaudeClient:
    """
    Isolated Claude API client.

    Supports both Anthropic API and AWS Bedrock.

    This class should NEVER import from ../agents/ or ../api/
    Keep LLM logic completely separate for containerization.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "claude-sonnet-4-20250514",
        use_bedrock: bool = True  # Default to Bedrock (your setup)
    ):
        """
        Initialize Claude client.

        Args:
            api_key: Anthropic API key (or use env var ANTHROPIC_API_KEY)
            model: Claude model to use
            use_bedrock: If True, use AWS Bedrock. If False, use Anthropic API.
        """
        self.use_bedrock = use_bedrock
        self.model = model

        if use_bedrock:
            if not HAS_BOTO3:
                raise ImportError("boto3 not installed. Run: pip install boto3")

            # Use AWS credentials from environment
            aws_region = os.getenv("AWS_REGION", "us-east-1")
            aws_access_key = os.getenv("AWS_ACCESS_KEY_ID")
            aws_secret_key = os.getenv("AWS_SECRET_ACCESS_KEY")

            if not aws_access_key or not aws_secret_key:
                raise ValueError("AWS credentials not found in environment")

            self.bedrock_client = boto3.client(
                service_name='bedrock-runtime',
                region_name=aws_region,
                aws_access_key_id=aws_access_key,
                aws_secret_access_key=aws_secret_key
            )

            # Map model names to Bedrock model IDs
            self.bedrock_model_id = self._get_bedrock_model_id(model)
        else:
            if not HAS_ANTHROPIC:
                raise ImportError("anthropic not installed. Run: pip install anthropic")

            self.api_key = api_key or os.getenv("ANTHROPIC_API_KEY")
            if not self.api_key:
                raise ValueError("ANTHROPIC_API_KEY not found in environment")

            self.client = Anthropic(api_key=self.api_key)

    def _get_bedrock_model_id(self, model: str) -> str:
        """Map model name to Bedrock model ID."""
        model_map = {
            "claude-sonnet-4-20250514": "us.anthropic.claude-sonnet-4-20250514-v1:0",
            "claude-3-5-sonnet-20241022": "us.anthropic.claude-3-5-sonnet-20241022-v2:0",
            "claude-3-5-sonnet": "us.anthropic.claude-3-5-sonnet-20241022-v2:0",
            "claude-3-opus": "anthropic.claude-3-opus-20240229-v1:0",
            "claude-3-sonnet": "anthropic.claude-3-sonnet-20240229-v1:0",
            "claude-3-haiku": "anthropic.claude-3-haiku-20240307-v1:0",
        }
        return model_map.get(model, "us.anthropic.claude-3-5-sonnet-20241022-v2:0")

    def complete(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        max_tokens: int = 4096,
        temperature: float = 0.0,
        **kwargs
    ) -> str:
        """
        Send a completion request to Claude.

        Args:
            prompt: User prompt/question
            system_prompt: System instructions
            max_tokens: Maximum response tokens
            temperature: Sampling temperature (0.0 = deterministic)
            **kwargs: Additional Claude API parameters

        Returns:
            Claude's response text
        """
        if self.use_bedrock:
            return self._complete_bedrock(prompt, system_prompt, max_tokens, temperature)
        else:
            return self._complete_anthropic(prompt, system_prompt, max_tokens, temperature, **kwargs)

    def _complete_anthropic(
        self,
        prompt: str,
        system_prompt: Optional[str],
        max_tokens: int,
        temperature: float,
        **kwargs
    ) -> str:
        """Complete using Anthropic API."""
        messages = [{"role": "user", "content": prompt}]

        params = {
            "model": self.model,
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": temperature,
            **kwargs
        }

        if system_prompt:
            params["system"] = system_prompt

        response = self.client.messages.create(**params)
        return response.content[0].text

    def _complete_bedrock(
        self,
        prompt: str,
        system_prompt: Optional[str],
        max_tokens: int,
        temperature: float
    ) -> str:
        """Complete using AWS Bedrock."""
        # Build request body for Bedrock
        body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": max_tokens,
            "temperature": temperature,
            "messages": [
                {
                    "role": "user",
                    "content": prompt
                }
            ]
        }

        if system_prompt:
            body["system"] = system_prompt

        # Call Bedrock
        response = self.bedrock_client.invoke_model(
            modelId=self.bedrock_model_id,
            body=json.dumps(body)
        )

        # Parse response
        response_body = json.loads(response['body'].read())
        return response_body['content'][0]['text']

    def complete_with_tools(
        self,
        prompt: str,
        tools: list[Dict[str, Any]],
        system_prompt: Optional[str] = None,
        max_tokens: int = 4096,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Complete with tool calling enabled.
        NOTE: Only supported in Anthropic SDK mode (use_bedrock=False).

        Args:
            prompt: User prompt
            tools: List of tool definitions
            system_prompt: System instructions
            max_tokens: Maximum response tokens
            **kwargs: Additional parameters

        Returns:
            Full response object with tool calls
        """
        if self.use_bedrock:
            raise NotImplementedError(
                "complete_with_tools() is not supported in Bedrock mode. "
                "Set use_bedrock=False (CLAUDE_USE_BEDROCK=false) to use tool calling."
            )

        messages = [{"role": "user", "content": prompt}]

        params = {
            "model": self.model,
            "messages": messages,
            "tools": tools,
            "max_tokens": max_tokens,
            **kwargs
        }

        if system_prompt:
            params["system"] = system_prompt

        response = self.client.messages.create(**params)

        return {
            "content": response.content,
            "stop_reason": response.stop_reason,
            "usage": {
                "input_tokens": response.usage.input_tokens,
                "output_tokens": response.usage.output_tokens
            }
        }


# Singleton instance (can be configured at app startup)
_client: Optional[ClaudeClient] = None


def get_client() -> ClaudeClient:
    """Get or create the Claude client singleton."""
    global _client
    if _client is None:
        model = os.getenv("CLAUDE_MODEL", "claude-sonnet-4-20250514")
        use_bedrock = os.getenv("CLAUDE_USE_BEDROCK", "true").lower() == "true"
        _client = ClaudeClient(model=model, use_bedrock=use_bedrock)
    return _client


def set_client(client: ClaudeClient):
    """Set the Claude client (for testing/configuration)."""
    global _client
    _client = client
