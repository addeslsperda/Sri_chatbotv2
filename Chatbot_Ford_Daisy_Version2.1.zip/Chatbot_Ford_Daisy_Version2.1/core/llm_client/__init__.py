"""
LLM Client - Isolated from application logic
This module should be deployable as a separate container.
"""
from .claude_client import ClaudeClient, get_client, set_client

__all__ = ["ClaudeClient", "get_client", "set_client"]
