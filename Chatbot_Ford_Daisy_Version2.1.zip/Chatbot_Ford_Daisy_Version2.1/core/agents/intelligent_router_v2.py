"""
Intelligent Multi-Agent Router V2 — Config-Driven, Two-Stage LLM Routing.

Auto-discovers agents from AGENT.md files in each *_agent/ folder.
Stage 1: Classify question -> Agent (~400ms)
Stage 2: Within agent -> Pick skill + extract params (~500ms)

To add a new agent:  create <agent_name>/AGENT.md
To add a new skill:  update the skills: block in that AGENT.md
Zero code changes needed in this file.
"""
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
from pathlib import Path
import json
import re
import os
import logging

_logger = logging.getLogger("daisy.router")


# ─────────────────────────────────────────────────────────────
# YAML Frontmatter Parser (no PyYAML dependency needed)
# ─────────────────────────────────────────────────────────────

def _parse_frontmatter(text: str) -> dict:
    """Parse YAML frontmatter from a markdown file (between --- delimiters)."""
    try:
        import yaml
        match = re.match(r"^---\s*\n(.*?)\n---", text, re.DOTALL)
        if match:
            return yaml.safe_load(match.group(1)) or {}
    except ImportError:
        pass
    return {}


# ─────────────────────────────────────────────────────────────
# Config Loader
# ─────────────────────────────────────────────────────────────

class ConfigLoader:
    """
    Auto-discovers agents from AGENT.md files in *_agent/ directories.

    Expected structure:
        claude_agent/
        ├── vehicle_agent/
        │   └── AGENT.md        <- YAML frontmatter with description, skills, routing_examples, stage2_prompt
        ├── operations_agent/
        │   └── AGENT.md
        └── ...
    """

    def __init__(self, base_path: str = None):
        if base_path:
            self.base_path = Path(base_path)
        else:
            # This file is at core/agents/, go up 2 levels to project root
            self.base_path = Path(__file__).parent.parent.parent

    def load_all_agents(self) -> Dict[str, Any]:
        """Scan for *_agent/AGENT.md files and load all agent configs."""
        agents = {}
        for item in self.base_path.iterdir():
            if item.is_dir() and item.name.endswith("_agent"):
                config = self._load_agent_config(item)
                if config and not config.get("disabled", False):
                    agents[item.name] = config
        return agents

    def _load_agent_config(self, agent_dir: Path) -> Optional[Dict]:
        """Load a single agent config from its AGENT.md frontmatter."""
        agent_md = agent_dir / "AGENT.md"
        if not agent_md.exists():
            return None

        text = agent_md.read_text(encoding="utf-8")
        config = _parse_frontmatter(text)

        # Ensure required keys exist
        if "skills" not in config:
            config["skills"] = {}
        if "routing_examples" not in config:
            config["routing_examples"] = []
        if "stage2_prompt" not in config:
            config["stage2_prompt"] = ""

        return config


# ─────────────────────────────────────────────────────────────
# Router V2
# ─────────────────────────────────────────────────────────────

class IntelligentRouterV2:
    """
    Config-Driven Two-Stage LLM Router.

    Stage 1: Classify question -> Agent  (uses agent descriptions + few-shot examples)
    Stage 2: Within agent -> Pick skill + extract params  (uses per-agent stage2_prompt)

    Falls back to keyword matching if LLM is unavailable.
    """

    def __init__(self, use_llm: bool = True, base_path: str = None):
        self.use_llm = use_llm
        self.loader = ConfigLoader(base_path)

        self.agents = self.loader.load_all_agents()
        if not self.agents:
            self.agents = self._get_default_agents()

        # Build prompts once at startup
        self._stage1_system = self._build_stage1_system()
        self._stage1_examples = self._build_stage1_examples()
        self._stage2_systems = self._build_stage2_systems()

    # ── Prompt builders ───────────────────────────────────────

    def _build_stage1_system(self) -> str:
        lines = []
        for name, cfg in self.agents.items():
            lines.append(f"- {name}: {cfg.get('description', name)}")
        agents_block = "\n".join(lines)

        return f"""You are a routing classifier for Ford CRC (Customer Relationship Center) analytics — an internal tool called "Daisy".

Classify the user's question into exactly ONE agent.

Available agents:
{agents_block}
- smalltalk: Greetings (Hello, Hi, Hey), system questions (Who am I, What page am I on, What can I ask, How does this work, Who are you, What is Daisy), security/injection inputs (URLs, SQL, gibberish), AND questions about topics not covered by any agent above (knowledge gaps)

Decision rules (apply in order):
1. Any mention of BlueCruise / Blue Cruise -> bluecruise_agent  (EXCEPTION: "what team handles bluecruise" -> operations_agent)
2. NHTSA / VOQ / buyback / lemon law / BBB / attorney / lawyer / recall / escalation keyword search -> vehicle_agent (use keyword_search with --by-vehicle to find these calls across all vehicles)
3. dealer / dealership -> operations_agent  (dealer questions are ALWAYS operational, even if "sentiment" also appears)
4. "What vehicles have" / "show me vehicles with" / "vehicles with X calls" / "vehicles that have" -> vehicle_agent  (problem-vehicle queries go here even if count/sentiment words appear)
5. "How many calls" / "count" / "% of" / "how often" / "volume" / "breakdown" / team / AHT / handle time / transfer / peak hour / agent pain points / regional -> operations_agent
   EXCEPTIONS (send to vehicle_agent instead):
   - "how many calls about [vehicle model]" / "how many [vehicle] calls" / "how many F-150 / F-Series / Bronco / Mach-E / Lightning / Explorer / Ranger / Mustang / Transit / Expedition / Navigator / Escape / Maverick calls" -> vehicle_agent/vehicle_volume
   - "how many … Amazon/Tesla/AT&T/SiriusXM/Alexa/Jeep/[third-party brand]" -> vehicle_agent/third_party_mentions
   - "how many calls about FordPass" / "how many FordPass calls" / "how many calls about [Ford app/product/feature]" -> vehicle_agent/keyword_search  (FordPass, Ford Pass, phone as a key, PAAK, remote start, Connected Navigation, Alexa Built-In are Ford products — NOT team names)
6. Sentiment / satisfaction / NPS / delight / "went well" / positive feedback / defection / frustrated / upset -> sentiment_agent
7. "Share an example" / "customer comment" / "what are customers saying about X" / vehicle issues / pain points / topics / third-party brand mentions (Amazon, Tesla, AT&T, SiriusXM) -> vehicle_agent
8. "Export" / "download" / "CSV" / "bulk export" / "transcripts" / "provide transcripts" / "give me all conversations" / "download calls" / "turn-by-turn" / "conversation breakdown" -> vehicle_agent  (routes to transcript_export internally — Daisy CAN export transcripts)
9. Greeting / system question / injection / URL / gibberish -> smalltalk
10. Question about analytics/data but does NOT match any agent above (out-of-scope topic, unsupported metric, untracked data dimension) -> smalltalk with reason "knowledge_gap: <topic>"

Important disambiguation:
- "Top vehicle pain points" / "top pain points this month" (no specific vehicle) -> vehicle_agent (routes to topic_trends internally)
- "Top pain points for [vehicle]" (specific vehicle named, no specific component) -> vehicle_agent (routes to vehicle_pain_points internally)
- "How many calls about [specific part] on/for [vehicle]" / "[vehicle] [part] issues" / "brake calls", "transmission problems", "battery issues" etc -> vehicle_agent (routes to keyword_search with --keyword=<part>)
- "Similar calls to X" / "find calls like X" / "conceptually related to X" -> vehicle_agent (routes to keyword_search internally)
- "Agent pain points" (about agents, not customers) -> operations_agent
- "Customer pain points" / "vehicle pain points" -> vehicle_agent

Return ONLY valid JSON: {{"agent": "<agent_name>", "reason": "<brief reason>"}}"""

    def _build_stage1_examples(self) -> list:
        examples = []
        for name, cfg in self.agents.items():
            for ex in cfg.get("routing_examples", []):
                examples.append({
                    "q": ex.get("question", ""),
                    "a": json.dumps({"agent": name, "reason": ex.get("reason", "")})
                })

        # Always include smalltalk examples
        smalltalk_examples = [
            ("Hello", "Greeting"),
            ("Hi DAISY", "Greeting"),
            ("Who am I?", "System question"),
            ("What can I ask you?", "Capability question"),
            ("What page am I on?", "System question"),
            ("Who are you?", "System question"),
            ("http://www.google.com", "URL injection — not a valid query"),
            ("Hello\" AND \"1\"=\"1", "SQL injection attempt"),
        ]
        for q, reason in smalltalk_examples:
            examples.append({"q": q, "a": json.dumps({"agent": "smalltalk", "reason": reason})})

        return examples

    def _build_stage2_systems(self) -> Dict[str, str]:
        prompts = {}
        for agent_name, cfg in self.agents.items():
            custom = cfg.get("stage2_prompt", "")
            if custom:
                prompts[agent_name] = custom
            else:
                # Auto-generate from skills dict
                skills_lines = "\n".join(
                    f"- {k}: {v}" for k, v in cfg.get("skills", {}).items()
                )
                prompts[agent_name] = (
                    f"You are selecting the best skill for a {agent_name.replace('_agent','').upper()} question.\n\n"
                    f"Available skills:\n{skills_lines}\n\n"
                    "Extract params: vehicle, keyword, search_term, date_from, date_to, model_year, team, filter_term\n\n"
                    'Return ONLY: {"skill": "<skill_name>", "params": {<extracted_params>}, "reason": "<brief>"}'
                )
        return prompts

    # ── Date helper ────────────────────────────────────────────

    @staticmethod
    def _default_dates(params: dict) -> dict:
        now = datetime.now()
        if not params.get("date_from"):
            params["date_from"] = (now - timedelta(days=30)).strftime("%Y-%m-%d")
        if not params.get("date_to"):
            params["date_to"] = now.strftime("%Y-%m-%d")
        return params

    # ── Main entry point ───────────────────────────────────────

    def route(self, question: str, chat_history: list = None) -> List[Dict[str, Any]]:
        """
        Route a natural-language question.

        Returns:
            List of {"agent", "skill", "params", "confidence", "reason"}
        """
        if self.use_llm:
            return self._route_two_stage(question, chat_history)
        return self._route_fallback(question)

    # ── Two-stage LLM routing ──────────────────────────────────

    def _route_two_stage(self, question: str, chat_history: list = None) -> List[Dict[str, Any]]:
        try:
            from core.llm_client.claude_client import get_client
            client = get_client()

            # Pre-stage: resolve follow-up questions before routing
            resolved_question, inherited_params = self._resolve_followup(client, question, chat_history)

            # Stage 1
            agent_name = self._stage1_classify(client, resolved_question, chat_history)

            if agent_name == "smalltalk":
                return [{"agent": "smalltalk", "skill": "respond", "params": {}, "confidence": 5, "reason": "Greeting or system question"}]

            # Stage 2 — pass resolved question so skill/param extraction has full context
            skill_result = self._stage2_select_skill(client, agent_name, resolved_question, chat_history)

            # Merge: inherited params as base, Stage 2 extracted params win on conflict
            merged_params = {**inherited_params, **skill_result.get("params", {})}
            params = self._default_dates(merged_params)

            return [{
                "agent": agent_name,
                "skill": skill_result["skill"],
                "params": params,
                "confidence": 5,
                "reason": skill_result.get("reason", "LLM two-stage routing")
            }]

        except Exception as e:
            _logger.warning("Two-stage LLM routing failed: %s — falling back to keywords", e)
            return self._route_fallback(question)

    def _resolve_followup(self, client, question: str, chat_history: list = None) -> tuple:
        """
        Pre-routing stage: detect if this is a follow-up and rewrite it as a
        fully self-contained question, inheriting params from recent turns.

        Looks back up to 3 turns to recover params that may have been dropped
        when the conversation crossed agents (e.g. vehicle lost when switching
        from vehicle_agent to sentiment_agent).

        Returns (resolved_question, inherited_params_dict).
        If not a follow-up, returns (original_question, {}).
        """
        if not chat_history:
            return question, {}

        # Build a merged param pool from last 3 turns, most-recent wins.
        # This recovers params that were present 2 turns ago but absent last turn
        # because an intermediate cross-agent hop didn't use them.
        param_pool: dict = {}
        for turn in chat_history[-3:]:
            for k, v in (turn.get("params") or {}).items():
                if v:  # only non-empty values
                    param_pool[k] = v  # later turns overwrite earlier — recency wins

        # Build recent conversation context for the resolver
        recent_turns = chat_history[-3:]
        turns_context = ""
        for i, turn in enumerate(recent_turns):
            label = f"Turn -{len(recent_turns) - i}"
            turns_context += f"{label}: {turn.get('question', '')}\n"
            turns_context += f"  Agent: {turn.get('agent', '')} / Skill: {turn.get('skill', '')}\n"
            turns_context += f"  Params: {json.dumps(turn.get('params') or {})}\n"

        # What params are available across recent history
        prior_context = (
            f"Recent conversation history (most recent last):\n{turns_context}\n"
            f"Accumulated params available to inherit: {json.dumps(param_pool)}"
        )

        system_prompt = """You are a query resolver for a Ford analytics chatbot.

Your job: decide if the current question is a follow-up. If yes, rewrite it as a fully self-contained question and identify which params to inherit from the conversation history.

A follow-up uses references like: "those", "that", "of those", "same period", "break that down", "how many of those", "what about X", "now show me", "and for X", "narrow that down", "same vehicle", "same dates", etc.

A standalone question stands on its own with no reference to prior context.

Rules:
- If standalone: return the original question unchanged, no inherited params
- If follow-up: rewrite so it is fully self-contained — fill in the actual vehicle name, date range, topic etc. from the accumulated params
- Inherit params from ANY recent turn (not just the last one) — if vehicle appeared 2 turns ago but not last turn, still inherit it
- Never inherit a param the user has explicitly changed in the new question
- For params the user has not mentioned, use the most recent value from the history

Return ONLY valid JSON:
{"is_followup": true/false, "resolved_question": "<full standalone question>", "inherited_params": {<only params to carry forward>}, "reason": "<brief>"}"""

        user_prompt = f"""{prior_context}

Current question: "{question}"

Is this a follow-up? If yes, resolve it."""

        try:
            response = client.complete(
                prompt=user_prompt,
                system_prompt=system_prompt,
                max_tokens=350,
                temperature=0.0
            )
            clean = response.strip().replace("```json", "").replace("```", "").strip()
            result = json.loads(clean)

            if result.get("is_followup"):
                resolved = result.get("resolved_question") or question
                inherited = result.get("inherited_params") or {}
                _logger.info("Follow-up resolved: '%s' -> '%s' (inherited: %s)", question, resolved, inherited)
                return resolved, inherited

        except Exception as e:
            _logger.debug("Follow-up resolver failed (%s) — treating as standalone", e)

        return question, {}

    def _stage1_classify(self, client, question: str, chat_history: list = None) -> str:
        examples_text = "\n".join(
            f'Q: "{ex["q"]}"\nA: {ex["a"]}' for ex in self._stage1_examples
        )

        context_text = ""
        if chat_history:
            recent = chat_history[-3:]
            context_text = "\nRecent conversation:\n"
            for entry in recent:
                if isinstance(entry, dict):
                    context_text += f"- User asked: {entry.get('question', '')}\n"
                    context_text += f"  Routed to: {entry.get('agent', '')} / {entry.get('skill', '')}\n"
                    params = entry.get('params') or {}
                    if params:
                        context_text += f"  Params: {json.dumps(params)}\n"

        user_prompt = f"""Examples:
{examples_text}
{context_text}
Q: "{question}"
A:"""

        response = client.complete(
            prompt=user_prompt,
            system_prompt=self._stage1_system,
            max_tokens=200,
            temperature=0.0
        )

        try:
            clean = response.strip().replace("```json", "").replace("```", "").strip()
            result = json.loads(clean)
            agent = result.get("agent", "vehicle_agent")
            if agent not in self.agents and agent != "smalltalk":
                agent = "vehicle_agent"
            return agent
        except Exception:
            r = response.lower()
            for name in self.agents:
                if name in r:
                    return name
            if "smalltalk" in r or "greeting" in r:
                return "smalltalk"
            return "vehicle_agent"

    def _stage2_select_skill(self, client, agent_name: str, question: str, chat_history: list = None) -> dict:
        system_prompt = self._stage2_systems.get(agent_name)
        if not system_prompt:
            first = list(self.agents[agent_name]["skills"].keys())[0]
            return {"skill": first, "params": {}, "reason": "Default first skill"}

        today = datetime.now().strftime("%Y-%m-%d")

        context_text = ""
        if chat_history:
            recent = chat_history[-3:]
            context_text = "\nPrevious conversation:\n"
            for entry in recent:
                if isinstance(entry, dict):
                    context_text += f"- User asked: {entry.get('question', '')}\n"
                    context_text += f"  Skill used: {entry.get('skill', '')} (agent: {entry.get('agent', '')})\n"
                    params = entry.get('params') or {}
                    if params:
                        context_text += f"  Params: {json.dumps(params)}\n"

        user_prompt = f"""Today's date: {today}
{context_text}
Question: "{question}"

Select the best skill and extract any parameters."""

        response = client.complete(
            prompt=user_prompt,
            system_prompt=system_prompt,
            max_tokens=400,
            temperature=0.0
        )

        try:
            clean = response.strip().replace("```json", "").replace("```", "").strip()
            result = json.loads(clean)
            valid_skills = self.agents[agent_name]["skills"]
            if result.get("skill") not in valid_skills:
                result["skill"] = list(valid_skills.keys())[0]
            return result
        except Exception:
            first = list(self.agents[agent_name]["skills"].keys())[0]
            return {"skill": first, "params": {}, "reason": "Parse failed — using default"}

    # ── Keyword fallback ───────────────────────────────────────

    def _route_fallback(self, question: str) -> List[Dict[str, Any]]:
        """Fast deterministic fallback — no LLM required."""
        q = question.lower().strip()

        # ── 1. Smalltalk / injection (highest priority) ────────────────
        if re.match(r"^https?://", q) or re.match(r"^www\.", q):
            return [{"agent": "smalltalk", "skill": "respond", "params": {}, "confidence": 5, "reason": "URL input"}]
        # SQL injection patterns
        if any(pat in q for pat in ["' or ", "\" and \"", "\" or \"", "1=1", "1'='1", "drop table", "union select"]):
            return [{"agent": "smalltalk", "skill": "respond", "params": {}, "confidence": 5, "reason": "Injection attempt"}]
        if any(q.strip() == g for g in ["hello", "hi", "hey", "hi daisy", "hello daisy", "hello;", "hello(", "hello\""]):
            return [{"agent": "smalltalk", "skill": "respond", "params": {}, "confidence": 5, "reason": "Greeting"}]
        if any(kw in q for kw in ["who am i", "what page", "what can i ask", "who are you", "how does this work",
                                   "what am i looking at", "what am i seeing", "what am i on"]):
            return [{"agent": "smalltalk", "skill": "respond", "params": {}, "confidence": 5, "reason": "System question"}]

        # ── 2. BlueCruise (check before flags/ops — "how many bluecruise" should go here) ──
        if any(kw in q for kw in ["bluecruise", "blue cruise"]):
            skill = "call_volume" if any(kw in q for kw in ["how many", "count", "volume", "referenced"]) else "top_issues"
            return [{"agent": "bluecruise_agent", "skill": skill, "params": self._default_dates({}), "confidence": 5, "reason": "BlueCruise keyword"}]

        # ── 3. Flags (check BEFORE operations — flags trump "how many" counting) ────────
        # These escalation keywords always go to flags regardless of "how many" phrasing
        flags_triggers = ["nhtsa", "voq", "vehicle owner questionnaire", "buyback", "buy back",
                          "bought back", "repurchase", "lemon law", " lemon ", "lemon in",
                          "bbb", "attorney", "lawyer", " recall", "supervisor", " escalat"]
        if any(kw in q for kw in flags_triggers) or q.endswith("lemon") or q.startswith("lemon"):
            if "recall" in q:
                skill = "recall_analysis"
            elif any(kw in q for kw in ["find all", "find cases", "mention", "referenced", "contain"]):
                skill = "keyword_search"
            elif any(kw in q for kw in ["how many", "count", "breakdown", "trend", "increasing"]):
                skill = "flag_counts"
            else:
                skill = "escalation_tracking"
            return [{"agent": "flags_agent", "skill": skill, "params": self._default_dates({}), "confidence": 5, "reason": "Flags keyword"}]

        # ── 4. Sentiment ────────────────────────────────────────────────
        if any(kw in q for kw in ["sentiment", "satisfaction", "nps", "went well", "delight",
                                   "positive feedback", "defection", "happy customers", "unhappy",
                                   "customers feel", "customer feel", "how customers feel"]):
            skill = "positive_feedback" if any(kw in q for kw in ["went well", "delight", "positive", "happy", "favorable"]) else "sentiment_deep_dive"
            return [{"agent": "sentiment_agent", "skill": skill, "params": self._default_dates({}), "confidence": 4, "reason": "Sentiment keyword"}]

        # ── 5. Operations — count/volume/team/operational queries ───────
        ops_keywords = ["how many calls", "call count", "how many customers", "how many were",
                        "% of", "percentage", "breakdown", "handle time", "aht",
                        "peak hour", "peak time", "busiest", "team performance", "transfer rate",
                        "callback", "dealer", "dealership", "ford of canada", "lincoln only",
                        "south america", "mexico", "argentina", "colombia",
                        "agent pain points", "month over month", "week over week", "year over year",
                        "compare april", "compare may", "april to may", "may to april",
                        "how often", "how frequently", "what time", "day of week",
                        "hour of day", "serial caller", "repeat customer",
                        "which team", "what team", "which agent"]
        if any(kw in q for kw in ops_keywords):
            if any(kw in q for kw in ["ford of canada", "lincoln only", "south america", "mexico", "argentina", "colombia", "regional", "isolate"]):
                skill = "regional_analysis"
            elif "dealer" in q or "dealership" in q:
                skill = "dealer_analysis"
            elif any(kw in q for kw in ["handle time", "aht", "average handle"]):
                skill = "aht_analysis"
            elif any(kw in q for kw in ["agent pain", "pain point"]) and "agent" in q:
                skill = "agent_pain_points"
            elif any(kw in q for kw in ["compare", "month over month", "week over week", "year over year", "april to may", "may to april"]):
                skill = "temporal_comparison"
            elif any(kw in q for kw in ["peak hour", "busiest time", "what time", "hour of day"]):
                skill = "hour_of_day"
            elif any(kw in q for kw in ["day of week", "weekday", "weekend"]):
                skill = "day_of_week"
            elif "transfer" in q:
                skill = "transfer_analysis"
            elif "callback" in q:
                skill = "callback_analysis"
            elif any(kw in q for kw in ["which team", "what team", "which agent", "what agent", "routing"]):
                skill = "team_routing_analysis"
            else:
                skill = "team_volume"
            return [{"agent": "operations_agent", "skill": skill, "params": self._default_dates({}), "confidence": 4, "reason": "Operations keyword"}]

        # Vehicle — default for "what are customers saying", "share an example", pain points, etc.
        if any(kw in q for kw in ["share an example", "customer comment", "example of"]):
            return [{"agent": "vehicle_agent", "skill": "vehicle_examples", "params": self._default_dates({}), "confidence": 4, "reason": "Transcript example request"}]
        if any(kw in q for kw in ["pain point", "top issue", "what are customers saying", "what are people saying", "biggest problem"]):
            skill = "vehicle_pain_points" if any(v in q for v in ["f-150", "f-series", "mach-e", "explorer", "bronco", "escape", "ranger", "lightning", "transit", "expedition", "navigator", "mustang"]) else "topic_trends"
            return [{"agent": "vehicle_agent", "skill": skill, "params": self._default_dates({}), "confidence": 4, "reason": "Vehicle pain points"}]
        if any(kw in q for kw in ["emerging", "trending", "spiking", "spike", "uptick", "getting worse"]):
            return [{"agent": "vehicle_agent", "skill": "emerging_issues", "params": self._default_dates({}), "confidence": 4, "reason": "Emerging issues"}]

        # Default fallback
        return [{"agent": "vehicle_agent", "skill": "topic_trends", "params": self._default_dates({}), "confidence": 2, "reason": "Default fallback"}]

    # ── Runtime reload ─────────────────────────────────────────

    def reload(self):
        """Reload all AGENT.md configs from disk without restarting."""
        self.agents = self.loader.load_all_agents()
        if not self.agents:
            self.agents = self._get_default_agents()
        self._stage1_system = self._build_stage1_system()
        self._stage1_examples = self._build_stage1_examples()
        self._stage2_systems = self._build_stage2_systems()

    # ── Hardcoded defaults (if no AGENT.md files found) ────────

    def _get_default_agents(self) -> Dict[str, Any]:
        """Fallback agents used when no AGENT.md files exist on disk."""
        return {
            "vehicle_agent": {
                "description": "Analyzes vehicle-related issues, what customers are saying about products/features, pain points, chargers, adapters, FordPass, apps, accessories, parts, specific vehicle models",
                "routing_examples": [
                    {"question": "What are customers saying about ordering home chargers online?", "reason": "Product topic question"},
                    {"question": "What issues are customers having with their transmissions?", "reason": "Vehicle issue question"},
                    {"question": "Share an example of a customer comment regarding charger availability", "reason": "Transcript example request"},
                    {"question": "What are the top pain points for F-150?", "reason": "Vehicle-specific pain points"},
                    {"question": "What are the top issues we have seen over the past week?", "reason": "General topic question"},
                    {"question": "What are customers saying about phone as a key?", "reason": "Feature feedback"},
                    {"question": "Tell me more about mach e customers not being able to use Tesla chargers.", "reason": "Vehicle + third party"},
                    {"question": "What are the most recent emerging topics?", "reason": "Emerging issues"},
                    {"question": "What are the biggest pain points for F-150 customers?", "reason": "Vehicle-specific pain points"},
                    {"question": "What issues are customers having with BlueCruise?", "reason": "Customer issues — not specifically BlueCruise volume"},
                ],
                "skills": {
                    "vin_history": "Track vehicles with multiple calls, lemon law candidates, buyback candidates",
                    "emerging_issues": "Detect spiking/trending problems, what is getting worse or newly appearing",
                    "vehicle_pain_points": "Top issues for a SPECIFIC vehicle model (requires vehicle name)",
                    "topic_trends": "Overall topic analysis, what customers are calling about, weekly pain points",
                    "vehicle_volume": "Call volume counts by vehicle model",
                    "model_year_analysis": "Issues by model year",
                    "issue_breakdown": "Categorize types of issues into groups",
                    "third_party_mentions": "Mentions of Amazon, Tesla, AT&T, or other third-party brands",
                    "vehicle_examples": "Sample call transcripts/summaries (use for 'share an example', 'customer comment')",
                    "keyword_search": "Search transcripts for a specific term or phrase",
                    "transcript_export": "Export call transcripts in bulk",
                    "data_discovery": "What data and fields are available"
                },
                "stage2_prompt": """You are selecting the best skill for a VEHICLE question in Ford's CRC analytics tool.

Available skills:
- vin_history: Track vehicles with multiple calls, lemon law candidates (use for specific VINs or repeat-problem vehicles)
- emerging_issues: Detect spiking/trending problems (use for "what's getting worse", "new issues", "uptick", "spike")
- vehicle_pain_points: Top issues for a SPECIFIC vehicle model — REQUIRES a vehicle name in the question
- topic_trends: Overall topic analysis — use when no specific vehicle mentioned, or for weekly/monthly pain points
- vehicle_volume: Call volume counts by vehicle model
- model_year_analysis: Issues broken down by model year (use when model year is mentioned)
- issue_breakdown: Categorize types of issues into groups
- third_party_mentions: Third-party brand mentions — Amazon, Tesla, AT&T, Alexa, SiriusXM, competitors
- vehicle_examples: Get sample call transcripts/summaries — use for "share an example", "show me a customer comment", "give me a verbatim"
- keyword_search: Search transcripts for a specific term — use for "what are customers saying about X", "how many calls mention X"
- transcript_export: Export transcripts in bulk
- data_discovery: What data/fields are available

Decision rules (apply in order):
1. "Share an example" / "customer comment" / "verbatim" / "what did customers say" -> vehicle_examples
2. "What are customers saying about X" / "how many calls mention X" / specific keyword search -> keyword_search
3. "Top issues/pain points for [vehicle_name]" (vehicle explicitly named) -> vehicle_pain_points
4. "Trending" / "spiking" / "emerging" / "uptick" / "getting worse" -> emerging_issues
5. Model year mentioned (e.g. "2024 F-150", "2025 model") -> model_year_analysis
6. "Amazon" / "Tesla" / "AT&T" / "Alexa" / "SiriusXM" / competitor brand -> third_party_mentions
7. Vehicle named but asking general issues -> vehicle_pain_points
8. No specific vehicle -> topic_trends
9. "Volume" / "count" with specific vehicle -> vehicle_volume

Extract params: vehicle (model name), keyword (search term), date_from (YYYY-MM-DD), date_to (YYYY-MM-DD), model_year

For date parsing:
- "last week" = 7 days ago to today
- "past month" / "last month" = 30 days ago to today
- "last 90 days" = 90 days ago to today
- "last 6 months" = 180 days ago to today
- "yesterday" = yesterday to yesterday
- "this week" = Monday of current week to today
- Named month = first to last day of that month

Return ONLY: {"skill": "<skill_name>", "params": {<extracted_params>}, "reason": "<brief>"}"""
            },
            "operations_agent": {
                "description": "Analyzes call counts, volumes, team performance, handle time, dealers, transfers, peak hours, agent workload, percentages, geographic/regional filters, agent pain points, temporal comparisons",
                "routing_examples": [
                    {"question": "how many calls came in last week about mustang mach-e?", "reason": "Call count question"},
                    {"question": "how many calls did we have on multi-factor authentication", "reason": "Call count"},
                    {"question": "What are some agent pain points regarding the premium connectivity subscription?", "reason": "Agent pain points"},
                    {"question": "Can I get the past 2 weeks data for the Inquiry Teams", "reason": "Team data request"},
                    {"question": "% of reasons customers are calling the CRC", "reason": "Percentage breakdown"},
                    {"question": "Compare April to May call reasons for Lincoln CRC", "reason": "Temporal comparison"},
                    {"question": "Can you give me a view of Lincoln only?", "reason": "Regional/geographic filter"},
                    {"question": "Hi DAISY, are you able to isolate the Ford of Canada team data?", "reason": "Geographic filter"},
                    {"question": "What are the top agent pain points regarding connected navigation?", "reason": "Agent pain points"},
                    {"question": "What time did most problematic calls came in?", "reason": "Peak hour analysis"},
                    {"question": "How many calls were transferred into the BEV PQs from other teams?", "reason": "Transfer count"},
                    {"question": "What are customer frustrated about with the dealership?", "reason": "Dealer analysis"},
                    {"question": "What is the AHT in April MTD for Mach E calls", "reason": "AHT analysis"},
                ],
                "skills": {
                    "team_routing_analysis": "Team performance, routing efficiency, transfer rates by team, agent names",
                    "dealer_analysis": "Dealer complaints, problematic dealers, regional dealer performance, pacode lookup",
                    "customer_journey_analysis": "Serial callers, repeat customers, multiple calls from same VIN",
                    "aht_analysis": "Average handle time, call duration, time per call",
                    "transfer_analysis": "Transfer rates, transfer patterns, which issues get transferred",
                    "complexity_analysis": "Call complexity, difficult issues, high complexity calls",
                    "callback_analysis": "Callback rates, repeat calls",
                    "hour_of_day": "Peak hours, busiest times, call volume by hour",
                    "day_of_week": "Busiest days, weekday vs weekend patterns",
                    "regional_analysis": "Geographic patterns — Ford of Canada, Lincoln only, state/region filters, South America",
                    "team_volume": "Call counts and volume by any filter — team, vehicle, date, keyword",
                    "agent_pain_points": "Issues agents struggle with, high complexity calls, training needs",
                    "temporal_comparison": "Month over month, week over week, year over year, compare date ranges",
                    "trend_analysis": "Patterns over time, is X increasing or decreasing",
                    "data_discovery": "Schema and available fields"
                },
                "stage2_prompt": """You are selecting the best skill for an OPERATIONS question in Ford's CRC analytics tool.

Available skills:
- team_routing_analysis: Team performance, routing efficiency, transfer rates, agent-level data
- dealer_analysis: Dealer complaints, problematic dealers, pacode, territory, dealer sentiment
- customer_journey_analysis: Serial callers, repeat customers, same VIN calling multiple times
- aht_analysis: Average handle time, call duration, time per call
- transfer_analysis: Transfer rates, which issues cause transfers, transfer patterns
- complexity_analysis: Call complexity scores, difficult issues, high complexity teams
- callback_analysis: Callback rates, repeat calls from same customer
- hour_of_day: Peak hours, busiest times of day, call volume by hour
- day_of_week: Busiest days, weekday vs weekend patterns
- regional_analysis: Geographic filters — Ford of Canada, Lincoln only, state-level, South America, Mexico
- team_volume: Call counts and volume by ANY filter — use for "how many calls about X", "% of reasons", "breakdown of"
- agent_pain_points: Issues agents struggle with, pain points FOR AGENTS (not customers), training needs
- temporal_comparison: Compare time periods — month over month, week over week, April vs May
- trend_analysis: Is X increasing/decreasing over time, patterns over time
- data_discovery: Schema and available fields

Decision rules:
- "How many calls about X" / "count" / "% of" / "breakdown of" -> team_volume (use filter_term param)
- "Agent pain points" / "issues agents struggle with" / "high friction for agents" -> agent_pain_points
- "Dealer" / "dealership" -> dealer_analysis
- "Handle time" / "AHT" / "average handle" / "call duration" -> aht_analysis
- "Transfer" / "transferred" -> transfer_analysis
- "Compare [period A] to [period B]" / "month over month" / "week over week" -> temporal_comparison
- "Ford of Canada" / "Lincoln only" / "regional" / "South America" / "Mexico" / "isolate [region]" -> regional_analysis
- "Peak hour" / "busiest time" / "what time" / "hour" -> hour_of_day
- "Day of week" / "weekday" / "weekend" -> day_of_week
- "Serial callers" / "repeat customers" / "called multiple times" -> customer_journey_analysis
- "Callback" -> callback_analysis
- "Team performance" / "routing" / "which teams" / "agent names" -> team_routing_analysis
- "Trend" / "increasing" / "decreasing" -> trend_analysis

Extract params: team, filter_term (what to count/filter by), date_from (YYYY-MM-DD), date_to (YYYY-MM-DD), region, vehicle, model_year

Return ONLY: {"skill": "<skill_name>", "params": {<extracted_params>}, "reason": "<brief>"}"""
            },
            "sentiment_agent": {
                "description": "Analyzes customer satisfaction, sentiment scores, NPS, positive feedback, what went well, customer delight, frustration levels, defection risk",
                "routing_examples": [
                    {"question": "What went well yesterday?", "reason": "Positive feedback"},
                    {"question": "what delights customers last week?", "reason": "Positive customer experience"},
                    {"question": "What issues are themes that are causing negative sentiment", "reason": "Sentiment analysis"},
                    {"question": "Which vehicle model has the highest defection rate?", "reason": "Defection = satisfaction metric"},
                    {"question": "Daisy, show me differences in sentiment between agents and customers when discussing charging failures", "reason": "Agent vs customer sentiment"},
                    {"question": "What is the customers sentiment when they learn their buyback request has been denied", "reason": "Sentiment deep dive"},
                    {"question": "customer sentiment for april", "reason": "Monthly sentiment analysis"},
                    {"question": "summarize customer sentiment about charging concerns", "reason": "Topic-specific sentiment"},
                ],
                "skills": {
                    "sentiment_deep_dive": "Overall sentiment analysis, satisfaction levels, negative themes, what frustrates customers",
                    "positive_feedback": "What is working well, customer praise, delights, happy experiences",
                    "resolution_analysis": "First call resolution (FCR), whether issues got resolved, resolution rate",
                    "sentiment_by_vehicle": "Sentiment analysis for a specific vehicle model",
                    "nps_trend": "Net Promoter Score trends over time",
                    "agent_customer_sentiment": "Compare agent sentiment vs customer sentiment on the same calls",
                    "data_discovery": "Schema and available fields"
                },
                "stage2_prompt": """You are selecting the best skill for a SENTIMENT question in Ford's CRC analytics tool.

Available skills:
- sentiment_deep_dive: Overall sentiment, negative themes, frustration, what upsets customers
- positive_feedback: What is working well, customer praise, delights, happy experiences
- resolution_analysis: First call resolution (FCR), whether issues got resolved
- sentiment_by_vehicle: Sentiment for a specific vehicle model
- nps_trend: Net Promoter Score trends over time
- agent_customer_sentiment: Compare agent vs customer sentiment on the same calls

Decision rules:
- "What went well" / "delight" / "positive" / "happy" / "praise" / "favorable" -> positive_feedback
- "Negative sentiment" / "frustration" / "upset" / "defection" / "angry" -> sentiment_deep_dive
- "FCR" / "resolution" / "first call resolution" -> resolution_analysis
- "NPS" / "net promoter" -> nps_trend
- "Agent vs customer" / "difference in sentiment" / "compare agent and customer" -> agent_customer_sentiment
- "Sentiment for [vehicle]" / vehicle name mentioned -> sentiment_by_vehicle
- General sentiment question -> sentiment_deep_dive

Extract params: vehicle, date_from, date_to, team, topic

Return ONLY: {"skill": "<skill_name>", "params": {<extracted_params>}, "reason": "<brief>"}"""
            },
            "flags_agent": {
                "description": "Tracks NHTSA, VOQ, buyback requests, lemon law, BBB, legal issues, recalls, supervisor requests, escalations, regulatory compliance",
                "routing_examples": [
                    {"question": "find all cases where NHTSA was mentioned", "reason": "NHTSA = regulatory flag keyword search"},
                    {"question": "How many customers in the last 90 days have requested for their vehicle to be bought back", "reason": "Buyback = escalation flag"},
                    {"question": "how many calls have the word supervisor", "reason": "Supervisor escalation keyword count"},
                    {"question": "How many customers called their call a lemon in the last 90 days", "reason": "Lemon law = legal flag"},
                    {"question": "Can you break down the NHTSA calls for the last 6 months?", "reason": "NHTSA breakdown"},
                    {"question": "rear axle shaft recalls", "reason": "Recall analysis"},
                    {"question": "find all cases where VOQ was mentioned", "reason": "VOQ = vehicle owner questionnaire = regulatory"},
                    {"question": "I am interested in all mentions of VOQ or Vehicle Owner Questionnaire", "reason": "VOQ keyword search"},
                    {"question": "What are customers saying about requesting to speak to a supervisor", "reason": "Supervisor = escalation"},
                    {"question": "do agents recommend to contact NHTSA", "reason": "NHTSA mention search"},
                ],
                "skills": {
                    "escalation_tracking": "Track and summarize BBB, NHTSA, buyback requests, legal issues, lemon law, supervisor requests",
                    "flag_counts": "Count of specific flag types (buyback, warranty, recall, NHTSA, supervisor, etc.)",
                    "flag_trends": "Are escalations increasing or decreasing over time",
                    "flag_examples": "Example flagged calls, escalation call transcripts",
                    "recall_analysis": "Recall-related calls — what recall, how many affected, which vehicles",
                    "keyword_search": "Search for specific legal/escalation terms in transcripts and summaries",
                    "data_discovery": "Schema and available fields"
                },
                "stage2_prompt": """You are selecting the best skill for a FLAGS/ESCALATION question in Ford's CRC analytics tool.

Available skills:
- escalation_tracking: General escalation summary — BBB, NHTSA, buyback, legal, lemon law, supervisor requests
- flag_counts: Count specific flag types — use for "how many X were there" with a flag keyword
- flag_trends: Are escalations increasing/decreasing over time
- flag_examples: Example escalated calls, show me flagged call transcripts
- recall_analysis: Recall-specific analysis — which recalls, affected vehicles, call volume
- keyword_search: Search for specific terms — use for "find all cases where X was mentioned", "how many calls contain X"

Decision rules:
- "Find all cases where X was mentioned" / "how many calls contain X" / "mention of X" -> keyword_search (set search_term=X)
- "How many buyback / NHTSA / recall / lemon / supervisor" -> flag_counts
- "Are escalations increasing" / "trend" -> flag_trends
- "Show me examples" / "give me transcripts" -> flag_examples
- "Recall" / "recall analysis" / "rear axle" / "transmission recall" -> recall_analysis
- General escalation question -> escalation_tracking

Extract params: search_term (exact term to search), vehicle, date_from, date_to, flag_type

Return ONLY: {"skill": "<skill_name>", "params": {<extracted_params>}, "reason": "<brief>"}"""
            },
            "bluecruise_agent": {
                "description": "Analyzes BlueCruise-specific issues, subscription problems, hands-free driving features, autonomous driving",
                "routing_examples": [
                    {"question": "What issues are customers having with BlueCruise?", "reason": "BlueCruise specific issues"},
                    {"question": "How many calls was BlueCruise referenced on?", "reason": "BlueCruise volume count"},
                    {"question": "What are the top pain points for BlueCruise by nameplate?", "reason": "BlueCruise by vehicle breakdown"},
                    {"question": "For BlueCruise issues, how common is intermittent functionality?", "reason": "BlueCruise specific issue"},
                    {"question": "Why are people cancelling bluecruise?", "reason": "BlueCruise subscription cancellation"},
                    {"question": "What are some of the agent pain points regarding BlueCruise?", "reason": "BlueCruise agent pain points"},
                    {"question": "What are the biggest agent pain points around blue cruise?", "reason": "BlueCruise agent pain points"},
                    {"question": "in the month of august how many calls were related to bluecruise", "reason": "BlueCruise volume by month"},
                ],
                "skills": {
                    "call_volume": "BlueCruise call volume counts by period",
                    "top_issues": "Top BlueCruise customer problems and pain points",
                    "vehicle_breakdown": "BlueCruise issues broken down by vehicle model/nameplate",
                    "vehicle_topics": "BlueCruise topics for a specific vehicle",
                    "sentiment_trend": "BlueCruise customer satisfaction and sentiment over time",
                    "contact_volume_trend": "BlueCruise call volume trends over time",
                    "subscription_issues": "Subscription activation, billing, cancellation, renewal problems",
                    "subscription_stage": "Where in the subscription journey problems occur",
                    "keyword_search": "Search BlueCruise call transcripts for specific terms",
                    "call_examples": "Sample BlueCruise call transcripts/summaries"
                },
                "stage2_prompt": """You are selecting the best skill for a BLUECRUISE question in Ford's CRC analytics tool.

Available skills:
- call_volume: BlueCruise call volume counts — use for "how many calls", "count", "volume"
- top_issues: Top BlueCruise customer problems — use for general "what issues", "what problems", "pain points"
- vehicle_breakdown: BlueCruise by vehicle/nameplate — use for "by vehicle", "by model", "which vehicles"
- vehicle_topics: Topics for a specific BlueCruise vehicle
- sentiment_trend: BlueCruise customer satisfaction and sentiment
- contact_volume_trend: BlueCruise call trends over time — use for "trend", "over time", "increasing"
- subscription_issues: Subscription problems — activation, billing, cancellation, renewal
- subscription_stage: Where in the customer journey subscription problems occur
- keyword_search: Search for specific terms in BlueCruise transcripts
- call_examples: Sample call transcripts — use for "example", "show me", "what did customer say"

Decision rules:
- "How many BlueCruise calls" / "count" / "volume" -> call_volume
- "Top issues / problems / pain points" -> top_issues
- "By vehicle / by nameplate / by model" -> vehicle_breakdown
- "Subscription" / "cancel" / "billing" / "activation" -> subscription_issues
- "Sentiment / satisfaction / happy / frustrated" -> sentiment_trend
- "Trend over time / increasing / decreasing" -> contact_volume_trend
- "Agent pain points" -> top_issues (filter for agent difficulty)
- "Show example / transcript" -> call_examples

Extract params: vehicle, date_from, date_to, keyword

Return ONLY: {"skill": "<skill_name>", "params": {<extracted_params>}, "reason": "<brief>"}"""
            }
        }
