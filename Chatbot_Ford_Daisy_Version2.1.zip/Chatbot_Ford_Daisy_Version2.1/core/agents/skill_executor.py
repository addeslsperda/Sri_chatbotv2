"""
Skill Executor - Runs Python scripts for analytics skills
NO LLM dependencies - pure Python execution
"""
import json
import subprocess  # nosec B404 - runs trusted first-party skill scripts only
from pathlib import Path
from typing import Dict, Any, Optional
import logging

_logger = logging.getLogger("daisy.skill_executor")


class SkillExecutor:
    """
    Executes analytics skill scripts.

    This class handles running the actual Python scripts that do the work.
    NO LLM calls here - this is pure computation/data access.
    """

    def __init__(self, base_path: Path):
        """
        Initialize executor.

        Args:
            base_path: Base path to claude_agent folder
        """
        self.base_path = Path(base_path)

    def execute_skill(
        self,
        agent_name: str,
        skill_name: str,
        params: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Execute a skill script.

        Args:
            agent_name: Agent folder (e.g., "vehicle_agent")
            skill_name: Skill to run (e.g., "vin_history")
            params: Parameters for the script (date_from, date_to, etc.)

        Returns:
            Parsed JSON result from the script

        Raises:
            FileNotFoundError: Script not found
            subprocess.CalledProcessError: Script execution failed
            json.JSONDecodeError: Invalid JSON output
        """
        # Build script path - try .claude/skills first, then skills/
        script_path_claude = (
            self.base_path /
            agent_name /
            ".claude" /
            "skills" /
            skill_name /
            "scripts" /
            f"{skill_name}.py"
        )

        script_path_direct = (
            self.base_path /
            agent_name /
            "skills" /
            skill_name /
            "scripts" /
            f"{skill_name}.py"
        )

        # Use whichever path exists
        if script_path_claude.exists():
            script_path = script_path_claude
        elif script_path_direct.exists():
            script_path = script_path_direct
        else:
            raise FileNotFoundError(
                f"Skill script not found at:\n"
                f"  {script_path_claude}\n"
                f"  {script_path_direct}"
            )

        # Build command
        cmd = ["python", str(script_path)]

        # Always pass --include-insights for bluecruise skills that support it
        # (returns richer {status, data, insights} structure vs plain list)
        BLUECRUISE_INSIGHTS_SKILLS = {
            "call_volume", "top_issues", "vehicle_breakdown", "vehicle_topics",
            "sentiment_trend", "contact_volume_trend", "subscription_issues",
            "keyword_search", "call_examples"
        }
        if agent_name == "bluecruise_agent" and skill_name in BLUECRUISE_INSIGHTS_SKILLS:
            cmd.append("--include-insights")

        _logger.debug("skill_executor params: %s", params)

        # Special handling for temporal_comparison: split date range into two equal periods
        if skill_name == "temporal_comparison" and "date_from" in params and "date_to" in params:
            from datetime import date as _date, timedelta as _td
            d_from = _date.fromisoformat(str(params["date_from"]))
            d_to   = _date.fromisoformat(str(params["date_to"]))
            midpoint = d_from + _td(days=(d_to - d_from).days // 2)
            p2_from = midpoint + _td(days=1)
            p2_to   = d_to
            p1_from = d_from
            p1_to   = midpoint
            cmd.extend(["--period1-from", str(p1_from), "--period1-to", str(p1_to),
                         "--period2-from", str(p2_from), "--period2-to", str(p2_to)])
            # Pass remaining params (vehicle, team, etc) below — skip date_from/date_to
            params = {k: v for k, v in params.items() if k not in ("date_from", "date_to")}

        # Add parameters
        for key, value in params.items():
            # Convert param names (date_from -> --from)
            if key == "date_from":
                cmd.extend(["--from", str(value)])
            elif key == "date_to":
                cmd.extend(["--to", str(value)])
            elif key == "vehicle":
                cmd.extend(["--vehicle", str(value)])
            elif key == "min_calls":
                cmd.extend(["--min-calls", str(value)])
            elif key == "sort":
                cmd.extend(["--sort", str(value)])
            elif key == "by_model":
                # Boolean flag for vehicle_volume ranking
                if value and str(value).lower() not in ("false", "0", ""):
                    cmd.append("--by-model")
            elif key == "escalation_type":
                cmd.extend(["--escalation-type", str(value)])
            elif key == "group_by":
                cmd.extend(["--group-by", str(value)])
            elif key == "analysis_type":
                # Valid values: overview, drivers, performance — never pass "by_team" or "by_vehicle"
                valid = {"overview", "drivers", "performance"}
                val = str(value).lower()
                if val in valid:
                    cmd.extend(["--analysis-type", val])
                # else silently skip — bad value; group_by handles the breakdown dimension
            elif key == "topic":
                # issue_breakdown uses --pain-point instead of --topic
                if skill_name == "issue_breakdown":
                    cmd.extend(["--pain-point", str(value)])
                else:
                    cmd.extend(["--topic", str(value)])
            elif key == "topics":
                cmd.extend(["--topics", str(value)])
            elif key == "comparison":
                cmd.extend(["--comparison", str(value)])
            elif key == "min_spike":
                cmd.extend(["--min-spike", str(value)])
            elif key == "min_occurrences":
                cmd.extend(["--min-occurrences", str(value)])
            elif key == "issue_type":
                cmd.extend(["--issue-type", str(value)])
            elif key == "limit":
                cmd.extend(["--limit", str(value)])
            elif key == "flag_type":
                cmd.extend(["--flag", str(value)])
            elif key == "search_term":
                # transcript_export uses --keywords (plural), all others use --keyword
                if skill_name == "transcript_export":
                    cmd.extend(["--keywords", str(value)])
                else:
                    cmd.extend(["--keyword", str(value)])
            elif key == "keyword":
                # transcript_export uses --keywords (plural), all others use --keyword
                if skill_name == "transcript_export":
                    cmd.extend(["--keywords", str(value)])
                else:
                    cmd.extend(["--keyword", str(value)])
            elif key == "filter_term":
                # filter_term maps to --team for team_volume, or --keyword for search skills
                if skill_name in ("team_volume",):
                    cmd.extend(["--team", str(value)])
                else:
                    cmd.extend(["--keyword", str(value)])
            elif key == "team":
                cmd.extend(["--team", str(value)])
            elif key == "region":
                cmd.extend(["--region", str(value)])
            elif key == "model_year":
                # All vehicle scripts accept --year; model_year_analysis also accepts --model-year
                cmd.extend(["--year", str(value)])
            else:
                # Generic parameter — handle boolean flags (store_true) vs value flags
                if isinstance(value, bool):
                    if value:
                        cmd.append(f"--{key.replace('_', '-')}")
                    # False booleans: omit the flag entirely
                else:
                    cmd.extend([f"--{key.replace('_', '-')}", str(value)])

        _logger.debug("skill_executor command: %s", " ".join(cmd))

        # Execute
        try:
            result = subprocess.run(  # nosec B603 - cmd is built from trusted first-party paths, not user input
                cmd,
                capture_output=True,
                text=True,
                timeout=120,  # 2 minute timeout
                check=True
            )

            # Parse JSON output
            return json.loads(result.stdout)

        except subprocess.CalledProcessError as e:
            raise RuntimeError(
                f"Skill execution failed: {e.stderr or e.stdout}"
            )
        except json.JSONDecodeError as e:
            raise RuntimeError(
                f"Invalid JSON output from skill: {result.stdout[:500]}"
            )


# Example usage
if __name__ == "__main__":
    executor = SkillExecutor(Path(__file__).parent.parent.parent)

    result = executor.execute_skill(
        agent_name="vehicle_agent",
        skill_name="vin_history",
        params={
            "date_from": "2026-01-01",
            "date_to": "2026-01-31",
            "min_calls": 5
        }
    )

    print(json.dumps(result, indent=2))
