"""
DAISY Version 2 - Databricks Compatible Application
Fixed version for Databricks Apps deployment with proper error handling
"""

import os
import sys
import traceback
from pathlib import Path

# Set up environment first
os.environ.setdefault("API_DEBUG", "false")

try:
    # Load environment variables
    from dotenv import load_dotenv

    # Try to load .env from multiple locations
    env_paths = [
        Path(__file__).resolve().parent / ".env",
        Path("/app/.env"),
        Path("/.env")
    ]

    env_loaded = False
    for env_path in env_paths:
        if env_path.exists():
            load_dotenv(env_path, override=True)
            env_loaded = True
            print(f"[OK] Environment loaded from: {env_path}")
            break

    if not env_loaded:
        print("[WARN] No .env file found, using system environment variables")

    # Import core dependencies
    from litestar import Litestar
    from litestar.config.cors import CORSConfig
    from litestar.exceptions import HTTPException
    from litestar.response import Response
    from litestar.static_files import create_static_files_router
    from litestar.status_codes import HTTP_500_INTERNAL_SERVER_ERROR

    print("[OK] Core dependencies imported successfully")

except ImportError as e:
    print(f"[ERROR] Import error: {e}")
    print("Please ensure all required packages are installed:")
    print("pip install litestar uvicorn databricks-sql-connector python-dotenv requests pydantic")
    sys.exit(1)
except Exception as e:
    print(f"[ERROR] Initialization error: {e}")
    traceback.print_exc()
    sys.exit(1)

# Global configuration
DEBUG = os.getenv("API_DEBUG", "false").lower() in ("1", "true", "yes")
HOST = os.getenv("HOST", "0.0.0.0")
PORT = int(os.getenv("PORT", "8000"))

def create_health_route():
    """Create basic health check route"""
    from litestar import get

    @get("/health")
    async def health() -> dict:
        """Health check endpoint"""
        return {
            "status": "healthy",
            "version": "2.0.0",
            "service": "daisy_analytics",
            "debug_mode": DEBUG
        }

    return health

def create_basic_query_route():
    """Create basic query route with error handling"""
    from litestar import post
    from pydantic import BaseModel

    class QueryRequest(BaseModel):
        question: str
        session_id: str | None = None
        date_from: str | None = None
        date_to: str | None = None

    class QueryResponse(BaseModel):
        question: str
        answer: str
        agent_used: str
        skill_used: str
        status: str

    @post("/api/query")
    async def basic_query(data: QueryRequest) -> QueryResponse:
        """Basic query endpoint with fallback response"""
        try:
            # Import route modules with error handling
            try:
                from api.routes import query
                # Delegate to the full query handler
                return await query.query_endpoint(data)
            except ImportError as import_error:
                print(f"[WARN] Could not import full query handler: {import_error}")
                # Fallback response
                return QueryResponse(
                    question=data.question,
                    answer=f"I received your question: '{data.question}'. The full DAISY system is initializing. Please try again in a moment.",
                    agent_used="system",
                    skill_used="fallback",
                    status="fallback_mode"
                )
        except Exception as e:
            print(f"[ERROR] Query error: {e}")
            return QueryResponse(
                question=data.question,
                answer=f"I encountered an error processing your question. Error: {str(e)}",
                agent_used="system",
                skill_used="error_handler",
                status="error"
            )

    return basic_query

def create_conversation_routes():
    """Create conversation management routes with error handling"""
    from litestar import get, post
    import uuid
    import json
    from datetime import datetime

    @post("/api/conversations/sessions/start")
    async def start_session(data: dict | None = None) -> dict:
        """Start conversation session with fallback"""
        try:
            # Try to import full conversation handler
            try:
                sys.path.append(str(Path(__file__).resolve().parent / 'tracking'))
                from conversation_tracker import conversation_tracker
                session_id = conversation_tracker.start_conversation_session()
                return {
                    "session_id": session_id,
                    "status": "started",
                    "timestamp": datetime.utcnow().isoformat()
                }
            except ImportError:
                # Fallback to basic session
                session_id = str(uuid.uuid4())
                return {
                    "session_id": session_id,
                    "status": "started_offline",
                    "timestamp": datetime.utcnow().isoformat(),
                    "message": "Using offline session management"
                }
        except Exception as e:
            return {
                "session_id": str(uuid.uuid4()),
                "status": "error",
                "error": str(e)
            }

    @get("/api/conversations/{session_id}/download")
    async def download_conversation(session_id: str) -> Response:
        """Basic conversation download"""
        try:
            # Create a simple conversation export
            conversation_data = {
                "metadata": {
                    "session_id": session_id,
                    "export_timestamp": datetime.utcnow().isoformat(),
                    "format": "json",
                    "version": "2.0.0"
                },
                "conversation": {
                    "session_id": session_id,
                    "status": "basic_export",
                    "message": "This is a basic conversation export. Full tracking features are initializing."
                }
            }

            content = json.dumps(conversation_data, indent=2)
            filename = f"conversation_{session_id[:8]}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"

            return Response(
                content=content,
                media_type="application/json",
                headers={
                    "Content-Disposition": f"attachment; filename={filename}",
                    "Content-Type": "application/json"
                }
            )
        except Exception as e:
            return Response(
                content=f'{{"error": "Download failed: {str(e)}"}}',
                status_code=500,
                media_type="application/json"
            )

    return [start_session, download_conversation]

def create_app():
    """Create the Litestar application with progressive enhancement"""

    print("[DEPLOY] Creating DAISY Version 2 application...")

    # CORS configuration for Databricks
    cors_config = CORSConfig(
        allow_origins=["*"],  # More permissive for Databricks
        allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        allow_headers=["*"],
        allow_credentials=True,
    )

    # Exception handler
    def handle_exception(request, exc: Exception) -> Response:
        """Global exception handler"""
        print(f"[ERROR] Application error: {exc}")
        if DEBUG:
            traceback.print_exc()

        return Response(
            content={
                "error": str(exc),
                "type": type(exc).__name__,
                "detail": "An error occurred in DAISY Version 2"
            },
            status_code=HTTP_500_INTERNAL_SERVER_ERROR,
            media_type="application/json",
        )

    # Build route handlers with progressive loading
    route_handlers = []

    try:
        # Always include health check
        route_handlers.append(create_health_route())
        print("[OK] Health route added")

        # Try to add full routes, fall back to basic ones
        try:
            from api.routes import health, query, agents, conversation
            route_handlers.extend([
                query.router,
                agents.router,
                conversation.router
            ])
            print("[OK] Full API routes loaded")
        except ImportError as e:
            print(f"[WARN] Could not load full routes ({e}), using basic fallbacks")

            # Add basic fallback routes
            route_handlers.append(create_basic_query_route())
            route_handlers.extend(create_conversation_routes())
            print("[OK] Basic fallback routes added")

        # Add static file serving if available
        static_dir = Path(__file__).resolve().parent / "api" / "static"
        if static_dir.is_dir():
            route_handlers.append(
                create_static_files_router(
                    path="/",
                    directories=[static_dir],
                    html_mode=True,
                )
            )
            print(f"[OK] Static files served from: {static_dir}")
        else:
            print("[WARN] Static directory not found, skipping static file serving")

    except Exception as e:
        print(f"[ERROR] Error setting up routes: {e}")
        # Minimal fallback - just health check
        route_handlers = [create_health_route()]

    # Create the application
    app = Litestar(
        route_handlers=route_handlers,
        cors_config=cors_config,
        exception_handlers={
            HTTP_500_INTERNAL_SERVER_ERROR: handle_exception
        },
        debug=DEBUG
    )

    print(f"[OK] DAISY Version 2 application created with {len(route_handlers)} route handlers")
    return app

# Create the app instance
try:
    app = create_app()
    print("[SUCCESS] DAISY Version 2 ready for deployment!")
except Exception as e:
    print(f"[ERROR] Failed to create application: {e}")
    traceback.print_exc()
    sys.exit(1)

# For Databricks Apps
def main():
    """Main entry point for Databricks"""
    try:
        import uvicorn
        print("=" * 70)
        print("DAISY Version 2 - Ford Analytics Platform")
        print("=" * 70)
        print(f"\n[DEPLOY] Starting server at {HOST}:{PORT}")
        print(f"[TOOL] Debug mode: {DEBUG}")
        print(f"[DATA] Environment: Databricks Apps")

        print("\n[LIST] Available endpoints:")
        print("  GET  /health                    - Health check")
        print("  POST /api/query                 - Natural language query")
        print("  POST /api/conversations/sessions/start - Start session")
        print("  GET  /api/conversations/{id}/download  - Download conversation")
        print("=" * 70 + "\n")

        uvicorn.run(
            app,
            host=HOST,
            port=PORT,
            reload=False,  # Disable reload in production
            access_log=DEBUG,
            log_level="info" if DEBUG else "warning"
        )
    except Exception as e:
        print(f"[ERROR] Server startup failed: {e}")
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()