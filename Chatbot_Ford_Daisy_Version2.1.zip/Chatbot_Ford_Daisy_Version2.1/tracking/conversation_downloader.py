"""
DAISY Version 2: Conversation Download Manager
Handles conversation export functionality for frontend (JSON, PDF, CSV formats)
"""
import json
import uuid
import pandas as pd
import os
import sys
from datetime import datetime
from typing import Dict, List, Optional, Any
from pathlib import Path
from databricks import sql
import requests
from dotenv import load_dotenv

# Load environment
load_dotenv(Path(__file__).resolve().parents[1] / ".env", override=True)

class ConversationDownloader:
    """Handles downloading and exporting conversations in multiple formats"""

    def __init__(self):
        self.connection = None

    def _get_token(self):
        """Get Databricks access token"""
        try:
            host = os.environ["DATABRICKS_HOST"]
            resp = requests.post(
                f"{host}/oidc/v1/token",
                data={"grant_type": "client_credentials", "scope": "all-apis"},
                auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
                timeout=30
            )
            resp.raise_for_status()
            return resp.json()["access_token"]
        except Exception as e:
            print(f"Error getting Databricks token: {e}", file=sys.stderr)
            return None

    def _get_databricks_connection(self):
        """Get Databricks connection with error handling"""
        if self.connection is None:
            try:
                token = self._get_token()
                if token:
                    self.connection = sql.connect(
                        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
                        http_path=os.environ["DATABRICKS_HTTP_PATH"],
                        access_token=token
                    )
                else:
                    raise Exception("Could not obtain access token")
            except Exception as e:
                print(f"Error connecting to Databricks: {e}", file=sys.stderr)
                return None
        return self.connection

    def get_conversation_data(self, session_id: str) -> Dict[str, Any]:
        """Retrieve complete conversation data for a session"""

        conn = self._get_databricks_connection()
        if conn is None:
            return {"error": "Could not connect to database"}

        try:
            # Get session details
            session_query = """
            SELECT
                session_id,
                user_id,
                session_start,
                session_end,
                session_duration_minutes,
                total_questions,
                session_type,
                primary_agent_used,
                skills_used,
                topics_covered,
                avg_response_time,
                error_count,
                success_rate,
                user_satisfaction_avg,
                session_completed,
                final_action,
                conversation_exported,
                daisy_version
            FROM sandbox.sri_addepalli.chatbot_conversation_sessions
            WHERE session_id = ?
            """

            # Get all questions and responses
            questions_query = """
            SELECT
                question_id,
                original_question,
                cleaned_question,
                question_category,
                question_intent,
                question_complexity,
                detected_entities,
                suggested_skills,
                actual_skill_used,
                agent_type,
                response_status,
                response_time_seconds,
                response_length,
                response_quality_score,
                user_satisfaction,
                user_feedback,
                timestamp_utc,
                question_tokens,
                response_tokens,
                data_sources_used
            FROM sandbox.sri_addepalli.chatbot_user_questions
            WHERE session_id = ?
            ORDER BY timestamp_utc
            """

            # Get skill executions
            skills_query = """
            SELECT
                execution_id,
                skill_name,
                agent_type,
                execution_status,
                start_time,
                end_time,
                duration_seconds,
                input_parameters,
                output_format,
                output_size_bytes,
                records_returned,
                tables_accessed,
                sql_queries_count,
                total_rows_scanned,
                data_processed_mb,
                memory_usage_mb,
                error_message,
                error_type
            FROM sandbox.sri_addepalli.chatbot_skill_usage_tracking
            WHERE session_id = ?
            ORDER BY start_time
            """

            with conn.cursor() as cursor:
                # Get session info
                cursor.execute(session_query, [session_id])
                session_result = cursor.fetchone()
                session_data = dict(session_result._asdict()) if session_result else None

                # Get questions
                cursor.execute(questions_query, [session_id])
                questions_results = cursor.fetchall()
                questions = [dict(q._asdict()) for q in questions_results]

                # Get skills
                cursor.execute(skills_query, [session_id])
                skills_results = cursor.fetchall()
                skills = [dict(s._asdict()) for s in skills_results]

            return {
                "session_info": session_data,
                "questions": questions,
                "skill_executions": skills,
                "total_questions": len(questions),
                "total_skills_executed": len(skills)
            }

        except Exception as e:
            print(f"Error retrieving conversation data: {e}", file=sys.stderr)
            return {"error": str(e)}

    def export_conversation_json(self, session_id: str, file_path: Optional[str] = None) -> str:
        """Export conversation as structured JSON"""

        data = self.get_conversation_data(session_id)

        if "error" in data:
            raise Exception(f"Could not retrieve conversation data: {data['error']}")

        if not file_path:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            file_path = f"conversation_{session_id[:8]}_{timestamp}.json"

        # Create enhanced JSON structure
        export_data = {
            "metadata": {
                "export_timestamp": datetime.utcnow().isoformat(),
                "session_id": session_id,
                "daisy_version": "2.0",
                "export_format": "json",
                "total_interactions": data["total_questions"],
                "total_skills_executed": data["total_skills_executed"]
            },
            "session_summary": data["session_info"],
            "conversation_timeline": [],
            "skills_summary": self._generate_skills_summary(data["skill_executions"]),
            "analytics_summary": self._generate_session_analytics(data)
        }

        # Create chronological conversation timeline
        all_events = []

        # Add questions
        for question in data["questions"]:
            all_events.append({
                "timestamp": question["timestamp_utc"],
                "type": "question",
                "data": question
            })

        # Add skill executions
        for skill in data["skill_executions"]:
            all_events.append({
                "timestamp": skill["start_time"],
                "type": "skill_execution",
                "data": skill
            })

        # Sort by timestamp
        all_events.sort(key=lambda x: x["timestamp"] if x["timestamp"] else datetime.min)

        # Create conversation flow
        conversation_sequence = 1
        current_question = None

        for event in all_events:
            if event["type"] == "question":
                current_question = event["data"]
                export_data["conversation_timeline"].append({
                    "sequence": conversation_sequence,
                    "timestamp": event["timestamp"].isoformat() if event["timestamp"] else None,
                    "type": "user_question",
                    "question": {
                        "id": current_question["question_id"],
                        "text": current_question["original_question"],
                        "category": current_question["question_category"],
                        "intent": current_question["question_intent"],
                        "complexity": current_question["question_complexity"],
                        "entities": current_question["detected_entities"]
                    },
                    "response": {
                        "status": current_question["response_status"],
                        "agent_used": current_question["agent_type"],
                        "skill_used": current_question["actual_skill_used"],
                        "response_time_seconds": current_question["response_time_seconds"],
                        "quality_score": current_question["response_quality_score"],
                        "user_satisfaction": current_question["user_satisfaction"],
                        "data_sources": current_question["data_sources_used"]
                    }
                })
                conversation_sequence += 1

            elif event["type"] == "skill_execution" and current_question:
                # Find related skills within 30 seconds of question
                question_time = current_question["timestamp_utc"]
                skill_time = event["timestamp"]

                if skill_time and question_time:
                    time_diff = abs((skill_time - question_time).total_seconds())
                    if time_diff <= 30:  # Within 30 seconds
                        export_data["conversation_timeline"][-1]["technical_execution"] = {
                            "execution_id": event["data"]["execution_id"],
                            "skill_name": event["data"]["skill_name"],
                            "agent_type": event["data"]["agent_type"],
                            "status": event["data"]["execution_status"],
                            "duration_seconds": event["data"]["duration_seconds"],
                            "records_returned": event["data"]["records_returned"],
                            "tables_accessed": event["data"]["tables_accessed"],
                            "data_processed_mb": event["data"]["data_processed_mb"],
                            "error": event["data"]["error_message"] if event["data"]["error_message"] else None
                        }

        # Write to file
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, indent=2, default=str, ensure_ascii=False)
        except Exception as e:
            raise Exception(f"Could not write JSON file: {e}")

        # Update export tracking
        self._update_export_tracking(session_id, "json", file_path)

        return file_path

    def export_conversation_csv(self, session_id: str, file_path: Optional[str] = None) -> str:
        """Export conversation as CSV for analysis"""

        data = self.get_conversation_data(session_id)

        if "error" in data:
            raise Exception(f"Could not retrieve conversation data: {data['error']}")

        if not file_path:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            file_path = f"conversation_{session_id[:8]}_{timestamp}.csv"

        # Prepare data for CSV
        csv_data = []

        for i, question in enumerate(data["questions"]):
            # Find related skill execution
            related_skill = None
            question_time = question["timestamp_utc"]

            for skill in data["skill_executions"]:
                if skill["start_time"] and question_time:
                    time_diff = abs((skill["start_time"] - question_time).total_seconds())
                    if time_diff <= 30:  # Within 30 seconds
                        related_skill = skill
                        break

            csv_row = {
                "sequence": i + 1,
                "timestamp": question["timestamp_utc"],
                "question": question["original_question"],
                "question_category": question["question_category"],
                "question_intent": question["question_intent"],
                "question_complexity": question["question_complexity"],
                "agent_type": question["agent_type"],
                "skill_used": question["actual_skill_used"],
                "response_status": question["response_status"],
                "response_time_seconds": question["response_time_seconds"],
                "user_satisfaction": question["user_satisfaction"],
                "skill_execution_status": related_skill["execution_status"] if related_skill else None,
                "skill_duration": related_skill["duration_seconds"] if related_skill else None,
                "records_returned": related_skill["records_returned"] if related_skill else None,
                "tables_accessed": ", ".join(related_skill["tables_accessed"]) if related_skill and related_skill["tables_accessed"] else None,
                "error_message": related_skill["error_message"] if related_skill else None
            }
            csv_data.append(csv_row)

        # Create DataFrame and save
        try:
            df = pd.DataFrame(csv_data)
            df.to_csv(file_path, index=False, encoding='utf-8')
        except Exception as e:
            raise Exception(f"Could not write CSV file: {e}")

        # Update export tracking
        self._update_export_tracking(session_id, "csv", file_path)

        return file_path

    def export_conversation_txt(self, session_id: str, file_path: Optional[str] = None) -> str:
        """Export conversation as readable text report"""

        data = self.get_conversation_data(session_id)

        if "error" in data:
            raise Exception(f"Could not retrieve conversation data: {data['error']}")

        if not file_path:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            file_path = f"conversation_{session_id[:8]}_{timestamp}.txt"

        # Generate text report
        lines = []
        lines.append("="*80)
        lines.append("DAISY VERSION 2 - CONVERSATION EXPORT REPORT")
        lines.append("="*80)
        lines.append(f"Export Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S UTC')}")
        lines.append(f"Session ID: {session_id}")
        lines.append("")

        # Session summary
        if data["session_info"]:
            session = data["session_info"]
            lines.append("SESSION SUMMARY")
            lines.append("-" * 40)
            lines.append(f"Start Time: {session.get('session_start', 'N/A')}")
            lines.append(f"End Time: {session.get('session_end', 'N/A')}")
            lines.append(f"Duration: {session.get('session_duration_minutes', 0):.1f} minutes")
            lines.append(f"Total Questions: {session.get('total_questions', 0)}")
            lines.append(f"Primary Agent: {session.get('primary_agent_used', 'N/A')}")
            lines.append(f"Session Completed: {session.get('session_completed', False)}")
            lines.append(f"Success Rate: {session.get('success_rate', 0)*100:.1f}%")
            lines.append("")

        # Conversation flow
        lines.append("CONVERSATION FLOW")
        lines.append("-" * 40)

        for i, question in enumerate(data["questions"]):
            lines.append(f"\n[Q{i+1}] {question['timestamp_utc']}")
            lines.append(f"Question: {question['original_question']}")
            lines.append(f"Category: {question['question_category']} | Intent: {question['question_intent']} | Complexity: {question['question_complexity']}")
            lines.append(f"Agent: {question['agent_type']} | Skill: {question['actual_skill_used']}")
            lines.append(f"Status: {question['response_status']} | Response Time: {question['response_time_seconds']:.2f}s")

            if question['user_satisfaction']:
                lines.append(f"User Satisfaction: {question['user_satisfaction']}/5")

            # Find related skill execution
            question_time = question["timestamp_utc"]
            for skill in data["skill_executions"]:
                if skill["start_time"] and question_time:
                    time_diff = abs((skill["start_time"] - question_time).total_seconds())
                    if time_diff <= 30:
                        lines.append(f"  Technical: {skill['skill_name']} | Status: {skill['execution_status']} | Duration: {skill['duration_seconds']:.2f}s")
                        if skill['records_returned']:
                            lines.append(f"  Results: {skill['records_returned']} records returned")
                        if skill['error_message']:
                            lines.append(f"  Error: {skill['error_message']}")
                        break

        # Analytics summary
        analytics = self._generate_session_analytics(data)
        if analytics:
            lines.append("\n\nSESSION ANALYTICS")
            lines.append("-" * 40)
            lines.append(f"Average Response Time: {analytics.get('avg_response_time', 0):.2f} seconds")
            lines.append(f"Success Rate: {analytics.get('success_rate', 0)*100:.1f}%")
            lines.append(f"Most Used Agent: {analytics.get('most_used_agent', 'N/A')}")
            lines.append(f"Most Common Category: {analytics.get('most_common_category', 'N/A')}")
            lines.append(f"Total Skills Executed: {analytics.get('total_skills_executed', 0)}")

        lines.append("\n" + "="*80)
        lines.append("End of Report")

        # Write to file
        try:
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write('\n'.join(lines))
        except Exception as e:
            raise Exception(f"Could not write text file: {e}")

        # Update export tracking
        self._update_export_tracking(session_id, "txt", file_path)

        return file_path

    def _generate_skills_summary(self, skills: List[Dict]) -> Dict:
        """Generate summary of skills executed"""
        if not skills:
            return {}

        agents = {}
        total_duration = 0
        error_count = 0

        for skill in skills:
            agent = skill.get("agent_type", "unknown")
            if agent not in agents:
                agents[agent] = {"skills": [], "count": 0, "avg_duration": 0}

            agents[agent]["skills"].append(skill["skill_name"])
            agents[agent]["count"] += 1

            if skill.get("duration_seconds"):
                total_duration += skill["duration_seconds"]

            if skill.get("execution_status") == "error":
                error_count += 1

        return {
            "agents_used": agents,
            "total_skills": len(skills),
            "total_duration_seconds": total_duration,
            "error_count": error_count,
            "success_rate": (len(skills) - error_count) / len(skills) if skills else 0
        }

    def _generate_session_analytics(self, data: Dict) -> Dict:
        """Generate analytics summary for the session"""
        questions = data["questions"]
        skills = data["skill_executions"]

        if not questions:
            return {}

        # Calculate metrics
        total_response_time = sum(q.get("response_time_seconds", 0) or 0 for q in questions)
        avg_response_time = total_response_time / len(questions)

        success_count = len([q for q in questions if q.get("response_status") == "success"])
        success_rate = success_count / len(questions)

        # Most used agent
        agents = [q.get("agent_type") for q in questions if q.get("agent_type")]
        most_used_agent = max(set(agents), key=agents.count) if agents else None

        # Most common category
        categories = [q.get("question_category") for q in questions if q.get("question_category")]
        most_common_category = max(set(categories), key=categories.count) if categories else None

        # User satisfaction
        satisfactions = [q.get("user_satisfaction") for q in questions if q.get("user_satisfaction")]
        avg_satisfaction = sum(satisfactions) / len(satisfactions) if satisfactions else None

        return {
            "total_interactions": len(questions),
            "avg_response_time": avg_response_time,
            "success_rate": success_rate,
            "most_used_agent": most_used_agent,
            "most_common_category": most_common_category,
            "avg_user_satisfaction": avg_satisfaction,
            "total_skills_executed": len(skills),
            "unique_skills_used": len(set(s.get("skill_name") for s in skills if s.get("skill_name"))),
            "agents_used": list(set(q.get("agent_type") for q in questions if q.get("agent_type"))),
            "question_categories": list(set(q.get("question_category") for q in questions if q.get("question_category")))
        }

    def _update_export_tracking(self, session_id: str, export_format: str, file_path: str):
        """Update conversation session with export information"""
        try:
            conn = self._get_databricks_connection()
            if conn is None:
                return

            query = """
            UPDATE sandbox.sri_addepalli.chatbot_conversation_sessions
            SET conversation_exported = true,
                export_timestamp = ?,
                export_format = ?
            WHERE session_id = ?
            """

            with conn.cursor() as cursor:
                cursor.execute(query, [datetime.utcnow(), export_format, session_id])
                conn.commit()

        except Exception as e:
            print(f"Error updating export tracking: {e}", file=sys.stderr)

# Convenience functions
def download_conversation_json(session_id: str, output_path: str = None) -> str:
    """Download conversation as JSON"""
    downloader = ConversationDownloader()
    return downloader.export_conversation_json(session_id, output_path)

def download_conversation_csv(session_id: str, output_path: str = None) -> str:
    """Download conversation as CSV"""
    downloader = ConversationDownloader()
    return downloader.export_conversation_csv(session_id, output_path)

def download_conversation_txt(session_id: str, output_path: str = None) -> str:
    """Download conversation as text report"""
    downloader = ConversationDownloader()
    return downloader.export_conversation_txt(session_id, output_path)