"""
DAISY Version 2: Conversation Tracking System
Handles logging of user questions, skill executions, and session management
Uses SQL Statement Execution API for reliable writes to Unity Catalog tables.
"""
import uuid
import json
import os
import sys
import traceback
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Any
import requests
from dotenv import load_dotenv

# Load environment
load_dotenv(Path(__file__).resolve().parents[1] / ".env", override=True)

# Logging helper - prints to stderr so app logs capture it
def _log(level: str, msg: str):
    print(f"[TRACKER:{level}] {msg}", file=sys.stderr, flush=True)


class ConversationTracker:
    """Handles all conversation tracking and logging to Databricks tables.

    Uses the SQL Statement Execution REST API instead of databricks-sql-connector
    to avoid parameterized-query issues with MAP/ARRAY column types and to
    ensure connection freshness (token is fetched per-call, no stale pool).
    """

    def __init__(self):
        self.session_id = os.environ.get('DAISY_SESSION_ID', str(uuid.uuid4()))
        self._host = os.environ.get("DATABRICKS_HOST", "")
        self._warehouse_id = os.environ.get("DATABRICKS_HTTP_PATH", "").split("/")[-1]
        self._client_id = os.environ.get("DATABRICKS_CLIENT_ID", "")
        self._client_secret = os.environ.get("DATABRICKS_CLIENT_SECRET", "")
        self._token = None
        self._token_expiry = None

    def _get_token(self) -> Optional[str]:
        """Get Databricks access token with caching (tokens last ~1 hour)."""
        now = datetime.utcnow()
        if self._token and self._token_expiry and now < self._token_expiry:
            return self._token
        try:
            resp = requests.post(
                f"{self._host}/oidc/v1/token",
                data={"grant_type": "client_credentials", "scope": "all-apis"},
                auth=(self._client_id, self._client_secret),
                timeout=30,
            )
            resp.raise_for_status()
            data = resp.json()
            self._token = data["access_token"]
            # Cache for 50 min (tokens typically last 60 min)
            self._token_expiry = now + timedelta(minutes=50)
            return self._token
        except Exception as e:
            _log("ERROR", f"Token acquisition failed: {e}")
            self._token = None
            self._token_expiry = None
            return None

    def _execute_sql(self, statement: str) -> bool:
        """Execute a SQL statement via the REST API. Returns True on success."""
        token = self._get_token()
        if not token:
            _log("WARN", "No token — skipping SQL execution")
            return False
        try:
            resp = requests.post(
                f"{self._host}/api/2.0/sql/statements",
                headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
                json={"warehouse_id": self._warehouse_id, "statement": statement, "wait_timeout": "30s"},
                timeout=60,
            )
            result = resp.json()
            state = result.get("status", {}).get("state", "UNKNOWN")
            if state == "SUCCEEDED":
                return True
            error_msg = result.get("status", {}).get("error", {}).get("message", "Unknown error")
            _log("ERROR", f"SQL execution failed ({state}): {error_msg}")
            _log("DEBUG", f"Statement: {statement[:300]}")
            return False
        except Exception as e:
            _log("ERROR", f"SQL execution exception: {e}")
            return False

    @staticmethod
    def _esc(value) -> str:
        """Escape a value for safe SQL embedding."""
        if value is None:
            return "NULL"
        if isinstance(value, bool):
            return "true" if value else "false"
        if isinstance(value, (int, float)):
            return str(value)
        if isinstance(value, datetime):
            return f"TIMESTAMP '{value.strftime('%Y-%m-%d %H:%M:%S')}'"
        if isinstance(value, type(datetime.utcnow().date())):
            return f"DATE '{value.strftime('%Y-%m-%d')}'"
        # String: escape single quotes
        s = str(value).replace("'", "''")
        return f"'{s}'"

    def detect_question_category(self, question_text: str) -> str:
        """Auto-categorize questions based on content"""
        question_lower = question_text.lower()

        # Vehicle-related keywords
        if any(keyword in question_lower for keyword in [
            'vehicle', 'car', 'model', 'f-150', 'mustang', 'explorer', 'bronco',
            'mach-e', 'edge', 'escape', 'ecosport', 'transmission', 'engine', 'brake'
        ]):
            return 'vehicle'

        # Operations-related keywords
        elif any(keyword in question_lower for keyword in [
            'aht', 'handle time', 'callback', 'transfer', 'complexity', 'team',
            'agent', 'performance', 'trend', 'volume', 'regional'
        ]):
            return 'operations'

        # BlueCruise-related keywords
        elif any(keyword in question_lower for keyword in [
            'bluecruise', 'subscription', 'autonomous', 'autopilot', 'cruise'
        ]):
            return 'bluecruise'

        # General analytics
        elif any(keyword in question_lower for keyword in [
            'analyze', 'report', 'data', 'metric', 'chart', 'graph', 'compare'
        ]):
            return 'analytics'

        return 'general'

    def detect_question_intent(self, question_text: str) -> str:
        """Detect the intent behind the question"""
        question_lower = question_text.lower()

        if any(keyword in question_lower for keyword in ['example', 'show me', 'sample']):
            return 'examples'
        elif any(keyword in question_lower for keyword in ['trend', 'over time', 'pattern']):
            return 'trends'
        elif any(keyword in question_lower for keyword in ['compare', 'vs', 'versus', 'difference']):
            return 'comparison'
        elif any(keyword in question_lower for keyword in ['how many', 'count', 'volume']):
            return 'count'
        elif any(keyword in question_lower for keyword in ['why', 'what causes', 'reason']):
            return 'analysis'
        elif any(keyword in question_lower for keyword in ['breakdown', 'by', 'split']):
            return 'breakdown'
        else:
            return 'general_inquiry'

    def log_user_question(self,
                         question_text: str,
                         session_id: Optional[str] = None,
                         agent_type: Optional[str] = None,
                         skill_used: Optional[str] = None,
                         response_status: str = "success",
                         response_time: Optional[float] = None,
                         user_satisfaction: Optional[int] = None) -> str:
        """Log user question to tracking table"""

        if session_id is None:
            session_id = self.session_id

        question_id = str(uuid.uuid4())

        try:
            # Auto-detect question properties
            category = self.detect_question_category(question_text)
            intent = self.detect_question_intent(question_text)
            complexity = self._assess_complexity(question_text)
            now = datetime.utcnow()

            sql = f"""
            INSERT INTO sandbox.sri_addepalli.chatbot_user_questions
            (question_id, session_id, user_id, original_question, cleaned_question,
             question_category, question_intent, question_complexity, actual_skill_used,
             agent_type, response_status, response_time_seconds, user_satisfaction,
             timestamp_utc, date_partition, processing_version, model_version)
            VALUES (
                {self._esc(question_id)}, {self._esc(session_id)}, NULL,
                {self._esc(question_text)}, {self._esc(question_text.strip().lower())},
                {self._esc(category)}, {self._esc(intent)}, {self._esc(complexity)},
                {self._esc(skill_used)}, {self._esc(agent_type)}, {self._esc(response_status)},
                {self._esc(response_time)}, {self._esc(user_satisfaction)},
                {self._esc(now)}, {self._esc(now.date())},
                '2.0', 'claude-sonnet'
            )
            """

            ok = self._execute_sql(sql)
            if ok:
                _log("INFO", f"Logged question {question_id[:8]} session={session_id[:8]}")
            else:
                _log("WARN", f"Failed to log question {question_id[:8]}")

        except Exception as e:
            _log("ERROR", f"log_user_question exception: {e}")
            traceback.print_exc(file=sys.stderr)

        return question_id

    def log_skill_execution(self,
                           session_id: Optional[str],
                           agent_type: str,
                           skill_name: str,
                           execution_status: str = "success",
                           start_time: Optional[datetime] = None,
                           duration_seconds: Optional[float] = None,
                           input_parameters: Optional[Dict] = None,
                           tables_accessed: Optional[List[str]] = None,
                           records_returned: Optional[int] = None,
                           error_message: Optional[str] = None) -> str:
        """Log skill execution to tracking table"""

        if session_id is None:
            session_id = self.session_id

        execution_id = str(uuid.uuid4())

        try:
            if start_time is None:
                start_time = datetime.utcnow()

            end_time = start_time
            if duration_seconds:
                end_time = start_time + timedelta(seconds=duration_seconds)

            # Build MAP literal for input_parameters
            if input_parameters and isinstance(input_parameters, dict):
                map_entries = ", ".join(
                    f"{self._esc(str(k))}, {self._esc(str(v))}"
                    for k, v in input_parameters.items()
                )
                params_sql = f"MAP({map_entries})" if map_entries else "NULL"
            else:
                params_sql = "NULL"

            # Build ARRAY literal for tables_accessed
            if tables_accessed and isinstance(tables_accessed, list):
                arr_entries = ", ".join(self._esc(str(t)) for t in tables_accessed)
                tables_sql = f"ARRAY({arr_entries})"
            else:
                tables_sql = "NULL"

            # Determine error type
            error_type = None
            if execution_status == "error" and error_message:
                if "sql" in error_message.lower():
                    error_type = "sql"
                elif "timeout" in error_message.lower():
                    error_type = "timeout"
                elif "memory" in error_message.lower():
                    error_type = "memory"
                else:
                    error_type = "unknown"

            now = datetime.utcnow()
            sql = f"""
            INSERT INTO sandbox.sri_addepalli.chatbot_skill_usage_tracking
            (execution_id, session_id, agent_type, skill_name, execution_status,
             start_time, end_time, duration_seconds, input_parameters,
             tables_accessed, records_returned, error_message, error_type,
             timestamp_utc, date_partition, daisy_version)
            VALUES (
                {self._esc(execution_id)}, {self._esc(session_id)},
                {self._esc(agent_type)}, {self._esc(skill_name)}, {self._esc(execution_status)},
                {self._esc(start_time)}, {self._esc(end_time)}, {self._esc(duration_seconds)},
                {params_sql}, {tables_sql}, {self._esc(records_returned)},
                {self._esc(error_message)}, {self._esc(error_type)},
                {self._esc(now)}, {self._esc(now.date())}, '2.0'
            )
            """

            ok = self._execute_sql(sql)
            if ok:
                _log("INFO", f"Logged skill {skill_name} exec={execution_id[:8]}")
            else:
                _log("WARN", f"Failed to log skill {skill_name}")

        except Exception as e:
            _log("ERROR", f"log_skill_execution exception: {e}")
            traceback.print_exc(file=sys.stderr)

        return execution_id

    def start_conversation_session(self,
                                  user_id: Optional[str] = None,
                                  session_type: str = "exploratory") -> str:
        """Start a new conversation session"""

        session_id = str(uuid.uuid4())
        self.session_id = session_id

        try:
            now = datetime.utcnow()
            sql = f"""
            INSERT INTO sandbox.sri_addepalli.chatbot_conversation_sessions
            (session_id, user_id, session_start, session_type, total_questions,
             session_completed, created_at, date_partition, daisy_version)
            VALUES (
                {self._esc(session_id)}, {self._esc(user_id)}, {self._esc(now)},
                {self._esc(session_type)}, 0, false,
                {self._esc(now)}, {self._esc(now.date())}, '2.0'
            )
            """

            ok = self._execute_sql(sql)
            if ok:
                _log("INFO", f"Session started: {session_id[:8]}")
            else:
                _log("WARN", f"Failed to log session start: {session_id[:8]}")

        except Exception as e:
            _log("ERROR", f"start_conversation_session exception: {e}")
            traceback.print_exc(file=sys.stderr)

        return session_id

    def end_conversation_session(self,
                               session_id: Optional[str] = None,
                               session_completed: bool = True,
                               final_action: Optional[str] = None):
        """End a conversation session"""

        if session_id is None:
            session_id = self.session_id

        try:
            now = datetime.utcnow()
            sql = f"""
            UPDATE sandbox.sri_addepalli.chatbot_conversation_sessions
            SET session_end = {self._esc(now)},
                session_completed = {self._esc(session_completed)},
                final_action = {self._esc(final_action)}
            WHERE session_id = {self._esc(session_id)}
            """

            ok = self._execute_sql(sql)
            if ok:
                _log("INFO", f"Session ended: {session_id[:8]}")
            else:
                _log("WARN", f"Failed to end session: {session_id[:8]}")

        except Exception as e:
            _log("ERROR", f"end_conversation_session exception: {e}")
            traceback.print_exc(file=sys.stderr)

    def _assess_complexity(self, question_text: str) -> str:
        """Assess question complexity"""
        question_lower = question_text.lower()

        # Count complexity indicators
        complexity_score = 0

        # Multiple filters/conditions
        if len([word for word in ['and', 'or', 'between', 'where'] if word in question_lower]) > 1:
            complexity_score += 2

        # Time ranges
        if any(word in question_lower for word in ['compare', 'vs', 'versus', 'trend', 'over time']):
            complexity_score += 1

        # Multiple entities
        entities = len([word for word in question_lower.split() if word in [
            'vehicle', 'team', 'agent', 'region', 'model', 'f-150', 'mustang'
        ]])
        if entities > 1:
            complexity_score += 1

        # Question length
        if len(question_text.split()) > 15:
            complexity_score += 1

        if complexity_score >= 3:
            return "Complex"
        elif complexity_score >= 1:
            return "Medium"
        else:
            return "Simple"

# Global instance for easy access
conversation_tracker = ConversationTracker()

def log_question(question_text: str, agent_type: str = None, skill_used: str = None, **kwargs) -> str:
    """Convenience function to log a question"""
    return conversation_tracker.log_user_question(
        question_text=question_text,
        agent_type=agent_type,
        skill_used=skill_used,
        **kwargs
    )

def log_skill(agent_type: str, skill_name: str, status: str = "success", **kwargs) -> str:
    """Convenience function to log skill execution"""
    return conversation_tracker.log_skill_execution(
        agent_type=agent_type,
        skill_name=skill_name,
        execution_status=status,
        **kwargs
    )

def start_session(user_id: str = None, session_type: str = "exploratory") -> str:
    """Convenience function to start a session"""
    return conversation_tracker.start_conversation_session(user_id, session_type)

def end_session(session_id: str = None, completed: bool = True, final_action: str = None):
    """Convenience function to end a session"""
    conversation_tracker.end_conversation_session(session_id, completed, final_action)