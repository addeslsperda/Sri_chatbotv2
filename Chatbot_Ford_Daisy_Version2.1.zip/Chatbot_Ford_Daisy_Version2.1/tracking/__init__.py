"""
DAISY Version 2: Tracking Module
Comprehensive conversation and skill tracking system
"""

from .conversation_tracker import (
    ConversationTracker,
    conversation_tracker,
    log_question,
    log_skill,
    start_session,
    end_session
)

from .conversation_downloader import (
    ConversationDownloader,
    download_conversation_json,
    download_conversation_csv,
    download_conversation_txt
)

from .skill_tracker_integration import (
    SkillTracker,
    skill_tracker,
    track_operations_skill,
    track_vehicle_skill,
    track_bluecruise_skill,
    log_skill_manually,
    apply_tracking_to_all_skills
)

__all__ = [
    # Core tracking
    'ConversationTracker',
    'conversation_tracker',
    'log_question',
    'log_skill',
    'start_session',
    'end_session',

    # Download functionality
    'ConversationDownloader',
    'download_conversation_json',
    'download_conversation_csv',
    'download_conversation_txt',

    # Skill tracking
    'SkillTracker',
    'skill_tracker',
    'track_operations_skill',
    'track_vehicle_skill',
    'track_bluecruise_skill',
    'log_skill_manually',
    'apply_tracking_to_all_skills'
]

__version__ = "2.0.0"
__author__ = "DAISY Version 2 Team"