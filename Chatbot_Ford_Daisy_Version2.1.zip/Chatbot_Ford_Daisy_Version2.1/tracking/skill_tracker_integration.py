"""
DAISY Version 2: Skill Tracker Integration
Adds tracking functionality to all existing skills without modifying original code
"""
import os
import sys
import json
import uuid
import functools
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any, Callable

# Import the conversation tracker
try:
    from .conversation_tracker import conversation_tracker, log_skill
except ImportError:
    # Fallback for direct execution
    sys.path.append(str(Path(__file__).parent))
    from conversation_tracker import conversation_tracker, log_skill

class SkillTracker:
    """Decorator and context manager for tracking skill executions"""

    def __init__(self):
        self.session_id = os.environ.get('DAISY_SESSION_ID', str(uuid.uuid4()))
        self.current_executions = {}

    def track_skill_execution(self, agent_type: str, skill_name: str):
        """Decorator to automatically track skill execution"""
        def decorator(func: Callable) -> Callable:
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                execution_id = str(uuid.uuid4())
                start_time = datetime.utcnow()

                # Extract parameters for logging
                input_params = self._extract_parameters(args, kwargs)

                try:
                    # Execute the original function
                    result = func(*args, **kwargs)

                    # Calculate execution time
                    duration = (datetime.utcnow() - start_time).total_seconds()

                    # Extract result metadata
                    records_returned = self._extract_record_count(result)
                    tables_accessed = self._extract_tables_accessed(kwargs, input_params)

                    # Log successful execution
                    log_skill(
                        agent_type=agent_type,
                        skill_name=skill_name,
                        status="success",
                        session_id=self.session_id,
                        start_time=start_time,
                        duration_seconds=duration,
                        input_parameters=input_params,
                        tables_accessed=tables_accessed,
                        records_returned=records_returned
                    )

                    return result

                except Exception as e:
                    # Calculate execution time even on error
                    duration = (datetime.utcnow() - start_time).total_seconds()

                    # Log failed execution
                    log_skill(
                        agent_type=agent_type,
                        skill_name=skill_name,
                        status="error",
                        session_id=self.session_id,
                        start_time=start_time,
                        duration_seconds=duration,
                        input_parameters=input_params,
                        error_message=str(e)
                    )

                    # Re-raise the exception
                    raise e

            return wrapper
        return decorator

    def manual_log(self,
                   agent_type: str,
                   skill_name: str,
                   status: str = "success",
                   duration: float = None,
                   input_params: Dict = None,
                   tables_accessed: List[str] = None,
                   records_returned: int = None,
                   error_message: str = None):
        """Manually log a skill execution (for existing scripts)"""

        log_skill(
            agent_type=agent_type,
            skill_name=skill_name,
            status=status,
            session_id=self.session_id,
            duration_seconds=duration,
            input_parameters=input_params,
            tables_accessed=tables_accessed,
            records_returned=records_returned,
            error_message=error_message
        )

    def _extract_parameters(self, args: tuple, kwargs: dict) -> Dict[str, Any]:
        """Extract parameters from function arguments"""
        params = {}

        # Add keyword arguments
        for key, value in kwargs.items():
            if key not in ['connection', 'cursor']:  # Skip connection objects
                try:
                    # Convert to JSON-serializable format
                    json.dumps(value)
                    params[key] = value
                except (TypeError, ValueError):
                    params[key] = str(value)

        # Look for common parameter patterns in args
        if len(args) >= 2:
            # Common pattern: main(args) where args has from_date, to_date
            if hasattr(args[0], 'from_date'):
                params['from_date'] = getattr(args[0], 'from_date', None)
            if hasattr(args[0], 'to_date'):
                params['to_date'] = getattr(args[0], 'to_date', None)
            if hasattr(args[0], 'vehicle'):
                params['vehicle'] = getattr(args[0], 'vehicle', None)
            if hasattr(args[0], 'team'):
                params['team'] = getattr(args[0], 'team', None)

        return params

    def _extract_record_count(self, result: Any) -> Optional[int]:
        """Try to extract record count from result"""
        try:
            if isinstance(result, dict):
                # Look for common result patterns
                if 'data' in result and isinstance(result['data'], list):
                    return len(result['data'])
                elif 'results' in result and isinstance(result['results'], list):
                    return len(result['results'])
                elif 'records' in result:
                    return result['records'] if isinstance(result['records'], int) else len(result['records'])
            elif isinstance(result, list):
                return len(result)
        except Exception:
            pass
        return None

    def _extract_tables_accessed(self, kwargs: dict, params: dict) -> Optional[List[str]]:
        """Extract which tables were likely accessed based on parameters"""
        tables = []

        # Common DAISY tables based on agent type and parameters
        if 'vehicle' in str(params).lower() or 'vehicle' in str(kwargs).lower():
            tables.extend([
                'text_analytics.nlp_analytics.call_data',
                'text_analytics.nlp_analytics.call_table',
                'text_analytics.nlp_configs.topic_detail'
            ])

        if 'aht' in str(params).lower() or 'complexity' in str(params).lower():
            tables.extend([
                'ford_daisy.analytics.call_data',
                'text_analytics.nlp_analytics.sentiments'
            ])

        if 'callback' in str(params).lower():
            tables.extend([
                'text_analytics.nlp_analytics.call_data',
                'embedding_tables'
            ])

        return list(set(tables)) if tables else None

# Global skill tracker instance
skill_tracker = SkillTracker()

# Convenience functions for adding tracking to existing scripts
def track_operations_skill(skill_name: str):
    """Decorator for operations_agent skills"""
    return skill_tracker.track_skill_execution("operations_agent", skill_name)

def track_vehicle_skill(skill_name: str):
    """Decorator for vehicle_agent skills"""
    return skill_tracker.track_skill_execution("vehicle_agent", skill_name)

def track_bluecruise_skill(skill_name: str):
    """Decorator for bluecruise_agent skills"""
    return skill_tracker.track_skill_execution("bluecruise_agent", skill_name)

def log_skill_manually(agent_type: str, skill_name: str, **kwargs):
    """Manual logging function for existing scripts"""
    return skill_tracker.manual_log(agent_type, skill_name, **kwargs)

def add_tracking_to_existing_script(script_content: str, agent_type: str, skill_name: str) -> str:
    """Add tracking to existing script without major modifications"""

    # Add imports at the top
    tracking_import = f"""
# DAISY V2 Tracking Integration (Auto-added)
import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[2] / 'tracking'))
try:
    from skill_tracker_integration import log_skill_manually
    TRACKING_AVAILABLE = True
except ImportError:
    TRACKING_AVAILABLE = False
    def log_skill_manually(*args, **kwargs):
        pass  # Fallback if tracking not available

"""

    # Add tracking at the start of main function
    tracking_start = f"""
    # DAISY V2 Tracking - Start
    import time
    _start_time = time.time()
    _input_params = {{}}
    try:
        _input_params = vars(args) if hasattr(args, '__dict__') else {{}}
    except:
        pass
"""

    # Add tracking at the end of successful execution
    tracking_success = f"""
    # DAISY V2 Tracking - Success
    if TRACKING_AVAILABLE:
        try:
            log_skill_manually(
                agent_type="{agent_type}",
                skill_name="{skill_name}",
                status="success",
                duration=time.time() - _start_time,
                input_params=_input_params
            )
        except Exception as track_error:
            print(f"Warning: Tracking failed: {{track_error}}", file=sys.stderr)
"""

    # Add tracking for error handling
    tracking_error = f"""
    # DAISY V2 Tracking - Error
    if TRACKING_AVAILABLE:
        try:
            log_skill_manually(
                agent_type="{agent_type}",
                skill_name="{skill_name}",
                status="error",
                duration=time.time() - _start_time,
                input_params=_input_params,
                error_message=str(e)
            )
        except Exception as track_error:
            pass  # Don't fail on tracking errors during error handling
"""

    # Insert tracking code into script
    lines = script_content.split('\n')
    result_lines = []

    # Add imports after existing imports
    import_added = False
    main_function_found = False

    for i, line in enumerate(lines):
        result_lines.append(line)

        # Add imports after the last import statement
        if not import_added and (line.startswith('import ') or line.startswith('from ')) and \
           (i + 1 >= len(lines) or not (lines[i + 1].startswith('import ') or lines[i + 1].startswith('from '))):
            result_lines.append(tracking_import)
            import_added = True

        # Add tracking start after main function definition
        if 'def main(' in line or 'if __name__ == "__main__"' in line:
            if not main_function_found:
                # Find the next non-comment, non-empty line
                j = i + 1
                while j < len(lines) and (lines[j].strip() == '' or lines[j].strip().startswith('#')):
                    j += 1
                if j < len(lines):
                    result_lines.append(tracking_start)
                    main_function_found = True

        # Add success tracking before return or print statements
        if ('print(' in line and 'json.dumps' in line) or ('return ' in line and 'result' in line):
            result_lines.append(tracking_success)

        # Add error tracking in exception handlers
        if 'except Exception as e:' in line or 'except Exception:' in line:
            result_lines.append(tracking_error)

    return '\n'.join(result_lines)

def apply_tracking_to_all_skills():
    """Apply tracking to all skills in daisy_version_2"""

    base_path = Path(__file__).resolve().parents[1]

    agents = {
        'operations_agent': base_path / 'operations_agent' / '.claude' / 'skills',
        'vehicle_agent': base_path / 'vehicle_agent' / '.claude' / 'skills',
        'bluecruise_agent': base_path / 'bluecruise_agent' / '.claude' / 'skills'
    }

    modified_files = []

    for agent_type, agent_path in agents.items():
        if not agent_path.exists():
            continue

        # Process each skill directory
        for skill_dir in agent_path.iterdir():
            if not skill_dir.is_dir():
                continue

            scripts_dir = skill_dir / 'scripts'
            if not scripts_dir.exists():
                continue

            skill_name = skill_dir.name
            main_script = scripts_dir / f"{skill_name}.py"

            if main_script.exists():
                try:
                    # Read original script
                    with open(main_script, 'r', encoding='utf-8') as f:
                        original_content = f.read()

                    # Check if tracking is already added
                    if 'DAISY V2 Tracking Integration' in original_content:
                        continue  # Already has tracking

                    # Add tracking
                    modified_content = add_tracking_to_existing_script(
                        original_content, agent_type, skill_name
                    )

                    # Create backup
                    backup_file = scripts_dir / f"{skill_name}_pre_tracking_backup.py"
                    with open(backup_file, 'w', encoding='utf-8') as f:
                        f.write(original_content)

                    # Write modified script
                    with open(main_script, 'w', encoding='utf-8') as f:
                        f.write(modified_content)

                    modified_files.append(str(main_script))

                except Exception as e:
                    print(f"Error processing {main_script}: {e}", file=sys.stderr)

    return modified_files

if __name__ == "__main__":
    # Apply tracking to all skills when run directly
    print("Applying DAISY V2 tracking to all skills...")
    modified = apply_tracking_to_all_skills()
    print(f"Modified {len(modified)} skill files:")
    for file in modified:
        print(f"  - {file}")
    print("Tracking integration complete!")