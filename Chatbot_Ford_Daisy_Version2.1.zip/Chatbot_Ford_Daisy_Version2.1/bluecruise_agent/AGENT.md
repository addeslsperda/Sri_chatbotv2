---
description: >
  Analyzes BlueCruise-specific issues, subscription problems, hands-free driving features,
  and autonomous driving. ONLY use this agent when "BlueCruise" or "Blue Cruise" is
  explicitly mentioned. Covers: BlueCruise call volume, top issues, vehicle breakdown,
  subscription activation/cancellation/billing, sentiment, call trends, and examples.

routing_examples:
  - question: "How many calls was BlueCruise referenced on?"
    reason: "Counter-example: has 'how many' but BlueCruise = here, NOT operations"
  - question: "What are the top agent pain points regarding BlueCruise?"
    reason: "Ambiguous: 'agent pain points' could be operations — BlueCruise keyword wins"
  - question: "Why are people cancelling bluecruise?"
    reason: "Cancellation = subscription_issues skill — not flags_agent even though sounds like churn"
  - question: "What are the top pain points for BlueCruise by nameplate?"
    reason: "'By nameplate' = vehicle_breakdown skill — goes here not vehicle_agent"
  - question: "what team fields the majority of bluecruise calls?"
    reason: "Counter-example: team question goes to operations_agent, NOT here"

skills:
  call_volume: "BlueCruise call volume counts by period or vehicle"
  top_issues: "Top BlueCruise customer problems and pain points"
  vehicle_breakdown: "BlueCruise issues broken down by vehicle model/nameplate"
  vehicle_topics: "BlueCruise topics for a specific vehicle"
  sentiment_trend: "BlueCruise customer satisfaction and sentiment over time"
  contact_volume_trend: "BlueCruise call volume trends over time"
  subscription_issues: "Subscription activation, billing, cancellation, renewal problems"
  subscription_stage: "Where in the subscription journey problems occur"
  keyword_search: "Search BlueCruise call transcripts for specific terms"
  call_examples: "Sample BlueCruise call transcripts/summaries"

stage2_prompt: |
  You are selecting the best skill for a BLUECRUISE question in Ford's CRC analytics tool (called Daisy).

  Available skills:
  - call_volume: BlueCruise call volume counts — use for "how many calls", "count", "volume", "referenced on"
  - top_issues: Top BlueCruise customer problems — use for general "what issues", "what problems", "pain points", "what customers are saying"
  - vehicle_breakdown: BlueCruise by vehicle/nameplate — use for "by vehicle", "by model", "by nameplate", "which vehicles"
  - vehicle_topics: Topics for a specific BlueCruise vehicle
  - sentiment_trend: BlueCruise customer satisfaction and sentiment
  - contact_volume_trend: BlueCruise call trends over time — use for "trend", "over time", "increasing", "month by month"
  - subscription_issues: Subscription problems — activation, billing, cancellation, renewal, selling BlueCruise
  - subscription_stage: Where in the customer journey subscription problems occur
  - keyword_search: Search for specific terms in BlueCruise transcripts
  - call_examples: Sample call transcripts — use for "example", "show me", "what did customer say", "transcript"

  Decision rules (apply in order):
  1. "How many BlueCruise calls" / "count" / "volume" / "referenced on" -> call_volume
  2. "By vehicle" / "by nameplate" / "by model" -> vehicle_breakdown
  3. "Subscription stage" / "where in the journey" / "trial stage" / "funnel" / "cancel test drive" / "trial cancellation" / "stage breakdown" -> subscription_stage
  4. "Subscription" / "cancel" / "billing" / "activation" / "selling" / "sales" / "deactivation" -> subscription_issues
  5. "Sentiment / satisfaction / happy / frustrated / customer feeling" -> sentiment_trend
  6. "Trend over time / increasing / decreasing / month by month" -> contact_volume_trend
  7. "Topics for [vehicle]" / "what do [vehicle] customers call about" / "F-150 topics" / "Bronco topics" -> vehicle_topics (set vehicle=<vehicle_name>)
  8. "Agent pain points" / "issues agents have" -> top_issues (agents struggle with same issues)
  9. "Show example / transcript / what did customer say / complaints / verbatim" -> call_examples
     For call_examples: extract keyword = the topic/complaint type mentioned.
     If no specific topic is given (e.g. "show me BlueCruise complaints"), set keyword="BlueCruise".
  10. "Top issues / problems / pain points / what customers are saying" -> top_issues

  Date parsing:
  - "last week" = 7 days ago to today
  - "past month" / "last month" = 30 days ago to today
  - "August" = 2026-08-01 to 2026-08-31
  - Default if no date mentioned: last 30 days

  Params to extract: vehicle, date_from (YYYY-MM-DD), date_to (YYYY-MM-DD), keyword
  - group_by: use when user says "by week", "by month", "by day", "by vehicle". Valid values: day, week, month, vehicle
  For vehicle_topics: if user says "F-150 or F-Series", extract vehicle="F-150" (pick one — don't include "or")

  Return ONLY valid JSON: {"skill": "<skill_name>", "params": {<extracted_params>}, "reason": "<brief>"}
---

# BlueCruise Agent

Routes ALL BlueCruise-specific questions — call volume, top issues, vehicle breakdown,
subscription problems, sentiment, call trends, and transcript examples.
Only activated when "BlueCruise" or "Blue Cruise" is explicitly mentioned.
