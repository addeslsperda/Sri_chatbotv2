---
name: subscription_issues
display_name: Enhanced BlueCruise Subscription Intelligence
description: Production-grade multi-dimensional subscription analysis with embedding-enhanced billing detection, churn root cause analysis, and data-driven business classification across all BlueCruise data sources.
signals:
  - subscription issues
  - billing problems
  - cancellation reasons
  - deactivation analysis
  - subscription churn
  - trial issues
  - renewal problems
  - activation failures
  - subscription sentiment
  - hardware-driven cancellations
  - revenue impact analysis
requires:
  - a date range (from and to)
capabilities:
  - Multi-table subscription analysis (base_view + subscriptions + topics + parts + pain_points + embeddings)
  - Embedding-enhanced billing detection (more accurate than keyword matching)
  - Churn root cause analysis (hardware issues, billing problems, sentiment drivers)
  - Revenue impact assessment with REVENUE_CRITICAL classification for Deactivations
  - Data-driven business priority scoring and actionable recommendations
  - Vehicle-specific subscription problem correlation
not_good_for: General call volumes (use call_volume), overall issue breakdown (use top_issues)
---

# Enhanced BlueCruise Subscription Intelligence

## What this does
Performs comprehensive multi-dimensional subscription analysis across all BlueCruise data sources with embedding-enhanced detection, revenue impact assessment, and data-driven churn root cause analysis.

## Production Features
- **Multi-table subscription analysis**: Combines base_view, subscriptions, topics, parts, pain_points, and embeddings tables
- **Embedding-enhanced billing detection**: Uses call summaries and multi-field analysis for accurate billing issue identification  
- **Churn root cause analysis**: Identifies hardware issues, billing problems, and sentiment drivers causing cancellations
- **Revenue impact classification**: REVENUE_CRITICAL for Deactivations, SENTIMENT_CRISIS, HARDWARE_DRIVEN classifications
- **Business priority scoring**: Data-driven priority scores based on revenue impact + sentiment + hardware correlation
- **Vehicle correlation**: Subscription issues by vehicle model with hardware problem identification
- **AI insights**: Automated recommendations for reducing churn and improving subscription experience

## How to run it

```bash
python .claude/skills/subscription_issues/scripts/subscription_issues.py --from YYYY-MM-DD --to YYYY-MM-DD
```

## Enhanced Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--from` | Yes | — | Start date in YYYY-MM-DD format |
| `--to` | Yes | — | End date in YYYY-MM-DD format |
| `--category` | No | all | Filter to specific subscription category (e.g., "Deactivations", "Trials") |
| `--vehicle` | No | all | Filter to specific vehicle model |
| `--include-insights` | No | false | Include AI-powered subscription insights and recommendations |

## Example Usage

```bash
# Comprehensive subscription analysis with business insights
python subscription_issues.py --from 2025-01-01 --to 2025-12-31 --include-insights

# Deep dive into cancellations (revenue critical)
python subscription_issues.py --from 2025-01-01 --to 2025-12-31 --category "Deactivations" --include-insights

# Vehicle-specific subscription problems
python subscription_issues.py --from 2025-01-01 --to 2025-12-31 --vehicle "F-SERIES" --include-insights

# Trial subscription issues analysis
python subscription_issues.py --from 2025-01-01 --to 2025-12-31 --category "Trials"
```

## Enhanced Output Format

```json
{
  "status": "success",
  "analysis_type": "enhanced_subscription_issues",
  "parameters": {
    "date_from": "2025-01-01",
    "date_to": "2025-12-31",
    "embedding_enhanced": true
  },
  "data": [
    {
      "subscription_category": "Deactivations",
      "call_count": 2030,
      "pct_of_subscription_calls": 11.6,
      "negative_calls": 1543,
      "negative_pct": 76.0,
      "positive_calls": 234,
      "positive_pct": 11.5,
      "hardware_related_calls": 812,
      "hardware_correlation_pct": 40.0,
      "billing_related_calls": 508,
      "billing_pct": 25.0,
      "sample_hardware_issue": "steering sensor calibration failure causing BlueCruise disengagement",
      "churn_hardware_cause": "wiring harness replacement required for BlueCruise functionality",
      "churn_primary_reason": "BlueCruise stops working after software update, requires expensive hardware repair",
      "churn_customer_voice": "Tired of paying monthly fee for feature that doesn't work reliably",
      "subscription_issue_classification": "REVENUE_CRITICAL",
      "subscription_priority_score": 187.3
    },
    {
      "subscription_category": "Trials",
      "call_count": 6213,
      "pct_of_subscription_calls": 35.6,
      "negative_pct": 42.1,
      "hardware_correlation_pct": 18.2,
      "billing_pct": 67.3,
      "subscription_issue_classification": "BILLING_FOCUSED",
      "subscription_priority_score": 89.4
    }
  ],
  "insights": {
    "summary": {
      "total_calls_analyzed": 17459,
      "subscription_categories": 8,
      "revenue_critical_categories": 1,
      "billing_focused_categories": 2
    },
    "insights": [
      {
        "type": "alert",
        "message": "Revenue critical: 2030 deactivation calls (76.0% negative sentiment)",
        "severity": "high",
        "supporting_data": "Hardware correlation: 40.0%, Billing issues: 25.0%"
      }
    ],
    "recommendations": [
      {
        "action": "Engineering review required for churn-causing hardware: steering sensor calibration failure",
        "priority": "urgent",
        "estimated_impact": "Reduce revenue loss from hardware-driven cancellations"
      }
    ]
  }
}
```

## Business Classifications

### Subscription Issue Types
- **REVENUE_CRITICAL**: Deactivations (direct revenue loss)
- **SENTIMENT_CRISIS**: 2+ standard deviations above average negative sentiment  
- **HARDWARE_DRIVEN**: 80th percentile hardware correlation (data-driven threshold)
- **SENTIMENT_CRITICAL**: 80th percentile negative sentiment (data-driven threshold)
- **BILLING_FOCUSED**: 75th percentile billing-related calls (embedding-enhanced detection)
- **NORMAL**: Standard operational performance

### Business Intelligence
- **Churn Root Cause Analysis**: Identifies specific hardware issues and billing problems causing cancellations
- **Revenue Impact Assessment**: Quantifies revenue loss from subscription issues
- **Hardware-Subscription Correlation**: Links hardware failures to subscription cancellations
- **Embedding-Enhanced Detection**: More accurate billing issue identification using call summaries
- **Vehicle-Specific Analysis**: Subscription problems by vehicle model

## Revenue Impact Value
Enhanced subscription_issues provides critical business intelligence for:
- **Churn Reduction**: Identify and fix root causes of subscription cancellations
- **Revenue Protection**: Prioritize issues based on actual revenue impact
- **Customer Experience**: Improve subscription processes to reduce billing confusion
- **Hardware Investment**: Data-driven decisions on hardware reliability improvements
- **Process Optimization**: Streamline subscription workflows based on actual customer pain points

## Error Handling
Enhanced error handling with detailed error classification, security validation, and comprehensive logging for production monitoring.