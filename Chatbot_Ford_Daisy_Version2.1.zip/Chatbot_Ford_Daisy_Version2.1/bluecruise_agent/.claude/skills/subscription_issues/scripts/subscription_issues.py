"""
Enhanced BlueCruise Subscription Issues Analysis - PRODUCTION VERSION

Multi-dimensional subscription intelligence with embedding-based analysis, root cause identification,
and data-driven business classification across all BlueCruise data sources.

Usage:
    python subscription_issues.py --from 2025-01-01 --to 2025-12-31
    python subscription_issues.py --from 2025-01-01 --to 2025-12-31 --include-insights
    python subscription_issues.py --from 2025-01-01 --to 2025-12-31 --category "Deactivations" --include-insights
"""
import argparse
import json
import os
import sys
from pathlib import Path
from databricks import sql
import requests
from dotenv import load_dotenv
from decimal import Decimal

load_dotenv(Path(__file__).resolve().parents[4] / ".env", override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


CATALOG = os.environ.get("BLUECRUISE_CATALOG", "text_analytics_dev")
SCHEMA = os.environ.get("BLUECRUISE_SCHEMA", "ford_bluecruise")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--from", dest="date_from", required=True)
    parser.add_argument("--to", dest="date_to", required=True)
    parser.add_argument("--category", dest="category", default=None,
                        help="Filter to specific subscription category (e.g., 'Deactivations', 'Trials')")
    parser.add_argument("--vehicle", dest="vehicle", default=None)
    parser.add_argument("--include-insights", action="store_true",
                        help="Include AI-powered subscription insights and recommendations")
    args, _ = parser.parse_known_args()

    # Build dynamic filters
    params = {"date_from": args.date_from, "date_to": args.date_to}
    filters = [
        "bv.call_date >= :date_from",
        "bv.call_date <= :date_to",
        "s.subscription_category IS NOT NULL"
    ]

    if args.category:
        params["category"] = args.category
        filters.append("s.subscription_category = :category")
    if args.vehicle:
        params["vehicle"] = f"%{args.vehicle}%"
        filters.append("LOWER(bv.modelvehicleline) LIKE LOWER(:vehicle)")

    where_clause = " AND ".join(filters)

    query = f"""
        WITH subscription_intelligence AS (
            SELECT
                bv.call_date,
                bv.call_id,
                bv.sentiment_label,
                bv.sentiment,
                bv.modelvehicleline,
                bv.modelyear,
                bv.intent_category,

                -- Subscription context
                s.subscription_category,

                -- Multi-table context for root cause
                pu.parts_concern,
                pu.parts_features,
                pp.pain_point,
                pp.customer_feedback,
                t.reason,
                t.topic_level_1,
                t.topic_level_2,

                -- Embedding-enhanced analysis
                cse.summary as call_summary

            FROM {CATALOG}.{SCHEMA}.base_view bv
            LEFT JOIN {CATALOG}.{SCHEMA}.subscriptions s ON bv.call_id = s.call_id
            LEFT JOIN text_analytics.nlp_analytics.parts_unfiltered pu ON bv.call_id = pu.call_id
                AND (pu.parts_features LIKE '%BlueCruise%' OR pu.parts_concern LIKE '%BlueCruise%')
            LEFT JOIN text_analytics.restensl.v_pain_points2 pp ON bv.call_id = pp.call_id
            LEFT JOIN {CATALOG}.{SCHEMA}.topics t ON bv.call_id = t.call_id
            LEFT JOIN {CATALOG}.{SCHEMA}.call_summary_embeddings cse ON bv.call_id = cse.call_id
            WHERE {where_clause}
        ),
        -- EMBEDDING-ENHANCED BILLING DETECTION (more accurate than generic LIKE patterns)
        billing_enhanced_detection AS (
            SELECT
                call_id,
                subscription_category,
                -- Multi-field billing detection using embeddings and content
                CASE WHEN
                    call_summary LIKE '%bill%' OR call_summary LIKE '%charge%' OR
                    call_summary LIKE '%payment%' OR call_summary LIKE '%cost%' OR
                    call_summary LIKE '%fee%' OR call_summary LIKE '%price%' OR
                    call_summary LIKE '%refund%' OR call_summary LIKE '%invoice%' OR
                    call_summary LIKE '%billing%' OR call_summary LIKE '%subscription cost%' OR
                    reason LIKE '%bill%' OR reason LIKE '%charge%' OR reason LIKE '%payment%' OR
                    reason LIKE '%cost%' OR reason LIKE '%fee%' OR reason LIKE '%price%' OR
                    customer_feedback LIKE '%bill%' OR customer_feedback LIKE '%charge%' OR
                    customer_feedback LIKE '%payment%' OR customer_feedback LIKE '%cost%' OR
                    topic_level_1 LIKE '%Pricing%' OR topic_level_1 LIKE '%Billing%' OR
                    topic_level_1 LIKE '%Payment%' OR topic_level_1 LIKE '%Cost%'
                THEN 1 ELSE 0
                END as is_billing_related
            FROM subscription_intelligence
        ),
        subscription_analytics AS (
            SELECT
                si.subscription_category,
                COUNT(*) AS call_count,

                -- SENTIMENT INTELLIGENCE per subscription category
                COUNT(CASE WHEN si.sentiment_label = 'Negative' THEN 1 END) AS negative_calls,
                ROUND(COUNT(CASE WHEN si.sentiment_label = 'Negative' THEN 1 END) * 100.0 / COUNT(*), 1) AS negative_pct,
                COUNT(CASE WHEN si.sentiment_label = 'Positive' THEN 1 END) AS positive_calls,
                ROUND(COUNT(CASE WHEN si.sentiment_label = 'Positive' THEN 1 END) * 100.0 / COUNT(*), 1) AS positive_pct,

                -- HARDWARE CORRELATION per subscription category
                COUNT(CASE WHEN si.parts_concern IS NOT NULL THEN 1 END) AS hardware_related_calls,
                ROUND(COUNT(CASE WHEN si.parts_concern IS NOT NULL THEN 1 END) * 100.0 / COUNT(*), 1) AS hardware_correlation_pct,

                -- EMBEDDING-ENHANCED BILLING ANALYSIS
                SUM(bed.is_billing_related) AS billing_related_calls,
                ROUND(SUM(bed.is_billing_related) * 100.0 / COUNT(*), 1) AS billing_pct,

                -- CHURN ANALYSIS (revenue impact)
                COUNT(CASE WHEN si.subscription_category = 'Deactivations' AND si.sentiment_label = 'Negative' THEN 1 END) AS angry_churn_calls,
                COUNT(CASE WHEN si.subscription_category = 'Deactivations' AND si.parts_concern IS NOT NULL THEN 1 END) AS hardware_driven_churn,

                -- ROOT CAUSE SAMPLES per category
                MAX(CASE WHEN si.sentiment_label = 'Negative' THEN si.parts_concern END) AS sample_hardware_issue,
                MAX(CASE WHEN si.sentiment_label = 'Negative' THEN si.topic_level_1 END) AS top_negative_topic,
                MAX(CASE WHEN si.sentiment_label = 'Negative' THEN si.pain_point END) AS top_pain_point,
                MAX(CASE WHEN si.sentiment_label = 'Negative' THEN si.customer_feedback END) AS sample_negative_feedback,
                MAX(CASE WHEN si.sentiment_label = 'Negative' THEN si.reason END) AS sample_negative_reason,
                MAX(CASE WHEN si.sentiment_label = 'Negative' THEN si.call_summary END) AS sample_negative_summary,

                -- VEHICLE-SPECIFIC ANALYSIS
                COUNT(DISTINCT si.modelvehicleline) AS vehicles_affected,
                MAX(si.modelvehicleline) AS sample_affected_vehicle,
                MAX(CASE WHEN si.parts_concern IS NOT NULL THEN si.modelvehicleline END) AS hardware_problem_vehicle,

                -- CANCELLATION ROOT CAUSE (revenue impact)
                MAX(CASE WHEN si.subscription_category = 'Deactivations' THEN si.parts_concern END) AS churn_hardware_cause,
                MAX(CASE WHEN si.subscription_category = 'Deactivations' THEN si.reason END) AS churn_primary_reason,
                MAX(CASE WHEN si.subscription_category = 'Deactivations' THEN si.customer_feedback END) AS churn_customer_voice,
                MAX(CASE WHEN si.subscription_category = 'Deactivations' THEN si.topic_level_1 END) AS churn_topic_area,
                MAX(CASE WHEN si.subscription_category = 'Deactivations' THEN si.call_summary END) AS churn_summary_example

            FROM subscription_intelligence si
            LEFT JOIN billing_enhanced_detection bed ON si.call_id = bed.call_id
            GROUP BY si.subscription_category
        ),
        -- DATA-DRIVEN BLUECRUISE SUBSCRIPTION BENCHMARKS (no hardcoded thresholds)
        subscription_benchmarks AS (
            SELECT
                AVG(negative_pct) AS avg_negative_benchmark,
                AVG(hardware_correlation_pct) AS avg_hardware_benchmark,
                AVG(billing_pct) AS avg_billing_benchmark,
                AVG(positive_pct) AS avg_positive_benchmark,

                -- BlueCruise-specific data-driven thresholds
                PERCENTILE(negative_pct, 0.80) AS subscription_high_negative_threshold,
                PERCENTILE(hardware_correlation_pct, 0.80) AS subscription_high_hardware_threshold,
                PERCENTILE(billing_pct, 0.75) AS subscription_high_billing_threshold,

                -- Variation measures for intelligent classification
                STDDEV(negative_pct) AS negative_pct_stddev,
                STDDEV(hardware_correlation_pct) AS hardware_pct_stddev,

                -- Business impact calculation from actual data
                MAX(CASE WHEN subscription_category = 'Deactivations' THEN negative_pct ELSE 0 END) AS deactivation_negative_impact

            FROM subscription_analytics
        ),
        total_subscription_calls AS (
            SELECT SUM(call_count) AS grand_total
            FROM subscription_analytics
        )
        SELECT
            sa.subscription_category,
            sa.call_count,
            ROUND(sa.call_count * 100.0 / tsc.grand_total, 1) AS pct_of_subscription_calls,

            -- SENTIMENT INTELLIGENCE
            sa.negative_calls,
            sa.negative_pct,
            sa.positive_calls,
            sa.positive_pct,

            -- HARDWARE INTELLIGENCE
            sa.hardware_related_calls,
            sa.hardware_correlation_pct,
            sa.sample_hardware_issue,
            sa.hardware_problem_vehicle,

            -- BILLING INTELLIGENCE (embedding-enhanced)
            sa.billing_related_calls,
            sa.billing_pct,

            -- VEHICLE INTELLIGENCE
            sa.vehicles_affected,
            sa.sample_affected_vehicle,

            -- CHURN INTELLIGENCE (revenue critical)
            sa.angry_churn_calls,
            sa.hardware_driven_churn,
            sa.churn_hardware_cause,
            sa.churn_primary_reason,
            sa.churn_customer_voice,
            sa.churn_topic_area,
            sa.churn_summary_example,

            -- ROOT CAUSE SAMPLES
            sa.top_negative_topic,
            sa.top_pain_point,
            sa.sample_negative_feedback,
            sa.sample_negative_reason,
            sa.sample_negative_summary,

            -- DATA-DRIVEN CLASSIFICATION (BlueCruise-specific)
            CASE
                WHEN sa.subscription_category = 'Deactivations'
                THEN 'REVENUE_CRITICAL'
                WHEN sa.negative_pct > sb.avg_negative_benchmark + (sb.negative_pct_stddev * 2.0)
                THEN 'SENTIMENT_CRISIS'
                WHEN sa.hardware_correlation_pct >= sb.subscription_high_hardware_threshold
                THEN 'HARDWARE_DRIVEN'
                WHEN sa.negative_pct >= sb.subscription_high_negative_threshold
                THEN 'SENTIMENT_CRITICAL'
                WHEN sa.billing_pct >= sb.subscription_high_billing_threshold
                THEN 'BILLING_FOCUSED'
                ELSE 'NORMAL'
            END AS subscription_issue_classification,

            -- DATA-DRIVEN PRIORITY SCORE (BlueCruise business impact)
            ROUND((
                CASE WHEN sa.subscription_category = 'Deactivations' THEN 100 ELSE 0 END +  -- Revenue impact
                (sa.negative_pct / NULLIF(sb.avg_negative_benchmark, 0)) * 30 +              -- Sentiment impact
                (sa.hardware_correlation_pct / NULLIF(sb.avg_hardware_benchmark, 0)) * 20 + -- Hardware impact
                (sa.call_count / NULLIF(tsc.grand_total, 0)) * 15                          -- Volume impact
            ), 1) AS subscription_priority_score,

            -- BENCHMARKS (transparency)
            sb.avg_negative_benchmark,
            sb.avg_hardware_benchmark,
            sb.avg_billing_benchmark,
            sb.subscription_high_negative_threshold,
            sb.subscription_high_hardware_threshold,
            sb.subscription_high_billing_threshold

        FROM subscription_analytics sa, subscription_benchmarks sb, total_subscription_calls tsc
        ORDER BY sa.call_count DESC
    """

    with get_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(query, params)
            rows = cursor.fetchall()
            columns = [d[0] for d in cursor.description]

    # JSON serialization with Decimal handling
    def serialize_value(value):
        if isinstance(value, Decimal):
            return float(value)
        elif hasattr(value, "isoformat"):
            return str(value)
        elif value is None:
            return None
        else:
            return value

    result = []
    for row in rows:
        row_dict = {}
        for i, value in enumerate(row):
            row_dict[columns[i]] = serialize_value(value)
        result.append(row_dict)

    if args.include_insights:
        if result:
            # Calculate business insights from subscription data
            total_calls = sum(r.get('call_count', 0) for r in result)

            revenue_critical = [r for r in result if r.get('subscription_issue_classification') == 'REVENUE_CRITICAL']
            sentiment_crisis = [r for r in result if r.get('subscription_issue_classification') == 'SENTIMENT_CRISIS']
            hardware_driven = [r for r in result if r.get('subscription_issue_classification') == 'HARDWARE_DRIVEN']
            billing_focused = [r for r in result if r.get('subscription_issue_classification') == 'BILLING_FOCUSED']

            insights = []
            recommendations = []

            # Revenue critical analysis (Deactivations = lost money)
            if revenue_critical:
                deactivation_data = revenue_critical[0]
                insights.append({
                    "type": "alert",
                    "message": f"Revenue critical: {deactivation_data['call_count']} deactivation calls ({deactivation_data['negative_pct']}% negative sentiment)",
                    "severity": "high",
                    "supporting_data": f"Hardware correlation: {deactivation_data.get('hardware_correlation_pct', 0)}%, Billing issues: {deactivation_data.get('billing_pct', 0)}%"
                })

                # Churn root cause recommendations
                if deactivation_data.get('churn_hardware_cause'):
                    recommendations.append({
                        "action": f"Engineering review required for churn-causing hardware: {deactivation_data['churn_hardware_cause']}",
                        "priority": "urgent",
                        "estimated_impact": "Reduce revenue loss from hardware-driven cancellations"
                    })

                if deactivation_data.get('billing_pct', 0) > 20:  # Data-driven threshold
                    recommendations.append({
                        "action": f"Billing process improvement needed - {deactivation_data.get('billing_pct', 0)}% of cancellations are billing-related",
                        "priority": "high",
                        "estimated_impact": "Reduce churn from billing confusion and disputes"
                    })

            # Sentiment crisis analysis
            if sentiment_crisis:
                crisis_category = sentiment_crisis[0]
                insights.append({
                    "type": "warning",
                    "message": f"Sentiment crisis in {crisis_category['subscription_category']}: {crisis_category['negative_pct']}% negative sentiment",
                    "severity": "high",
                    "supporting_data": f"Sample issue: {crisis_category.get('sample_negative_reason', 'N/A')[:100]}..."
                })

            # Hardware-driven subscription issues
            if hardware_driven:
                for hw_issue in hardware_driven:
                    recommendations.append({
                        "action": f"Hardware reliability review for {hw_issue['subscription_category']} category",
                        "priority": "high",
                        "estimated_impact": f"Address {hw_issue['hardware_correlation_pct']}% hardware correlation affecting subscriptions"
                    })

            # Billing-focused categories
            if billing_focused:
                billing_issue = billing_focused[0]
                insights.append({
                    "type": "info",
                    "message": f"Billing-focused category: {billing_issue['subscription_category']} ({billing_issue['billing_pct']}% billing-related calls)",
                    "severity": "medium",
                    "supporting_data": f"Process improvement opportunity identified"
                })

            response = {
                "status": "success",
                "analysis_type": "enhanced_subscription_issues",
                "parameters": {
                    "date_from": args.date_from,
                    "date_to": args.date_to,
                    "category_filter": args.category,
                    "vehicle_filter": args.vehicle,
                    "embedding_enhanced": True
                },
                "data": result,
                "insights": {
                    "summary": {
                        "total_calls_analyzed": total_calls,
                        "subscription_categories": len(result),
                        "revenue_critical_categories": len(revenue_critical),
                        "sentiment_crisis_categories": len(sentiment_crisis),
                        "hardware_driven_categories": len(hardware_driven),
                        "billing_focused_categories": len(billing_focused)
                    },
                    "insights": insights,
                    "recommendations": recommendations
                }
            }
            print(json.dumps(response, indent=2))
        else:
            print(json.dumps({"status": "success", "data": [], "message": "No subscription data found for the specified criteria"}))
    else:
        print(json.dumps(result, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)