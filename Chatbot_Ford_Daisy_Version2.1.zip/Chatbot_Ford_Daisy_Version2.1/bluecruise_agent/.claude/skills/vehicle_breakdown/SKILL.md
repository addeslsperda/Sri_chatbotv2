---
name: vehicle_breakdown
display_name: Enhanced BlueCruise Vehicle Intelligence
description: Production-grade multi-dimensional vehicle analysis with hardware correlation, business priority scoring, and vehicle-specific issue identification across all BlueCruise data sources.
signals:
  - by vehicle
  - vehicle model
  - F-150
  - Bronco
  - Mustang
  - which vehicle
  - compare models
  - vehicle comparison
  - by model
  - vehicle hardware issues
  - model-specific problems
  - vehicle priority ranking
requires:
  - a date range (from and to)
capabilities:
  - Multi-table vehicle analysis (base_view + topics + subscriptions + parts + pain_points)
  - Vehicle-specific hardware correlation and failure analysis
  - Business priority scoring with data-driven vehicle classification
  - Model-specific issue identification and root cause samples
  - Cross-vehicle benchmarking and comparative analysis
  - AI-powered insights and engineering recommendations
not_good_for: Sentiment over time (use sentiment_trend), general issue categories (use top_issues)
---

# Enhanced BlueCruise Vehicle Intelligence

## What this does
Performs comprehensive multi-dimensional vehicle analysis across all BlueCruise data sources with hardware correlation, business priority scoring, and vehicle-specific issue identification for engineering prioritization.

## Production Features
- **Multi-table vehicle analysis**: Combines base_view, topics, subscriptions, parts, and pain_points tables
- **Hardware correlation**: Vehicle-specific hardware failure rates and component issues
- **Business priority scoring**: Data-driven vehicle classification and priority ranking
- **Root cause analysis**: Sample issues, hardware problems, and customer feedback per vehicle
- **Cross-vehicle benchmarking**: Comparative analysis against vehicle fleet averages
- **Vehicle classification**: CRITICAL_VEHICLE, HARDWARE_PRONE, SENTIMENT_RISK, CHURN_RISK, NORMAL
- **Engineering insights**: AI-generated recommendations for vehicle-specific improvements

## How to run it

```bash
python .claude/skills/vehicle_breakdown/scripts/vehicle_breakdown.py --from YYYY-MM-DD --to YYYY-MM-DD
```

## Enhanced Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--from` | Yes | — | Start date in YYYY-MM-DD format |
| `--to` | Yes | — | End date in YYYY-MM-DD format |
| `--models` | No | all | Comma-separated vehicle models to include (e.g., "F-150,Bronco") |
| `--year` | No | all | Filter by model year (e.g., 2024) |
| `--include-insights` | No | false | Include AI-powered business insights and recommendations |

## Example Usage

```bash
# Comprehensive vehicle analysis with engineering insights
python vehicle_breakdown.py --from 2025-01-01 --to 2025-12-31 --include-insights

# Compare F-150 vs Bronco hardware issues
python vehicle_breakdown.py --from 2025-01-01 --to 2025-12-31 --models "F-150,Bronco" --include-insights

# 2024 model year vehicle analysis
python vehicle_breakdown.py --from 2025-01-01 --to 2025-12-31 --year 2024 --include-insights

# Single vehicle deep dive
python vehicle_breakdown.py --from 2025-01-01 --to 2025-12-31 --models "F-150"
```

## Enhanced Output Format

```json
{
  "status": "success",
  "analysis_type": "enhanced_vehicle_breakdown",
  "parameters": {
    "date_from": "2025-01-01",
    "date_to": "2025-12-31",
    "models_filter": "F-150,Bronco"
  },
  "data": [
    {
      "modelvehicleline": "F-150",
      "modelyear": 2024,
      "call_count": 1247,
      "pct_of_total_calls": 23.4,
      "negative_calls": 589,
      "negative_pct": 47.2,
      "churn_calls": 156,
      "churn_rate": 12.5,
      "hardware_calls": 412,
      "hardware_pct": 33.0,
      "pain_point_calls": 823,
      "pain_point_pct": 66.0,
      "sample_hardware_issue": "steering sensor alignment issues affecting BlueCruise",
      "primary_topic_area": "Feature Availability & Performance",
      "sample_feedback": "BlueCruise turns off unexpectedly in highway construction zones",
      "sample_reason": "Lane centering malfunction during highway driving",
      "vehicle_classification": "HARDWARE_PRONE",
      "vehicle_priority_score": 142.3,
      "avg_negative_benchmark": 45.7,
      "avg_churn_benchmark": 10.2,
      "avg_hardware_benchmark": 28.5
    }
  ],
  "insights": {
    "summary": {
      "total_calls_analyzed": 5321,
      "vehicles_analyzed": 8,
      "critical_vehicles": 2,
      "hardware_prone_vehicles": 3
    },
    "insights": [
      {
        "type": "alert",
        "message": "Critical vehicles detected: 2 models need immediate attention",
        "severity": "high",
        "supporting_data": "Vehicles: F-150 2024, Bronco 2023"
      }
    ],
    "recommendations": [
      {
        "action": "Engineering review required for 2 vehicle models",
        "priority": "urgent",
        "estimated_impact": "Address vehicle-specific hardware and experience issues"
      }
    ]
  }
}
```

## Vehicle Classifications

### Priority Classifications
- **CRITICAL_VEHICLE**: High negative sentiment + high churn rate (immediate engineering attention)
- **HARDWARE_PRONE**: Above 75th percentile hardware correlation (reliability review needed)
- **SENTIMENT_RISK**: 30% above average negative sentiment (experience improvement needed)
- **CHURN_RISK**: 30% above average churn rate (retention strategy required)
- **NORMAL**: Standard operational performance

### Business Intelligence
- **Vehicle Priority Score**: Data-driven ranking based on sentiment + churn + hardware correlation
- **Cross-Vehicle Benchmarking**: Performance vs fleet averages
- **Hardware Correlation**: Specific component failures per vehicle model
- **Root Cause Samples**: Real customer feedback and technical issues per vehicle

## Engineering Value
Enhanced vehicle breakdown provides actionable intelligence for:
- **Engineering Prioritization**: Which vehicles need immediate hardware attention
- **Model-Specific Issues**: Root cause analysis per vehicle type
- **Resource Allocation**: Data-driven investment decisions per vehicle line
- **Quality Improvement**: Targeted fixes based on vehicle-specific failure patterns

## Error Handling
Enhanced error handling with detailed error classification, security validation, and comprehensive logging for production monitoring.
