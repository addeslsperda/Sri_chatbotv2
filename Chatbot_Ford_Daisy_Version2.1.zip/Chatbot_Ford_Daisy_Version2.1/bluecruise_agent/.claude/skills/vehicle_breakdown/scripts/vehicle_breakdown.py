"""
Enhanced BlueCruise Vehicle Breakdown Analysis - PRODUCTION VERSION

Multi-table vehicle intelligence with hardware correlation, business priority scoring,
and vehicle-specific issue analysis across all BlueCruise data sources.

Usage:
    python vehicle_breakdown.py --from 2025-01-01 --to 2025-12-31
    python vehicle_breakdown.py --from 2025-01-01 --to 2025-12-31 --models "F-150,Bronco" --include-insights
    python vehicle_breakdown.py --from 2025-01-01 --to 2025-12-31 --year 2024 --include-insights
"""
import argparse
import json
import os
import sys
from pathlib import Path
from databricks import sql
import requests
from dotenv import load_dotenv
from decimal import Decimal

load_dotenv(Path(__file__).resolve().parents[4] / ".env", override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


CATALOG = os.environ.get("BLUECRUISE_CATALOG", "text_analytics_dev")
SCHEMA = os.environ.get("BLUECRUISE_SCHEMA", "ford_bluecruise")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--from", dest="date_from", required=True)
    parser.add_argument("--to", dest="date_to", required=True)
    parser.add_argument("--models", dest="models", default=None,
                        help="Comma-separated vehicle models to filter (e.g., 'F-150,Bronco')")
    parser.add_argument("--year", dest="year", default=None)
    parser.add_argument("--include-insights", action="store_true",
                        help="Include AI-powered business insights and recommendations")
    args, _ = parser.parse_known_args()

    # Build dynamic filters
    params = {"date_from": args.date_from, "date_to": args.date_to}
    filters = [
        "bv.call_date >= :date_from",
        "bv.call_date <= :date_to",
        "bv.modelvehicleline IS NOT NULL"
    ]

    if args.models:
        model_markers = []
        for i, m in enumerate(args.models.split(",")):
            params[f"model{i}"] = m.strip()
            model_markers.append(f":model{i}")
        filters.append(f"bv.modelvehicleline IN ({', '.join(model_markers)})")
    if args.year:
        params["year"] = args.year
        filters.append("bv.modelyear = :year")

    where_clause = " AND ".join(filters)

    query = f"""
        WITH vehicle_intelligence AS (
            SELECT
                bv.modelvehicleline,
                bv.modelyear,
                bv.call_id,
                bv.sentiment_label,
                bv.intent_category,
                s.subscription_category,
                pu.parts_concern,
                pu.parts_features,
                pp.pain_point,
                pp.customer_feedback,
                t.reason,
                t.topic_level_1
            FROM {CATALOG}.{SCHEMA}.base_view bv
            LEFT JOIN {CATALOG}.{SCHEMA}.subscriptions s ON bv.call_id = s.call_id
            LEFT JOIN text_analytics.nlp_analytics.parts_unfiltered pu ON bv.call_id = pu.call_id
                AND (pu.parts_features LIKE '%BlueCruise%' OR pu.parts_concern LIKE '%BlueCruise%')
            LEFT JOIN text_analytics.restensl.v_pain_points2 pp ON bv.call_id = pp.call_id
            LEFT JOIN {CATALOG}.{SCHEMA}.topics t ON bv.call_id = t.call_id
            WHERE {where_clause}
        ),
        vehicle_analytics AS (
            SELECT
                modelvehicleline,
                modelyear,
                COUNT(*) AS call_count,

                -- Sentiment breakdown
                COUNT(CASE WHEN sentiment_label = 'Negative' THEN 1 END) AS negative_calls,
                ROUND(COUNT(CASE WHEN sentiment_label = 'Negative' THEN 1 END) * 100.0 / COUNT(*), 1) AS negative_pct,

                -- Business impact
                COUNT(CASE WHEN subscription_category = 'Deactivations' THEN 1 END) AS churn_calls,
                ROUND(COUNT(CASE WHEN subscription_category = 'Deactivations' THEN 1 END) * 100.0 / COUNT(*), 1) AS churn_rate,

                -- Hardware correlation
                COUNT(CASE WHEN parts_concern IS NOT NULL THEN 1 END) AS hardware_calls,
                ROUND(COUNT(CASE WHEN parts_concern IS NOT NULL THEN 1 END) * 100.0 / COUNT(*), 1) AS hardware_pct,

                -- Pain point correlation
                COUNT(CASE WHEN pain_point IS NOT NULL THEN 1 END) AS pain_point_calls,
                ROUND(COUNT(CASE WHEN pain_point IS NOT NULL THEN 1 END) * 100.0 / COUNT(*), 1) AS pain_point_pct,

                -- Top issues per vehicle (avoid nested aggregates)
                MAX(parts_concern) AS sample_hardware_issue,
                MAX(topic_level_1) AS primary_topic_area,
                MAX(customer_feedback) AS sample_feedback,
                MAX(reason) AS sample_reason

            FROM vehicle_intelligence
            GROUP BY modelvehicleline, modelyear
        ),
        -- BlueCruise-specific vehicle benchmarks
        vehicle_benchmarks AS (
            SELECT
                AVG(negative_pct) AS avg_negative_benchmark,
                AVG(churn_rate) AS avg_churn_benchmark,
                AVG(hardware_pct) AS avg_hardware_benchmark,
                PERCENTILE(negative_pct, 0.85) AS high_negative_threshold,
                PERCENTILE(churn_rate, 0.85) AS high_churn_threshold,
                PERCENTILE(hardware_pct, 0.85) AS high_hardware_threshold
            FROM vehicle_analytics
        ),
        total_calls AS (
            SELECT SUM(call_count) AS grand_total
            FROM vehicle_analytics
        )
        SELECT
            va.modelvehicleline,
            va.modelyear,
            va.call_count,
            ROUND(va.call_count * 100.0 / tc.grand_total, 1) AS pct_of_total_calls,

            -- Enhanced metrics
            va.negative_calls,
            va.negative_pct,
            va.churn_calls,
            va.churn_rate,
            va.hardware_calls,
            va.hardware_pct,
            va.pain_point_calls,
            va.pain_point_pct,

            -- Context samples
            va.sample_hardware_issue,
            va.primary_topic_area,
            va.sample_feedback,
            va.sample_reason,

            -- BlueCruise-specific vehicle classification
            CASE
                WHEN va.negative_pct >= vb.high_negative_threshold
                 AND va.churn_rate >= vb.high_churn_threshold
                THEN 'CRITICAL_VEHICLE'
                WHEN va.hardware_pct >= vb.high_hardware_threshold
                THEN 'HARDWARE_PRONE'
                WHEN va.negative_pct >= vb.avg_negative_benchmark * 1.5
                THEN 'SENTIMENT_RISK'
                WHEN va.churn_rate >= vb.avg_churn_benchmark * 1.5
                THEN 'CHURN_RISK'
                ELSE 'NORMAL'
            END AS vehicle_classification,

            -- Vehicle priority score (data-driven)
            ROUND((
                (va.negative_pct / NULLIF(vb.avg_negative_benchmark, 0)) * 40 +
                (va.churn_rate / NULLIF(vb.avg_churn_benchmark, 0)) * 40 +
                (va.hardware_pct / NULLIF(vb.avg_hardware_benchmark, 0)) * 20
            ), 1) AS vehicle_priority_score,

            -- Benchmark context
            vb.avg_negative_benchmark,
            vb.avg_churn_benchmark,
            vb.avg_hardware_benchmark

        FROM vehicle_analytics va, vehicle_benchmarks vb, total_calls tc
        ORDER BY va.call_count DESC
    """

    with get_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(query, params)
            rows = cursor.fetchall()
            columns = [d[0] for d in cursor.description]

    # JSON serialization with Decimal handling
    def serialize_value(value):
        if isinstance(value, Decimal):
            return float(value)
        elif hasattr(value, "isoformat"):
            return str(value)
        elif value is None:
            return None
        else:
            return value

    result = []
    for row in rows:
        row_dict = {}
        for i, value in enumerate(row):
            row_dict[columns[i]] = serialize_value(value)
        result.append(row_dict)

    if args.include_insights:
        if result:
            total_calls = sum(r.get('call_count', 0) for r in result)
            critical_vehicles = [r for r in result if r.get('vehicle_classification') in ['CRITICAL_VEHICLE', 'HARDWARE_PRONE']]

            insights = []
            recommendations = []

            # Generate vehicle-specific insights
            if critical_vehicles:
                critical_names = [f"{r['modelvehicleline']} {r['modelyear']}" for r in critical_vehicles]
                insights.append({
                    "type": "alert",
                    "message": f"Critical vehicles detected: {len(critical_vehicles)} models need immediate attention",
                    "severity": "high",
                    "supporting_data": f"Vehicles: {', '.join(critical_names[:3])}"
                })

                recommendations.append({
                    "action": f"Engineering review required for {len(critical_vehicles)} vehicle models",
                    "priority": "urgent",
                    "estimated_impact": "Address vehicle-specific hardware and experience issues"
                })

            # Hardware-prone vehicles
            hardware_prone = [r for r in result if r.get('vehicle_classification') == 'HARDWARE_PRONE']
            if hardware_prone:
                recommendations.append({
                    "action": f"Hardware reliability improvement needed for {len(hardware_prone)} vehicle models",
                    "priority": "high",
                    "estimated_impact": "Reduce vehicle-specific hardware failures"
                })

            # Top problematic vehicle
            if result:
                top_problem_vehicle = max(result, key=lambda x: x.get('vehicle_priority_score', 0))
                insights.append({
                    "type": "warning",
                    "message": f"Highest priority vehicle: {top_problem_vehicle['modelvehicleline']} {top_problem_vehicle['modelyear']}",
                    "severity": "medium",
                    "supporting_data": f"Priority score: {top_problem_vehicle.get('vehicle_priority_score', 0)}"
                })

            response = {
                "status": "success",
                "analysis_type": "enhanced_vehicle_breakdown",
                "parameters": {
                    "date_from": args.date_from,
                    "date_to": args.date_to,
                    "models_filter": args.models,
                    "year_filter": args.year
                },
                "data": result,
                "insights": {
                    "summary": {
                        "total_calls_analyzed": total_calls,
                        "vehicles_analyzed": len(result),
                        "critical_vehicles": len(critical_vehicles),
                        "hardware_prone_vehicles": len(hardware_prone)
                    },
                    "insights": insights,
                    "recommendations": recommendations
                }
            }
            print(json.dumps(response, indent=2))
        else:
            print(json.dumps({"status": "success", "data": [], "message": "No data found for the specified criteria"}))
    else:
        print(json.dumps(result, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)
