"""
Enhanced BlueCruise Call Examples Analysis - PRODUCTION VERSION

Embedding-enhanced semantic search for real customer voices with multi-dimensional business context,
root cause correlation, and actionable insights across all BlueCruise data sources.

Usage:
    python call_examples.py --topic "steering problems" --include-insights
    python call_examples.py --topic "subscription issues" --sentiment negative --limit 10
    python call_examples.py --topic "BlueCruise failing" --vehicle "F-150" --include-insights
"""
import argparse
import json
import os
import sys
from pathlib import Path
from databricks import sql
import requests
from dotenv import load_dotenv
from decimal import Decimal

# Databricks Vector Search Integration (same as keyword_search)
try:
    from databricks.vector_search.client import VectorSearchClient
    from databricks.sdk import WorkspaceClient
    from databricks.sdk.core import Config

    cfg = Config()
    vs_client = VectorSearchClient(
        workspace_url=cfg.host,
        service_principal_client_id=cfg.client_id,
        service_principal_client_secret=cfg.client_secret
    )
    w = WorkspaceClient()

    def _get_embedding(query_str: str):
        """Get embedding using Databricks serving endpoint"""
        response = w.serving_endpoints.query(
            name="qwen3-embedding-06b",
            instances=[query_str]
        )
        return response.predictions[0]

    vs_index = vs_client.get_index(
        endpoint_name="knowledgbase_endpoint",
        index_name="text_analytics.nlp_agent.call_summary_qwen06b_vs_v2"
    )

    EMBEDDING_AVAILABLE = True
except ImportError as e:
    print(f"Warning: Databricks vector search not available: {e}. Using enhanced LIKE search.", file=sys.stderr)
    EMBEDDING_AVAILABLE = False

load_dotenv(Path(__file__).resolve().parents[4] / ".env", override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


CATALOG = os.environ.get("BLUECRUISE_CATALOG", "text_analytics_dev")
SCHEMA = os.environ.get("BLUECRUISE_SCHEMA", "ford_bluecruise")
BASE_VIEW = f"{CATALOG}.{SCHEMA}.base_view"
IDENTIFICATION = f"{CATALOG}.{SCHEMA}.ford_bluecruise_identification"


def get_topic_matched_call_ids(topic, similarity_threshold=0.4, limit=1000):
    """Get call_ids using Databricks vector search for topic examples"""
    if not EMBEDDING_AVAILABLE:
        return []

    try:
        print(f"Getting embedding for topic: {topic}", file=sys.stderr)
        embedding = _get_embedding(f"find customer examples about: {topic}")
        print("Retrieving semantically similar calls", file=sys.stderr)

        res = vs_index.similarity_search(
            ['call_id', 'summary', 'call_date'],
            query_vector=embedding,
            num_results=limit,
            score_threshold=similarity_threshold
        )
        print(f"Retrieved {len(res['result']['data_array'])} matching call examples", file=sys.stderr)

        # Extract call_ids from results
        call_ids = [row[0] for row in res['result']['data_array']]
        return call_ids

    except Exception as e:
        print(f"Warning: Vector search failed: {e}. Using enhanced LIKE search.", file=sys.stderr)
        return []


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--topic", "--keyword", dest="topic", required=True,
                        help="Topic or keyword to find examples for")
    parser.add_argument("--from", dest="date_from", default=None)
    parser.add_argument("--to", dest="date_to", default=None)
    parser.add_argument("--vehicle", dest="vehicle", default=None)
    parser.add_argument("--year", dest="year", default=None)
    parser.add_argument("--limit", type=int, default=20,
                        help="Number of call examples to return")
    parser.add_argument("--sentiment", dest="sentiment", choices=["positive", "neutral", "negative"], default=None)
    parser.add_argument("--similarity-threshold", dest="similarity_threshold", type=float, default=0.4,
                        help="Minimum similarity score for semantic matching")
    parser.add_argument("--include-insights", action="store_true",
                        help="Include AI-powered insights and business context")
    args, _ = parser.parse_known_args()

    # Step 1: Get semantically similar call_ids using Databricks vector search
    matched_call_ids = get_topic_matched_call_ids(args.topic, args.similarity_threshold, args.limit * 10)

    # Build dynamic filters
    params = {"date_from": args.date_from or "2020-01-01", "date_to": args.date_to or "2030-12-31"}
    filters = [
        "bv.call_date >= :date_from",
        "bv.call_date <= :date_to"
    ]

    if args.vehicle:
        params["vehicle"] = f"%{args.vehicle}%"
        filters.append("LOWER(bv.modelvehicleline) LIKE LOWER(:vehicle)")
    if args.year:
        params["year"] = args.year
        filters.append("bv.modelyear = :year")
    if args.sentiment:
        params["sentiment"] = args.sentiment.capitalize()
        filters.append("bv.sentiment_label = :sentiment")

    where_clause = " AND ".join(filters)

    # Step 2: Choose search method based on vector search results
    if matched_call_ids and EMBEDDING_AVAILABLE:
        # Use embedding-matched call_ids
        limited_call_ids = matched_call_ids[:500]  # Limit for performance
        call_id_placeholders = ",".join([f":call_id_{i}" for i in range(len(limited_call_ids))])
        for i, call_id in enumerate(limited_call_ids):
            params[f"call_id_{i}"] = call_id

        call_id_filter = f"bv.call_id IN ({call_id_placeholders})" if limited_call_ids else "1=0"
        search_method = "embedding_semantic"
        print(f"Using embedding search with {len(matched_call_ids)} semantically similar calls", file=sys.stderr)
    else:
        # Fallback to enhanced LIKE search across multiple fields
        params["topic"] = f"%{args.topic}%"
        call_id_filter = """(
            LOWER(t.reason) LIKE LOWER(:topic) OR
            LOWER(pp.customer_feedback) LIKE LOWER(:topic) OR
            LOWER(pu.parts_concern) LIKE LOWER(:topic) OR
            LOWER(cse.summary) LIKE LOWER(:topic)
        )"""
        search_method = "multi_field_like"
        print(f"Using multi-field LIKE search for topic: {args.topic}", file=sys.stderr)

    # Step 3: Enhanced query with multi-table context
    query = f"""
        WITH example_calls AS (
            SELECT
                bv.call_id,
                bv.call_date,
                bv.modelvehicleline,
                bv.modelyear,
                bv.sentiment_label,
                bv.sentiment,
                bv.intent_category,

                -- Call content
                COALESCE(cse.summary, 'Call example found via topic search') as call_summary,

                -- Multi-table context for rich examples
                s.subscription_category,
                pu.parts_concern,
                pu.parts_features,
                pp.pain_point,
                pp.customer_feedback,
                t.reason,
                t.topic_level_1,
                t.topic_level_2

            FROM {CATALOG}.{SCHEMA}.base_view bv
            LEFT JOIN {CATALOG}.{SCHEMA}.call_summary_embeddings cse ON bv.call_id = cse.call_id
            LEFT JOIN {CATALOG}.{SCHEMA}.subscriptions s ON bv.call_id = s.call_id
            LEFT JOIN text_analytics.nlp_analytics.parts_unfiltered pu ON bv.call_id = pu.call_id
                AND (pu.parts_features LIKE '%BlueCruise%' OR pu.parts_concern LIKE '%BlueCruise%')
            LEFT JOIN text_analytics.restensl.v_pain_points2 pp ON bv.call_id = pp.call_id
            LEFT JOIN {CATALOG}.{SCHEMA}.topics t ON bv.call_id = t.call_id
            WHERE {where_clause}
              AND {call_id_filter}
              AND LENGTH(COALESCE(cse.summary, pp.customer_feedback, t.reason, '')) > 30
        )
        SELECT
            call_id,
            DATE(call_date) AS call_date,
            modelvehicleline,
            modelyear,
            sentiment_label,
            sentiment,
            intent_category,
            call_summary,

            -- Business context per example
            subscription_category,
            parts_concern as hardware_issue,
            pain_point,
            customer_feedback as customer_voice,
            reason as call_reason,
            topic_level_1 as primary_topic,

            -- Business classification per call example
            CASE
                WHEN subscription_category = 'Deactivations' AND sentiment_label = 'Negative'
                THEN 'EXAMPLE_CHURN_RISK'
                WHEN parts_concern IS NOT NULL AND sentiment_label = 'Negative'
                THEN 'EXAMPLE_HARDWARE_CRISIS'
                WHEN sentiment_label = 'Negative' AND sentiment < 0.3
                THEN 'EXAMPLE_CRITICAL_ISSUE'
                WHEN subscription_category IS NOT NULL
                THEN 'EXAMPLE_SUBSCRIPTION_FOCUSED'
                WHEN parts_concern IS NOT NULL
                THEN 'EXAMPLE_HARDWARE_FOCUSED'
                ELSE 'EXAMPLE_GENERAL'
            END AS example_classification

        FROM example_calls
        ORDER BY
            CASE WHEN sentiment_label = 'Negative' THEN 1
                 WHEN sentiment_label = 'Neutral' THEN 2
                 ELSE 3 END,
            sentiment ASC,
            call_date DESC
        LIMIT {args.limit}
    """

    with get_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(query, params)
            rows = cursor.fetchall()
            columns = [d[0] for d in cursor.description]

    # JSON serialization with Decimal handling
    def serialize_value(value):
        if isinstance(value, Decimal):
            return float(value)
        elif hasattr(value, "isoformat"):
            return str(value)
        elif value is None:
            return None
        else:
            return value

    result = []
    for row in rows:
        row_dict = {}
        for i, value in enumerate(row):
            row_dict[columns[i]] = serialize_value(value)
        result.append(row_dict)

    if args.include_insights and result:
        # Generate insights from call examples
        total_examples = len(result)
        negative_examples = len([r for r in result if r.get('sentiment_label') == 'Negative'])
        churn_risk_examples = len([r for r in result if r.get('example_classification') == 'EXAMPLE_CHURN_RISK'])
        hardware_crisis_examples = len([r for r in result if r.get('example_classification') == 'EXAMPLE_HARDWARE_CRISIS'])

        insights = []
        recommendations = []

        # Generate example-specific insights
        if negative_examples > total_examples * 0.6:
            insights.append({
                "type": "alert",
                "message": f"High negative sentiment in examples: {negative_examples}/{total_examples} examples are negative",
                "severity": "high",
                "supporting_data": f"Topic '{args.topic}' shows concerning customer sentiment patterns"
            })

        if churn_risk_examples > 0:
            insights.append({
                "type": "warning",
                "message": f"Churn risk detected: {churn_risk_examples} examples show subscription cancellation risk",
                "severity": "high",
                "supporting_data": f"Revenue impact from '{args.topic}' issues"
            })

        if hardware_crisis_examples > 0:
            recommendations.append({
                "action": f"Engineering review required for '{args.topic}' - {hardware_crisis_examples} hardware crisis examples found",
                "priority": "urgent",
                "estimated_impact": "Address customer-reported hardware failures"
            })

        # Sample customer voices for context
        negative_voices = [r.get('customer_voice') for r in result if r.get('sentiment_label') == 'Negative' and r.get('customer_voice')]
        if negative_voices:
            insights.append({
                "type": "info",
                "message": f"Sample customer voice: '{negative_voices[0][:100]}...'",
                "severity": "medium",
                "supporting_data": "Direct customer feedback from call examples"
            })

        response = {
            "status": "success",
            "analysis_type": "enhanced_call_examples",
            "parameters": {
                "topic": args.topic,
                "search_method": search_method,
                "similarity_threshold": args.similarity_threshold if search_method == "embedding_semantic" else "N/A",
                "limit": args.limit,
                "sentiment_filter": args.sentiment,
                "vehicle_filter": args.vehicle
            },
            "examples": result,
            "insights": {
                "summary": {
                    "total_examples": total_examples,
                    "negative_examples": negative_examples,
                    "churn_risk_examples": churn_risk_examples,
                    "hardware_crisis_examples": hardware_crisis_examples
                },
                "insights": insights,
                "recommendations": recommendations
            }
        }
        print(json.dumps(response, indent=2))
    else:
        # Simple examples output
        print(json.dumps(result, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)
