---
name: call_examples
display_name: Enhanced BlueCruise Call Examples Intelligence
description: Production-grade embedding-enhanced semantic search for real customer voices with multi-dimensional business context, root cause correlation, and actionable insights across all BlueCruise data sources.
signals:
  - show me real call examples
  - what are customers actually saying
  - customer verbatim examples
  - real customer voices
  - actual call examples
  - customer story examples
  - sample customer calls
  - example customer feedback
  - customer complaint examples
  - what customers are experiencing
  - real customer issues
  - customer testimonial examples
  - actual customer complaints
  - sample negative calls
  - example churn calls
  - customer voice analysis
  - real call transcripts
requires:
  - a topic or keyword to find examples for
capabilities:
  - Embedding-enhanced semantic search using Qwen/Qwen3-Embedding-0.6B model
  - Multi-table call context (base_view + topics + subscriptions + parts + pain_points + embeddings)
  - Rich customer voice examples with business context and root cause correlation
  - Data-driven call classification with BlueCruise-specific business priorities
  - Real customer quotes with hardware issues, churn risk, and sentiment analysis
  - AI-powered insights from actual customer examples and recommendations
not_good_for: Counts and statistics (use keyword_search or top_issues), sentiment scores (use sentiment_trend), volume over time (use call_volume)
---

# Enhanced BlueCruise Call Examples Intelligence

## What this does
Performs embedding-enhanced semantic search for real customer voices across all BlueCruise data sources with multi-dimensional business context, root cause correlation, and actionable insights from actual call examples.

## Production Features
- **Embedding-enhanced semantic search**: Uses Qwen/Qwen3-Embedding-0.6B model for finding semantically similar customer examples
- **Multi-table call context**: Combines base_view, topics, subscriptions, parts, pain_points, and embeddings tables
- **Rich customer examples**: Real call summaries + customer feedback + hardware issues + subscription context
- **Data-driven classification**: EXAMPLE_CHURN_RISK, EXAMPLE_HARDWARE_CRISIS classifications using business logic
- **Customer voice analysis**: Direct customer quotes with sentiment and business impact assessment
- **AI insights**: Automated analysis of customer example patterns and actionable recommendations

## How to run it

```bash
python .claude/skills/call_examples/scripts/call_examples.py --topic "topic_or_keyword"
```

## Enhanced Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--topic` | Yes | — | Topic or keyword to find customer examples for |
| `--from` | No | all time | Start date in YYYY-MM-DD format |
| `--to` | No | all time | End date in YYYY-MM-DD format |
| `--vehicle` | No | all | Filter to a specific vehicle (partial match) |
| `--year` | No | all | Filter to a specific model year |
| `--limit` | No | 20 | Number of call examples to return |
| `--sentiment` | No | all | Filter by: `positive`, `neutral`, or `negative` |
| `--similarity-threshold` | No | 0.4 | Minimum similarity score for semantic matching (0.0-1.0) |
| `--include-insights` | No | false | Include AI-powered insights and business context analysis |

## Example Usage

```bash
# Real customer examples of steering problems with business insights
python call_examples.py --topic "steering issues" --include-insights

# Negative customer voices about subscription problems
python call_examples.py --topic "subscription problems" --sentiment negative --limit 5 --include-insights

# F-150 customer examples about BlueCruise failures
python call_examples.py --topic "BlueCruise not working" --vehicle "F-150" --include-insights

# Recent customer complaints with high semantic similarity
python call_examples.py --topic "customer complaints" --similarity-threshold 0.6 --from 2025-01-01

# Churn risk customer examples
python call_examples.py --topic "cancel subscription" --sentiment negative --include-insights
```

## Enhanced Output Format

```json
{
  "status": "success",
  "analysis_type": "enhanced_call_examples",
  "parameters": {
    "topic": "steering issues",
    "search_method": "embedding_semantic",
    "similarity_threshold": 0.4,
    "limit": 10,
    "sentiment_filter": "negative"
  },
  "examples": [
    {
      "call_id": "ABC123",
      "call_date": "2025-03-15",
      "modelvehicleline": "F-150",
      "modelyear": "2024",
      "sentiment_label": "Negative",
      "sentiment": 0.21,
      "intent_category": "Technical Support",
      "call_summary": "Customer reports BlueCruise steering sensor keeps failing after software update, causing unsafe disengagement on highway",
      "subscription_category": "Deactivations",
      "hardware_issue": "steering sensor calibration failure causing BlueCruise disengagement",
      "pain_point": "Steering Issues",
      "customer_voice": "This stupid steering thing won't stay engaged, I'm paying monthly for nothing and it's dangerous",
      "call_reason": "BlueCruise malfunction - steering behavior",
      "primary_topic": "Hardware & Technology",
      "example_classification": "EXAMPLE_CHURN_RISK"
    }
  ],
  "insights": {
    "summary": {
      "total_examples": 10,
      "negative_examples": 8,
      "churn_risk_examples": 3,
      "hardware_crisis_examples": 5
    },
    "insights": [
      {
        "type": "alert",
        "message": "High negative sentiment in examples: 8/10 examples are negative",
        "severity": "high",
        "supporting_data": "Topic 'steering issues' shows concerning customer sentiment patterns"
      },
      {
        "type": "warning", 
        "message": "Churn risk detected: 3 examples show subscription cancellation risk",
        "severity": "high",
        "supporting_data": "Revenue impact from 'steering issues' issues"
      }
    ],
    "recommendations": [
      {
        "action": "Engineering review required for 'steering issues' - 5 hardware crisis examples found",
        "priority": "urgent",
        "estimated_impact": "Address customer-reported hardware failures"
      }
    ]
  }
}
```

## Business Classifications

### Call Example Types
- **EXAMPLE_CHURN_RISK**: Deactivation calls with negative sentiment (revenue loss)
- **EXAMPLE_HARDWARE_CRISIS**: Hardware issues with negative sentiment (engineering priority)
- **EXAMPLE_CRITICAL_ISSUE**: Extremely negative sentiment calls (urgent response needed)
- **EXAMPLE_SUBSCRIPTION_FOCUSED**: Subscription-related customer examples
- **EXAMPLE_HARDWARE_FOCUSED**: Hardware-related customer examples
- **EXAMPLE_GENERAL**: Standard operational examples

### Business Intelligence
- **Real Customer Voices**: Direct quotes from actual customer calls with business context
- **Root Cause Correlation**: Links customer examples to specific hardware issues, subscription problems
- **Sentiment Context**: Customer emotion analysis with business impact assessment
- **Churn Risk Analysis**: Identifies customers at risk of subscription cancellation
- **Hardware Impact Assessment**: Customer-reported hardware failures with specific vehicle models

## Technical Features

### Embedding Model Integration
- **Model**: Qwen/Qwen3-Embedding-0.6B (same as call_summary_embeddings generation)
- **Similarity Method**: Cosine similarity via Databricks vector search
- **Fallback**: Multi-field LIKE search if embeddings unavailable
- **Threshold**: Configurable similarity threshold (default 0.4)

### Multi-Field Search Coverage
- **call_summary_embeddings**: Primary semantic search for call content
- **topics.reason**: Detailed call reasons and issues
- **pain_points.customer_feedback**: Direct customer voice and complaints
- **parts_unfiltered.parts_concern**: Hardware-specific customer reports

## Business Value
Enhanced call_examples provides critical customer intelligence for:
- **Customer Voice Analysis**: Understand what customers are actually saying about issues
- **Product Development**: Real customer feedback to guide feature improvements
- **Engineering Priorities**: Customer-reported hardware failures with specific examples
- **Customer Experience**: Identify pain points through actual customer words
- **Executive Reporting**: Real customer stories for business decision-making

## Error Handling
Enhanced error handling with embedding model fallbacks, detailed error classification, and comprehensive logging for production monitoring.
