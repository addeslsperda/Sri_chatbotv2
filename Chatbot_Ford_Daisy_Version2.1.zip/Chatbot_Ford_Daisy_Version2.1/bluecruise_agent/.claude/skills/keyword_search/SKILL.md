---
name: keyword_search
display_name: Enhanced BlueCruise Keyword Intelligence
description: Production-grade embedding-enhanced semantic keyword search with multi-dimensional business intelligence, root cause analysis, and data-driven classification across all BlueCruise data sources.
signals:
  - semantic keyword search
  - keyword-related issues analysis
  - embedding-based keyword matching
  - keyword sentiment analysis
  - keyword root cause analysis
  - keyword crisis detection
  - hardware issues related to keyword
  - subscription problems with keyword
  - keyword business impact analysis
  - vehicle-specific keyword problems
  - calls about specific topics
  - semantic similarity search
  - keyword trend analysis
  - keyword business intelligence
requires:
  - a keyword or phrase to search for
capabilities:
  - Embedding-enhanced semantic search using Qwen/Qwen3-Embedding-0.6B model
  - Multi-table keyword intelligence (base_view + topics + subscriptions + parts + pain_points + embeddings)
  - Root cause correlation for keyword-related issues (sentiment, hardware, churn analysis)
  - Data-driven keyword classification with BlueCruise-specific thresholds
  - Business impact assessment and actionable recommendations
  - Vehicle-specific keyword problem analysis
not_good_for: Top issues by category (use top_issues), sentiment trends (use sentiment_trend), vehicle comparisons (use vehicle_breakdown)
---

# Enhanced BlueCruise Keyword Intelligence

## What this does
Performs embedding-enhanced semantic keyword search across all BlueCruise data sources with multi-dimensional business intelligence, root cause analysis, and data-driven classification.

## Production Features
- **Embedding-enhanced semantic search**: Uses Qwen/Qwen3-Embedding-0.6B model for semantic similarity matching
- **Multi-table keyword intelligence**: Combines base_view, topics, subscriptions, parts, pain_points, and embeddings tables
- **Root cause correlation**: Identifies sentiment patterns, hardware issues, and churn events related to keywords
- **Data-driven classification**: KEYWORD_CRISIS, KEYWORD_HARDWARE_DRIVEN classifications using BlueCruise thresholds
- **Business impact assessment**: Keyword priority scoring based on sentiment, hardware, and churn correlation
- **AI insights**: Automated recommendations for addressing keyword-related root causes

## How to run it

```bash
python .claude/skills/keyword_search/scripts/keyword_search.py --keyword "keyword_or_phrase"
```

## Enhanced Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--keyword` | Yes | — | Word or phrase to search semantically |
| `--from` | No | all time | Start date in YYYY-MM-DD format |
| `--to` | No | all time | End date in YYYY-MM-DD format |
| `--vehicle` | No | all | Filter to a specific vehicle (partial match) |
| `--similarity-threshold` | No | 0.4 | Minimum similarity score for semantic matching (0.0-1.0) |
| `--include-insights` | No | false | Include AI-powered keyword insights and root cause analysis |
| `--by-vehicle` | No | false | Include breakdown by vehicle model |

## Example Usage

```bash
# Semantic search for steering-related issues with business insights
python keyword_search.py --keyword "steering problems" --include-insights

# Subscription billing issues with vehicle breakdown
python keyword_search.py --keyword "billing confusion" --include-insights --by-vehicle

# BlueCruise failure analysis for specific time period
python keyword_search.py --keyword "BlueCruise not working" --from 2025-01-01 --to 2025-12-31 --include-insights

# High-sensitivity semantic search for hardware issues
python keyword_search.py --keyword "sensor calibration" --similarity-threshold 0.6 --include-insights

# Vehicle-specific keyword analysis
python keyword_search.py --keyword "hands-free driving" --vehicle "F-150" --include-insights
```

## Enhanced Output Format

```json
{
  "status": "success",
  "analysis_type": "enhanced_keyword_search",
  "parameters": {
    "keyword": "steering problems",
    "search_method": "embedding_semantic",
    "similarity_threshold": 0.4,
    "date_from": "2025-01-01",
    "date_to": "2025-12-31"
  },
  "data": {
    "total_keyword_matches": 1247,
    "negative_keyword_calls": 892,
    "keyword_negative_pct": 71.5,
    "positive_keyword_calls": 156,
    "keyword_positive_pct": 12.5,
    "keyword_hardware_related": 834,
    "keyword_hardware_pct": 66.9,
    "keyword_churn_calls": 89,
    "keyword_churn_pct": 7.1,
    "sample_negative_context": "Customer experiencing steering sensor calibration failure causing BlueCruise to disengage unexpectedly",
    "sample_hardware_issue": "steering sensor calibration failure",
    "sample_churn_reason": "BlueCruise stopped working, customer wants to cancel subscription",
    "primary_topic_area": "Hardware & Technology",
    "sample_pain_point": "Steering Issues",
    "sample_customer_voice": "Steering feels loose when BlueCruise is active",
    "vehicles_affected": 15,
    "sample_affected_vehicle": "F-150",
    "hardware_problem_vehicle": "F-150",
    "avg_similarity_score": 0.73,
    "max_similarity_score": 0.95,
    "keyword_classification": "KEYWORD_HARDWARE_DRIVEN",
    "keyword_priority_score": 145.2
  },
  "insights": {
    "summary": {
      "total_matches": 1247,
      "negative_sentiment_pct": 71.5,
      "hardware_correlation_pct": 66.9,
      "avg_similarity_score": 0.73
    },
    "insights": [
      {
        "type": "alert",
        "message": "Keyword crisis: 'steering problems' shows 71.5% negative sentiment",
        "severity": "high",
        "supporting_data": "Hardware correlation: 66.9%, Churn: 7.1%"
      }
    ],
    "recommendations": [
      {
        "action": "Engineering review for keyword 'steering problems' - high hardware correlation",
        "priority": "high",
        "estimated_impact": "Address: steering sensor calibration failure"
      }
    ]
  }
}
```

## Business Classifications

### Keyword Issue Types
- **KEYWORD_CRISIS**: High negative sentiment (>70%) + significant churn correlation (>15%)
- **KEYWORD_HARDWARE_DRIVEN**: Above 75th percentile hardware correlation (data-driven threshold)
- **KEYWORD_SENTIMENT_RISK**: 1.5x above average negative sentiment for BlueCruise
- **KEYWORD_TRENDING_NEGATIVE**: High volume (>100 calls) + high negative sentiment (>60%)
- **KEYWORD_NORMAL**: Standard operational performance

### Business Intelligence
- **Semantic Search**: Uses same Qwen/Qwen3-Embedding-0.6B model as call_summary_embeddings for accurate matching
- **Root Cause Correlation**: Links keywords to specific hardware issues, churn events, or topic areas
- **Sentiment Analysis**: Keyword-specific sentiment patterns and negative sentiment drivers
- **Hardware Impact Assessment**: Identifies vehicle models and components related to keyword issues
- **Churn Correlation**: Tracks keywords that correlate with subscription cancellations

## Technical Features

### Embedding Model Integration
- **Model**: Qwen/Qwen3-Embedding-0.6B (same as call_summary_embeddings generation)
- **Similarity Method**: Cosine similarity calculation in SQL
- **Fallback**: Multi-field LIKE search if embeddings unavailable
- **Threshold**: Configurable similarity threshold (default 0.4)

### Multi-Field Search Coverage
- **call_summary_embeddings**: Primary semantic search
- **topics.reason**: Detailed call reasons
- **pain_points.customer_feedback**: Direct customer voice
- **parts_unfiltered.parts_concern**: Hardware-specific mentions

## Business Value
Enhanced keyword_search provides critical business intelligence for:
- **Issue Detection**: Early identification of emerging problems through semantic analysis
- **Root Cause Analysis**: Understand what drives keyword-related customer issues
- **Engineering Priorities**: Focus hardware reliability efforts on keyword-correlated problems
- **Customer Experience**: Identify and address keyword-related pain points
- **Process Optimization**: Improve customer service based on keyword sentiment patterns

## Error Handling
Enhanced error handling with embedding model fallbacks, detailed error classification, and comprehensive logging for production monitoring.
