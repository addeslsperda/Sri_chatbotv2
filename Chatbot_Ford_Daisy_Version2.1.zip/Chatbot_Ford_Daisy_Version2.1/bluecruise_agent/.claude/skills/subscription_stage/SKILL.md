---
name: subscription_stage
display_name: Enhanced BlueCruise Subscription Lifecycle Intelligence
description: Production-grade multi-dimensional subscription lifecycle analysis with stage-specific intelligence, funnel optimization insights, and data-driven business classification across the complete BlueCruise subscription journey.
signals:
  - subscription lifecycle analysis
  - subscription funnel optimization
  - stage-specific customer issues
  - trial conversion barriers
  - subscription churn stages
  - lifecycle stage health
  - subscription journey problems
  - stage conversion rates
  - subscription ecosystem health
  - lifecycle stage comparison
  - subscription stage crisis detection
  - funnel drop-off analysis
  - stage-specific business intelligence
requires: []
capabilities:
  - Multi-table subscription lifecycle analysis (base_view + subscriptions + topics + parts + pain_points)
  - Stage-specific issue correlation with hardware, sentiment, and business impact analysis
  - Subscription funnel flow analysis with conversion barrier identification
  - Data-driven stage health classification with BlueCruise-specific business priorities
  - Lifecycle stage comparison and optimization recommendations
  - AI-powered insights for subscription journey optimization and churn prevention
not_good_for: Subscription category volumes over time (use subscription_issues), general call sentiment (use sentiment_trend), vehicle-specific analysis (use vehicle_topics)
---

# Enhanced BlueCruise Subscription Lifecycle Intelligence

## What this does
Performs comprehensive multi-dimensional subscription lifecycle analysis across all BlueCruise data sources with stage-specific intelligence, funnel optimization insights, and data-driven business classification.

## Production Features
- **Multi-table lifecycle analysis**: Combines base_view, subscriptions, topics, parts, and pain_points tables
- **Stage-specific intelligence**: Analyzes customer issues, sentiment, and hardware correlation at each subscription lifecycle stage
- **Subscription funnel analysis**: Identifies conversion barriers and drop-off points in the customer journey
- **Data-driven classification**: STAGE_CHURN_CRISIS, STAGE_CONVERSION_BARRIER classifications using BlueCruise thresholds
- **Lifecycle optimization**: Business priority scoring and actionable recommendations for subscription journey improvement
- **AI insights**: Automated subscription ecosystem health assessment and funnel optimization recommendations

## How to run it

```bash
python .claude/skills/subscription_stage/scripts/subscription_stage.py
```

## Enhanced Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--from` | No | all time | Start date in YYYY-MM-DD format |
| `--to` | No | all time | End date in YYYY-MM-DD format |
| `--vehicle` | No | all | Filter to a specific vehicle (partial match) |
| `--year` | No | all years | Filter to a specific model year |
| `--category` | No | all | Filter by subscription category |
| `--stage-analysis` | No | lifecycle | Analysis type: lifecycle, funnel, health |
| `--compare-stages` | No | false | Compare performance across subscription stages |
| `--limit` | No | 20 | Number of stages to return |
| `--include-insights` | No | false | Include AI-powered subscription lifecycle insights and business context |

## Example Usage

```bash
# Complete subscription lifecycle analysis with business insights
python subscription_stage.py --include-insights

# Subscription funnel optimization analysis
python subscription_stage.py --stage-analysis funnel --compare-stages --include-insights

# Vehicle-specific subscription lifecycle (F-SERIES)
python subscription_stage.py --vehicle "F-SERIES" --include-insights

# Trial stage conversion barrier analysis
python subscription_stage.py --category "trial" --stage-analysis lifecycle --include-insights

# Subscription ecosystem health assessment
python subscription_stage.py --stage-analysis health --compare-stages --include-insights
```

## Enhanced Output Format

```json
{
  "status": "success",
  "analysis_type": "enhanced_subscription_stage",
  "parameters": {
    "stage_analysis": "lifecycle",
    "compare_stages": true,
    "vehicle_filter": null,
    "category_filter": null
  },
  "data": [
    {
      "lifecycle_stage": "Trials",
      "stage_call_count": 12179,
      "pct_of_ecosystem": 40.1,
      "negative_stage_calls": 7800,
      "stage_negative_pct": 64.0,
      "positive_stage_calls": 2449,
      "stage_positive_pct": 20.1,
      "avg_stage_sentiment_score": -0.234,
      "stage_hardware_calls": 1908,
      "stage_hardware_pct": 15.7,
      "subscription_mgmt_calls": 7665,
      "subscription_mgmt_pct": 62.9,
      "feature_performance_calls": 3456,
      "feature_performance_pct": 28.4,
      "pricing_value_calls": 2134,
      "pricing_value_pct": 17.5,
      "sample_stage_negative_reason": "BlueCruise trial activation failed despite eligible vehicle",
      "sample_stage_hardware_issue": "steering sensor calibration required for BlueCruise trial",
      "primary_stage_topic": "Subscription Management & Clarity",
      "sample_stage_pain_point": "Trial Activation Issues",
      "sample_stage_customer_voice": "Cannot activate free trial, system says not eligible",
      "vehicles_in_stage": 23,
      "sample_stage_vehicle": "F-SERIES",
      "stage_health_classification": "STAGE_CONVERSION_BARRIER",
      "stage_priority_score": 142.3,
      "avg_stage_negative_pct": 54.2,
      "ecosystem_avg_negative_pct": 51.8,
      "total_ecosystem_calls": 30387
    },
    {
      "lifecycle_stage": "Deactivations",
      "stage_call_count": 2966,
      "pct_of_ecosystem": 9.8,
      "stage_negative_pct": 78.2,
      "stage_health_classification": "STAGE_CHURN_CRISIS",
      "stage_priority_score": 189.7
    }
  ],
  "insights": {
    "summary": {
      "total_calls_analyzed": 30387,
      "stages_analyzed": 8,
      "crisis_stages": 1,
      "conversion_barriers": 1,
      "healthy_stages": 2
    },
    "insights": [
      {
        "type": "info",
        "message": "Subscription ecosystem analysis: 8 stages analyzed across 30387 calls",
        "severity": "low",
        "supporting_data": "Stage distribution and health assessment completed"
      },
      {
        "type": "alert",
        "message": "Subscription stage crisis: 1 stages need urgent attention",
        "severity": "high",
        "supporting_data": "Crisis stages: Deactivations"
      }
    ],
    "recommendations": [
      {
        "action": "Urgent review for Deactivations stage - 78.2% negative sentiment",
        "priority": "urgent",
        "estimated_impact": "Address revenue-critical subscription stage issues"
      },
      {
        "action": "Optimization needed for trial conversion - 1 barrier stages identified",
        "priority": "high",
        "estimated_impact": "Improve subscription funnel conversion rates"
      }
    ]
  }
}
```

## Business Classifications

### Subscription Lifecycle Stage Types
- **STAGE_CHURN_CRISIS**: Deactivation stages with high negative sentiment (urgent revenue protection)
- **STAGE_CONVERSION_BARRIER**: Trial stages with above-average negative sentiment (funnel optimization)
- **STAGE_HARDWARE_FRICTION**: Stages with high hardware correlation (engineering priority)
- **STAGE_PROCESS_ISSUE**: High subscription management issues (process improvement)
- **STAGE_HEALTHY**: Below-average negative sentiment (best practice extraction)
- **STAGE_NORMAL**: Standard operational performance

### Business Intelligence
- **Lifecycle Flow Analysis**: Customer journey optimization from trial through renewal/churn
- **Stage-Specific Intelligence**: Issues, sentiment, and hardware correlation unique to each lifecycle stage
- **Funnel Optimization**: Conversion barrier identification and drop-off point analysis
- **Ecosystem Health**: Overall subscription lifecycle performance assessment
- **Business Priority Scoring**: Data-driven prioritization based on revenue impact and stage criticality

## Key Use Cases

### Subscription Funnel Optimization
- **"Where do we lose customers in the subscription journey?"** -> Stage-specific drop-off analysis
- **"What's blocking trial conversions?"** -> Trial stage barrier identification with root causes
- **"How can we improve subscription renewals?"** -> Renewal stage optimization recommendations

### Stage-Specific Intelligence
- **"What issues do trial customers face?"** -> Trial-specific problem analysis with customer voices
- **"Why do active subscribers call support?"** -> Active stage issue correlation and patterns
- **"What drives subscription cancellations?"** -> Deactivation stage root cause analysis

### Business Impact Assessment
- **"Which subscription stages are most problematic?"** -> Health classification and priority scoring
- **"What's the ROI of fixing trial issues?"** -> Revenue impact analysis of stage improvements
- **"How healthy is our subscription ecosystem?"** -> Overall lifecycle performance assessment

## Business Value
Enhanced subscription_stage provides critical business intelligence for:
- **Subscription Growth**: Optimize conversion funnel for increased subscriber acquisition
- **Churn Prevention**: Identify and address stage-specific issues causing cancellations
- **Customer Experience**: Improve subscription journey through stage-specific issue resolution
- **Revenue Protection**: Prioritize stages with highest business impact for resource allocation
- **Process Optimization**: Streamline subscription operations based on stage-specific insights

## Technical Features

### Data-Driven Approach
- **No hardcoded thresholds**: Uses PERCENTILE functions and standard deviations from actual BlueCruise data
- **Verified subscription categories**: Based on actual data values, not assumptions
- **Dynamic topic analysis**: Flexible pattern matching for emerging subscription topics
- **Business-driven classifications**: Priority scoring aligned with subscription business metrics

### Multi-Dimensional Analysis
- **Stage-specific metrics**: Sentiment, hardware, and topic correlation unique to each lifecycle stage
- **Ecosystem perspective**: Stage performance relative to overall subscription health
- **Business context**: Revenue impact and priority scoring for strategic decision-making

## Error Handling
Enhanced error handling with detailed error classification, graceful degradation, and comprehensive logging for production monitoring.
