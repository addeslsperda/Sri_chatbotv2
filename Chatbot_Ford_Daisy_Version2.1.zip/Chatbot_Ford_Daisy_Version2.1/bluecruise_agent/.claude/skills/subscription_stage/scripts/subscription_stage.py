"""
Enhanced BlueCruise Subscription Lifecycle Stage Analysis - PRODUCTION VERSION

Multi-dimensional subscription stage intelligence with lifecycle flow analysis, stage-specific issue correlation,
and data-driven business classification across all BlueCruise subscription touchpoints.

Usage:
    python subscription_stage.py --include-insights
    python subscription_stage.py --vehicle "F-SERIES" --stage-analysis lifecycle --include-insights
    python subscription_stage.py --compare-stages --include-insights
"""
import argparse
import json
import os
import sys
from pathlib import Path
from databricks import sql
import requests
from dotenv import load_dotenv
from decimal import Decimal

load_dotenv(Path(__file__).resolve().parents[4] / ".env", override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


CATALOG = os.environ.get("BLUECRUISE_CATALOG", "text_analytics_dev")
SCHEMA = os.environ.get("BLUECRUISE_SCHEMA", "ford_bluecruise")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--from", dest="date_from", default=None)
    parser.add_argument("--to", dest="date_to", default=None)
    parser.add_argument("--vehicle", dest="vehicle", default=None)
    parser.add_argument("--year", dest="year", default=None)
    parser.add_argument("--category", dest="category", default=None,
                        help="Filter by subscription category")
    parser.add_argument("--stage-analysis", dest="stage_analysis",
                        choices=["lifecycle", "funnel", "health"], default="lifecycle",
                        help="Type of stage analysis to perform")
    parser.add_argument("--compare-stages", action="store_true",
                        help="Compare performance across subscription stages")
    parser.add_argument("--limit", type=int, default=20)
    parser.add_argument("--include-insights", action="store_true",
                        help="Include AI-powered subscription stage insights and business context")
    args, _ = parser.parse_known_args()

    # Build dynamic filters
    params = {"date_from": args.date_from or "2020-01-01", "date_to": args.date_to or "2030-12-31"}
    filters = [
        "bv.call_date >= :date_from",
        "bv.call_date <= :date_to",
        "s.subscription_category IS NOT NULL"
    ]

    if args.vehicle:
        params["vehicle"] = f"%{args.vehicle}%"
        filters.append("LOWER(bv.modelvehicleline) LIKE LOWER(:vehicle)")
    if args.year:
        params["year"] = args.year
        filters.append("bv.modelyear = :year")
    if args.category:
        params["category"] = f"%{args.category}%"
        filters.append("LOWER(s.subscription_category) LIKE LOWER(:category)")

    where_clause = " AND ".join(filters)

    # ZERO ASSUMPTIONS - Pure data-driven discovery query
    query = f"""
        WITH subscription_lifecycle_intelligence AS (
            SELECT
                bv.call_date,
                bv.call_id,
                bv.sentiment_label,
                bv.sentiment,
                bv.modelvehicleline,
                bv.modelyear,
                bv.intent_category,

                -- Subscription stage data (actual values only)
                s.subscription_category AS lifecycle_stage,

                -- Multi-table context for stage analysis
                pu.parts_concern,
                pu.parts_features,
                pp.pain_point,
                pp.customer_feedback,
                t.reason,
                t.topic_level_1,
                t.topic_level_2

            FROM {CATALOG}.{SCHEMA}.base_view bv
            LEFT JOIN {CATALOG}.{SCHEMA}.subscriptions s ON bv.call_id = s.call_id
            LEFT JOIN text_analytics.nlp_analytics.parts_unfiltered pu ON bv.call_id = pu.call_id
                AND (pu.parts_features LIKE '%BlueCruise%' OR pu.parts_concern LIKE '%BlueCruise%')
            LEFT JOIN text_analytics.restensl.v_pain_points2 pp ON bv.call_id = pp.call_id
            LEFT JOIN {CATALOG}.{SCHEMA}.topics t ON bv.call_id = t.call_id
            WHERE {where_clause}
        ),
        subscription_stage_analytics AS (
            SELECT
                lifecycle_stage,

                -- Basic stage metrics (pure data)
                COUNT(*) AS stage_call_count,
                COUNT(CASE WHEN sentiment_label = 'Negative' THEN 1 END) AS negative_stage_calls,
                ROUND(COUNT(CASE WHEN sentiment_label = 'Negative' THEN 1 END) * 100.0 / COUNT(*), 1) AS stage_negative_pct,
                COUNT(CASE WHEN sentiment_label = 'Positive' THEN 1 END) AS positive_stage_calls,
                ROUND(COUNT(CASE WHEN sentiment_label = 'Positive' THEN 1 END) * 100.0 / COUNT(*), 1) AS stage_positive_pct,
                ROUND(AVG(sentiment), 4) AS avg_stage_sentiment_score,

                -- Hardware correlation (data-driven)
                COUNT(CASE WHEN parts_concern IS NOT NULL THEN 1 END) AS stage_hardware_calls,
                ROUND(COUNT(CASE WHEN parts_concern IS NOT NULL THEN 1 END) * 100.0 / COUNT(*), 1) AS stage_hardware_pct,

                -- ZERO HARDCODED PATTERNS - Use actual topic values only
                MAX(topic_level_1) AS most_common_stage_topic,
                COUNT(DISTINCT topic_level_1) AS unique_topics_in_stage,

                -- Actual data samples (no assumptions)
                MAX(CASE WHEN sentiment_label = 'Negative' THEN reason END) AS sample_stage_negative_reason,
                MAX(CASE WHEN parts_concern IS NOT NULL THEN parts_concern END) AS sample_stage_hardware_issue,
                MAX(pain_point) AS sample_stage_pain_point,
                MAX(customer_feedback) AS sample_stage_customer_voice,

                -- Vehicle diversity per stage (actual data)
                COUNT(DISTINCT modelvehicleline) AS vehicles_in_stage,
                MAX(modelvehicleline) AS sample_stage_vehicle

            FROM subscription_lifecycle_intelligence
            GROUP BY lifecycle_stage
            HAVING COUNT(*) >= 5  -- Only stages with meaningful volume
        ),
        -- PURE DATA-DRIVEN BENCHMARKS (no hardcoded multipliers)
        stage_health_benchmarks AS (
            SELECT
                AVG(stage_negative_pct) AS avg_stage_negative_pct,
                AVG(stage_hardware_pct) AS avg_stage_hardware_pct,
                STDDEV(stage_negative_pct) AS stage_negative_stddev,
                STDDEV(stage_hardware_pct) AS stage_hardware_stddev,
                PERCENTILE(stage_negative_pct, 0.50) AS median_negative_pct,
                PERCENTILE(stage_negative_pct, 0.75) AS q3_negative_threshold,
                PERCENTILE(stage_negative_pct, 0.85) AS high_negative_threshold,
                PERCENTILE(stage_hardware_pct, 0.75) AS q3_hardware_threshold,
                PERCENTILE(stage_hardware_pct, 0.85) AS high_hardware_threshold
            FROM subscription_stage_analytics
        ),
        subscription_ecosystem_metrics AS (
            SELECT
                SUM(stage_call_count) AS total_ecosystem_calls,
                AVG(stage_negative_pct) AS ecosystem_avg_negative_pct,
                AVG(stage_hardware_pct) AS ecosystem_avg_hardware_pct,
                MAX(stage_call_count) AS max_stage_volume,
                COUNT(*) AS total_stages
            FROM subscription_stage_analytics
        ),
        subscription_stage_final AS (
            SELECT
                ssa.*,
                shb.avg_stage_negative_pct,
                shb.stage_negative_stddev,
                shb.q3_negative_threshold,
                shb.high_negative_threshold,
                shb.q3_hardware_threshold,
                shb.high_hardware_threshold,
                sem.total_ecosystem_calls,
                sem.ecosystem_avg_negative_pct,
                sem.max_stage_volume,

                -- Percentage of total subscription ecosystem
                ROUND(ssa.stage_call_count * 100.0 / sem.total_ecosystem_calls, 1) AS pct_of_ecosystem,

                -- PURE DATA-DRIVEN CLASSIFICATION (no hardcoded logic)
                CASE
                    WHEN ssa.stage_negative_pct > shb.high_negative_threshold
                    THEN 'STAGE_HIGH_NEGATIVE'
                    WHEN ssa.stage_negative_pct > shb.q3_negative_threshold
                    THEN 'STAGE_ELEVATED_NEGATIVE'
                    WHEN ssa.stage_hardware_pct > shb.high_hardware_threshold
                    THEN 'STAGE_HIGH_HARDWARE'
                    WHEN ssa.stage_hardware_pct > shb.q3_hardware_threshold
                    THEN 'STAGE_ELEVATED_HARDWARE'
                    WHEN ssa.stage_negative_pct < (shb.avg_stage_negative_pct - shb.stage_negative_stddev)
                    THEN 'STAGE_LOW_NEGATIVE'
                    ELSE 'STAGE_BASELINE'
                END AS stage_health_classification,

                -- PURE DATA-DRIVEN PRIORITY SCORE (no hardcoded weights)
                ROUND((
                    -- Negative sentiment relative to ecosystem average
                    (ssa.stage_negative_pct / NULLIF(shb.avg_stage_negative_pct, 0)) * 100 +
                    -- Volume relative to ecosystem total
                    (ssa.stage_call_count / NULLIF(sem.total_ecosystem_calls, 0)) * 100 +
                    -- Hardware correlation relative to ecosystem average
                    (ssa.stage_hardware_pct / NULLIF(sem.ecosystem_avg_hardware_pct, 0)) * 100
                ) / 3, 1) AS stage_priority_score

            FROM subscription_stage_analytics ssa, stage_health_benchmarks shb, subscription_ecosystem_metrics sem
        )
        SELECT
            lifecycle_stage,
            stage_call_count,
            pct_of_ecosystem,
            negative_stage_calls,
            stage_negative_pct,
            positive_stage_calls,
            stage_positive_pct,
            avg_stage_sentiment_score,
            stage_hardware_calls,
            stage_hardware_pct,

            -- Pure data discovery (no assumptions)
            most_common_stage_topic,
            unique_topics_in_stage,

            -- Stage context samples
            sample_stage_negative_reason,
            sample_stage_hardware_issue,
            sample_stage_pain_point,
            sample_stage_customer_voice,

            -- Vehicle intelligence
            vehicles_in_stage,
            sample_stage_vehicle,

            -- Data-driven business intelligence
            stage_health_classification,
            stage_priority_score,

            -- Ecosystem benchmarks (transparency)
            avg_stage_negative_pct,
            ecosystem_avg_negative_pct,
            total_ecosystem_calls

        FROM subscription_stage_final
        ORDER BY stage_priority_score DESC, stage_call_count DESC
        LIMIT {args.limit}
    """

    with get_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(query, params)
            rows = cursor.fetchall()
            columns = [d[0] for d in cursor.description]

    # JSON serialization with Decimal handling
    def serialize_value(value):
        if isinstance(value, Decimal):
            return float(value)
        elif hasattr(value, "isoformat"):
            return str(value)
        elif value is None:
            return None
        else:
            return value

    result = []
    for row in rows:
        row_dict = {}
        for i, value in enumerate(row):
            row_dict[columns[i]] = serialize_value(value)
        result.append(row_dict)

    if args.include_insights and result:
        # Generate stage-specific insights
        total_calls = sum(r.get('stage_call_count', 0) for r in result)
        crisis_stages = [r for r in result if r.get('stage_health_classification') == 'STAGE_CHURN_CRISIS']
        conversion_barriers = [r for r in result if r.get('stage_health_classification') == 'STAGE_CONVERSION_BARRIER']
        healthy_stages = [r for r in result if r.get('stage_health_classification') == 'STAGE_HEALTHY']

        insights = []
        recommendations = []

        # Stage ecosystem overview
        insights.append({
            "type": "info",
            "message": f"Subscription ecosystem analysis: {len(result)} stages analyzed across {total_calls} calls",
            "severity": "low",
            "supporting_data": f"Stage distribution and health assessment completed"
        })

        # Crisis stage detection
        if crisis_stages:
            crisis_names = [r['lifecycle_stage'] for r in crisis_stages]
            insights.append({
                "type": "alert",
                "message": f"Subscription stage crisis: {len(crisis_stages)} stages need urgent attention",
                "severity": "high",
                "supporting_data": f"Crisis stages: {', '.join(crisis_names)}"
            })

            for stage in crisis_stages:
                recommendations.append({
                    "action": f"Urgent review for {stage['lifecycle_stage']} stage - {stage['stage_negative_pct']}% negative sentiment",
                    "priority": "urgent",
                    "estimated_impact": f"Address revenue-critical subscription stage issues"
                })

        # Conversion barrier detection
        if conversion_barriers:
            recommendations.append({
                "action": f"Optimization needed for trial conversion - {len(conversion_barriers)} barrier stages identified",
                "priority": "high",
                "estimated_impact": "Improve subscription funnel conversion rates"
            })

        # Healthy stage recognition
        if healthy_stages:
            insights.append({
                "type": "info",
                "message": f"Healthy stages identified: {len(healthy_stages)} stages performing well",
                "severity": "low",
                "supporting_data": "Best practices can be extracted from healthy stages"
            })

        response = {
            "status": "success",
            "analysis_type": "enhanced_subscription_stage",
            "parameters": {
                "stage_analysis": args.stage_analysis,
                "compare_stages": args.compare_stages,
                "vehicle_filter": args.vehicle,
                "year_filter": args.year,
                "category_filter": args.category
            },
            "data": result,
            "insights": {
                "summary": {
                    "total_calls_analyzed": total_calls,
                    "stages_analyzed": len(result),
                    "crisis_stages": len(crisis_stages),
                    "conversion_barriers": len(conversion_barriers),
                    "healthy_stages": len(healthy_stages)
                },
                "insights": insights,
                "recommendations": recommendations
            }
        }
        print(json.dumps(response, indent=2))
    else:
        # Simple stage output
        print(json.dumps(result, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)
