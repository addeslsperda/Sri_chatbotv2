---
name: vehicle_topics
display_name: Enhanced BlueCruise Vehicle Topics Intelligence
description: Production-grade multi-dimensional vehicle-topic analysis with comparative intelligence, root cause correlation, and data-driven business classification across all BlueCruise data sources.
signals:
  - vehicle topic analysis
  - what are F-150 top issues
  - F-SERIES 2025 call count
  - topics for specific vehicle
  - vehicle comparison analysis
  - hardware issues by vehicle
  - subscription problems by vehicle
  - vehicle-specific topic trends
  - compare vehicle issues
  - business priority by vehicle-topic
  - vehicle topic crisis detection
  - total calls for vehicle model
requires:
  - a vehicle name OR comparison request
capabilities:
  - Multi-table vehicle-topic intelligence (base_view + topics + subscriptions + parts + pain_points)
  - Single vehicle deep-dive analysis with total call counts and topic breakdowns
  - Multi-vehicle comparative analysis across topic patterns and business metrics
  - Root cause correlation for vehicle-topic combinations (sentiment, hardware, churn analysis)
  - Data-driven vehicle-topic classification with BlueCruise-specific business priorities
  - Business impact assessment and actionable recommendations per vehicle model
not_good_for: Sentiment trends over time (use sentiment_trend), aggregate call volume across all vehicles (use vehicle_breakdown), subscription-specific questions (use subscription_issues)
---

# Enhanced BlueCruise Vehicle Topics Intelligence

## What this does
Performs comprehensive multi-dimensional vehicle-topic analysis across all BlueCruise data sources with comparative intelligence, root cause correlation, and data-driven business classification.

## Production Features
- **Multi-table vehicle-topic analysis**: Combines base_view, topics, subscriptions, parts, and pain_points tables
- **Total call counting**: Answers "how many calls for F-SERIES 2025" with complete topic breakdown
- **Comparative analysis**: Compare topic patterns between multiple vehicles (F-150 vs Bronco vs Explorer)
- **Root cause correlation**: Links vehicle-topic combinations to sentiment, hardware issues, and churn events
- **Data-driven classification**: VEHICLE_TOPIC_CRISIS, VEHICLE_HARDWARE_HOTSPOT classifications using business logic
- **Business prioritization**: Priority scoring for vehicle-topic combinations based on business impact

## How to run it

```bash
python .claude/skills/vehicle_topics/scripts/vehicle_topics.py --vehicle "vehicle_name"
```

## Enhanced Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--vehicle` | No* | all | Single vehicle to analyze (e.g., 'F-SERIES', 'F-150') |
| `--compare-vehicles` | No* | none | Comma-separated vehicles to compare (e.g., 'F-SERIES,BRONCO,EXPLORER') |
| `--from` | No | all time | Start date in YYYY-MM-DD format |
| `--to` | No | all time | End date in YYYY-MM-DD format |
| `--year` | No | all years | Filter to a specific model year (e.g., 2025) |
| `--keyword` | No | none | Filter topics containing this keyword |
| `--by` | No | topic_level_1 | Group by: topic_level_1, topic_level_2, reason |
| `--limit` | No | 15 | Number of topics to return per vehicle |
| `--include-insights` | No | false | Include AI-powered vehicle-topic insights and business context |

*Either --vehicle or --compare-vehicles is required

## Example Usage

```bash
# Total F-SERIES 2025 calls with topic breakdown and business insights
python vehicle_topics.py --vehicle "F-SERIES" --year 2025 --include-insights

# Deep-dive F-150 analysis across all years
python vehicle_topics.py --vehicle "F-150" --include-insights

# Compare top issues across major vehicle lines
python vehicle_topics.py --compare-vehicles "F-SERIES,BRONCO,EXPLORER" --include-insights

# Subscription-related topics for Bronco with detailed analysis
python vehicle_topics.py --vehicle "BRONCO" --keyword "subscription" --include-insights

# Hardware issues comparison between vehicles
python vehicle_topics.py --compare-vehicles "F-150,MUSTANG MACH-E" --keyword "hardware" --include-insights
```

## Enhanced Output Format

### Single Vehicle Analysis
```json
{
  "status": "success",
  "analysis_type": "enhanced_vehicle_topics",
  "parameters": {
    "vehicle": "F-SERIES",
    "year_filter": "2025",
    "analysis_mode": "single"
  },
  "data": [
    {
      "modelvehicleline": "F-SERIES",
      "modelyear": "2025",
      "category": "Feature Availability & Performance",
      "call_count": 891,
      "pct_of_total": 27.4,
      "negative_topic_calls": 553,
      "topic_negative_pct": 62.1,
      "topic_hardware_calls": 456,
      "topic_hardware_pct": 51.2,
      "topic_churn_calls": 89,
      "topic_churn_pct": 10.0,
      "sample_negative_reason": "BlueCruise not activating despite active subscription",
      "sample_hardware_issue": "steering sensor calibration failure",
      "sample_churn_reason": "BlueCruise feature reliability issues causing cancellation",
      "sample_pain_point": "Steering Issues",
      "sample_customer_voice": "BlueCruise keeps disengaging unexpectedly",
      "vehicle_topic_classification": "VEHICLE_TOPIC_CRISIS",
      "vehicle_topic_priority_score": 187.3,
      "vehicle_total_calls": 3247
    }
  ],
  "insights": {
    "summary": {
      "total_topics_analyzed": 8,
      "analysis_mode": "single",
      "vehicles_covered": 1
    },
    "insights": [
      {
        "type": "info",
        "message": "Total BlueCruise calls for F-SERIES: 3247",
        "severity": "low",
        "supporting_data": "Analysis covers 8 distinct topics"
      },
      {
        "type": "alert",
        "message": "Topic crisis detected for F-SERIES: 2 critical topics",
        "severity": "high",
        "supporting_data": "Crisis topics: Feature Availability & Performance, Hardware & Technology"
      }
    ],
    "recommendations": [
      {
        "action": "Engineering review for F-SERIES hardware issues",
        "priority": "high",
        "estimated_impact": "Address 2 hardware-related topic areas"
      }
    ]
  }
}
```

### Multi-Vehicle Comparison
```json
{
  "status": "success",
  "analysis_type": "enhanced_vehicle_topics",
  "parameters": {
    "compare_vehicles": "F-SERIES,BRONCO,EXPLORER",
    "analysis_mode": "comparison"
  },
  "data": [
    {
      "modelvehicleline": "F-SERIES",
      "category": "Feature Availability & Performance",
      "call_count": 891,
      "pct_of_total": 27.4,
      "vehicle_topic_classification": "VEHICLE_TOPIC_CRISIS"
    },
    {
      "modelvehicleline": "BRONCO", 
      "category": "Subscription Management & Clarity",
      "call_count": 234,
      "pct_of_total": 31.2,
      "vehicle_topic_classification": "VEHICLE_TOP_ISSUE"
    },
    {
      "modelvehicleline": "EXPLORER",
      "category": "Connectivity & Software Reliability", 
      "call_count": 156,
      "pct_of_total": 22.1,
      "vehicle_topic_classification": "VEHICLE_NORMAL_TOPIC"
    }
  ]
}
```

## Business Classifications

### Vehicle-Topic Types
- **VEHICLE_TOPIC_CRISIS**: High negative sentiment + high call volume (urgent engineering response)
- **VEHICLE_HARDWARE_HOTSPOT**: Above 75th percentile hardware correlation (engineering priority)
- **VEHICLE_CHURN_DRIVER**: 15%+ churn correlation (revenue impact)
- **VEHICLE_TOP_ISSUE**: 15%+ of vehicle's total calls (high visibility)
- **VEHICLE_NORMAL_TOPIC**: Standard operational performance

### Business Intelligence
- **Total Call Counting**: Complete call counts per vehicle model with topic breakdown
- **Comparative Analysis**: Side-by-side vehicle performance on same topics
- **Root Cause Correlation**: Links vehicle-topic combinations to specific business impacts
- **Hardware Impact Assessment**: Vehicle-specific hardware failure patterns
- **Churn Risk Analysis**: Which vehicle-topic combinations drive subscription cancellations

## Key Use Cases

### Single Vehicle Analysis
- **"How many calls for F-SERIES 2025?"** -> Total count + topic breakdown + business context
- **"What are F-150's biggest issues?"** -> Prioritized topics with business impact assessment
- **"F-SERIES hardware problems?"** -> Hardware-focused topic analysis with root causes

### Multi-Vehicle Comparison  
- **"Compare F-150 vs Bronco issues"** -> Side-by-side topic performance analysis
- **"Which vehicle has most subscription problems?"** -> Subscription topic comparison across vehicles
- **"Hardware issues by vehicle model"** -> Hardware correlation comparison

### Business Intelligence
- **Vehicle prioritization** for engineering resources
- **Topic-vehicle combinations** requiring urgent attention
- **Comparative performance** analysis for product decisions

## Business Value
Enhanced vehicle_topics provides critical business intelligence for:
- **Engineering Priorities**: Focus resources on vehicle-topic combinations with highest business impact
- **Product Development**: Understand vehicle-specific customer pain points for targeted improvements
- **Customer Experience**: Identify and address vehicle model-specific issues
- **Business Planning**: Data-driven vehicle performance analysis for strategic decisions
- **Comparative Analysis**: Benchmark vehicle performance against fleet averages

## Error Handling
Enhanced error handling with detailed error classification, graceful degradation, and comprehensive logging for production monitoring.
