"""
Enhanced BlueCruise Vehicle Topics Analysis - PRODUCTION VERSION

Multi-dimensional vehicle-topic intelligence with comparative analysis, root cause correlation,
and data-driven business classification across all BlueCruise data sources.

Usage:
    python vehicle_topics.py --vehicle "F-SERIES" --year 2025 --include-insights
    python vehicle_topics.py --vehicle "F-150" --from 2025-01-01 --to 2025-12-31 --include-insights
    python vehicle_topics.py --compare-vehicles "F-SERIES,BRONCO,EXPLORER" --include-insights
"""
import argparse
import json
import os
import sys
from pathlib import Path
from databricks import sql
import requests
from dotenv import load_dotenv
from decimal import Decimal

load_dotenv(Path(__file__).resolve().parents[4] / ".env", override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


CATALOG = os.environ.get("BLUECRUISE_CATALOG", "text_analytics_dev")
SCHEMA = os.environ.get("BLUECRUISE_SCHEMA", "ford_bluecruise")
BASE_VIEW = f"{CATALOG}.{SCHEMA}.base_view"
TOPICS = f"{CATALOG}.{SCHEMA}.topics"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--from", dest="date_from", default=None)
    parser.add_argument("--to", dest="date_to", default=None)
    parser.add_argument("--vehicle", dest="vehicle", default=None,
                        help="Single vehicle to analyze (e.g., 'F-SERIES', 'F-150')")
    parser.add_argument("--compare-vehicles", dest="compare_vehicles", default=None,
                        help="Comma-separated vehicles to compare (e.g., 'F-SERIES,BRONCO,EXPLORER')")
    parser.add_argument("--year", dest="year", default=None)
    parser.add_argument("--keyword", dest="keyword", default=None)
    parser.add_argument("--limit", type=int, default=15,
                        help="Number of topics to return per vehicle")
    parser.add_argument("--by", dest="group_col", choices=["topic_level_1", "topic_level_2", "reason"],
                        default="topic_level_1")
    parser.add_argument("--include-insights", action="store_true",
                        help="Include AI-powered vehicle-topic insights and business context")
    args, _ = parser.parse_known_args()

    # Build dynamic filters
    params = {"date_from": args.date_from or "2020-01-01", "date_to": args.date_to or "2030-12-31"}
    filters = [
        "bv.call_date >= :date_from",
        "bv.call_date <= :date_to",
        "bv.modelvehicleline IS NOT NULL",
        f"t.{args.group_col} IS NOT NULL"
    ]

    # Vehicle filtering logic
    if args.compare_vehicles:
        # Multi-vehicle comparison
        vehicles = [v.strip() for v in args.compare_vehicles.split(",")]
        vehicle_conditions = []
        for i, vehicle in enumerate(vehicles):
            params[f"vehicle_{i}"] = f"%{vehicle}%"
            vehicle_conditions.append(f"LOWER(bv.modelvehicleline) LIKE LOWER(:vehicle_{i})")
        filters.append(f"({' OR '.join(vehicle_conditions)})")
        analysis_mode = "comparison"
    elif args.vehicle:
        # Single vehicle analysis
        params["vehicle"] = f"%{args.vehicle}%"
        filters.append("LOWER(bv.modelvehicleline) LIKE LOWER(:vehicle)")
        analysis_mode = "single"
    else:
        # All vehicles overview
        analysis_mode = "overview"

    if args.year:
        params["year"] = args.year
        filters.append("bv.modelyear = :year")
    if args.keyword:
        params["keyword"] = f"%{args.keyword}%"
        filters.append(f"LOWER(t.{args.group_col}) LIKE LOWER(:keyword)")

    where_clause = " AND ".join(filters)

    # Enhanced query with multi-table intelligence
    query = f"""
        WITH vehicle_topic_intelligence AS (
            SELECT
                bv.modelvehicleline,
                bv.modelyear,
                bv.call_date,
                bv.call_id,
                bv.sentiment_label,
                bv.sentiment,
                bv.intent_category,

                -- Topic data (main analysis)
                t.{args.group_col} as primary_topic,
                t.topic_level_1,
                t.topic_level_2,
                t.reason,

                -- Multi-table context for vehicle-topic analysis
                s.subscription_category,
                pu.parts_concern,
                pu.parts_features,
                pp.pain_point,
                pp.customer_feedback

            FROM {CATALOG}.{SCHEMA}.base_view bv
            JOIN {CATALOG}.{SCHEMA}.topics t ON bv.call_id = t.call_id
            LEFT JOIN {CATALOG}.{SCHEMA}.subscriptions s ON bv.call_id = s.call_id
            LEFT JOIN text_analytics.nlp_analytics.parts_unfiltered pu ON bv.call_id = pu.call_id
                AND (pu.parts_features LIKE '%BlueCruise%' OR pu.parts_concern LIKE '%BlueCruise%')
            LEFT JOIN text_analytics.restensl.v_pain_points2 pp ON bv.call_id = pp.call_id
            WHERE {where_clause}
        ),
        vehicle_topic_analytics AS (
            SELECT
                modelvehicleline,
                modelyear,
                primary_topic,

                -- Basic metrics per vehicle-topic combination
                COUNT(*) AS topic_call_count,
                COUNT(CASE WHEN sentiment_label = 'Negative' THEN 1 END) AS negative_topic_calls,
                ROUND(COUNT(CASE WHEN sentiment_label = 'Negative' THEN 1 END) * 100.0 / COUNT(*), 1) AS topic_negative_pct,

                -- HARDWARE CORRELATION per vehicle-topic
                COUNT(CASE WHEN parts_concern IS NOT NULL THEN 1 END) AS topic_hardware_calls,
                ROUND(COUNT(CASE WHEN parts_concern IS NOT NULL THEN 1 END) * 100.0 / COUNT(*), 1) AS topic_hardware_pct,

                -- SUBSCRIPTION CORRELATION per vehicle-topic
                COUNT(CASE WHEN subscription_category = 'Deactivations' THEN 1 END) AS topic_churn_calls,
                ROUND(COUNT(CASE WHEN subscription_category = 'Deactivations' THEN 1 END) * 100.0 / COUNT(*), 1) AS topic_churn_pct,

                -- SAMPLES per vehicle-topic combination
                MAX(CASE WHEN sentiment_label = 'Negative' THEN reason END) AS sample_negative_reason,
                MAX(CASE WHEN parts_concern IS NOT NULL THEN parts_concern END) AS sample_hardware_issue,
                MAX(CASE WHEN subscription_category = 'Deactivations' THEN reason END) AS sample_churn_reason,
                MAX(pain_point) AS sample_pain_point,
                MAX(customer_feedback) AS sample_customer_voice

            FROM vehicle_topic_intelligence
            GROUP BY modelvehicleline, modelyear, primary_topic
            HAVING COUNT(*) >= 3  -- Only include topics with meaningful volume
        ),
        -- VEHICLE BENCHMARKS for comparison
        vehicle_benchmarks AS (
            SELECT
                modelvehicleline,
                AVG(topic_negative_pct) AS vehicle_avg_negative_pct,
                AVG(topic_hardware_pct) AS vehicle_avg_hardware_pct,
                PERCENTILE(topic_negative_pct, 0.80) AS vehicle_high_negative_threshold,
                PERCENTILE(topic_hardware_pct, 0.75) AS vehicle_high_hardware_threshold,
                SUM(topic_call_count) AS vehicle_total_calls
            FROM vehicle_topic_analytics
            GROUP BY modelvehicleline
        ),
        -- FINAL ANALYSIS with vehicle-topic combinations
        vehicle_topic_final AS (
            SELECT
                vta.*,
                vb.vehicle_avg_negative_pct,
                vb.vehicle_high_negative_threshold,
                vb.vehicle_high_hardware_threshold,
                vb.vehicle_total_calls,

                -- Percentage of vehicle's total calls for this topic
                ROUND(vta.topic_call_count * 100.0 / vb.vehicle_total_calls, 1) AS pct_of_vehicle_calls,

                -- DATA-DRIVEN VEHICLE-TOPIC CLASSIFICATION
                CASE
                    WHEN vta.topic_negative_pct > vb.vehicle_high_negative_threshold
                     AND vta.topic_call_count > 20
                    THEN 'VEHICLE_TOPIC_CRISIS'
                    WHEN vta.topic_hardware_pct > vb.vehicle_high_hardware_threshold
                    THEN 'VEHICLE_HARDWARE_HOTSPOT'
                    WHEN vta.topic_churn_pct > 15.0
                    THEN 'VEHICLE_CHURN_DRIVER'
                    WHEN vta.topic_call_count > vb.vehicle_total_calls * 0.15
                    THEN 'VEHICLE_TOP_ISSUE'
                    ELSE 'VEHICLE_NORMAL_TOPIC'
                END AS vehicle_topic_classification,

                -- BUSINESS PRIORITY SCORE per vehicle-topic
                ROUND((
                    (vta.topic_negative_pct / NULLIF(vb.vehicle_avg_negative_pct, 0)) * 40 +
                    (vta.topic_call_count / NULLIF(vb.vehicle_total_calls, 0)) * 30 +
                    (vta.topic_hardware_pct / NULLIF(vb.vehicle_avg_hardware_pct, 0)) * 20 +
                    (vta.topic_churn_pct / 10.0) * 10
                ), 1) AS vehicle_topic_priority_score

            FROM vehicle_topic_analytics vta
            JOIN vehicle_benchmarks vb ON vta.modelvehicleline = vb.modelvehicleline
        )
        SELECT
            modelvehicleline,
            modelyear,
            primary_topic as category,
            topic_call_count as call_count,
            pct_of_vehicle_calls as pct_of_total,
            negative_topic_calls,
            topic_negative_pct,
            topic_hardware_calls,
            topic_hardware_pct,
            topic_churn_calls,
            topic_churn_pct,

            -- Context samples
            sample_negative_reason,
            sample_hardware_issue,
            sample_churn_reason,
            sample_pain_point,
            sample_customer_voice,

            -- Business intelligence
            vehicle_topic_classification,
            vehicle_topic_priority_score,
            vehicle_total_calls

        FROM vehicle_topic_final
        ORDER BY vehicle_topic_priority_score DESC, call_count DESC
        LIMIT {args.limit * 10}
    """

    with get_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(query, params)
            rows = cursor.fetchall()
            columns = [d[0] for d in cursor.description]

    # JSON serialization with Decimal handling
    def serialize_value(value):
        if isinstance(value, Decimal):
            return float(value)
        elif hasattr(value, "isoformat"):
            return str(value)
        elif value is None:
            return None
        else:
            return value

    result = []
    for row in rows:
        row_dict = {}
        for i, value in enumerate(row):
            row_dict[columns[i]] = serialize_value(value)
        result.append(row_dict)

    if args.include_insights and result:
        # Generate insights based on analysis mode
        if analysis_mode == "single":
            # Single vehicle analysis
            vehicle_name = args.vehicle
            total_calls = result[0].get('vehicle_total_calls', 0) if result else 0
            crisis_topics = [r for r in result if r.get('vehicle_topic_classification') == 'VEHICLE_TOPIC_CRISIS']
            hardware_hotspots = [r for r in result if r.get('vehicle_topic_classification') == 'VEHICLE_HARDWARE_HOTSPOT']

            insights = []
            recommendations = []

            insights.append({
                "type": "info",
                "message": f"Total BlueCruise calls for {vehicle_name}: {total_calls}",
                "severity": "low",
                "supporting_data": f"Analysis covers {len(result)} distinct topics"
            })

            if crisis_topics:
                crisis_topic_names = [r['category'] for r in crisis_topics[:3]]
                insights.append({
                    "type": "alert",
                    "message": f"Topic crisis detected for {vehicle_name}: {len(crisis_topics)} critical topics",
                    "severity": "high",
                    "supporting_data": f"Crisis topics: {', '.join(crisis_topic_names)}"
                })

            if hardware_hotspots:
                recommendations.append({
                    "action": f"Engineering review for {vehicle_name} hardware issues",
                    "priority": "high",
                    "estimated_impact": f"Address {len(hardware_hotspots)} hardware-related topic areas"
                })

        elif analysis_mode == "comparison":
            # Multi-vehicle comparison
            vehicles_analyzed = list(set([r['modelvehicleline'] for r in result]))

            insights = []
            recommendations = []

            insights.append({
                "type": "info",
                "message": f"Comparative analysis across {len(vehicles_analyzed)} vehicles",
                "severity": "low",
                "supporting_data": f"Vehicles: {', '.join(vehicles_analyzed)}"
            })

        response = {
            "status": "success",
            "analysis_type": "enhanced_vehicle_topics",
            "parameters": {
                "vehicle": args.vehicle,
                "compare_vehicles": args.compare_vehicles,
                "analysis_mode": analysis_mode,
                "year_filter": args.year,
                "keyword_filter": args.keyword,
                "group_by": args.group_col
            },
            "data": result[:args.limit] if analysis_mode == "single" else result,
            "insights": {
                "summary": {
                    "total_topics_analyzed": len(result),
                    "analysis_mode": analysis_mode,
                    "vehicles_covered": len(set([r['modelvehicleline'] for r in result]))
                },
                "insights": insights,
                "recommendations": recommendations
            }
        }
        print(json.dumps(response, indent=2))
    else:
        # Simple topics output - limit per vehicle for readability
        if analysis_mode == "single":
            simple_result = result[:args.limit]
        else:
            simple_result = result

        print(json.dumps(simple_result, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)
