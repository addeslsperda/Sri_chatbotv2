---
name: call_volume
display_name: Enhanced BlueCruise Volume Intelligence
description: Production-grade multi-dimensional call volume analysis with AI-powered insights, pattern-aware anomaly detection, and comprehensive business impact assessment. Analyzes across all BlueCruise tables for complete intelligence.
signals:
  - how many calls
  - call volume trends
  - volume spike detection
  - call patterns
  - business impact analysis
  - complaint trends
  - churn indicators
  - volume forecasting
  - anomaly detection
requires:
  - a date range (from and to)
capabilities:
  - Multi-table volume analysis (base_view + topics + subscriptions + parts + pain_points)
  - Data-driven threshold detection with no hardcoded values
  - Pattern-aware analysis (weekday vs weekend vs holiday patterns)
  - AI-powered business insights and recommendations
  - Comprehensive security and input validation
  - Real-time anomaly classification (spikes, drops, crises)
not_good_for: Simple call counts (use basic version), individual customer details (use call_examples)
---

# Enhanced BlueCruise Volume Intelligence

## What this does
Performs comprehensive multi-dimensional volume analysis across all BlueCruise data sources with intelligent pattern detection, business impact assessment, and AI-generated insights.

## Production Features
- **Multi-table analysis**: Combines base_view, topics, subscriptions, parts, and pain_points tables
- **Data-driven thresholds**: Automatically calculates normal ranges from historical data  
- **Pattern awareness**: Different baselines for weekdays, weekends, and special periods
- **Security hardening**: Input validation, SQL injection prevention, error handling
- **Business intelligence**: Crisis detection, churn risk assessment, onboarding issue identification
- **AI insights**: Automated trend analysis and actionable recommendations

## Scripts Available

```bash
python .claude/skills/call_volume/scripts/call_volume.py --from YYYY-MM-DD --to YYYY-MM-DD
```

## Enhanced Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--from` | Yes | — | Start date in YYYY-MM-DD format |
| `--to` | Yes | — | End date in YYYY-MM-DD format |
| `--group-by` | No | `day` | Granularity: `day`, `week`, or `month` |
| `--vehicle` | No | all | Filter to specific vehicle model |
| `--include-insights` | No | false | Include AI-powered insights and recommendations |

## Example Usage

```bash
# Comprehensive daily analysis with insights
python enhanced_call_volume.py --from 2026-01-01 --to 2026-01-31 --include-insights

# Weekly trends for F-150 only
python enhanced_call_volume.py --from 2026-01-01 --to 2026-03-31 --group-by week --vehicle "F-SERIES"

# Monthly business intelligence report
python enhanced_call_volume.py --from 2025-01-01 --to 2025-12-31 --group-by month --include-insights
```

## Enhanced Output Format

```json
{
  "status": "success",
  "analysis_type": "comprehensive_volume_analysis",
  "parameters": {
    "date_from": "2026-01-01",
    "date_to": "2026-01-31", 
    "group_by": "day",
    "vehicle_filter": null
  },
  "data": [
    {
      "period": "2026-01-01",
      "total_calls": 247,
      "complaint_calls": 89,
      "complaint_pct": 36.0,
      "deactivation_calls": 34,
      "churn_rate_pct": 13.8,
      "confused_trial_calls": 12,
      "hardware_issue_calls": 45,
      "volume_classification": "MODERATE_SPIKE",
      "business_impact": "HIGH_RISK",
      "confidence_level": "HIGH_CONFIDENCE",
      "vs_avg_pct": 23.4,
      "expected_avg_calls": 201
    }
  ],
  "insights": {
    "summary": {
      "total_calls_analyzed": 7842,
      "average_complaint_rate": 28.5,
      "crisis_periods": 3,
      "analysis_confidence": "HIGH"
    },
    "insights": [
      {
        "type": "alert",
        "message": "Crisis conditions detected on 3 days",
        "severity": "high",
        "supporting_data": "Average complaint rate: 28.5%"
      }
    ],
    "recommendations": [
      {
        "action": "Immediate escalation to engineering and customer success teams",
        "priority": "urgent",
        "estimated_impact": "Prevent customer churn and reputation damage"
      }
    ]
  }
}
```

## Intelligence Classifications

### Volume Patterns
- **SIGNIFICANT_SPIKE**: >90th percentile for this day-of-week pattern
- **MODERATE_SPIKE**: >75th percentile for this day-of-week pattern  
- **NORMAL_RANGE**: Within expected range for this pattern
- **SIGNIFICANT_DROP**: <70% of average for this pattern

### Business Impact
- **CRISIS**: High complaint rate + significant churn calls
- **HIGH_RISK**: Elevated complaints or churn indicators
- **ONBOARDING_ISSUE**: High confused trial user calls
- **CHURN_RISK**: Elevated deactivation rate
- **STABLE**: Normal operational patterns

### Confidence Levels
- **HIGH_CONFIDENCE**: 30+ historical days for pattern baseline
- **MEDIUM_CONFIDENCE**: 15-29 historical days  
- **LOW_CONFIDENCE**: <15 historical days (new pattern)

## Error Handling
Enhanced error handling with detailed error classification, security validation, and comprehensive logging for production monitoring.
