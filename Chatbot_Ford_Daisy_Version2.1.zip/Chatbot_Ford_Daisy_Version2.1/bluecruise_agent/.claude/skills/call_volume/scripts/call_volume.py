"""
Enhanced BlueCruise Call Volume Analysis - FINAL VERSION

Same structure as original call_volume.py but with multi-table intelligence.

Usage:
    python enhanced_call_volume.py --from 2026-01-01 --to 2026-01-31
    python enhanced_call_volume.py --from 2026-01-01 --to 2026-01-31 --include-insights
"""
import argparse
import json
import os
import sys
from pathlib import Path
from databricks import sql
import requests
from dotenv import load_dotenv
from decimal import Decimal

load_dotenv(Path(__file__).resolve().parents[4] / ".env", override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


CATALOG = os.environ.get("BLUECRUISE_CATALOG", "text_analytics_dev")
SCHEMA = os.environ.get("BLUECRUISE_SCHEMA", "ford_bluecruise")
BASE_VIEW = f"{CATALOG}.{SCHEMA}.base_view"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--from", dest="date_from", required=True)
    parser.add_argument("--to", dest="date_to", required=True)
    parser.add_argument("--group-by", dest="group_by", choices=["day", "week", "month"], default="day")
    parser.add_argument("--vehicle", dest="vehicle", default=None)
    parser.add_argument("--include-insights", action="store_true")
    args, _ = parser.parse_known_args()

    if args.group_by == "day":
        date_trunc = "DATE(call_date)"
        label = "date"
    elif args.group_by == "week":
        date_trunc = "DATE_TRUNC('week', call_date)"
        label = "week_start"
    else:
        date_trunc = "DATE_TRUNC('month', call_date)"
        label = "month_start"

    params = {"date_from": args.date_from, "date_to": args.date_to}
    filters = [
        "call_date >= :date_from",
        "call_date <= :date_to",
    ]
    if args.vehicle:
        params["vehicle"] = f"%{args.vehicle}%"
        filters.append("LOWER(modelvehicleline) LIKE LOWER(:vehicle)")
    where = " AND ".join(filters)

    query = f"""
        SELECT
            {date_trunc} AS {label},
            COUNT(*) AS call_count,

            -- Enhanced analytics
            COUNT(CASE WHEN bv.sentiment_label = 'Positive' THEN 1 END) as positive_calls,
            COUNT(CASE WHEN bv.sentiment_label = 'Negative' THEN 1 END) as negative_calls,
            COUNT(CASE WHEN bv.intent_category = 'Complaint' THEN 1 END) as complaint_calls,
            COUNT(CASE WHEN s.subscription_category = 'Deactivations' THEN 1 END) as deactivation_calls,
            COUNT(CASE WHEN pu.call_id IS NOT NULL THEN 1 END) as hardware_calls,
            COUNT(CASE WHEN bv.intent_category = 'Complaint' AND s.subscription_category = 'Deactivations' THEN 1 END) as angry_churn_calls,

            -- Percentages
            ROUND(COUNT(CASE WHEN bv.intent_category = 'Complaint' THEN 1 END) * 100.0 / COUNT(*), 1) as complaint_pct,
            ROUND(COUNT(CASE WHEN s.subscription_category = 'Deactivations' THEN 1 END) * 100.0 / COUNT(*), 1) as churn_rate_pct

        FROM {BASE_VIEW} bv
        LEFT JOIN {CATALOG}.{SCHEMA}.subscriptions s ON bv.call_id = s.call_id
        LEFT JOIN text_analytics.nlp_analytics.parts_unfiltered pu ON bv.call_id = pu.call_id
            AND (pu.parts_features LIKE '%BlueCruise%' OR pu.parts_concern LIKE '%BlueCruise%')
        WHERE {where}
        GROUP BY {date_trunc}
        ORDER BY {date_trunc}
    """

    with get_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(query, params)
            rows = cursor.fetchall()
            columns = [d[0] for d in cursor.description]

    result = []
    for row in rows:
        row_dict = {}
        for i, value in enumerate(row):
            if hasattr(value, "isoformat"):
                row_dict[columns[i]] = str(value)
            elif isinstance(value, Decimal):
                row_dict[columns[i]] = float(value)
            elif isinstance(value, (float, int)):
                row_dict[columns[i]] = value
            else:
                row_dict[columns[i]] = value
        result.append(row_dict)

    if args.include_insights:
        # Simple insights
        total_calls = sum(int(r.get('call_count', 0)) for r in result)
        avg_complaint_rate = sum(float(r.get('complaint_pct', 0)) for r in result) / len(result) if result else 0

        response = {
            "status": "success",
            "data": result,
            "insights": {
                "summary": {
                    "total_calls": total_calls,
                    "periods": len(result),
                    "avg_complaint_rate": round(avg_complaint_rate, 1)
                }
            }
        }
        print(json.dumps(response, indent=2))
    else:
        print(json.dumps(result, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)