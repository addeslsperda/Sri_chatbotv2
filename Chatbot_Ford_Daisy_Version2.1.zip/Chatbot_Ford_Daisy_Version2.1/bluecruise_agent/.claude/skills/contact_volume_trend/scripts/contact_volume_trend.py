"""
Enhanced BlueCruise Contact Volume Trend Analysis - PRODUCTION VERSION

Multi-dimensional volume intelligence with pattern-aware anomaly detection, root cause analysis,
and data-driven business classification across all BlueCruise data sources.

Usage:
    python contact_volume_trend.py --from 2025-01-01 --to 2025-12-31
    python contact_volume_trend.py --from 2025-01-01 --to 2025-12-31 --group-by week --include-insights
    python contact_volume_trend.py --from 2025-01-01 --to 2025-12-31 --vehicle "F-SERIES" --include-insights
"""
import argparse
import json
import os
import sys
from pathlib import Path
from databricks import sql
import requests
from dotenv import load_dotenv
from decimal import Decimal

load_dotenv(Path(__file__).resolve().parents[4] / ".env", override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


CATALOG = os.environ.get("BLUECRUISE_CATALOG", "text_analytics_dev")
SCHEMA = os.environ.get("BLUECRUISE_SCHEMA", "ford_bluecruise")
BASE_VIEW = f"{CATALOG}.{SCHEMA}.base_view"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--from", dest="date_from", required=True)
    parser.add_argument("--to", dest="date_to", required=True)
    parser.add_argument("--group-by", dest="group_by", choices=["day", "week", "month"], default="week")
    parser.add_argument("--vehicle", dest="vehicle", default=None)
    parser.add_argument("--intent-category", dest="intent_category", default=None)
    parser.add_argument("--include-insights", action="store_true",
                        help="Include AI-powered volume insights and root cause analysis")
    args, _ = parser.parse_known_args()

    # Dynamic date grouping with pattern-aware comparison
    if args.group_by == "day":
        date_trunc = "DATE(call_date)"
        label = "date"
        # Compare Monday to Monday, Tuesday to Tuesday, etc.
        pattern_group = "DAYOFWEEK(call_date)"
        pattern_label = "day_of_week"
    elif args.group_by == "week":
        date_trunc = "DATE_TRUNC('week', call_date)"
        label = "week_start"
        # All weeks are comparable
        pattern_group = "1"
        pattern_label = "week_pattern"
    else:
        date_trunc = "DATE_TRUNC('month', call_date)"
        label = "month_start"
        # Compare January to January, February to February, etc.
        pattern_group = "MONTH(call_date)"
        pattern_label = "month_of_year"

    # Build dynamic filters
    params = {"date_from": args.date_from, "date_to": args.date_to}
    filters = [
        "bv.call_date >= :date_from",
        "bv.call_date <= :date_to"
    ]
    if args.vehicle:
        params["vehicle"] = f"%{args.vehicle}%"
        filters.append("LOWER(bv.modelvehicleline) LIKE LOWER(:vehicle)")
    if args.intent_category:
        params["intent_category"] = f"%{args.intent_category}%"
        filters.append("LOWER(bv.intent_category) LIKE LOWER(:intent_category)")

    where_clause = " AND ".join(filters)

    query = f"""
        WITH volume_intelligence AS (
            SELECT
                bv.call_date,
                bv.call_id,
                bv.sentiment_label,
                bv.modelvehicleline,
                bv.modelyear,
                bv.intent_category,

                -- Multi-table context for root cause analysis
                s.subscription_category,
                pu.parts_concern,
                pu.parts_features,
                pp.pain_point,
                t.reason,
                t.topic_level_1,
                t.topic_level_2

            FROM {CATALOG}.{SCHEMA}.base_view bv
            LEFT JOIN {CATALOG}.{SCHEMA}.subscriptions s ON bv.call_id = s.call_id
            LEFT JOIN text_analytics.nlp_analytics.parts_unfiltered pu ON bv.call_id = pu.call_id
                AND (pu.parts_features LIKE '%BlueCruise%' OR pu.parts_concern LIKE '%BlueCruise%')
            LEFT JOIN text_analytics.restensl.v_pain_points2 pp ON bv.call_id = pp.call_id
            LEFT JOIN {CATALOG}.{SCHEMA}.topics t ON bv.call_id = t.call_id
            WHERE {where_clause}
        ),
        volume_analytics AS (
            SELECT
                {date_trunc} AS period,
                {pattern_group} AS pattern_group,

                -- Basic volume metrics
                COUNT(*) AS call_count,
                COUNT(CASE WHEN sentiment_label = 'Negative' THEN 1 END) AS negative_calls,
                ROUND(COUNT(CASE WHEN sentiment_label = 'Negative' THEN 1 END) * 100.0 / COUNT(*), 1) AS negative_pct,

                -- ROOT CAUSE ANALYSIS - What drives volume spikes
                COUNT(CASE WHEN parts_concern IS NOT NULL THEN 1 END) AS hardware_driven_calls,
                ROUND(COUNT(CASE WHEN parts_concern IS NOT NULL THEN 1 END) * 100.0 / COUNT(*), 1) AS hardware_pct,

                COUNT(CASE WHEN subscription_category = 'Deactivations' THEN 1 END) AS churn_calls,
                ROUND(COUNT(CASE WHEN subscription_category = 'Deactivations' THEN 1 END) * 100.0 / COUNT(*), 1) AS churn_pct,

                -- Sample root causes per period
                MAX(CASE WHEN parts_concern IS NOT NULL THEN parts_concern END) AS sample_hardware_cause,
                MAX(CASE WHEN subscription_category = 'Deactivations' THEN reason END) AS sample_churn_reason,
                MAX(topic_level_1) AS primary_topic_driver,
                MAX(modelvehicleline) AS sample_vehicle,

                -- Vehicle breakdown during volume periods
                COUNT(DISTINCT modelvehicleline) AS vehicles_affected,
                MAX(CASE WHEN parts_concern IS NOT NULL THEN modelvehicleline END) AS hardware_problem_vehicle

            FROM volume_intelligence
            GROUP BY {date_trunc}, {pattern_group}
        ),
        -- PATTERN-AWARE BASELINES (compare same day patterns)
        pattern_baselines AS (
            SELECT
                pattern_group,
                AVG(call_count) AS pattern_avg_volume,
                STDDEV(call_count) AS pattern_volume_stddev,
                PERCENTILE(call_count, 0.85) AS pattern_high_volume_threshold,
                COUNT(*) AS pattern_periods
            FROM volume_analytics
            GROUP BY pattern_group
            HAVING COUNT(*) >= 3
        ),
        volume_trends AS (
            SELECT
                va.*,
                COALESCE(pb.pattern_avg_volume, 1000.0) AS pattern_avg_volume,
                COALESCE(pb.pattern_volume_stddev, 200.0) AS pattern_volume_stddev,
                COALESCE(pb.pattern_high_volume_threshold, 1200.0) AS pattern_high_volume_threshold,

                -- Period-over-period comparison (same pattern only)
                LAG(va.call_count, 1) OVER (
                    PARTITION BY va.pattern_group ORDER BY va.period
                ) AS prev_period_volume,

                ROUND((va.call_count - LAG(va.call_count, 1) OVER (
                    PARTITION BY va.pattern_group ORDER BY va.period
                )) * 100.0 / NULLIF(LAG(va.call_count, 1) OVER (
                    PARTITION BY va.pattern_group ORDER BY va.period
                ), 0), 2) AS pct_change

            FROM volume_analytics va
            LEFT JOIN pattern_baselines pb ON va.pattern_group = pb.pattern_group
        )
        SELECT
            vt.period,
            vt.call_count,
            vt.pct_change,
            vt.negative_calls,
            vt.negative_pct,
            vt.hardware_driven_calls,
            vt.hardware_pct,
            vt.churn_calls,
            vt.churn_pct,

            -- Root cause samples
            vt.sample_hardware_cause,
            vt.sample_churn_reason,
            vt.primary_topic_driver,
            vt.sample_vehicle,
            vt.vehicles_affected,
            vt.hardware_problem_vehicle,

            -- BlueCruise-specific volume classification
            CASE
                WHEN vt.call_count > vt.pattern_avg_volume + (2 * vt.pattern_volume_stddev)
                THEN 'VOLUME_CRISIS'
                WHEN vt.call_count > vt.pattern_high_volume_threshold
                THEN 'VOLUME_SPIKE'
                WHEN vt.call_count < vt.pattern_avg_volume - (1.5 * vt.pattern_volume_stddev)
                THEN 'VOLUME_DROP'
                WHEN ABS(vt.pct_change) > 25 AND vt.pct_change > 0
                THEN 'VOLUME_SURGE'
                ELSE 'VOLUME_NORMAL'
            END AS volume_classification,

            -- Pattern benchmarks (transparency)
            vt.pattern_avg_volume,
            vt.pattern_high_volume_threshold

        FROM volume_trends vt
        ORDER BY vt.period
    """

    with get_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(query, params)
            rows = cursor.fetchall()
            columns = [d[0] for d in cursor.description]

    # JSON serialization with Decimal handling
    def serialize_value(value):
        if isinstance(value, Decimal):
            return float(value)
        elif hasattr(value, "isoformat"):
            return str(value)
        elif value is None:
            return None
        else:
            return value

    result = []
    for row in rows:
        row_dict = {}
        for i, value in enumerate(row):
            row_dict[columns[i]] = serialize_value(value)
        result.append(row_dict)

    if args.include_insights:
        if result:
            # Calculate insights from volume trends
            crisis_periods = [r for r in result if r.get('volume_classification') == 'VOLUME_CRISIS']
            spike_periods = [r for r in result if r.get('volume_classification') == 'VOLUME_SPIKE']
            drop_periods = [r for r in result if r.get('volume_classification') == 'VOLUME_DROP']
            surge_periods = [r for r in result if r.get('volume_classification') == 'VOLUME_SURGE']

            total_calls = sum(r.get('call_count', 0) for r in result)
            avg_volume = total_calls / len(result) if result else 0

            insights = []
            recommendations = []

            # Crisis periods analysis
            if crisis_periods:
                crisis_dates = [r['period'] for r in crisis_periods[:3]]
                insights.append({
                    "type": "alert",
                    "message": f"Volume crisis detected in {len(crisis_periods)} periods",
                    "severity": "high",
                    "supporting_data": f"Crisis dates: {', '.join(map(str, crisis_dates))}"
                })

                # Root cause analysis for crisis periods
                crisis_hardware_issues = [r['sample_hardware_cause'] for r in crisis_periods if r.get('sample_hardware_cause')]
                if crisis_hardware_issues:
                    recommendations.append({
                        "action": f"Engineering review required for volume-driving hardware issues",
                        "priority": "urgent",
                        "estimated_impact": f"Address: {', '.join(set(crisis_hardware_issues[:3]))}"
                    })

            # Spike periods analysis
            if spike_periods:
                spike_dates = [r['period'] for r in spike_periods[:3]]
                insights.append({
                    "type": "warning",
                    "message": f"Volume spikes in {len(spike_periods)} periods",
                    "severity": "medium",
                    "supporting_data": f"Spike dates: {', '.join(map(str, spike_dates))}"
                })

            # Hardware correlation analysis
            hardware_heavy_periods = [r for r in result if r.get('hardware_pct', 0) > 20]
            if hardware_heavy_periods:
                recommendations.append({
                    "action": f"Hardware reliability review - {len(hardware_heavy_periods)} periods with high hardware correlation",
                    "priority": "high",
                    "estimated_impact": "Reduce volume spikes from hardware issues"
                })

            # Volume drop analysis
            if drop_periods:
                insights.append({
                    "type": "info",
                    "message": f"Volume drops detected in {len(drop_periods)} periods",
                    "severity": "low",
                    "supporting_data": f"May indicate process improvements or reduced issues"
                })

            response = {
                "status": "success",
                "analysis_type": "enhanced_contact_volume_trend",
                "parameters": {
                    "date_from": args.date_from,
                    "date_to": args.date_to,
                    "group_by": args.group_by,
                    "vehicle_filter": args.vehicle,
                    "intent_filter": args.intent_category,
                    "pattern_aware_analysis": f"Comparing {args.group_by} to same {args.group_by} pattern"
                },
                "data": result,
                "insights": {
                    "summary": {
                        "total_calls_analyzed": total_calls,
                        "periods_analyzed": len(result),
                        "avg_volume_per_period": round(avg_volume, 1),
                        "crisis_periods": len(crisis_periods),
                        "spike_periods": len(spike_periods),
                        "drop_periods": len(drop_periods)
                    },
                    "insights": insights,
                    "recommendations": recommendations
                }
            }
            print(json.dumps(response, indent=2))
        else:
            print(json.dumps({"status": "success", "data": [], "message": "No data found for the specified criteria"}))
    else:
        print(json.dumps(result, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)
