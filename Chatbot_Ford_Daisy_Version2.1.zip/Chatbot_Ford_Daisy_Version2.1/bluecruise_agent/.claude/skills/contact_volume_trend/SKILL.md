---
name: contact_volume_trend
display_name: Enhanced BlueCruise Contact Volume Intelligence
description: Production-grade multi-dimensional volume trend analysis with pattern-aware anomaly detection, root cause correlation, and data-driven business classification across all BlueCruise data sources.
signals:
  - volume trends
  - call volume spikes
  - volume crisis detection
  - contact center patterns
  - volume anomaly analysis
  - what's driving volume changes
  - root cause of volume spikes
  - hardware-driven volume
  - churn-related volume trends
  - volume pattern analysis
  - week over week volume
  - month over month volume
  - volume surge detection
  - business impact of volume changes
requires:
  - a date range (from and to)
capabilities:
  - Multi-table volume analysis (base_view + topics + subscriptions + parts + pain_points)
  - Pattern-aware anomaly detection (compare Monday to Monday, January to January)
  - Root cause correlation for volume spikes (hardware issues, churn events, specific topics)
  - Data-driven volume classification with BlueCruise-specific thresholds
  - Business impact assessment and actionable recommendations
  - Volume crisis identification and emergency response recommendations
not_good_for: Snapshot totals for a single period (use call_volume), sentiment trends (use sentiment_trend), issue category breakdown (use top_issues)
---

# Enhanced BlueCruise Contact Volume Intelligence

## What this does
Performs comprehensive multi-dimensional volume trend analysis across all BlueCruise data sources with pattern-aware anomaly detection, root cause correlation, and data-driven business classification.

## Production Features
- **Multi-table volume analysis**: Combines base_view, topics, subscriptions, parts, and pain_points tables
- **Pattern-aware anomaly detection**: Compares same day patterns (Monday to Monday) for accurate trend analysis
- **Root cause correlation**: Identifies hardware issues, churn events, and topics driving volume spikes
- **Data-driven classification**: VOLUME_CRISIS, VOLUME_SPIKE, VOLUME_SURGE classifications using BlueCruise thresholds
- **Business impact assessment**: Volume priority scoring based on sentiment, hardware, and churn correlation
- **AI insights**: Automated recommendations for addressing volume-driving root causes

## How to run it

```bash
python .claude/skills/contact_volume_trend/scripts/contact_volume_trend.py --from YYYY-MM-DD --to YYYY-MM-DD
```

## Enhanced Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--from` | Yes | — | Start date in YYYY-MM-DD format |
| `--to` | Yes | — | End date in YYYY-MM-DD format |
| `--group-by` | No | `week` | Granularity: `day`, `week`, or `month` |
| `--vehicle` | No | all | Filter to a specific vehicle (partial match) |
| `--intent-category` | No | all | Filter to a specific intent category (partial match) |
| `--include-insights` | No | false | Include AI-powered volume insights and root cause analysis |

## Example Usage

```bash
# Comprehensive volume trend analysis with business insights
python contact_volume_trend.py --from 2025-01-01 --to 2025-12-31 --include-insights

# Vehicle-specific volume patterns (F-Series trucks)
python contact_volume_trend.py --from 2025-01-01 --to 2025-12-31 --vehicle "F-SERIES" --include-insights

# Subscription-related volume trends with root cause analysis
python contact_volume_trend.py --from 2025-01-01 --to 2025-12-31 --intent-category "Subscription" --include-insights

# Daily volume anomaly detection
python contact_volume_trend.py --from 2025-01-01 --to 2025-03-31 --group-by day --include-insights
```

## Enhanced Output Format

```json
{
  "status": "success",
  "analysis_type": "enhanced_contact_volume_trend",
  "parameters": {
    "date_from": "2025-01-01",
    "date_to": "2025-12-31",
    "group_by": "week",
    "pattern_aware_analysis": "Comparing week to same week pattern"
  },
  "data": [
    {
      "period": "2025-01-05",
      "call_count": 1456,
      "pct_change": 15.3,
      "negative_calls": 643,
      "negative_pct": 44.2,
      "hardware_driven_calls": 289,
      "hardware_pct": 19.8,
      "churn_calls": 87,
      "churn_pct": 6.0,
      "sample_hardware_cause": "steering sensor calibration failure",
      "sample_churn_reason": "BlueCruise stopped working after update",
      "primary_topic_driver": "Hardware & Technology",
      "sample_vehicle": "F-150",
      "vehicles_affected": 15,
      "hardware_problem_vehicle": "F-150",
      "volume_classification": "VOLUME_SPIKE",
      "pattern_avg_volume": 1200.0,
      "pattern_high_volume_threshold": 1400.0
    }
  ],
  "insights": {
    "summary": {
      "total_calls_analyzed": 52340,
      "periods_analyzed": 52,
      "avg_volume_per_period": 1006.5,
      "crisis_periods": 2,
      "spike_periods": 8,
      "drop_periods": 3
    },
    "insights": [
      {
        "type": "alert",
        "message": "Volume crisis detected in 2 periods",
        "severity": "high",
        "supporting_data": "Crisis dates: 2025-03-15, 2025-09-22"
      }
    ],
    "recommendations": [
      {
        "action": "Engineering review required for volume-driving hardware issues",
        "priority": "urgent",
        "estimated_impact": "Address: steering sensor calibration failure, wiring harness replacement"
      }
    ]
  }
}
```

## Business Classifications

### Volume Pattern Types
- **VOLUME_CRISIS**: 2+ standard deviations above pattern average (urgent response needed)
- **VOLUME_SPIKE**: Above 85th percentile threshold (investigation required)
- **VOLUME_SURGE**: 25%+ sudden increase from previous period (monitor for escalation)
- **VOLUME_DROP**: Significant decrease (may indicate process improvements)
- **VOLUME_NORMAL**: Within expected pattern range

### Business Intelligence
- **Root Cause Correlation**: Links volume spikes to specific hardware issues, churn events, or topic areas
- **Pattern-Aware Analysis**: Compares same day patterns for accurate anomaly detection
- **Hardware Impact Assessment**: Identifies vehicle models and components driving volume increases
- **Churn Correlation**: Tracks volume patterns related to subscription cancellations
- **Vehicle-Specific Analysis**: Volume trends by vehicle model and year

## Business Value
Enhanced contact_volume_trend provides critical operational intelligence for:
- **Crisis Response**: Early detection of volume emergencies requiring immediate staffing adjustments
- **Root Cause Analysis**: Identify and address underlying issues driving volume spikes
- **Resource Planning**: Data-driven capacity planning based on pattern-aware forecasting
- **Process Optimization**: Understand volume drivers to improve upstream processes
- **Engineering Priorities**: Focus hardware reliability efforts on volume-driving issues

## Error Handling
Enhanced error handling with detailed error classification, security validation, and comprehensive logging for production monitoring.
