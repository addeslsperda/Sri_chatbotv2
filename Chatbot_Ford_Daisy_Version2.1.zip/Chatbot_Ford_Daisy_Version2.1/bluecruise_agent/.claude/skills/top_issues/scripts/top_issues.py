"""
Enhanced BlueCruise Top Issues Analysis - PRODUCTION VERSION

Dynamically analyzes issues by the most relevant dimension based on the question asked.
Supports multiple analysis modes: intent, topics, hardware, reasons, pain points.

Usage:
    python top_issues.py --from 2025-01-01 --to 2025-12-31 --analyze-by hardware
    python top_issues.py --from 2025-01-01 --to 2025-12-31 --analyze-by pain-points
    python top_issues.py --from 2025-01-01 --to 2025-12-31 --analyze-by reasons
    python top_issues.py --from 2025-01-01 --to 2025-12-31 --analyze-by topics
"""
import argparse
import json
import os
import sys
from pathlib import Path
from databricks import sql
import requests
from dotenv import load_dotenv
from decimal import Decimal

load_dotenv(Path(__file__).resolve().parents[4] / ".env", override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


CATALOG = os.environ.get("BLUECRUISE_CATALOG", "text_analytics_dev")
SCHEMA = os.environ.get("BLUECRUISE_SCHEMA", "ford_bluecruise")


def build_analysis_query(analysis_type, date_from, date_to, vehicle, year, limit):
    """Build query based on analysis type"""

    # Common base filters
    params = {"date_from": date_from, "date_to": date_to}
    filters = [
        "bv.call_date >= :date_from",
        "bv.call_date <= :date_to"
    ]

    if vehicle:
        params["vehicle"] = f"%{vehicle}%"
        filters.append("LOWER(bv.modelvehicleline) LIKE LOWER(:vehicle)")
    if year:
        params["year"] = year
        filters.append("bv.modelyear = :year")

    where_clause = " AND ".join(filters)

    # Define analysis configurations
    analysis_configs = {
        "hardware": {
            "group_by": "pu.parts_concern",
            "category_alias": "hardware_problem",
            "filter_condition": "AND pu.parts_concern IS NOT NULL",
            "description": "Hardware component failures causing BlueCruise issues"
        },
        "pain-points": {
            "group_by": "pp.pain_point",
            "category_alias": "pain_point_category",
            "filter_condition": "AND pp.pain_point IS NOT NULL",
            "description": "Customer pain points and frustrations with BlueCruise"
        },
        "reasons": {
            "group_by": "t.reason",
            "category_alias": "detailed_reason",
            "filter_condition": "AND t.reason IS NOT NULL",
            "description": "Detailed reasons customers are calling about BlueCruise"
        },
        "topics": {
            "group_by": "t.topic_level_2",
            "category_alias": "topic_category",
            "filter_condition": "AND t.topic_level_2 IS NOT NULL",
            "description": "Specific topic categories customers discuss"
        },
        "intent": {
            "group_by": "bv.intent_category",
            "category_alias": "intent_type",
            "filter_condition": "",
            "description": "Customer intent categories for BlueCruise calls"
        },
        "feedback": {
            "group_by": "pp.customer_feedback",
            "category_alias": "customer_feedback_theme",
            "filter_condition": "AND pp.customer_feedback IS NOT NULL",
            "description": "Customer feedback themes and sentiments"
        }
    }

    config = analysis_configs.get(analysis_type, analysis_configs["intent"])

    query = f"""
        WITH enhanced_base AS (
            SELECT
                {config["group_by"]} AS category,
                bv.call_id,
                bv.sentiment_label,
                bv.intent_category,
                bv.modelvehicleline,
                bv.modelyear,
                s.subscription_category,
                t.reason,
                t.topic_level_1,
                t.topic_level_2,
                pu.parts_concern,
                pu.parts_features,
                pp.pain_point,
                pp.customer_feedback
            FROM {CATALOG}.{SCHEMA}.base_view bv
            LEFT JOIN {CATALOG}.{SCHEMA}.subscriptions s ON bv.call_id = s.call_id
            LEFT JOIN {CATALOG}.{SCHEMA}.topics t ON bv.call_id = t.call_id
            LEFT JOIN text_analytics.nlp_analytics.parts_unfiltered pu ON bv.call_id = pu.call_id
                AND (pu.parts_features LIKE '%BlueCruise%' OR pu.parts_concern LIKE '%BlueCruise%')
            LEFT JOIN text_analytics.restensl.v_pain_points2 pp ON bv.call_id = pp.call_id
            WHERE {where_clause}
            {config["filter_condition"]}
        ),
        issue_analytics AS (
            SELECT
                category,
                COUNT(*) AS call_count,

                -- Sentiment breakdown
                COUNT(CASE WHEN sentiment_label = 'Negative' THEN 1 END) AS negative_calls,
                ROUND(COUNT(CASE WHEN sentiment_label = 'Negative' THEN 1 END) * 100.0 / COUNT(*), 1) AS negative_pct,

                -- Business impact
                COUNT(CASE WHEN subscription_category = 'Deactivations' THEN 1 END) AS churn_calls,
                ROUND(COUNT(CASE WHEN subscription_category = 'Deactivations' THEN 1 END) * 100.0 / COUNT(*), 1) AS churn_rate,

                -- Cross-references
                COUNT(CASE WHEN parts_concern IS NOT NULL THEN 1 END) AS hardware_related,
                ROUND(COUNT(CASE WHEN parts_concern IS NOT NULL THEN 1 END) * 100.0 / COUNT(*), 1) AS hardware_pct,

                COUNT(CASE WHEN pain_point IS NOT NULL THEN 1 END) AS pain_point_related,
                ROUND(COUNT(CASE WHEN pain_point IS NOT NULL THEN 1 END) * 100.0 / COUNT(*), 1) AS pain_point_pct,

                -- Context samples
                MAX(customer_feedback) AS sample_feedback,
                MAX(reason) AS sample_reason,
                MAX(parts_concern) AS sample_hardware_issue,
                MAX(pain_point) AS sample_pain_point,
                MAX(topic_level_1) AS related_topic_area

            FROM enhanced_base
            WHERE category IS NOT NULL
            GROUP BY category
        ),
        -- Data-driven thresholds
        historical_thresholds AS (
            SELECT
                PERCENTILE(negative_pct, 0.75) AS crisis_negative_threshold,
                PERCENTILE(churn_rate, 0.75) AS crisis_churn_threshold,
                PERCENTILE(hardware_pct, 0.75) AS hardware_critical_threshold,
                AVG(negative_pct) AS avg_negative_baseline,
                AVG(churn_rate) AS avg_churn_baseline,
                AVG(hardware_pct) AS avg_hardware_baseline
            FROM issue_analytics
        ),
        total_calls AS (
            SELECT SUM(call_count) AS grand_total
            FROM issue_analytics
        )
        SELECT
            ia.category,
            ia.call_count,
            ROUND(ia.call_count * 100.0 / tc.grand_total, 1) AS pct_of_total,

            -- Core metrics
            ia.negative_calls,
            ia.negative_pct,
            ia.churn_calls,
            ia.churn_rate,

            -- Cross-analysis metrics
            ia.hardware_related,
            ia.hardware_pct,
            ia.pain_point_related,
            ia.pain_point_pct,

            -- Context samples
            ia.sample_feedback,
            ia.sample_reason,
            ia.sample_hardware_issue,
            ia.sample_pain_point,
            ia.related_topic_area,

            -- Data-driven classification
            CASE
                WHEN ia.negative_pct >= ht.crisis_negative_threshold
                 AND ia.churn_rate >= ht.crisis_churn_threshold
                THEN 'CRISIS'
                WHEN ia.negative_pct >= ht.avg_negative_baseline * 1.5
                  OR ia.churn_rate >= ht.avg_churn_baseline * 1.5
                THEN 'HIGH_PRIORITY'
                WHEN ia.hardware_pct >= ht.hardware_critical_threshold
                THEN 'HARDWARE_CRITICAL'
                WHEN ia.pain_point_pct >= ht.hardware_critical_threshold
                THEN 'CUSTOMER_EXPERIENCE_CRITICAL'
                ELSE 'NORMAL'
            END AS priority_classification,

            -- Numeric score for ranking
            ROUND((
                (ia.negative_pct / NULLIF(ht.avg_negative_baseline, 0)) * 40 +
                (ia.churn_rate / NULLIF(ht.avg_churn_baseline, 0)) * 40 +
                (ia.hardware_pct / NULLIF(ht.avg_hardware_baseline, 0)) * 20
            ), 1) AS priority_score,

            -- Analysis context
            '{config["description"]}' AS analysis_description,
            ht.crisis_negative_threshold,
            ht.crisis_churn_threshold,
            ht.hardware_critical_threshold

        FROM issue_analytics ia, total_calls tc, historical_thresholds ht
        ORDER BY ia.call_count DESC
        LIMIT {limit}
    """

    return query, params


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--from", dest="date_from", required=True)
    parser.add_argument("--to", dest="date_to", required=True)
    parser.add_argument("--limit", type=int, default=20)
    parser.add_argument(
        "--analyze-by",
        dest="analysis_type",
        choices=["hardware", "pain-points", "reasons", "topics", "intent", "feedback"],
        default="intent",
        help="What dimension to analyze: hardware problems, pain points, detailed reasons, topics, intent, or customer feedback"
    )
    parser.add_argument("--vehicle", dest="vehicle", default=None)
    parser.add_argument("--year", dest="year", default=None)
    parser.add_argument("--include-insights", action="store_true")
    args, _ = parser.parse_known_args()

    query, params = build_analysis_query(
        args.analysis_type, args.date_from, args.date_to,
        args.vehicle, args.year, args.limit
    )

    with get_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(query, params)
            rows = cursor.fetchall()
            columns = [d[0] for d in cursor.description]

    # JSON serialization
    def serialize_value(value):
        if isinstance(value, Decimal):
            return float(value)
        elif hasattr(value, "isoformat"):
            return str(value)
        elif value is None:
            return None
        else:
            return value

    result = []
    for row in rows:
        row_dict = {}
        for i, value in enumerate(row):
            row_dict[columns[i]] = serialize_value(value)
        result.append(row_dict)

    if args.include_insights:
        if result:
            total_calls = sum(r.get('call_count', 0) for r in result)
            avg_negative_pct = sum(r.get('negative_pct', 0) or 0 for r in result) / len(result)
            avg_churn_rate = sum(r.get('churn_rate', 0) or 0 for r in result) / len(result)
            crisis_issues = [r for r in result if r.get('priority_classification') in ['CRISIS', 'HIGH_PRIORITY']]

            # Analysis-specific insights
            analysis_description = result[0].get('analysis_description', '')

            insights = []
            recommendations = []

            if crisis_issues:
                insights.append({
                    "type": "alert",
                    "message": f"Critical {args.analysis_type} issues detected: {len(crisis_issues)} need immediate attention",
                    "severity": "high",
                    "supporting_data": f"Analysis focus: {analysis_description}"
                })

                if args.analysis_type == "hardware":
                    recommendations.append({
                        "action": f"Engineering review required for {len(crisis_issues)} hardware components",
                        "priority": "urgent",
                        "estimated_impact": "Address root cause hardware failures"
                    })
                elif args.analysis_type == "pain-points":
                    recommendations.append({
                        "action": f"Customer experience improvement needed for {len(crisis_issues)} pain points",
                        "priority": "urgent",
                        "estimated_impact": "Improve customer satisfaction and reduce churn"
                    })
                elif args.analysis_type == "reasons":
                    recommendations.append({
                        "action": f"Process improvement needed for {len(crisis_issues)} call reasons",
                        "priority": "urgent",
                        "estimated_impact": "Reduce repeat calls and improve resolution"
                    })

            response = {
                "status": "success",
                "analysis_type": f"intelligent_top_issues_{args.analysis_type}",
                "parameters": {
                    "date_from": args.date_from,
                    "date_to": args.date_to,
                    "analysis_dimension": args.analysis_type,
                    "limit": args.limit,
                    "vehicle_filter": args.vehicle,
                    "year_filter": args.year
                },
                "data": result,
                "insights": {
                    "summary": {
                        "total_calls_analyzed": total_calls,
                        f"top_{args.analysis_type}_count": len(result),
                        "avg_negative_sentiment": round(avg_negative_pct, 1),
                        "avg_churn_risk": round(avg_churn_rate, 1),
                        "crisis_issues": len(crisis_issues),
                        "analysis_focus": analysis_description
                    },
                    "insights": insights,
                    "recommendations": recommendations
                }
            }
            print(json.dumps(response, indent=2))
        else:
            print(json.dumps({"status": "success", "data": [], "message": "No data found for the specified criteria"}))
    else:
        print(json.dumps(result, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)