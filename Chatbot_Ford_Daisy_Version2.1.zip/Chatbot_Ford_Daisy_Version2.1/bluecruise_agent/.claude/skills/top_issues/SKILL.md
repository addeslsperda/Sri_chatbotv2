---
name: top_issues
display_name: Enhanced BlueCruise Issues Intelligence
description: Production-grade multi-dimensional issue analysis with business context, churn risk assessment, hardware correlation, and actionable insights. Analyzes across all BlueCruise tables for complete intelligence.
signals:
  - top issues
  - most common problems
  - what are customers calling about
  - call reasons breakdown
  - priority issues
  - churn risk analysis
  - hardware correlation
  - business impact assessment
  - issue trends
  - root cause analysis
requires:
  - a date range (from and to)
capabilities:
  - Multi-table issue analysis (base_view + topics + subscriptions + parts + pain_points)
  - Business priority scoring (sentiment + churn + hardware correlation)
  - Sample customer feedback and hardware issues for context
  - Vehicle-specific issue patterns
  - Actionable insights and recommendations
  - Data-driven security with input validation
not_good_for: Individual call details (use call_examples), simple volume counts (use basic version)
---

# Enhanced BlueCruise Issues Intelligence

## What this does
Performs comprehensive multi-dimensional issue analysis across all BlueCruise data sources with business priority scoring, root cause analysis, and AI-generated insights.

## Production Features
- **Multi-table analysis**: Combines base_view, topics, subscriptions, parts, and pain_points tables
- **Business priority scoring**: Weighted scoring based on sentiment + churn risk + hardware correlation
- **Root cause context**: Sample customer feedback and hardware issues for each top issue  
- **Vehicle correlation**: Top affected vehicles per issue category
- **Churn risk assessment**: Subscription cancellation rates per issue type
- **Security hardening**: Input validation, SQL injection prevention, error handling
- **Actionable insights**: AI-generated recommendations for high-priority issues

## How to run it

```bash
python .claude/skills/top_issues/scripts/top_issues.py --from YYYY-MM-DD --to YYYY-MM-DD
```

## Enhanced Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--from` | Yes | — | Start date in YYYY-MM-DD format |
| `--to` | Yes | — | End date in YYYY-MM-DD format |
| `--limit` | No | `20` | Number of top categories to return |
| `--analyze-by` | No | `intent` | Analysis dimension: `hardware`, `pain-points`, `reasons`, `topics`, `intent`, `feedback` |
| `--vehicle` | No | all | Filter to specific vehicle model |
| `--year` | No | all | Filter to specific model year |
| `--include-insights` | No | false | Include AI-powered business insights and recommendations |

## Example Usage

```bash
# Hardware problems causing BlueCruise issues
python top_issues.py --from 2025-01-01 --to 2025-12-31 --analyze-by hardware --include-insights

# Customer pain points with BlueCruise
python top_issues.py --from 2025-01-01 --to 2025-12-31 --analyze-by pain-points --limit 10

# Detailed reasons customers call about BlueCruise
python top_issues.py --from 2025-01-01 --to 2025-12-31 --analyze-by reasons --include-insights

# Specific topics customers discuss
python top_issues.py --from 2025-01-01 --to 2025-12-31 --analyze-by topics --vehicle "F-150"

# Customer feedback themes
python top_issues.py --from 2025-01-01 --to 2025-12-31 --analyze-by feedback --year 2025

# Traditional intent-based analysis
python top_issues.py --from 2025-01-01 --to 2025-12-31 --analyze-by intent --include-insights
```

## Enhanced Output Format

```json
{
  "status": "success",
  "analysis_type": "enhanced_top_issues",
  "parameters": {
    "date_from": "2026-01-01",
    "date_to": "2026-01-31",
    "group_by": "intent_category",
    "limit": 10
  },
  "data": [
    {
      "category": "Lane Centering",
      "call_count": 312,
      "pct_of_total": 24.5,
      "negative_calls": 265,
      "negative_pct": 85.0,
      "churn_calls": 72,
      "churn_rate": 23.1,
      "hardware_related": 209,
      "hardware_pct": 67.0,
      "top_vehicle": "F-150",
      "top_vehicle_pct": 45.2,
      "sample_feedback": "BlueCruise turns off in construction zones and won't re-engage",
      "sample_reason": "Lane centering not working properly on highway",
      "sample_hardware_issue": "Camera sensor alignment issues",
      "priority_score": 67.4
    }
  ],
  "insights": {
    "summary": {
      "total_calls_analyzed": 1274,
      "top_issues_count": 8,
      "avg_negative_sentiment": 68.2,
      "avg_churn_risk": 15.4,
      "crisis_issues": 3
    },
    "insights": [
      {
        "type": "alert",
        "message": "High-priority issues detected: 3 categories need immediate attention",
        "severity": "high",
        "supporting_data": "Average priority score: 58.7"
      }
    ],
    "recommendations": [
      {
        "action": "Escalate Lane Centering issues to engineering team immediately",
        "priority": "urgent",
        "estimated_impact": "Could prevent 23% churn rate in affected calls"
      }
    ]
  }
}
```

## Business Priority Scoring

**Priority Score Formula**: `(negative_sentiment% * 0.4) + (churn_rate% * 0.4) + (hardware_correlation% * 0.2)`

### Scoring Classifications:
- **CRISIS (70-100)**: Immediate engineering escalation required
- **HIGH PRIORITY (50-69)**: Weekly leadership review and action plan
- **MEDIUM PRIORITY (30-49)**: Monthly monitoring and process improvement
- **LOW PRIORITY (0-29)**: Standard operational handling

## Intelligence Classifications

### Issue Impact Levels:
- **CHURN_RISK**: >20% of calls lead to subscription cancellation
- **HARDWARE_CRITICAL**: >60% correlated with hardware problems
- **SENTIMENT_CRISIS**: >80% negative sentiment
- **VEHICLE_SPECIFIC**: >70% concentrated in single vehicle model

## Error Handling
Enhanced error handling with detailed error classification, security validation, and comprehensive logging for production monitoring.
