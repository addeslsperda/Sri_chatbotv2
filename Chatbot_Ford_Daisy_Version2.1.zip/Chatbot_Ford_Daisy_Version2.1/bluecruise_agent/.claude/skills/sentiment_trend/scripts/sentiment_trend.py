"""
Enhanced BlueCruise Sentiment Trend Analysis - PRODUCTION VERSION

Multi-dimensional sentiment intelligence with root cause analysis, pattern-aware comparisons,
and data-driven anomaly detection across all BlueCruise data sources.

Usage:
    python sentiment_trend.py --from 2025-01-01 --to 2025-12-31
    python sentiment_trend.py --from 2025-01-01 --to 2025-12-31 --group-by week --include-insights
    python sentiment_trend.py --from 2025-01-01 --to 2025-12-31 --vehicle "F-SERIES" --include-insights
"""
import argparse
import json
import os
import sys
from pathlib import Path
from databricks import sql
import requests
from dotenv import load_dotenv
from decimal import Decimal

load_dotenv(Path(__file__).resolve().parents[4] / ".env", override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


CATALOG = os.environ.get("BLUECRUISE_CATALOG", "text_analytics_dev")
SCHEMA = os.environ.get("BLUECRUISE_SCHEMA", "ford_bluecruise")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--from", dest="date_from", required=True)
    parser.add_argument("--to", dest="date_to", required=True)
    parser.add_argument("--group-by", dest="group_by", choices=["day", "week", "month"], default="day")
    parser.add_argument("--vehicle", dest="vehicle", default=None)
    parser.add_argument("--include-insights", action="store_true",
                        help="Include AI-powered sentiment insights and root cause analysis")
    args, _ = parser.parse_known_args()

    # Dynamic date grouping with pattern-aware comparison
    if args.group_by == "day":
        date_trunc = "DATE(call_date)"
        label = "date"
        # Compare Monday to Monday, Tuesday to Tuesday, etc.
        pattern_group = "DAYOFWEEK(call_date)"
        pattern_label = "day_of_week"
    elif args.group_by == "week":
        date_trunc = "DATE_TRUNC('week', call_date)"
        label = "week_start"
        # All weeks are comparable
        pattern_group = "1"
        pattern_label = "week_pattern"
    else:
        date_trunc = "DATE_TRUNC('month', call_date)"
        label = "month_start"
        # Compare January to January, February to February, etc.
        pattern_group = "MONTH(call_date)"
        pattern_label = "month_of_year"

    # Build dynamic filters
    params = {"date_from": args.date_from, "date_to": args.date_to}
    filters = [
        "bv.call_date >= :date_from",
        "bv.call_date <= :date_to"
    ]
    if args.vehicle:
        params["vehicle"] = f"%{args.vehicle}%"
        filters.append("LOWER(bv.modelvehicleline) LIKE LOWER(:vehicle)")

    where_clause = " AND ".join(filters)

    query = f"""
        WITH sentiment_intelligence AS (
            SELECT
                bv.call_date,
                bv.call_id,
                bv.sentiment_label,
                bv.sentiment,
                bv.modelvehicleline,
                bv.modelyear,
                bv.intent_category,

                -- Multi-table context for root cause analysis
                s.subscription_category,
                pu.parts_concern,
                pu.parts_features,
                pp.pain_point,
                pp.customer_feedback,
                t.reason,
                t.topic_level_1,
                t.topic_level_2

            FROM {CATALOG}.{SCHEMA}.base_view bv
            LEFT JOIN {CATALOG}.{SCHEMA}.subscriptions s ON bv.call_id = s.call_id
            LEFT JOIN text_analytics.nlp_analytics.parts_unfiltered pu ON bv.call_id = pu.call_id
                AND (pu.parts_features LIKE '%BlueCruise%' OR pu.parts_concern LIKE '%BlueCruise%')
            LEFT JOIN text_analytics.restensl.v_pain_points2 pp ON bv.call_id = pp.call_id
            LEFT JOIN {CATALOG}.{SCHEMA}.topics t ON bv.call_id = t.call_id
            WHERE {where_clause}
        ),
        sentiment_analytics AS (
            SELECT
                {date_trunc} AS period,
                {pattern_group} AS pattern_group,

                -- Basic sentiment metrics
                COUNT(*) AS call_count,
                ROUND(AVG(sentiment), 4) AS avg_sentiment_score,
                COUNT(CASE WHEN sentiment_label = 'Positive' THEN 1 END) AS positive_calls,
                COUNT(CASE WHEN sentiment_label = 'Negative' THEN 1 END) AS negative_calls,
                COUNT(CASE WHEN sentiment_label = 'Neutral' THEN 1 END) AS neutral_calls,
                ROUND(COUNT(CASE WHEN sentiment_label = 'Negative' THEN 1 END) * 100.0 / COUNT(*), 1) AS negative_pct,

                -- ROOT CAUSE ANALYSIS - What drives negative sentiment
                COUNT(CASE WHEN sentiment_label = 'Negative' AND parts_concern IS NOT NULL THEN 1 END) AS negative_hardware_calls,
                ROUND(COUNT(CASE WHEN sentiment_label = 'Negative' AND parts_concern IS NOT NULL THEN 1 END) * 100.0 /
                      NULLIF(COUNT(CASE WHEN sentiment_label = 'Negative' THEN 1 END), 0), 1) AS negative_hardware_pct,

                COUNT(CASE WHEN sentiment_label = 'Negative' AND subscription_category = 'Deactivations' THEN 1 END) AS negative_churn_calls,
                ROUND(COUNT(CASE WHEN sentiment_label = 'Negative' AND subscription_category = 'Deactivations' THEN 1 END) * 100.0 /
                      NULLIF(COUNT(CASE WHEN sentiment_label = 'Negative' THEN 1 END), 0), 1) AS negative_churn_pct,

                -- Sample negative drivers per period
                MAX(CASE WHEN sentiment_label = 'Negative' THEN parts_concern END) AS sample_negative_hardware,
                MAX(CASE WHEN sentiment_label = 'Negative' THEN topic_level_1 END) AS sample_negative_topic,
                MAX(CASE WHEN sentiment_label = 'Negative' THEN pain_point END) AS sample_negative_pain_point,
                MAX(CASE WHEN sentiment_label = 'Negative' THEN modelvehicleline END) AS sample_negative_vehicle,

                -- Context samples
                MAX(CASE WHEN sentiment_label = 'Negative' THEN customer_feedback END) AS sample_negative_feedback,
                MAX(CASE WHEN sentiment_label = 'Negative' THEN reason END) AS sample_negative_reason

            FROM sentiment_intelligence
            GROUP BY {date_trunc}, {pattern_group}
        ),
        -- PATTERN-AWARE BASELINES (compare apples to apples - Monday to Monday, etc.)
        pattern_baselines AS (
            SELECT
                pattern_group,
                AVG(negative_pct) AS pattern_avg_negative_pct,
                STDDEV(negative_pct) AS pattern_negative_stddev,
                PERCENTILE(negative_pct, 0.85) AS pattern_high_negative_threshold,
                COUNT(*) AS pattern_periods
            FROM sentiment_analytics
            GROUP BY pattern_group
            HAVING COUNT(*) >= 3  -- Need at least 3 periods for reliable pattern
        ),
        -- Sentiment trends with pattern-aware comparison
        sentiment_trends AS (
            SELECT
                sa.*,
                COALESCE(pb.pattern_avg_negative_pct, 50.0) AS pattern_avg_negative_pct,
                COALESCE(pb.pattern_negative_stddev, 10.0) AS pattern_negative_stddev,
                COALESCE(pb.pattern_high_negative_threshold, 60.0) AS pattern_high_negative_threshold,
                COALESCE(pb.pattern_periods, 0) AS pattern_periods,

                -- Period-over-period comparison (same pattern only)
                LAG(sa.negative_pct, 1) OVER (
                    PARTITION BY sa.pattern_group
                    ORDER BY sa.period
                ) AS prev_period_negative_pct,

                sa.negative_pct - LAG(sa.negative_pct, 1) OVER (
                    PARTITION BY sa.pattern_group
                    ORDER BY sa.period
                ) AS negative_pct_change

            FROM sentiment_analytics sa
            LEFT JOIN pattern_baselines pb ON sa.pattern_group = pb.pattern_group
        ),
        -- Final classification with data-driven thresholds
        final_sentiment_trends AS (
            SELECT
                *,
                -- BlueCruise-specific trend classification (data-driven)
                CASE
                    WHEN negative_pct > pattern_avg_negative_pct + (2 * pattern_negative_stddev)
                    THEN 'SENTIMENT_CRISIS'
                    WHEN negative_pct > pattern_high_negative_threshold
                    THEN 'SENTIMENT_ALERT'
                    WHEN ABS(negative_pct_change) > pattern_negative_stddev AND negative_pct_change > 0
                    THEN 'SENTIMENT_DECLINE'
                    WHEN ABS(negative_pct_change) > pattern_negative_stddev AND negative_pct_change < 0
                    THEN 'SENTIMENT_IMPROVEMENT'
                    ELSE 'SENTIMENT_STABLE'
                END AS sentiment_trend_classification

            FROM sentiment_trends
        )
        SELECT
            fst.period,
            fst.call_count,
            fst.avg_sentiment_score,
            fst.positive_calls,
            fst.negative_calls,
            fst.neutral_calls,
            fst.negative_pct,
            fst.negative_pct_change,
            fst.sentiment_trend_classification,

            -- Root cause insights
            fst.negative_hardware_calls,
            fst.negative_hardware_pct,
            fst.negative_churn_calls,
            fst.negative_churn_pct,

            -- Sample drivers
            fst.sample_negative_hardware,
            fst.sample_negative_topic,
            fst.sample_negative_pain_point,
            fst.sample_negative_vehicle,

            -- Context samples
            fst.sample_negative_feedback,
            fst.sample_negative_reason,

            -- Pattern-aware benchmarks (for transparency)
            fst.pattern_avg_negative_pct,
            fst.pattern_high_negative_threshold,
            fst.pattern_periods

        FROM final_sentiment_trends fst
        ORDER BY fst.period
    """

    with get_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(query, params)
            rows = cursor.fetchall()
            columns = [d[0] for d in cursor.description]

    # JSON serialization with Decimal handling
    def serialize_value(value):
        if isinstance(value, Decimal):
            return float(value)
        elif hasattr(value, "isoformat"):
            return str(value)
        elif value is None:
            return None
        else:
            return value

    result = []
    for row in rows:
        row_dict = {}
        for i, value in enumerate(row):
            row_dict[columns[i]] = serialize_value(value)
        result.append(row_dict)

    if args.include_insights:
        if result:
            # Calculate insights from sentiment trends
            crisis_periods = [r for r in result if r.get('sentiment_trend_classification') == 'SENTIMENT_CRISIS']
            declining_periods = [r for r in result if r.get('sentiment_trend_classification') == 'SENTIMENT_DECLINE']
            improving_periods = [r for r in result if r.get('sentiment_trend_classification') == 'SENTIMENT_IMPROVEMENT']

            total_calls = sum(r.get('call_count', 0) for r in result)
            avg_negative_pct = sum(r.get('negative_pct', 0) or 0 for r in result) / len(result)

            insights = []
            recommendations = []

            # Crisis periods analysis
            if crisis_periods:
                crisis_dates = [r['period'] for r in crisis_periods[:3]]
                insights.append({
                    "type": "alert",
                    "message": f"Sentiment crisis detected in {len(crisis_periods)} periods",
                    "severity": "high",
                    "supporting_data": f"Crisis dates: {', '.join(map(str, crisis_dates))}"
                })

                # Root cause analysis for crisis periods
                crisis_hardware_issues = [r['sample_negative_hardware'] for r in crisis_periods if r.get('sample_negative_hardware')]
                if crisis_hardware_issues:
                    recommendations.append({
                        "action": f"Engineering review required for hardware issues during crisis periods",
                        "priority": "urgent",
                        "estimated_impact": f"Address: {', '.join(set(crisis_hardware_issues[:3]))}"
                    })

            # Declining trend analysis
            if declining_periods:
                declining_dates = [r['period'] for r in declining_periods[:3]]
                insights.append({
                    "type": "warning",
                    "message": f"Sentiment declining in {len(declining_periods)} periods",
                    "severity": "medium",
                    "supporting_data": f"Decline dates: {', '.join(map(str, declining_dates))}"
                })

            # Improvement recognition
            if improving_periods:
                insights.append({
                    "type": "info",
                    "message": f"Sentiment improving in {len(improving_periods)} periods",
                    "severity": "low",
                    "supporting_data": f"Positive trend detected in {len(improving_periods)} periods"
                })

            response = {
                "status": "success",
                "analysis_type": "enhanced_sentiment_trend",
                "parameters": {
                    "date_from": args.date_from,
                    "date_to": args.date_to,
                    "group_by": args.group_by,
                    "vehicle_filter": args.vehicle,
                    "pattern_aware_analysis": f"Comparing {args.group_by} to same {args.group_by} pattern"
                },
                "data": result,
                "insights": {
                    "summary": {
                        "total_calls_analyzed": total_calls,
                        "periods_analyzed": len(result),
                        "avg_negative_sentiment": round(avg_negative_pct, 1),
                        "crisis_periods": len(crisis_periods),
                        "declining_periods": len(declining_periods),
                        "improving_periods": len(improving_periods)
                    },
                    "insights": insights,
                    "recommendations": recommendations
                }
            }
            print(json.dumps(response, indent=2))
        else:
            print(json.dumps({"status": "success", "data": [], "message": "No data found for the specified criteria"}))
    else:
        print(json.dumps(result, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)