---
name: sentiment_trend
display_name: Enhanced BlueCruise Sentiment Intelligence
description: Production-grade multi-dimensional sentiment analysis with pattern-aware trend detection, root cause analysis, and data-driven anomaly detection across all BlueCruise data sources.
signals:
  - sentiment
  - how are customers feeling
  - customer mood
  - satisfaction trend
  - sentiment over time
  - sentiment crisis
  - sentiment decline
  - sentiment improvement
  - what drives negative sentiment
  - root cause sentiment analysis
  - sentiment anomaly detection
requires:
  - a date range (from and to)
capabilities:
  - Multi-table sentiment analysis (base_view + topics + subscriptions + parts + pain_points)
  - Pattern-aware trend detection (compare Monday to Monday, January to January)
  - Root cause analysis of sentiment drivers (hardware, subscription, topic correlation)
  - Data-driven anomaly detection with BlueCruise-specific thresholds
  - Sentiment crisis identification and classification
  - AI-powered insights and actionable recommendations
not_good_for: Call volume counts (use call_volume), general issue breakdowns (use top_issues)
---

# Sentiment Trend

## What this script does
Queries `text_analytics_dev.ford_bluecruise.base_view` and returns average sentiment scores and positive/neutral/negative call counts grouped by day, week, or month. Optionally filtered by vehicle model.

## How to run it

```bash
python .claude/skills/sentiment_trend/scripts/sentiment_trend.py --from YYYY-MM-DD --to YYYY-MM-DD
```

## Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--from` | Yes | — | Start date in YYYY-MM-DD format |
| `--to` | Yes | — | End date in YYYY-MM-DD format |
| `--group-by` | No | `week` | Granularity: `day`, `week`, or `month` |
| `--vehicle` | No | — | Filter to a specific vehicle model (e.g. `F-150`) |

## Example calls

```bash
# Weekly sentiment for January 2026
python .claude/skills/sentiment_trend/scripts/sentiment_trend.py --from 2026-01-01 --to 2026-01-31 --group-by week

# Daily sentiment for a specific vehicle
python .claude/skills/sentiment_trend/scripts/sentiment_trend.py --from 2026-01-01 --to 2026-01-31 --group-by day --vehicle "F-150"

# Monthly sentiment trend for all of 2025
python .claude/skills/sentiment_trend/scripts/sentiment_trend.py --from 2025-01-01 --to 2025-12-31 --group-by month
```

## Output format

With `--include-insights` (always passed in production):
```json
{
  "status": "success",
  "data": [
    {
      "period": "2026-01-05",
      "call_count": 189,
      "avg_sentiment_score": 0.6234,
      "positive_calls": 102,
      "neutral_calls": 54,
      "negative_calls": 33,
      "negative_pct": 17.5,
      "negative_hardware_pct": 8.2,
      "negative_churn_pct": 5.1,
      "sample_negative_hardware": "Camera not connecting",
      "sample_negative_topic": "Hardware Issues"
    }
  ],
  "insights": {
    "summary": { "total_calls": 1240, "avg_sentiment": 0.58, "trend_direction": "DECLINING" },
    "insights": [ { "type": "alert", "message": "...", "severity": "high" } ],
    "recommendations": [ { "action": "...", "priority": "high" } ]
  }
}
```

Note: `avg_sentiment_score` range is 0.0 (most negative) to 1.0 (most positive). `negative_churn_pct` = % of negative calls with a Deactivations subscription event.

## Error output
If something goes wrong, the script prints `{"error": "..."}` to stderr and exits with code 1.
