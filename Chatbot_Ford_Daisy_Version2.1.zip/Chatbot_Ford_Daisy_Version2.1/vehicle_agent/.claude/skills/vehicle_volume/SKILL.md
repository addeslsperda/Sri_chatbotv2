---
name: vehicle_volume
display_name: Vehicle Call Volume
description: Returns call volume by vehicle model or over time. Use for "how many calls for the Mach-E", "call volume by model this month", "weekly volume for the F-150", "which vehicle has the most calls".
signals:
  - how many calls
  - call volume
  - volume by vehicle
  - which vehicle has most calls
  - calls for the
  - mach-e volumes
  - volume trends
requires:
  - a date range (from and to)
not_good_for: Pain point breakdown (use vehicle_pain_points), customer verbatims (use vehicle_examples)
---

# Vehicle Call Volume

## What this script does
Queries `call_data` and returns either a time series of call volume (day/week/month) or a ranked list of call volume by vehicle model.

## How to run it

```bash
python .claude/skills/vehicle_volume/scripts/vehicle_volume.py --from 2026-01-01 --to 2026-01-31 --by-model
```

## Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--from` | Yes |  | Start date YYYY-MM-DD |
| `--to` | Yes |  | End date YYYY-MM-DD |
| `--vehicle` | No | all | Filter to a specific vehicle |
| `--group-by` | No | `week` | Time granularity: `day`, `week`, `month` |
| `--by-model` | No | false | If set, returns ranking by vehicle model instead of time series |

## Example calls

```bash
# Ranking by vehicle model
python .claude/skills/vehicle_volume/scripts/vehicle_volume.py --from 2026-01-01 --to 2026-01-31 --by-model

# Weekly volume for Mach-E
python .claude/skills/vehicle_volume/scripts/vehicle_volume.py --from 2026-01-01 --to 2026-03-31 --vehicle "Mach-E" --group-by week

# Monthly all-vehicle volume
python .claude/skills/vehicle_volume/scripts/vehicle_volume.py --from 2026-01-01 --to 2026-03-31 --group-by month
```

## Output format

With `--by-model`:
```json
[
  { "modelvehicleline": "F-150", "call_count": 4821 },
  { "modelvehicleline": "Mustang Mach-E", "call_count": 2341 }
]
```

Time series:
```json
[
  { "period": "2026-01-05", "call_count": 412 },
  { "period": "2026-01-12", "call_count": 438 }
]
```

## Error output
If something goes wrong, the script prints `{"error": "..."}` to stderr and exits with code 1.
