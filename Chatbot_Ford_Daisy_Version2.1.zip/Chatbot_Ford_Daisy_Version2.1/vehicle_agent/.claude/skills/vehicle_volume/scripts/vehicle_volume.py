"""
Enhanced Vehicle Call Volume Analytics with Complete Data Sources & Context-Aware Intelligence

Revolutionary improvements:
- Uses 100% complete vehicle data (models table) vs 18.2% incomplete (call_data.modelvehicleline)
- Integrates 99.3% complete sentiment data vs 22.9% incomplete (call_data.sentiment)
- Applies Ford-validated context-aware thresholds (business day vs weekend patterns)
- Vehicle-specific sentiment baselines and intelligent spike detection
- Robust SQL with proper joins and data quality validation

Usage:
    python vehicle_volume_enhanced.py --from 2026-01-01 --to 2026-01-31 --by-model
    python vehicle_volume_enhanced.py --from 2026-01-01 --to 2026-01-31 --vehicle "F-150" --group-by week --include-sentiment --detect-spikes
    python vehicle_volume_enhanced.py --from 2026-01-01 --to 2026-01-31 --by-model --compare-previous --business-days-only
"""
import argparse
import json
import os
import sys
from decimal import Decimal
from pathlib import Path
from datetime import datetime, date, timedelta
from databricks import sql
import requests
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parents[5] / ".env", override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


# Enhanced table definitions with complete data sources
CATALOG = os.environ.get("DATABRICKS_CATALOG", "text_analytics")
SCHEMA = os.environ.get("DATABRICKS_SCHEMA", "nlp_analytics")
AGENT_SCHEMA = os.environ.get("DATABRICKS_AGENT_SCHEMA", "nlp_agent")

CALL_DATA = f"{CATALOG}.{SCHEMA}.call_data"
MODELS = f"{CATALOG}.{SCHEMA}.models"
SENTIMENTS = f"{CATALOG}.{SCHEMA}.sentiments"
EMBEDDINGS = f"{CATALOG}.{AGENT_SCHEMA}.call_summary_qwen06b"


def load_ford_thresholds():
    """Load Ford-validated context-aware thresholds for intelligent analysis."""
    try:
        threshold_path = Path(__file__).parent / "ford_context_aware_thresholds.json"
        if not threshold_path.exists():
            # Try project root
            threshold_path = Path(__file__).resolve().parents[4] / "ford_context_aware_thresholds.json"

        if threshold_path.exists():
            with open(threshold_path, 'r') as f:
                return json.load(f)
        else:
            print("Warning: Ford thresholds not found, using statistical fallbacks", file=sys.stderr)
            return None
    except Exception as e:
        print(f"Warning: Could not load Ford thresholds: {e}", file=sys.stderr)
        return None


def serialize(v):
    """Bulletproof serialization - handles ALL Databricks types."""
    if v is None:
        return None
    if isinstance(v, Decimal):
        return float(v)
    if hasattr(v, "isoformat"):  # datetime objects
        return str(v)
    if isinstance(v, float):
        # Handle NaN and infinity
        if str(v) in ['nan', 'inf', '-inf']:
            return None
        return float(v)
    if isinstance(v, int):
        return int(v)
    # Convert everything else to string as fallback
    try:
        return str(v)
    except Exception:
        return None


def get_data_quality_stats(conn, date_from, date_to):
    """Validate data quality and coverage for the analysis period."""
    quality_query = f"""
    WITH base_calls AS (
        SELECT cd.call_id
        FROM {CALL_DATA} cd
        WHERE DATE(cd.call_date) >= :date_from
          AND DATE(cd.call_date) <= :date_to
    ),
    coverage_stats AS (
        SELECT
            COUNT(bc.call_id) as total_calls,
            COUNT(m.ModelVehicleLine) as calls_with_vehicle,
            COUNT(s.customer_sentiment) as calls_with_sentiment,
            COUNT(CASE WHEN m.ModelVehicleLine IS NOT NULL AND s.customer_sentiment IS NOT NULL THEN 1 END) as complete_records
        FROM base_calls bc
        LEFT JOIN {MODELS} m ON bc.call_id = m.call_id
        LEFT JOIN {SENTIMENTS} s ON bc.call_id = s.call_id
    )
    SELECT
        total_calls,
        calls_with_vehicle,
        calls_with_sentiment,
        complete_records,
        ROUND(CASE WHEN total_calls > 0 THEN calls_with_vehicle * 100.0 / total_calls ELSE 0 END, 1) as vehicle_coverage_pct,
        ROUND(CASE WHEN total_calls > 0 THEN calls_with_sentiment * 100.0 / total_calls ELSE 0 END, 1) as sentiment_coverage_pct,
        ROUND(CASE WHEN total_calls > 0 THEN complete_records * 100.0 / total_calls ELSE 0 END, 1) as complete_coverage_pct
    FROM coverage_stats
    """

    with conn.cursor() as cursor:
        cursor.execute(quality_query, {"date_from": date_from, "date_to": date_to})
        row = cursor.fetchone()
        return {
            "total_calls": serialize(row[0]),
            "vehicle_coverage_pct": serialize(row[4]),
            "sentiment_coverage_pct": serialize(row[5]),
            "complete_coverage_pct": serialize(row[6]),
            "data_quality": "excellent" if float(row[6]) > 95 else "good" if float(row[6]) > 80 else "fair"
        }


def get_vehicle_ranking_with_intelligence(conn, date_from, date_to, vehicle_filter=None,
                                        include_sentiment=False, detect_spikes=False,
                                        business_days_only=False, ford_thresholds=None):
    """Enhanced vehicle ranking with sentiment overlay and spike detection."""

    # Build dynamic WHERE conditions
    where_conditions = [
        "DATE(cd.call_date) >= :date_from",
        "DATE(cd.call_date) <= :date_to",
        "m.ModelVehicleLine IS NOT NULL"  # Ensure we have vehicle data
    ]

    params = {"date_from": date_from, "date_to": date_to}

    if vehicle_filter:
        where_conditions.append("LOWER(m.ModelVehicleLine) LIKE LOWER(:vehicle)")
        params["vehicle"] = f"%{vehicle_filter}%"

    if business_days_only:
        where_conditions.append("DAYOFWEEK(cd.call_date) NOT IN (1, 7)")  # Exclude weekends

    where_clause = " AND ".join(where_conditions)

    # Enhanced query with sentiment integration
    sentiment_fields = ""
    sentiment_joins = ""
    if include_sentiment:
        sentiment_fields = """
            , ROUND(AVG(s.customer_sentiment), 3) as avg_customer_sentiment
            , ROUND(AVG(s.overall_sentiment), 3) as avg_overall_sentiment
            , COUNT(s.customer_sentiment) as sentiment_sample_size
        """
        sentiment_joins = f"LEFT JOIN {SENTIMENTS} s ON cd.call_id = s.call_id"

    # ENHANCED QUERY WITH MODEL YEAR - Each part explained:
    query = f"""
    WITH vehicle_stats AS (
        SELECT
            m.ModelVehicleLine as vehicle,          -- Vehicle name (F-150, Mach-E, etc.)
            m.Model_Year as model_year,             --  ADDED: Model year (2024, 2025, etc.)
            COUNT(cd.call_id) as call_count,        -- Total calls for this vehicle
            COUNT(DISTINCT DATE(cd.call_date)) as days_with_calls,  -- How many different days had calls
            MIN(cd.call_date) as first_call_date,   -- When was the first call in this period
            MAX(cd.call_date) as last_call_date     -- When was the most recent call
            {sentiment_fields}                      -- Optional: sentiment averages if requested
        FROM {CALL_DATA} cd                         -- Main call records table
        INNER JOIN {MODELS} m ON cd.call_id = m.call_id    -- Join to get 100% vehicle info (not 18%)
        {sentiment_joins}                           -- Optional: join sentiment table if requested
        WHERE {where_clause}                        -- Apply date filters and vehicle filters
          AND m.ModelVehicleLine IS NOT NULL        -- Ensure we have vehicle data
          AND m.ModelVehicleLine NOT IN ('No Match Found', 'No Vehicle', '')  -- Filter out bad data
        GROUP BY m.ModelVehicleLine, m.Model_Year   --  FIXED: Group by both vehicle AND year
    ),
    ranked_vehicles AS (
        SELECT
            *,                                      -- All columns from vehicle_stats
            RANK() OVER (ORDER BY call_count DESC) as volume_rank,     -- Rank #1, #2, #3 by call volume
            ROUND(CASE WHEN SUM(call_count) OVER () > 0 THEN call_count * 100.0 / SUM(call_count) OVER () ELSE 0 END, 2) as pct_of_total  -- What % of total calls
        FROM vehicle_stats
        WHERE call_count >= 5                      -- Only include vehicles with at least 5 calls (reliable data)
    )
    SELECT * FROM ranked_vehicles
    ORDER BY call_count DESC                       -- Show highest call volume first
    LIMIT 500                                      -- Return top 500 (covers all vehicles + longer time periods)
    """

    with conn.cursor() as cursor:
        cursor.execute(query, params)
        rows = cursor.fetchall()
        columns = [d[0] for d in cursor.description]

    # Process results with intelligence
    vehicles = []
    for row in rows:
        vehicle_data = dict(zip(columns, [serialize(v) for v in row]))

        # Add intelligence features
        if include_sentiment and ford_thresholds:
            vehicle_name = vehicle_data["vehicle"].upper()
            if vehicle_name in ford_thresholds.get("sentiment_thresholds", {}).get("by_vehicle", {}):
                baseline = ford_thresholds["sentiment_thresholds"]["by_vehicle"][vehicle_name]["average"]
                current_sentiment = vehicle_data.get("avg_customer_sentiment", 0)

                if current_sentiment > baseline + 0.05:
                    vehicle_data["sentiment_vs_baseline"] = "better_than_normal"
                elif current_sentiment < baseline - 0.05:
                    vehicle_data["sentiment_vs_baseline"] = "worse_than_normal"
                else:
                    vehicle_data["sentiment_vs_baseline"] = "normal"

                vehicle_data["baseline_sentiment"] = baseline

        # Spike detection logic
        if detect_spikes and ford_thresholds:
            call_count = vehicle_data["call_count"]
            days_analyzed = vehicle_data["days_with_calls"]
            avg_daily_calls = call_count / max(days_analyzed, 1)

            # Use context-aware thresholds
            if business_days_only:
                baseline_avg = ford_thresholds["volume_thresholds"]["business_day"]["baseline_avg"]
                medium_threshold = ford_thresholds["volume_thresholds"]["business_day"]["medium"]
                high_threshold = ford_thresholds["volume_thresholds"]["business_day"]["high"]
            else:
                # Mixed business/weekend analysis - use blended baseline
                baseline_avg = (ford_thresholds["volume_thresholds"]["business_day"]["baseline_avg"] * 5 +
                              ford_thresholds["volume_thresholds"]["weekend"]["baseline_avg"] * 2) / 7
                medium_threshold = baseline_avg * 0.15  # 15% of blended average
                high_threshold = baseline_avg * 0.25    # 25% of blended average

            if avg_daily_calls > high_threshold:
                vehicle_data["volume_classification"] = "high_volume"
            elif avg_daily_calls > medium_threshold:
                vehicle_data["volume_classification"] = "medium_volume"
            else:
                vehicle_data["volume_classification"] = "normal_volume"

        vehicles.append(vehicle_data)

    return vehicles


def get_time_series_with_context(conn, date_from, date_to, group_by="week", vehicle_filter=None,
                               include_sentiment=False, detect_spikes=False, business_days_only=False,
                               ford_thresholds=None):
    """Enhanced time series with context-aware analysis and spike detection."""

    # Build date truncation based on grouping
    if group_by == "day":
        date_trunc = "DATE(cd.call_date)"
    elif group_by == "week":
        date_trunc = "DATE_TRUNC('week', cd.call_date)"
    else:  # month
        date_trunc = "DATE_TRUNC('month', cd.call_date)"

    # Build WHERE conditions
    where_conditions = [
        "DATE(cd.call_date) >= :date_from",
        "DATE(cd.call_date) <= :date_to",
        "m.ModelVehicleLine IS NOT NULL"
    ]

    params = {"date_from": date_from, "date_to": date_to}

    if vehicle_filter:
        where_conditions.append("LOWER(m.ModelVehicleLine) LIKE LOWER(:vehicle)")
        params["vehicle"] = f"%{vehicle_filter}%"

    if business_days_only:
        where_conditions.append("DAYOFWEEK(cd.call_date) NOT IN (1, 7)")

    where_clause = " AND ".join(where_conditions)

    # Enhanced sentiment integration
    sentiment_fields = ""
    sentiment_joins = ""
    if include_sentiment:
        sentiment_fields = """
            , ROUND(AVG(sent.customer_sentiment), 3) as avg_sentiment
            , COUNT(sent.customer_sentiment) as sentiment_sample_size
        """
        sentiment_joins = f"LEFT JOIN {SENTIMENTS} sent ON cd.call_id = sent.call_id"

    query = f"""
    WITH time_series AS (
        SELECT
            {date_trunc} as period,
            COUNT(cd.call_id) as call_count,
            AVG(CASE WHEN DAYOFWEEK(cd.call_date) IN (1, 7) THEN 0 ELSE 1 END) as business_day_ratio
            {sentiment_fields}
        FROM {CALL_DATA} cd
        INNER JOIN {MODELS} m ON cd.call_id = m.call_id
        {sentiment_joins}
        WHERE {where_clause}
          AND m.ModelVehicleLine IS NOT NULL
          AND m.ModelVehicleLine NOT IN ('No Match Found', 'No Vehicle', '')  -- Only real vehicles
        GROUP BY {date_trunc}
        ORDER BY {date_trunc}
    )
    SELECT
        period,
        call_count,
        business_day_ratio,
        LAG(call_count) OVER (ORDER BY period) as prev_period_calls
        {"" if not include_sentiment else ", avg_sentiment, sentiment_sample_size"}
    FROM time_series
    """

    with conn.cursor() as cursor:
        cursor.execute(query, params)
        rows = cursor.fetchall()
        columns = [d[0] for d in cursor.description]

    # Process with intelligence
    time_series = []
    for row in rows:
        period_data = dict(zip(columns, [serialize(v) for v in row]))

        # Add context intelligence
        call_count = period_data["call_count"]
        is_mostly_business_days = period_data.get("business_day_ratio", 0.7) > 0.5

        # Context-aware baseline comparison
        if detect_spikes and ford_thresholds:
            if is_mostly_business_days:
                baseline = ford_thresholds["volume_thresholds"]["business_day"]["baseline_avg"]
                if group_by == "week":
                    baseline *= 5  # 5 business days per week
                elif group_by == "month":
                    baseline *= 22  # ~22 business days per month

                medium_threshold = ford_thresholds["volume_thresholds"]["business_day"]["medium"]
                high_threshold = ford_thresholds["volume_thresholds"]["business_day"]["high"]
            else:
                baseline = ford_thresholds["volume_thresholds"]["weekend"]["baseline_avg"]
                if group_by == "week":
                    baseline *= 7  # Full week
                elif group_by == "month":
                    baseline *= 30  # ~30 days per month

                medium_threshold = ford_thresholds["volume_thresholds"]["weekend"]["medium"]
                high_threshold = ford_thresholds["volume_thresholds"]["weekend"]["high"]

            # Adjust thresholds for time period
            if group_by == "week":
                medium_threshold *= (5 if is_mostly_business_days else 7)
                high_threshold *= (5 if is_mostly_business_days else 7)
            elif group_by == "month":
                medium_threshold *= (22 if is_mostly_business_days else 30)
                high_threshold *= (22 if is_mostly_business_days else 30)

            # Classify volume level
            if call_count > high_threshold:
                period_data["volume_level"] = "high"
                period_data["spike_detected"] = True
            elif call_count > medium_threshold:
                period_data["volume_level"] = "medium"
                period_data["spike_detected"] = False
            else:
                period_data["volume_level"] = "normal"
                period_data["spike_detected"] = False

            # Calculate percentage vs baseline
            period_data["vs_baseline_pct"] = round((call_count - baseline) * 100.0 / baseline, 1)

        # Period-over-period change
        if period_data.get("prev_period_calls"):
            prev_calls = period_data["prev_period_calls"]
            pct_change = round((call_count - prev_calls) * 100.0 / prev_calls, 1)
            period_data["period_over_period_pct"] = pct_change

        time_series.append(period_data)

    return time_series


def get_comparative_analysis(conn, date_from, date_to, vehicle_filter=None, include_sentiment=False):
    """Year-over-year or equivalent period comparison with proper temporal alignment."""

    # Calculate equivalent comparison period (same duration, previous year)
    start_date = datetime.strptime(date_from, "%Y-%m-%d").date()
    end_date = datetime.strptime(date_to, "%Y-%m-%d").date()
    duration_days = (end_date - start_date).days

    # Previous year equivalent period
    prev_start = start_date.replace(year=start_date.year - 1)
    prev_end = prev_start + timedelta(days=duration_days)

    where_conditions = ["m.ModelVehicleLine IS NOT NULL"]
    params = {
        "current_from": date_from, "current_to": date_to,
        "prev_from": prev_start.isoformat(), "prev_to": prev_end.isoformat()
    }

    if vehicle_filter:
        where_conditions.append("LOWER(m.ModelVehicleLine) LIKE LOWER(:vehicle)")
        params["vehicle"] = f"%{vehicle_filter}%"

    base_where = " AND ".join(where_conditions)

    sentiment_fields = ""
    sentiment_joins = ""
    if include_sentiment:
        sentiment_fields = """
            , ROUND(AVG(sent.customer_sentiment), 3) as avg_sentiment
            , COUNT(sent.customer_sentiment) as sentiment_count
        """
        sentiment_joins = f"LEFT JOIN {SENTIMENTS} sent ON cd.call_id = sent.call_id"

    query = f"""
    WITH current_period AS (
        SELECT
            m.ModelVehicleLine as vehicle,
            COUNT(cd.call_id) as current_calls
            {sentiment_fields}
        FROM {CALL_DATA} cd
        INNER JOIN {MODELS} m ON cd.call_id = m.call_id
        {sentiment_joins}
        WHERE {base_where}
          AND DATE(cd.call_date) >= :current_from
          AND DATE(cd.call_date) <= :current_to
        GROUP BY m.ModelVehicleLine
    ),
    previous_period AS (
        SELECT
            m.ModelVehicleLine as vehicle,
            COUNT(cd.call_id) as previous_calls
            {sentiment_fields.replace('avg_sentiment', 'prev_avg_sentiment').replace('sentiment_count', 'prev_sentiment_count') if include_sentiment else ''}
        FROM {CALL_DATA} cd
        INNER JOIN {MODELS} m ON cd.call_id = m.call_id
        {sentiment_joins}
        WHERE {base_where}
          AND DATE(cd.call_date) >= :prev_from
          AND DATE(cd.call_date) <= :prev_to
        GROUP BY m.ModelVehicleLine
    )
    SELECT
        COALESCE(c.vehicle, p.vehicle) as vehicle,
        COALESCE(c.current_calls, 0) as current_calls,
        COALESCE(p.previous_calls, 0) as previous_calls,
        CASE
            WHEN p.previous_calls > 0 THEN
                ROUND((c.current_calls - p.previous_calls) * 100.0 / p.previous_calls, 1)
            ELSE NULL
        END as pct_change
        {', c.avg_sentiment, p.prev_avg_sentiment' if include_sentiment else ''}
    FROM current_period c
    FULL OUTER JOIN previous_period p ON c.vehicle = p.vehicle
    WHERE COALESCE(c.current_calls, 0) + COALESCE(p.previous_calls, 0) >= 5
    ORDER BY COALESCE(c.current_calls, 0) DESC
    LIMIT 25
    """

    with conn.cursor() as cursor:
        cursor.execute(query, params)
        rows = cursor.fetchall()
        columns = [d[0] for d in cursor.description]

    comparisons = []
    for row in rows:
        comp_data = dict(zip(columns, [serialize(v) for v in row]))

        # Add change significance classification
        pct_change = comp_data.get("pct_change")
        if pct_change is not None:
            if abs(pct_change) > 50:
                comp_data["change_significance"] = "major"
            elif abs(pct_change) > 25:
                comp_data["change_significance"] = "significant"
            elif abs(pct_change) > 10:
                comp_data["change_significance"] = "moderate"
            else:
                comp_data["change_significance"] = "minimal"

        # Sentiment change analysis
        if include_sentiment and comp_data.get("avg_sentiment") and comp_data.get("prev_avg_sentiment"):
            sentiment_change = comp_data["avg_sentiment"] - comp_data["prev_avg_sentiment"]
            comp_data["sentiment_change"] = round(sentiment_change, 3)
            comp_data["sentiment_improved"] = sentiment_change > 0.02  # Meaningful improvement threshold

        comparisons.append(comp_data)

    return {
        "comparison_period": {
            "current": {"from": date_from, "to": date_to},
            "previous": {"from": prev_start.isoformat(), "to": prev_end.isoformat()}
        },
        "vehicles": comparisons
    }


def main():
    parser = argparse.ArgumentParser(description="Enhanced Vehicle Volume Analytics with Complete Data & Intelligence")
    parser.add_argument("--from", dest="date_from", required=True, help="Start date (YYYY-MM-DD)")
    parser.add_argument("--to", dest="date_to", required=True, help="End date (YYYY-MM-DD)")
    parser.add_argument("--vehicle", dest="vehicle", default=None, help="Filter to specific vehicle")
    parser.add_argument("--group-by", dest="group_by", choices=["day", "week", "month"], default="week", help="Time granularity")
    parser.add_argument("--by-model", dest="by_model", action="store_true", help="Return ranking by vehicle model")
    parser.add_argument("--compare-previous", dest="compare_previous", action="store_true", help="Compare to equivalent prior period")
    parser.add_argument("--include-sentiment", dest="include_sentiment", action="store_true", help="Include sentiment analysis overlay")
    parser.add_argument("--detect-spikes", dest="detect_spikes", action="store_true", help="Apply Ford-validated spike detection")
    parser.add_argument("--business-days-only", dest="business_days_only", action="store_true", help="Filter to business days only")

    args, _ = parser.parse_known_args()

    # Load Ford-validated thresholds
    ford_thresholds = load_ford_thresholds()

    try:
        with get_connection() as conn:

            # Data quality validation
            quality_stats = get_data_quality_stats(conn, args.date_from, args.date_to)

            result = {
                "metadata": {
                    "analysis_period": {"from": args.date_from, "to": args.date_to},
                    "vehicle_filter": args.vehicle,
                    "business_days_only": args.business_days_only,
                    "enhancements_enabled": {
                        "sentiment_overlay": args.include_sentiment,
                        "spike_detection": args.detect_spikes,
                        "ford_thresholds": ford_thresholds is not None
                    }
                },
                "data_quality": quality_stats
            }

            # Execute appropriate analysis
            if args.compare_previous:
                comparison_data = get_comparative_analysis(
                    conn, args.date_from, args.date_to, args.vehicle, args.include_sentiment
                )
                result["comparative_analysis"] = comparison_data

            elif args.by_model:
                vehicles = get_vehicle_ranking_with_intelligence(
                    conn, args.date_from, args.date_to, args.vehicle,
                    args.include_sentiment, args.detect_spikes, args.business_days_only, ford_thresholds
                )
                result["vehicles"] = vehicles

            else:
                time_series = get_time_series_with_context(
                    conn, args.date_from, args.date_to, args.group_by, args.vehicle,
                    args.include_sentiment, args.detect_spikes, args.business_days_only, ford_thresholds
                )
                result["time_series"] = time_series

            # Data completeness warnings
            if quality_stats["vehicle_coverage_pct"] < 90:
                result["warnings"] = [f"Vehicle data coverage is {quality_stats['vehicle_coverage_pct']}% - results may be incomplete"]

            # Debug JSON serialization
            try:
                print(json.dumps(result, indent=2))
            except TypeError as e:
                print(f" JSON Error: {e}", file=sys.stderr)
                print(" Checking each field...", file=sys.stderr)
                for key, value in result.items():
                    try:
                        json.dumps({key: value})
                        print(f" {key}: OK", file=sys.stderr)
                    except TypeError:
                        print(f" {key}: {type(value)} - {value}", file=sys.stderr)
                        if isinstance(value, list) and value:
                            print(f"   First item: {type(value[0])}", file=sys.stderr)
                sys.exit(1)

    except Exception as e:
        error_response = {
            "error": str(e),
            "error_type": type(e).__name__,
            "suggestion": "Check date format (YYYY-MM-DD) and database connectivity"
        }
        print(json.dumps(error_response), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()