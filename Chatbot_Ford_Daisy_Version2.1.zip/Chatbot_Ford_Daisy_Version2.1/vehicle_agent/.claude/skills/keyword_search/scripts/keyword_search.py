"""
Enhanced Keyword Search - PRODUCTION VERSION

Multi-dimensional semantic search using Qwen embeddings with comprehensive multi-table intelligence,
data-driven business classification, and actionable insights across all Ford vehicle data.

Usage:
    python keyword_search.py --keyword "brake issues" --include-insights
    python keyword_search.py --keyword "NHTSA,VOQ" --by-vehicle --include-insights
    python keyword_search.py --keyword "transmission problems" --vehicle "F-150" --include-insights
    python keyword_search.py --keyword "charger problems" --semantic-limit 5000 --include-insights
"""
import argparse
import json
import os
import sys
import numpy as np
from pathlib import Path
from databricks import sql
# Import vector search with fallback - try multiple approaches
try:
    from databricks.vector_search.client import VectorSearchClient
    from databricks.sdk import WorkspaceClient
    VECTOR_SEARCH_AVAILABLE = True
    VECTOR_SEARCH_METHOD = "databricks_vector_search"
except ImportError:
    try:
        # Alternative: try direct databricks SDK approach
        from databricks.sdk import WorkspaceClient
        from databricks.sdk.core import Config
        VECTOR_SEARCH_AVAILABLE = True
        VECTOR_SEARCH_METHOD = "databricks_sdk"
    except ImportError:
        VECTOR_SEARCH_AVAILABLE = False
        VECTOR_SEARCH_METHOD = None
import requests
from dotenv import load_dotenv
from decimal import Decimal

load_dotenv(Path(__file__).resolve().parents[5] / ".env", override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


def get_vector_search_client():
    if not VECTOR_SEARCH_AVAILABLE:
        return None

    if VECTOR_SEARCH_METHOD == "databricks_vector_search":
        from databricks.sdk.core import Config
        cfg = Config()
        return VectorSearchClient(
            workspace_url=cfg.host,
            service_principal_client_id=cfg.client_id,
            service_principal_client_secret=cfg.client_secret
        )
    elif VECTOR_SEARCH_METHOD == "databricks_sdk":
        # Use alternative SDK-based approach
        from databricks.sdk.core import Config
        cfg = Config(
            host=os.environ.get("DATABRICKS_HOST"),
            client_id=os.environ.get("DATABRICKS_CLIENT_ID"),
            client_secret=os.environ.get("DATABRICKS_CLIENT_SECRET")
        )
        # Try to create a simulated vector search client
        return cfg
    return None


def cosine_similarity_batch(query_vec, matrix):
    """Vectorized cosine similarity: query_vec (1D) vs matrix (2D rows)."""
    query_norm = np.linalg.norm(query_vec)
    if query_norm == 0:
        return np.zeros(matrix.shape[0])
    row_norms = np.linalg.norm(matrix, axis=1)
    # Avoid division by zero
    row_norms = np.where(row_norms == 0, 1e-10, row_norms)
    dots = matrix @ query_vec
    return dots / (row_norms * query_norm)


def get_semantic_call_ids(query_embedding, similarity_threshold=0.4, limit=1000,
                          date_from="2020-01-01", date_to="2030-12-31",
                          keywords=None):
    """
    HYBRID semantic search: pre-filter by keyword on summary, then rank by
    cosine similarity. This processes only relevant candidates instead of
    scanning millions of rows.

    If keywords are provided, candidates are limited to rows whose summary
    matches at least one keyword (LIKE). Otherwise, scans recent data in
    batches (limited to 50K rows).
    """
    query_vec = np.array(query_embedding, dtype=np.float32)
    all_similarities = []  # list of (call_id, similarity)

    with get_connection() as conn:
        with conn.cursor() as cursor:
            # ── Build pre-filter ──────────────────────────────────
            keyword_filter = ""
            emb_params = {"date_from": date_from, "date_to": date_to}

            if keywords:
                kw_parts = [k.strip() for k in keywords if k.strip()]
                if kw_parts:
                    kw_conds = []
                    for i, kw in enumerate(kw_parts):
                        emb_params[f"kw{i}"] = f"%{kw}%"
                        kw_conds.append(f"LOWER(summary) LIKE LOWER(:kw{i})")
                    keyword_filter = f"AND ({' OR '.join(kw_conds)})"
                    print(f"Pre-filtering by keywords: {kw_parts}", file=sys.stderr)

            # Fetch candidate embeddings (pre-filtered by keyword if available)
            batch_size = 2000
            offset = 0
            max_rows = 50000  # Safety cap

            while offset < max_rows:
                query = f"""
                    SELECT call_id, embeddings
                    FROM {EMBEDDING_TABLE}
                    WHERE call_date >= :date_from
                      AND call_date <= :date_to
                      {keyword_filter}
                    ORDER BY call_date DESC
                    LIMIT {batch_size} OFFSET {offset}
                """
                cursor.execute(query, emb_params)
                rows = cursor.fetchall()
                if not rows:
                    break

                # Parse embeddings — array<double> comes back as Python list
                call_ids_batch = []
                emb_batch = []
                for call_id, emb in rows:
                    if emb and len(emb) == len(query_vec):
                        call_ids_batch.append(call_id)
                        emb_batch.append(emb)

                if emb_batch:
                    emb_matrix = np.array(emb_batch, dtype=np.float32)
                    sims = cosine_similarity_batch(query_vec, emb_matrix)
                    for idx, sim in enumerate(sims):
                        if sim >= similarity_threshold:
                            all_similarities.append((call_ids_batch[idx], float(sim)))

                print(f"Processed {offset + len(rows)} candidates, {len(all_similarities)} above threshold", file=sys.stderr)
                offset += batch_size

                # Early exit if we have enough high-quality matches
                if len(all_similarities) >= limit * 3:
                    break

    # Sort by similarity descending and take top N
    all_similarities.sort(key=lambda x: x[1], reverse=True)
    semantic_call_ids = [cid for cid, _ in all_similarities[:limit]]

    print(f"Semantic search: {len(all_similarities)} total matches, returning top {len(semantic_call_ids)}", file=sys.stderr)
    return semantic_call_ids


def _get_embedding(query_str: str) -> list[float]:
    """Get query embedding using Qwen/Qwen3-Embedding-0.6B serving endpoint."""

    # Method 1: Databricks serving endpoint (preferred — same model used for table embeddings)
    try:
        from databricks.sdk import WorkspaceClient as _WC
        w = _WC(
            host=os.environ.get("DATABRICKS_HOST"),
            client_id=os.environ.get("DATABRICKS_CLIENT_ID"),
            client_secret=os.environ.get("DATABRICKS_CLIENT_SECRET")
        )
        response = w.serving_endpoints.query(
            name="qwen3-embedding-06b",
            instances=[query_str]
        )
        return response.predictions[0]
    except Exception as e:
        print(f"Databricks Qwen embedding endpoint failed: {e}", file=sys.stderr)

    # Method 2: Local Qwen 0.6B model (fallback if endpoint unavailable)
    try:
        from sentence_transformers import SentenceTransformer
        model = SentenceTransformer(
            "Qwen/Qwen3-Embedding-0.6B",
            processor_kwargs={"padding_side": "left"}
        )
        embedding = model.encode([query_str])
        return embedding[0].tolist()
    except Exception as e:
        print(f"Local Qwen 0.6B model also failed: {e}", file=sys.stderr)
        return None


# Enhanced table configuration with all available Ford data
CATALOG = os.environ.get("DATABRICKS_CATALOG", "text_analytics")
SCHEMA = os.environ.get("DATABRICKS_SCHEMA", "nlp_analytics")
CALL_DATA = f"{CATALOG}.{SCHEMA}.call_data"
CALL_TABLE = f"{CATALOG}.{SCHEMA}.call_table"
PARTS_UNFILTERED = f"{CATALOG}.{SCHEMA}.parts_unfiltered"
PARTS_ACCESSORIES = f"{CATALOG}.{SCHEMA}.parts_accessories"
MODELS = f"{CATALOG}.{SCHEMA}.models"
V_PAIN_POINTS2 = f"{CATALOG}.restensl.v_pain_points2"
SENTIMENTS = f"{CATALOG}.{SCHEMA}.sentiments"
EMBEDDING_TABLE = f"{CATALOG}.nlp_agent.call_summary_qwen06b"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--keyword", required=True, help="Keyword(s) to search for (comma-separated)")
    parser.add_argument("--from", dest="date_from", default=None)
    parser.add_argument("--to", dest="date_to", default=None)
    parser.add_argument("--vehicle", dest="vehicle", default=None)
    parser.add_argument("--by-vehicle", dest="by_vehicle", action="store_true")
    parser.add_argument("--similarity-threshold", type=float, default=0.4,
                        help="Minimum similarity score for semantic matching (0.0-1.0)")
    parser.add_argument("--semantic-limit", type=int, default=10000,
                        help="Max semantic matches to analyze (higher = more comprehensive)")
    parser.add_argument("--limit", type=int, default=20)
    parser.add_argument("--include-insights", action="store_true",
                        help="Include AI-powered insights and business context")
    args, _ = parser.parse_known_args()

    # Parse keywords
    raw_keywords = [k.strip() for k in args.keyword.split(',') if k.strip()]
    search_query = " ".join(raw_keywords)

    # Build parameters
    params = {"date_from": args.date_from or "2020-01-01", "date_to": args.date_to or "2030-12-31"}
    filters = [
        "cd.call_date >= :date_from",
        "cd.call_date <= :date_to"
    ]

    if args.vehicle:
        params["vehicle"] = f"%{args.vehicle}%"
        # Use models table as PRIMARY source, fallback to call_data (following data quality report)
        filters.append("(LOWER(COALESCE(m.ModelVehicleLine, cd.modelvehicleline)) LIKE LOWER(:vehicle))")

    where_clause = " AND ".join(filters)

    # ── STEP 1: DISCOVER MATCHING CALL IDS ────────────────────────
    # Try multiple methods in priority order; all feed into the SAME full analysis.
    semantic_call_ids = []
    search_method = "unknown"

    # Method A: True semantic search — Qwen embeddings + cosine similarity
    try:
        print(f"Attempting Qwen semantic search for: {search_query}", file=sys.stderr)
        query_embedding = _get_embedding(f"find calls related to: {search_query}")
        if query_embedding:
            print(f"Embedding generated (dim={len(query_embedding)}). Computing similarities...", file=sys.stderr)
            semantic_call_ids = get_semantic_call_ids(
                query_embedding=query_embedding,
                similarity_threshold=args.similarity_threshold,
                limit=args.semantic_limit,
                date_from=params["date_from"],
                date_to=params["date_to"],
                keywords=raw_keywords
            )
            if semantic_call_ids:
                search_method = "true_cosine_similarity"
                print(f"Semantic search found {len(semantic_call_ids)} matches", file=sys.stderr)
    except Exception as e:
        print(f"Semantic search failed: {e}", file=sys.stderr)

    # Method B: LIKE search on embedding table summaries
    if not semantic_call_ids:
        try:
            print(f"Trying embedding table keyword search...", file=sys.stderr)
            with get_connection() as conn:
                with conn.cursor() as cursor:
                    kw_terms = []
                    emb_params = {}
                    for i, k in enumerate(raw_keywords):
                        emb_params[f"kw{i}"] = f"%{k}%"
                        kw_terms.append(f"LOWER(e.summary) LIKE LOWER(:kw{i})")
                    kw_cond = " OR ".join(kw_terms)
                    emb_params.update(params)
                    cursor.execute(f"""
                        SELECT e.call_id
                        FROM {EMBEDDING_TABLE} e
                        WHERE ({kw_cond})
                          AND e.call_date >= :date_from AND e.call_date <= :date_to
                        LIMIT {args.semantic_limit}
                    """, emb_params)
                    results = cursor.fetchall()
                    semantic_call_ids = [row[0] for row in results]
                    if semantic_call_ids:
                        search_method = "embedding_table_keyword"
                        print(f"Embedding table search found {len(semantic_call_ids)} matches", file=sys.stderr)
        except Exception as e:
            print(f"Embedding table search failed: {e}", file=sys.stderr)

    # Method C: Traditional LIKE search on call_table (summaries + transcripts)
    if not semantic_call_ids:
        try:
            print(f"Trying traditional keyword search...", file=sys.stderr)
            with get_connection() as conn:
                with conn.cursor() as cursor:
                    kw_terms = []
                    like_params = {}
                    for i, k in enumerate(raw_keywords):
                        like_params[f"kw{i}"] = f"%{k}%"
                        kw_terms.append(f"(LOWER(ct.summary) LIKE LOWER(:kw{i}) OR LOWER(ct.transcript) LIKE LOWER(:kw{i}))")
                    kw_cond = " OR ".join(kw_terms)
                    like_params.update(params)
                    cursor.execute(f"""
                        SELECT DISTINCT ct.call_id
                        FROM {CALL_TABLE} ct
                        JOIN {CALL_DATA} cd ON ct.call_id = cd.call_id
                        LEFT JOIN {MODELS} m ON cd.call_id = m.call_id
                        WHERE ({kw_cond}) AND {where_clause}
                        LIMIT {args.semantic_limit}
                    """, like_params)
                    results = cursor.fetchall()
                    semantic_call_ids = [row[0] for row in results]
                    if semantic_call_ids:
                        search_method = "traditional_keyword"
                        print(f"Traditional search found {len(semantic_call_ids)} matches", file=sys.stderr)
        except Exception as e:
            print(f"Traditional search failed: {e}", file=sys.stderr)

    # No results from any method
    if not semantic_call_ids:
        print(json.dumps({
            "status": "success",
            "analysis_type": "enhanced_keyword_search",
            "keyword": search_query,
            "results": {"total_semantic_matches": 0},
            "message": "No matches found for the given criteria"
        }, indent=2))
        return

    # ── STEP 2: FULL MULTI-TABLE ANALYSIS ─────────────────────────
    # Runs identically regardless of which discovery method succeeded.
    try:
        # DATA-DRIVEN THRESHOLD CALCULATION
        threshold_query = f"""
            WITH ford_benchmarks AS (
                SELECT
                    COUNT(*) as total_calls,
                    AVG(CASE WHEN cd.sentiment_label = 'Negative' THEN 100.0 ELSE 0.0 END) as avg_negative_pct,
                    STDDEV(CASE WHEN cd.sentiment_label = 'Negative' THEN 100.0 ELSE 0.0 END) as negative_stddev,
                    AVG(cd.complexity) as avg_complexity,
                    STDDEV(cd.complexity) as complexity_stddev,
                    PERCENTILE(CASE WHEN cd.sentiment_label = 'Negative' THEN 100.0 ELSE 0.0 END, 0.75) as q3_negative,
                    PERCENTILE(CASE WHEN cd.sentiment_label = 'Negative' THEN 100.0 ELSE 0.0 END, 0.85) as p85_negative,
                    PERCENTILE(CASE WHEN cd.sentiment_label = 'Negative' THEN 100.0 ELSE 0.0 END, 0.95) as p95_negative
                FROM {CALL_DATA} cd
                LEFT JOIN {MODELS} m ON cd.call_id = m.call_id
                WHERE {where_clause}
            )
            SELECT * FROM ford_benchmarks
        """

        with get_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(threshold_query, params)
                thresholds = cursor.fetchone()

        # Extract data-driven thresholds
        avg_negative_pct = float(thresholds[1]) if thresholds[1] else 50.0
        negative_stddev = float(thresholds[2]) if thresholds[2] else 10.0
        high_negative_threshold = avg_negative_pct + negative_stddev
        critical_negative_threshold = avg_negative_pct + (2 * negative_stddev)
        p85_negative = float(thresholds[6]) if thresholds[6] else 75.0

        # Step 3: COMPREHENSIVE MULTI-TABLE ANALYSIS
        enhanced_query = f"""
            WITH semantic_matches AS (
                SELECT call_id, 1 as is_semantic_match
                FROM (VALUES {','.join([f"('{cid}')" for cid in semantic_call_ids])}) AS t(call_id)
            ),
            comprehensive_analysis AS (
                SELECT
                    cd.call_id,
                    cd.call_date,

                    -- PROPER VEHICLE IDENTIFICATION (Apple-to-Apple)
                    COALESCE(m.ModelVehicleLine, cd.modelvehicleline) as vehicle_line,
                    COALESCE(m.Model_Year, cd.modelyear) as model_year,

                    cd.sentiment_label,
                    cd.sentiment,
                    cd.complexity,
                    cd.handle_time,

                    -- Call metadata
                    ct.summary,
                    ct.agent_team,
                    ct.troubleshooting_phrases,
                    ct.escalation_phrases,
                    ct.electrical_technical_phrases,
                    ct.software_technical_phrases,
                    ct.red_flag_phrases,

                    -- COMPREHENSIVE PARTS INTELLIGENCE
                    COALESCE(pu.parts_features, pa.parts_features) as parts_features,
                    COALESCE(pu.parts_concern, pa.parts_concern) as parts_concern,

                    -- Determine if accessories-related
                    CASE WHEN pa.call_id IS NOT NULL THEN 1 ELSE 0 END as is_accessories_related,

                    -- Pain points and sentiment details
                    pp.pain_point,
                    pp.customer_feedback,
                    s.agent_sentiment,
                    s.customer_sentiment

                FROM {CALL_DATA} cd
                INNER JOIN semantic_matches sm ON cd.call_id = sm.call_id
                LEFT JOIN {MODELS} m ON cd.call_id = m.call_id
                LEFT JOIN {CALL_TABLE} ct ON cd.call_id = ct.call_id
                LEFT JOIN {PARTS_UNFILTERED} pu ON cd.call_id = pu.call_id
                LEFT JOIN {PARTS_ACCESSORIES} pa ON cd.call_id = pa.call_id
                LEFT JOIN {V_PAIN_POINTS2} pp ON cd.call_id = pp.call_id
                LEFT JOIN {SENTIMENTS} s ON cd.call_id = s.call_id
                WHERE {where_clause}
            ),
            keyword_analytics AS (
                SELECT
                    COUNT(*) AS total_semantic_matches,

                    -- Sentiment analysis with data-driven classification
                    COUNT(CASE WHEN sentiment_label = 'Negative' THEN 1 END) AS negative_calls,
                    ROUND(COUNT(CASE WHEN sentiment_label = 'Negative' THEN 1 END) * 100.0 / COUNT(*), 1) AS negative_pct,

                    -- Multi-dimensional correlation
                    COUNT(CASE WHEN parts_concern IS NOT NULL THEN 1 END) AS hardware_related_calls,
                    ROUND(COUNT(CASE WHEN parts_concern IS NOT NULL THEN 1 END) * 100.0 / COUNT(*), 1) AS hardware_pct,

                    COUNT(CASE WHEN is_accessories_related = 1 THEN 1 END) AS accessories_calls,
                    ROUND(COUNT(CASE WHEN is_accessories_related = 1 THEN 1 END) * 100.0 / COUNT(*), 1) AS accessories_pct,

                    COUNT(CASE WHEN pain_point IS NOT NULL THEN 1 END) AS pain_point_calls,
                    ROUND(COUNT(CASE WHEN pain_point IS NOT NULL THEN 1 END) * 100.0 / COUNT(*), 1) AS pain_point_pct,

                    -- Phrase-based intelligence (most reliable)
                    AVG(troubleshooting_phrases) AS avg_troubleshooting_phrases,
                    AVG(escalation_phrases) AS avg_escalation_phrases,
                    AVG(red_flag_phrases) AS avg_red_flag_phrases,
                    COUNT(CASE WHEN escalation_phrases > 0 THEN 1 END) AS escalated_calls,

                    -- Business metrics
                    AVG(complexity) AS avg_complexity,
                    AVG(handle_time) AS avg_handle_time_min,
                    ROUND(AVG(sentiment), 4) AS avg_sentiment_score,

                    -- Vehicle diversity
                    COUNT(DISTINCT vehicle_line) AS unique_vehicles,

                    -- Sample data for context
                    MAX(CASE WHEN sentiment_label = 'Negative' THEN summary END) AS sample_negative_summary,
                    MAX(CASE WHEN parts_concern IS NOT NULL THEN parts_concern END) AS sample_hardware_issue,
                    MAX(CASE WHEN is_accessories_related = 1 THEN parts_features END) AS sample_accessory_issue,
                    MAX(pain_point) AS sample_pain_point,
                    MAX(customer_feedback) AS sample_customer_voice

                FROM comprehensive_analysis
            )
            SELECT
                ka.*,

                -- DATA-DRIVEN BUSINESS CLASSIFICATION using actual Ford thresholds
                CASE
                    WHEN ka.negative_pct >= {p85_negative} AND ka.hardware_pct > 20.0
                    THEN 'KEYWORD_HARDWARE_CRISIS'
                    WHEN ka.negative_pct >= {critical_negative_threshold}
                    THEN 'KEYWORD_CRITICAL_NEGATIVE'
                    WHEN ka.negative_pct >= {high_negative_threshold}
                    THEN 'KEYWORD_HIGH_NEGATIVE'
                    WHEN ka.accessories_pct > 30.0
                    THEN 'KEYWORD_ACCESSORIES_FOCUSED'
                    WHEN ka.hardware_pct > 25.0
                    THEN 'KEYWORD_HARDWARE_FOCUSED'
                    WHEN ka.avg_escalation_phrases > 2.0
                    THEN 'KEYWORD_ESCALATION_PATTERN'
                    ELSE 'KEYWORD_STANDARD'
                END AS keyword_classification,

                -- BUSINESS PRIORITY SCORE (data-driven weighting)
                ROUND((
                    (ka.negative_pct / {avg_negative_pct}) * 40 +
                    (ka.hardware_pct / 15.0) * 30 +
                    (ka.accessories_pct / 10.0) * 15 +
                    (ka.avg_escalation_phrases / 1.0) * 15
                ), 1) AS keyword_priority_score

            FROM keyword_analytics ka
        """

        with get_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(enhanced_query, params)
                rows = cursor.fetchall()
                columns = [d[0] for d in cursor.description]

        # JSON serialization
        def serialize_value(value):
            if isinstance(value, Decimal):
                return float(value)
            elif hasattr(value, "isoformat"):
                return str(value)
            elif value is None:
                return None
            else:
                return value

        result = []
        for row in rows:
            row_dict = {}
            for i, value in enumerate(row):
                row_dict[columns[i]] = serialize_value(value)
            result.append(row_dict)

        # VEHICLE BREAKDOWN with proper model identification (ALWAYS INCLUDED FOR BUSINESS INTELLIGENCE)
        vehicle_breakdown = []
        if result:  # Always include vehicle breakdown when we have results
            vehicle_query = f"""
                SELECT
                    COALESCE(m.ModelVehicleLine, cd.modelvehicleline) as vehicle_line,
                    COUNT(*) AS call_count,
                    ROUND(COUNT(CASE WHEN cd.sentiment_label = 'Negative' THEN 1 END) * 100.0 / COUNT(*), 1) AS negative_pct,
                    ROUND(AVG(ct.escalation_phrases), 1) AS avg_escalation_phrases,
                    COUNT(CASE WHEN pa.call_id IS NOT NULL THEN 1 END) AS accessories_calls
                FROM {CALL_DATA} cd
                INNER JOIN (VALUES {','.join([f"('{cid}')" for cid in semantic_call_ids])}) AS sm(call_id) ON cd.call_id = sm.call_id
                LEFT JOIN {MODELS} m ON cd.call_id = m.call_id
                LEFT JOIN {CALL_TABLE} ct ON cd.call_id = ct.call_id
                LEFT JOIN {PARTS_ACCESSORIES} pa ON cd.call_id = pa.call_id
                WHERE {where_clause}
                  AND COALESCE(m.ModelVehicleLine, cd.modelvehicleline) IS NOT NULL
                GROUP BY COALESCE(m.ModelVehicleLine, cd.modelvehicleline)
                ORDER BY call_count DESC
                LIMIT {args.limit}
            """

            # Use fresh connection to avoid "closed connection" errors
            with get_connection() as vehicle_conn:
                with vehicle_conn.cursor() as cursor:
                    cursor.execute(vehicle_query, params)
                    vehicle_rows = cursor.fetchall()
                    vehicle_breakdown = [
                    {
                        "modelvehicleline": row[0],
                        "call_count": row[1],
                        "negative_pct": float(row[2]) if row[2] is not None else 0.0,
                        "avg_escalation_phrases": float(row[3]) if row[3] is not None else 0.0,
                        "accessories_calls": row[4]
                    } for row in vehicle_rows
                ]

        # Build response
        if result:
            main_result = result[0]
            response = {
                "status": "success",
                "analysis_type": "enhanced_keyword_search",
                "parameters": {
                    "keyword": search_query,
                    "search_method": search_method,
                    "embedding_model": "Qwen/Qwen3-Embedding-0.6B" if search_method == "true_cosine_similarity" else "keyword_match",
                    "similarity_threshold": args.similarity_threshold,
                    "semantic_limit": args.semantic_limit,
                    "vehicle_filter": args.vehicle,
                    "date_range": {"from": params["date_from"], "to": params["date_to"]}
                },
                "thresholds_used": {
                    "avg_negative_pct": round(avg_negative_pct, 1),
                    "high_negative_threshold": round(high_negative_threshold, 1),
                    "critical_negative_threshold": round(critical_negative_threshold, 1),
                    "p85_negative": round(p85_negative, 1),
                    "data_driven": True
                },
                "results": {
                    "total_semantic_matches": main_result.get('total_semantic_matches', 0),
                    "negative_calls": main_result.get('negative_calls', 0),
                    "negative_pct": main_result.get('negative_pct', 0.0),
                    "hardware_related_calls": main_result.get('hardware_related_calls', 0),
                    "hardware_pct": main_result.get('hardware_pct', 0.0),
                    "accessories_calls": main_result.get('accessories_calls', 0),
                    "accessories_pct": main_result.get('accessories_pct', 0.0),
                    "escalated_calls": main_result.get('escalated_calls', 0),
                    "unique_vehicles": main_result.get('unique_vehicles', 0),
                    "keyword_classification": main_result.get('keyword_classification', 'UNKNOWN'),
                    "keyword_priority_score": main_result.get('keyword_priority_score', 0.0),
                    "sample_negative_summary": main_result.get('sample_negative_summary'),
                    "sample_hardware_issue": main_result.get('sample_hardware_issue'),
                    "sample_accessory_issue": main_result.get('sample_accessory_issue'),
                    "sample_pain_point": main_result.get('sample_pain_point'),
                    "sample_customer_voice": main_result.get('sample_customer_voice')
                }
            }

            # Always include vehicle breakdown for business intelligence
            if vehicle_breakdown:
                response["by_vehicle"] = vehicle_breakdown
            else:
                response["by_vehicle"] = []  # Empty array if no vehicle data found

        else:
            response = {
                "status": "success",
                "analysis_type": "enhanced_keyword_search",
                "results": {"total_semantic_matches": 0},
                "message": "No matches found for the given criteria"
            }

        # ENHANCED INSIGHTS with data-driven analysis
        if args.include_insights and result and main_result.get('total_semantic_matches', 0) > 0:
            insights = []
            recommendations = []

            classification = main_result.get('keyword_classification', 'UNKNOWN')
            total_calls = main_result.get('total_semantic_matches', 0)
            negative_pct = main_result.get('negative_pct', 0.0)
            hardware_pct = main_result.get('hardware_pct', 0.0)
            accessories_pct = main_result.get('accessories_pct', 0.0)
            unique_vehicles = main_result.get('unique_vehicles', 0)

            insights.append({
                "type": "info",
                "message": f"Comprehensive analysis: {total_calls} semantic matches across {unique_vehicles} vehicle models",
                "severity": "low",
                "supporting_data": f"Classification: {classification}"
            })

            # Classification-specific insights
            if classification == 'KEYWORD_HARDWARE_CRISIS':
                insights.append({
                    "type": "alert",
                    "message": f"CRITICAL: Hardware crisis detected for '{search_query}'",
                    "severity": "critical",
                    "supporting_data": f"{negative_pct}% negative sentiment, {hardware_pct}% hardware correlation"
                })
                recommendations.append({
                    "action": f"IMMEDIATE engineering escalation required for '{search_query}'",
                    "priority": "critical",
                    "estimated_impact": "Prevent widespread hardware failures"
                })

            elif classification == 'KEYWORD_ACCESSORIES_FOCUSED':
                insights.append({
                    "type": "info",
                    "message": f"High accessories correlation: {accessories_pct}% of calls involve accessories",
                    "severity": "medium",
                    "supporting_data": "May involve chargers, adapters, or aftermarket parts"
                })
                recommendations.append({
                    "action": f"Accessories supply chain review for '{search_query}'",
                    "priority": "medium",
                    "estimated_impact": "Improve accessories quality and availability"
                })

            elif classification == 'KEYWORD_CRITICAL_NEGATIVE':
                insights.append({
                    "type": "alert",
                    "message": f"Critical negative sentiment: {negative_pct}% negative calls (above 95th percentile)",
                    "severity": "high",
                    "supporting_data": "Customer satisfaction at critical levels"
                })

            elif classification == 'KEYWORD_HIGH_NEGATIVE':
                insights.append({
                    "type": "warning",
                    "message": f"High negative sentiment: {negative_pct}% negative calls",
                    "severity": "medium",
                    "supporting_data": "Above-average customer dissatisfaction"
                })

            response["insights"] = {
                "summary": {
                    "total_calls": total_calls,
                    "classification": classification,
                    "negative_sentiment_pct": negative_pct,
                    "hardware_correlation_pct": hardware_pct,
                    "accessories_correlation_pct": accessories_pct,
                    "vehicles_affected": unique_vehicles,
                    "thresholds_used": "data_driven"
                },
                "insights": insights,
                "recommendations": recommendations
            }

        print(json.dumps(response, indent=2))

    except Exception as e:
        # Full analysis SQL failed — provide simplified but still useful output
        print(f"Full analysis failed, using simplified fallback: {e}", file=sys.stderr)
        try:
            fallback_response = {
                "status": "success",
                "analysis_type": "simplified_keyword_search",
                "parameters": {"keyword": search_query, "search_method": search_method},
                "results": {"total_semantic_matches": len(semantic_call_ids)},
                "by_vehicle": [],
                "message": f"Found {len(semantic_call_ids)} matching calls. Full analysis unavailable."
            }
            # Try to get vehicle breakdown from discovered call_ids
            if semantic_call_ids:
                try:
                    call_id_list = "','" .join(semantic_call_ids[:5000])
                    with get_connection() as fb_conn:
                        with fb_conn.cursor() as fb_cursor:
                            fb_cursor.execute(f"""
                                SELECT
                                    COALESCE(m.ModelVehicleLine, cd.modelvehicleline) AS vehicle_line,
                                    COUNT(*) AS call_count,
                                    ROUND(COUNT(CASE WHEN cd.sentiment_label = 'Negative' THEN 1 END) * 100.0 / COUNT(*), 1) AS negative_pct
                                FROM {CALL_DATA} cd
                                LEFT JOIN {MODELS} m ON cd.call_id = m.call_id
                                WHERE cd.call_id IN ('{call_id_list}')
                                  AND COALESCE(m.ModelVehicleLine, cd.modelvehicleline) IS NOT NULL
                                GROUP BY COALESCE(m.ModelVehicleLine, cd.modelvehicleline)
                                ORDER BY call_count DESC
                                LIMIT 20
                            """, params)
                            vehicle_rows = fb_cursor.fetchall()
                            fallback_response["by_vehicle"] = [
                                {"modelvehicleline": r[0], "call_count": r[1], "negative_pct": float(r[2]) if r[2] else 0.0}
                                for r in vehicle_rows
                            ]
                except Exception as vb_err:
                    print(f"Vehicle breakdown fallback also failed: {vb_err}", file=sys.stderr)
            print(json.dumps(fallback_response, indent=2))
        except Exception:
            print(json.dumps({
                "status": "success",
                "analysis_type": "fallback_keyword_search",
                "parameters": {"keyword": search_query, "search_method": "fallback"},
                "results": {"total_semantic_matches": len(semantic_call_ids) if semantic_call_ids else 0}
            }, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)
