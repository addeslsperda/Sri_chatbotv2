---
name: keyword_search
display_name: Enhanced Keyword Search Intelligence
description: Production-grade semantic search using Qwen embeddings with comprehensive multi-table intelligence, data-driven business classification, and actionable insights across all Ford vehicle data. Use for advanced keyword analysis with hardware correlation, sentiment analysis, and business priority scoring.
signals:
  # KEYWORD ANALYSIS SIGNALS - Advanced intelligence focus
  - keyword analysis
  - keyword insights
  - keyword intelligence
  - enhanced keyword search
  - keyword correlation analysis
  - business impact of keyword
  - keyword priority analysis
  - keyword classification
  
  # SEMANTIC SEARCH SIGNALS - Qwen embedding focus  
  - semantic search for
  - semantic analysis of
  - embedding search for
  - contextual search for
  - smart search for
  - AI search for
  
  # BUSINESS INTELLIGENCE SIGNALS - Multi-table analysis
  - hardware correlation for
  - accessories correlation for
  - sentiment analysis for keyword
  - multi-table analysis for
  - comprehensive keyword analysis
  - production keyword intelligence
  
  # SPECIFIC PROBLEM ANALYSIS - Technical focus
  - brake issues intelligence
  - transmission analysis
  - NHTSA mentions analysis
  - recall keyword analysis
  - safety keyword analysis
  - quality keyword analysis
requires:
  - a keyword or phrase to search for
capabilities:
  - Semantic search using Qwen/Qwen3-Embedding-0.6B embeddings with 10K+ match analysis
  - Multi-table intelligence (call_data + parts_unfiltered + parts_accessories + models + v_pain_points2 + sentiments)  
  - VEHICLE BREAKDOWN BY DEFAULT: Always includes breakdown by vehicle model for business targeting
  - Data-driven threshold calculation using Ford-specific percentiles and standard deviations
  - Business classification (KEYWORD_HARDWARE_CRISIS, KEYWORD_ACCESSORIES_FOCUSED, etc.)
  - Apple-to-apple vehicle matching using models table for accurate identification  
  - Comprehensive correlation analysis across hardware, accessories, and sentiment dimensions
  - AI-powered insights with actionable recommendations based on business impact
not_good_for: Simple call counts (use vehicle_volume), real customer verbatim examples (use vehicle_examples)
---

# Enhanced Keyword Search Intelligence

## What this does
Performs semantic search using Qwen embeddings across all Ford vehicle data with comprehensive multi-table intelligence, data-driven business classification, and actionable insights for keyword-based analysis.

## Production Features
- Semantic search: Uses Databricks Qwen/Qwen3-Embedding-0.6B embeddings for intelligent matching
- Multi-table intelligence: Combines 7 data sources for comprehensive analysis
- Data-driven thresholds: Calculates Ford-specific benchmarks using percentiles and standard deviations
- Business classification: KEYWORD_HARDWARE_CRISIS, KEYWORD_ACCESSORIES_FOCUSED classifications
- Hardware correlation: Links keywords to parts_unfiltered + parts_accessories issues  
- Apple-to-apple comparison: Uses models table for accurate vehicle identification
- AI insights: Automated business impact assessment with actionable recommendations

## How to run it

```bash
python .claude/skills/keyword_search/scripts/keyword_search.py --keyword "brake issues" --include-insights
```

## Enhanced Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--keyword` | Yes |  | Keyword(s) to search for (comma-separated) |
| `--from` | No | all time | Start date YYYY-MM-DD |
| `--to` | No | all time | End date YYYY-MM-DD |
| `--vehicle` | No | all | Filter to a specific vehicle (partial match) |
| `--by-vehicle` | No | false | Break down results by vehicle model |
| `--similarity-threshold` | No | 0.4 | Minimum similarity score for semantic matching (0.0-1.0) |
| `--semantic-limit` | No | 10000 | Max semantic matches to analyze (higher = more comprehensive) |
| `--limit` | No | 20 | Number of vehicles to return when using `--by-vehicle` |
| `--include-insights` | No | false | Include AI-powered insights and business context |

## Example Usage

```bash
# Comprehensive brake issues analysis with business insights
python keyword_search.py --keyword "brake issues" --include-insights

# Multi-keyword NHTSA analysis with vehicle breakdown
python keyword_search.py --keyword "NHTSA,VOQ" --by-vehicle --include-insights

# Vehicle-specific transmission problems with high semantic matching
python keyword_search.py --keyword "transmission problems" --vehicle "F-150" --semantic-limit 5000 --include-insights

# Accessories analysis (chargers, adapters) with business classification
python keyword_search.py --keyword "charger problems,adapter issues" --include-insights

# High-precision semantic search with custom threshold
python keyword_search.py --keyword "steering failures" --similarity-threshold 0.6 --include-insights
```

## Enhanced Output Format

```json
{
  "status": "success",
  "analysis_type": "enhanced_keyword_search",
  "parameters": {
    "keyword": "brake issues",
    "search_method": "true_cosine_similarity",
    "similarity_threshold": 0.4,
    "semantic_limit": 10000,
    "vehicle_filter": null,
    "date_range": {"from": "2020-01-01", "to": "2030-12-31"}
  },
  "thresholds_used": {
    "avg_negative_pct": 48.3,
    "high_negative_threshold": 58.7,
    "critical_negative_threshold": 69.1,
    "p85_negative": 73.2,
    "data_driven": true
  },
  "results": {
    "total_semantic_matches": 1247,
    "negative_calls": 856,
    "negative_pct": 68.6,
    "hardware_related_calls": 634,
    "hardware_pct": 50.8,
    "accessories_calls": 89,
    "accessories_pct": 7.1,
    "escalated_calls": 156,
    "unique_vehicles": 12,
    "keyword_classification": "KEYWORD_HARDWARE_CRISIS",
    "keyword_priority_score": 187.3,
    "sample_negative_summary": "Customer reports brake pedal feels spongy and ABS warning light activated...",
    "sample_hardware_issue": "brake pad wear sensor malfunction causing false warnings",
    "sample_accessory_issue": "aftermarket brake pads not compatible with OEM system",
    "sample_pain_point": "Brake Performance Issues",
    "sample_customer_voice": "Brakes feel unsafe, pedal goes to floor sometimes"
  },
  "by_vehicle": [
    {
      "modelvehicleline": "F-SERIES",
      "call_count": 423,
      "negative_pct": 71.2,
      "avg_escalation_phrases": 2.8,
      "accessories_calls": 34
    }
  ],
  "insights": {
    "summary": {
      "total_calls": 1247,
      "classification": "KEYWORD_HARDWARE_CRISIS",
      "negative_sentiment_pct": 68.6,
      "hardware_correlation_pct": 50.8,
      "accessories_correlation_pct": 7.1,
      "vehicles_affected": 12,
      "thresholds_used": "data_driven"
    },
    "insights": [
      {
        "type": "alert",
        "message": "CRITICAL: Hardware crisis detected for 'brake issues'",
        "severity": "critical",
        "supporting_data": "68.6% negative sentiment, 50.8% hardware correlation"
      }
    ],
    "recommendations": [
      {
        "action": "IMMEDIATE engineering escalation required for 'brake issues'",
        "priority": "critical",
        "estimated_impact": "Prevent widespread hardware failures"
      }
    ]
  }
}
```

## Business Classifications

### Keyword Analysis Types
- KEYWORD_HARDWARE_CRISIS: P85 negative sentiment + >20% hardware correlation (critical engineering response)
- KEYWORD_CRITICAL_NEGATIVE: Above 95th percentile negative sentiment (urgent customer experience)
- KEYWORD_HIGH_NEGATIVE: Above average + 1 standard deviation (elevated attention)
- KEYWORD_ACCESSORIES_FOCUSED: >30% accessories correlation (supply chain focus)
- KEYWORD_HARDWARE_FOCUSED: >25% hardware correlation (engineering priority)
- KEYWORD_ESCALATION_PATTERN: Above-average escalation phrases (process improvement)
- KEYWORD_STANDARD: Normal operational performance

### Business Intelligence
- Semantic Discovery: Qwen embeddings find contextually related calls beyond literal keyword matching
- Multi-Dimensional Correlation: Hardware + accessories + sentiment + escalation analysis
- Data-Driven Thresholds: Ford-specific benchmarks calculated from actual data patterns
- Apple-to-Apple Comparison: Proper vehicle identification ensures accurate analysis
- Business Priority Scoring: Weighted scoring based on negative sentiment, hardware correlation, and business impact

## Key Use Cases

### Safety & Regulatory
- **"How many calls mention NHTSA or VOQ?"**  Regulatory compliance analysis with semantic discovery
- **"Brake issues analysis"**  Safety-critical hardware correlation with business impact assessment
- **"Steering problems breakdown"**  Multi-dimensional safety analysis across vehicle models

### Parts & Hardware Analysis  
- **"Transmission problems by vehicle"**  Hardware correlation analysis with data-driven thresholds
- **"Engine issues F-150"**  Vehicle-specific hardware intelligence with business classification
- **"Charger adapter problems"**  Accessories analysis differentiating hardware vs supply chain issues

### Business Intelligence
- **"Supervisor escalation patterns"**  Process improvement analysis with escalation correlation
- **"Lemon law mentions"**  Legal risk analysis with sentiment and hardware correlation
- **"Customer satisfaction keywords"**  Brand perception analysis with business impact scoring

## Technical Features

### Semantic Search Engine
- **Model**: Qwen/Qwen3-Embedding-0.6B (exact same model used for table embeddings)
- **Method**: True cosine similarity calculation with local model fallback
- **Processing**: Batch-based embedding comparison (5,000 embeddings per batch)
- **Fallback**: Databricks endpoint  local model  traditional LIKE search
- **Configurable Limits**: Up to 10K+ semantic matches for comprehensive coverage

### Multi-Table Intelligence
- **7 Data Sources**: call_data + call_table + parts_unfiltered + parts_accessories + models + v_pain_points2 + sentiments
- **Apple-to-Apple**: Proper vehicle matching via models table COALESCE logic
- **Hardware Correlation**: Parts + accessories analysis for component failure patterns
- **Sentiment Intelligence**: Agent vs customer sentiment differential analysis

### Data-Driven Approach
- **No Hardcoded Thresholds**: All benchmarks calculated from actual Ford data patterns
- **Percentile Analysis**: 75th, 85th, 95th percentiles for classification boundaries
- **Standard Deviation**: Statistical significance for threshold calculation
- **Ford-Specific**: Benchmarks derived from same date range and vehicle filters

## Error Handling
Enhanced error handling with semantic search fallbacks, comprehensive logging, and traditional keyword search backup for maximum reliability.

## Business Value
Enhanced keyword_search provides critical intelligence for:
- **Safety Analysis**: Early detection of safety-critical issues through semantic discovery
- **Engineering Priorities**: Data-driven hardware correlation analysis for resource allocation
- **Regulatory Compliance**: NHTSA/VOQ analysis with comprehensive context
- **Supply Chain Intelligence**: Accessories vs hardware issue differentiation
- **Customer Experience**: Multi-dimensional sentiment and escalation analysis
