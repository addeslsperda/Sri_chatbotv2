---
name: vin_history
display_name: Enhanced VIN Intelligence with Semantic Detection & Multi-Table Analysis
description: Comprehensive VIN-level call history using Qwen 0.6B semantic embeddings, 3-level topic classification, sentiment journey tracking, and multi-table intelligence. Tracks complete vehicle history, identifies lemon law candidates, and provides comprehensive VIN-based customer experience analytics. Use for "VIN call history", "lemon law candidates", "problem vehicle tracking", "VIN-based intelligence".
signals:
  - vin history
  - vin intelligence
  - vin tracking
  - lemon law analysis
  - vehicle call history
  - problem vehicle identification
  - vin-based analytics
  - vehicle timeline analysis
  - buyback candidate assessment
  - repeat issue tracking
  - vin sentiment analysis
  - vehicle-specific intelligence
  - comprehensive vin analytics
  - vin business intelligence
  - lemon law candidate identification
requires:
  - date range for temporal analysis
  - vin query OR min-calls threshold for lemon candidate identification
capabilities:
  - VIN-based semantic detection using Qwen/Qwen3-Embedding-0.6B embeddings AND 3-level topic classification
  - Complete call content analysis including summaries AND full transcripts for comprehensive VIN conversation understanding
  - Multi-table intelligence combining 8+ Ford data sources for comprehensive VIN context and vehicle history
  - Customer sentiment journey tracking from call start to end for VIN-specific experience measurement
  - Advanced lemon law assessment using semantic understanding of escalation patterns and repeat issues
  - Parts availability intelligence for identifying component-specific issues driving VIN problems
  - Agent team and case classification analysis for operational VIN handling insights
  - Business intelligence with actionable recommendations for VIN-based process improvement
  - User-query driven detection - searches for VIN patterns and issues based on semantic understanding
not_good_for: Model-level analysis (use vehicle_pain_points), general issues (use keyword_search), fleet analysis (use vehicle_volume)
---

# Enhanced VIN Intelligence with Semantic Detection & Multi-Table Analysis

## What this does
Provides comprehensive VIN-level call history analysis using dual detection methods (semantic embeddings + topic classification) with complete multi-table intelligence. Analyzes individual vehicle conversations including full transcripts, sentiment journeys, and business context to deliver actionable VIN-specific insights and advanced lemon law candidate assessment.

## Production Features
- **VIN-Focused Semantic Detection**: Combines Qwen 0.6B semantic search with VIN-specific topic classification for maximum vehicle history coverage
- **Complete Call Content Analysis**: Analyzes both call summaries AND full transcripts from call_table for comprehensive VIN conversation understanding
- **Multi-Table Intelligence**: Integrates 8+ Ford data sources including sentiments, vehicles, parts, cases, and agent teams for complete VIN context
- **Sentiment Journey Analysis**: Tracks customer and agent sentiment from call start to end during VIN-specific interactions
- **Advanced Lemon Law Assessment**: Semantic understanding of escalation patterns, repeat issues, and buyback indicators
- **Parts Intelligence Integration**: Component-specific analysis for identifying recurring VIN hardware issues
- **Business Classification Integration**: Correlates with case metadata and agent team performance for operational insights
- **Privacy-Preserved VIN Tracking**: Maintains VIN masking while providing comprehensive vehicle intelligence

## How to run it

```bash
# Specific VIN lookup
python .claude/skills/vin_history/scripts/vin_history.py --vin "12345" --from 2025-01-01 --to 2026-01-31

# Lemon law candidates 
python .claude/skills/vin_history/scripts/vin_history.py --from 2026-01-01 --to 2026-01-31 --min-calls 5
```

## Enhanced Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--vin` | No* | — | VIN to search (partial match supported, e.g., last 4 digits) |
| `--from` | Yes | — | Start date YYYY-MM-DD for temporal analysis |
| `--to` | Yes | — | End date YYYY-MM-DD for temporal analysis |
| `--vehicle` | No | all | Filter by specific vehicle model (partial match) |
| `--min-calls` | No | 5 | Minimum calls to flag as lemon candidate (when not using --vin) |
| `--similarity-threshold` | No | 0.4 | Minimum similarity score for semantic VIN matching (0.0-1.0) |
| `--limit` | No | 100 | Number of detailed examples to return (100 or 1000) |

*Either `--vin` OR `--min-calls` filter must be used

## Example Usage

```bash
# Specific VIN comprehensive history
python vin_history.py --vin "1FTFW1E84MKE12345" --from 2025-01-01 --to 2026-01-31

# Partial VIN search (last 4 digits)
python vin_history.py --vin "2345" --from 2026-01-01 --to 2026-01-31

# Lemon law candidates (5+ calls)
python vin_history.py --from 2026-01-01 --to 2026-01-31 --min-calls 5

# F-150 problem vehicles
python vin_history.py --from 2026-01-01 --to 2026-01-31 --vehicle "F-150" --min-calls 4

# High-precision semantic VIN analysis
python vin_history.py --vin "12345" --from 2026-01-01 --to 2026-01-31 --similarity-threshold 0.6

# Large-scale lemon candidate analysis
python vin_history.py --from 2026-01-01 --to 2026-01-31 --min-calls 3 --limit 1000

# Severe lemon cases (10+ calls)
python vin_history.py --from 2026-01-01 --to 2026-01-31 --min-calls 10

# Vehicle-specific lemon analysis
python vin_history.py --from 2026-01-01 --to 2026-01-31 --vehicle "Bronco" --min-calls 4
```

## Enhanced Output Format

### Specific VIN Lookup:
```json
{
  "vin_query": "12345",
  "vin_masked": "xxx-xxxx-2345",
  "parameters": {
    "search_method": "semantic_embeddings_plus_topics",
    "embedding_model": "Qwen/Qwen3-Embedding-0.6B",
    "similarity_threshold": 0.4,
    "topic_levels_analyzed": 3,
    "date_range": {"from": "2025-01-01", "to": "2026-01-31"},
    "vehicle_filter": "F-150"
  },
  "detection_summary": {
    "total_matches": 7,
    "semantic_matches": 5,
    "topic_matches": 2,
    "analyzed_examples": 7,
    "detection_methods": {
      "Semantic Detection": 5,
      "Topic Classification": 2
    }
  },
  "vehicle_information": {
    "vehicle_model": "F-150",
    "model_year": "2023",
    "vin_source": "call_data"
  },
  "call_summary": {
    "total_calls": 7,
    "first_call": "2025-03-15",
    "last_call": "2026-01-28",
    "days_span": 319,
    "avg_calls_per_month": 1.3
  },
  "sentiment_analysis": {
    "avg_customer_sentiment": -0.68,
    "sentiment_trajectory": "declining",
    "customer_start_sentiment": -0.40,
    "customer_end_sentiment": -0.95,
    "sentiment_decline": -0.55
  },
  "lemon_law_assessment": {
    "lemon_status": "strong_candidate",
    "priority": "high",
    "meets_criteria": true,
    "call_count_threshold": 4,
    "same_issue_repeating": true,
    "escalation_indicators": ["buyback_requested", "legal_mentions", "safety_concerns"],
    "recommendation": "Strong buyback candidate - 7 calls with declining sentiment"
  },
  "call_timeline": [
    {
      "call_number": 1,
      "call_date": "2025-03-15",
      "call_summary_preview": "Transmission slipping during acceleration, intermittent issue...",
      "call_transcript": "Customer: My F-150 transmission is slipping when I accelerate. Agent: I understand your concern about the transmission...",
      "vehicle_model": "F-150",
      "model_year": "2023",
      "agent_team": "MPH-CRC_Transmission_1",
      "case_level1": "Warranty",
      "topic_broad": "Vehicle Performance Issue",
      "topic_mid": "Transmission Problem",
      "topic_specific": "Transmission slipping during acceleration",
      "parts_concern": "Transmission Assembly",
      "customer_sentiment": -0.40,
      "agent_sentiment": 0.15,
      "sentiment_gap": -0.55,
      "complexity_score": 0.65,
      "number_of_transfers": 0,
      "handle_time_minutes": 8.5,
      "detection_method": "Semantic Detection"
    }
  ],
  "issue_analysis": {
    "primary_issue": "Transmission",
    "issue_occurrences": 5,
    "repair_attempts": 3,
    "issue_resolved": false,
    "parts_involved": ["Transmission Assembly", "Transmission Control Module"]
  },
  "data_sources": [
    "call_data (VIN source + core call information)",
    "sentiments (customer/agent sentiment journey)",
    "embedding_table (Qwen 0.6B semantic search)",
    "call_table (transcripts and agent teams)",
    "models (vehicle correlation)",
    "parts_unfiltered (component analysis)",
    "topic_detail (3-level topic hierarchy)",
    "case_metadata (business classification)"
  ]
}
```

### Lemon Candidates List:
```json
{
  "date_range": "2026-01-01 to 2026-01-31",
  "vehicle_filter": "all",
  "min_calls": 5,
  "parameters": {
    "search_method": "multi_table_intelligence",
    "lemon_assessment": "semantic_enhanced",
    "topic_levels_analyzed": 3
  },
  "summary": {
    "total_problem_vehicles": 42,
    "strong_candidates": 18,
    "monitoring_candidates": 24,
    "avg_calls_per_vehicle": 6.2
  },
  "lemon_candidates": [
    {
      "vin_masked": "xxx-xxxx-8397",
      "vehicle_model": "F-150",
      "model_year": "2023",
      "call_count": 9,
      "first_call": "2026-01-05",
      "last_call": "2026-01-30",
      "days_span": 25,
      "avg_customer_sentiment": -0.72,
      "sentiment_trajectory": "declining",
      "primary_issue": "Transmission",
      "parts_involved": ["Transmission Assembly", "Torque Converter"],
      "escalation_indicators": ["buyback_requested", "lemon_law_mentioned"],
      "agent_teams": ["MPH-CRC_Transmission_1", "MPH-CRC_Escalation_2"],
      "lemon_status": "strong_candidate",
      "priority": "high",
      "recommendation": "Immediate buyback review recommended"
    }
  ],
  "insights": {
    "most_common_issue": "Transmission (18 vehicles)",
    "highest_risk_vehicle": "xxx-xxxx-8397 (9 calls, buyback requested)",
    "avg_days_to_escalation": 45,
    "vehicles_by_model": {
      "F-150": 23,
      "Bronco": 12,
      "Explorer": 7
    }
  }
}
```

## Advanced Analytics Features

### VIN-Focused Semantic Intelligence
- **Semantic Embeddings**: Qwen 0.6B model identifies VIN-related content beyond exact keyword matching
- **3-Level Topic Classification**: Searches topic_level1, topic_level2, topic_level3 for VIN-specific issues
- **Combined Detection**: Union of both methods ensures maximum VIN conversation identification
- **Privacy-Preserved Search**: Maintains VIN masking while enabling comprehensive vehicle tracking

### Complete VIN History Analysis
- **Call Timeline**: Chronological sequence of all VIN-related calls with full context
- **Sentiment Journey**: Customer emotion tracking from first call to latest interaction
- **Issue Evolution**: Track how problems develop and escalate over time
- **Resolution Tracking**: Monitor repair attempts and their effectiveness

### Advanced Lemon Law Intelligence
- **Semantic Escalation Detection**: Identifies buyback requests, legal threats, safety concerns through natural language understanding
- **Repeat Issue Analysis**: Tracks same problems recurring across multiple calls
- **Timeline Assessment**: Evaluates call frequency and issue persistence patterns
- **Business Impact**: Correlates with case classification and operational metrics

### Multi-Dimensional VIN Intelligence
- **Parts Correlation**: Links VIN issues to specific vehicle components and assemblies
- **Vehicle Matching**: Apple-to-apple correlation via models table for accurate vehicle data
- **Agent Performance**: Tracks which teams handle VIN issues most effectively
- **Operational Metrics**: Complexity scoring, transfer analysis, and resolution effectiveness

## Key Use Cases

### Individual VIN Investigation
- **"Complete call history for VIN 12345"** - Full vehicle timeline with sentiment tracking
- **"What issues has this specific vehicle experienced?"** - Comprehensive problem analysis
- **"Track repair attempts for this VIN"** - Resolution effectiveness measurement

### Lemon Law Assessment
- **"Identify vehicles meeting lemon law criteria"** - Advanced candidate assessment
- **"Which vehicles have repeat transmission issues?"** - Component-specific problem tracking
- **"Find vehicles with declining customer satisfaction"** - Sentiment-based risk assessment

### Business Intelligence & Process Improvement
- **"Vehicles requiring immediate attention"** - Priority vehicle identification
- **"Parts causing most VIN-level escalations"** - Component reliability analysis
- **"Agent team effectiveness on problem vehicles"** - Operational performance evaluation

### Risk Management & Quality Intelligence
- **"Early warning indicators for lemon law cases"** - Proactive risk identification
- **"Vehicle batch quality assessment"** - Manufacturing correlation analysis
- **"Customer retention risk for specific VINs"** - Loyalty impact measurement

## Business Value
Enhanced vin_history provides strategic vehicle intelligence for:
- **Quality Management**: Individual vehicle tracking for manufacturing and design improvements
- **Customer Experience**: Complete VIN-specific conversation analysis for relationship management
- **Legal Risk Mitigation**: Advanced lemon law candidate identification and assessment
- **Operational Excellence**: Agent team performance optimization for vehicle-specific issues
- **Financial Intelligence**: Early identification of costly individual vehicle problems and buyback risks

## Technical Features

### Advanced Semantic + Topic Engine
- **VIN-Focused Detection**: Qwen/Qwen3-Embedding-0.6B embeddings optimized for vehicle history analysis
- **Multi-Source VIN Intelligence**: Uses call_data.vin as primary source with semantic fallback detection
- **Complete Coverage**: Semantic understanding combined with structured topic categorization for VIN tracking
- **Privacy Integration**: Maintains VIN masking throughout analysis pipeline

### Multi-Table Architecture
- **8+ Data Sources**: Complete integration across Ford data ecosystem for VIN intelligence
- **Complete Call Content**: Both summaries AND full transcripts for comprehensive VIN conversation analysis
- **Sentiment Intelligence**: Customer journey tracking from call start to completion for individual vehicles
- **Business Correlation**: Case classification, agent teams, vehicle matching, and parts correlation for VIN context

### Production-Ready Features
- **Flexible Analysis**: Support for both specific VIN lookup and lemon candidate identification
- **Vehicle Filtering**: Focus analysis on specific vehicle models within VIN tracking
- **Similarity Tuning**: Adjustable semantic similarity thresholds for precision control
- **Comprehensive Logging**: Detailed progress tracking and diagnostics for VIN analysis workflows

## Error Handling
Robust error handling with comprehensive logging, graceful degradation for missing VIN data, and detailed diagnostics for maximum reliability in production VIN tracking and lemon law assessment environments.