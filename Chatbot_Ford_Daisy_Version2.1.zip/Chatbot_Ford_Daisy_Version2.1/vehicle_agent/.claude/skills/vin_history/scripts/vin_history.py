"""
Enhanced VIN Intelligence using Semantic Detection & Multi-Table Analysis
=========================================================================

Uses Qwen 0.6B semantic embeddings + 3-level topic classification + multi-table analysis.
Comprehensive VIN-level call history with advanced lemon law assessment and vehicle intelligence.

Usage:
    python vin_history.py --vin "12345" --from 2025-01-01 --to 2026-01-31
    python vin_history.py --from 2026-01-01 --to 2026-01-31 --min-calls 5
    python vin_history.py --vin "F150" --from 2026-01-01 --to 2026-01-31 --similarity-threshold 0.6

Output: Comprehensive JSON with VIN intelligence using semantic + topic detection + multi-table analysis
"""
import argparse
import json
import os
import sys
import numpy as np
import pandas as pd
from collections import defaultdict
from decimal import Decimal
from datetime import datetime
from pathlib import Path
from databricks import sql
import requests
from dotenv import load_dotenv
from sentence_transformers import SentenceTransformer

load_dotenv(Path(__file__).resolve().parents[5] / ".env", override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]

def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )

# === ENHANCED TABLE CONFIGURATION (Same as proven flag skills) ===
CATALOG = os.environ.get("DATABRICKS_CATALOG", "text_analytics")
SCHEMA = os.environ.get("DATABRICKS_SCHEMA", "nlp_analytics")
CALL_DATA = f"{CATALOG}.{SCHEMA}.call_data"
CALL_TABLE = f"{CATALOG}.{SCHEMA}.call_table"
MODELS = f"{CATALOG}.{SCHEMA}.models"
PARTS_UNFILTERED = f"{CATALOG}.{SCHEMA}.parts_unfiltered"
SENTIMENTS = f"{CATALOG}.{SCHEMA}.sentiments"
CASE_METADATA = f"{CATALOG}.nlp_dashboard.case_metadata"
TOPIC_XWALK = f"{CATALOG}.{SCHEMA}.topic_xwalk"
TOPIC_DETAIL = f"{CATALOG}.nlp_configs.topic_detail"
EMBEDDING_TABLE = f"{CATALOG}.nlp_agent.call_summary_qwen06b"


def serialize(v):
    """Convert various types to JSON-serializable format"""
    if isinstance(v, Decimal):
        return float(v)
    if hasattr(v, "isoformat"):
        return str(v)
    return v

def mask_vin(vin):
    """Mask VIN for privacy"""
    if not vin or len(vin) < 8:
        return "xxx-xxxx-xxxx"
    s = str(vin)
    return f"xxx-xxxx-{s[-4:]}"

def get_query_embedding(query_text):
    """Get query embedding using same working method as other flag skills"""
    print(f"Generating query embedding for: '{query_text}'", file=sys.stderr)

    # Method 1: Try Databricks Qwen endpoint
    try:
        from databricks.sdk import WorkspaceClient
        w = WorkspaceClient(
            host=os.environ.get("DATABRICKS_HOST"),
            client_id=os.environ.get("DATABRICKS_CLIENT_ID"),
            client_secret=os.environ.get("DATABRICKS_CLIENT_SECRET")
        )
        response = w.serving_endpoints.query(
            name="qwen3-embedding-06b",
            instances=[query_text]
        )
        print(f"Databricks Qwen embedding generated successfully", file=sys.stderr)
        return response.predictions[0]
    except Exception as e:
        print(f"Databricks Qwen embedding failed: {e}", file=sys.stderr)

    # Method 2: Local Qwen 0.6B model (proven working method)
    try:
        model = SentenceTransformer(
            "Qwen/Qwen3-Embedding-0.6B",
            processor_kwargs={"padding_side": "left"}
        )
        embedding = model.encode([query_text])
        print(f"Query embedding generated successfully (dimension: {len(embedding[0])})", file=sys.stderr)
        return embedding[0].tolist()
    except Exception as e:
        print(f"Local Qwen 0.6B embedding failed: {e}", file=sys.stderr)
        return None

def cosine_similarity(vec1, vec2):
    """Calculate cosine similarity between two vectors"""
    vec1 = np.array(vec1)
    vec2 = np.array(vec2)
    return np.dot(vec1, vec2) / (np.linalg.norm(vec1) * np.linalg.norm(vec2))

def get_semantic_call_ids(vin_query, similarity_threshold, limit, date_from, date_to):
    """Find semantically similar calls for VIN-related content"""
    query_embedding = get_query_embedding(vin_query)
    if not query_embedding:
        return []

    print(f"Finding semantically similar VIN calls (threshold: {similarity_threshold})...", file=sys.stderr)

    semantic_call_ids = []

    with get_connection() as conn:
        with conn.cursor() as cursor:
            batch_size = 1000
            offset = 0
            max_batches = 10
            batch_count = 0

            while len(semantic_call_ids) < limit and batch_count < max_batches:
                cursor.execute(f"""
                    SELECT call_id, embeddings
                    FROM {EMBEDDING_TABLE}
                    WHERE call_date >= :date_from
                      AND call_date <= :date_to
                    ORDER BY call_date DESC
                    LIMIT {batch_size} OFFSET {offset}
                """, {"date_from": date_from, "date_to": date_to})

                batch_results = cursor.fetchall()
                if not batch_results:
                    break

                batch_count += 1
                print(f"Processing VIN semantic batch {batch_count}: {len(batch_results)} embeddings", file=sys.stderr)

                batch_similarities = []
                for call_id, db_embedding in batch_results:
                    try:
                        import ast
                        if db_embedding:
                            try:
                                embedding_str = str(db_embedding)
                                if embedding_str.startswith('[') and embedding_str.endswith(']'):
                                    db_emb_list = ast.literal_eval(embedding_str)
                                    embedding_array = np.array(db_emb_list)
                                else:
                                    embedding_array = np.array(db_embedding)
                            except:
                                continue

                            if len(embedding_array) == len(query_embedding):
                                similarity = cosine_similarity(query_embedding, embedding_array)
                                if similarity >= similarity_threshold:
                                    batch_similarities.append((call_id, similarity))
                    except Exception:
                        continue

                # Sort by similarity (highest first) and add to results
                batch_similarities.sort(key=lambda x: x[1], reverse=True)
                for call_id, similarity in batch_similarities:
                    if len(semantic_call_ids) < limit:
                        semantic_call_ids.append(call_id)

                offset += batch_size

            print(f"Total semantic VIN matches found: {len(semantic_call_ids)}", file=sys.stderr)
            return semantic_call_ids

def get_topic_call_ids(vin_query, date_from, date_to):
    """Find calls using 3-level topic classification for VIN-related topics"""
    print(f"Finding calls via 3-level topic classification for VIN: '{vin_query}'", file=sys.stderr)

    with get_connection() as conn:
        with conn.cursor() as cursor:
            # Search ALL 3 topic levels for VIN-related terms
            query_lower = vin_query.lower()
            cursor.execute(f"""
                SELECT DISTINCT cd.call_id
                FROM {CALL_DATA} cd
                JOIN {TOPIC_XWALK} tx ON cd.call_id = tx.call_id
                JOIN {TOPIC_DETAIL} td ON tx.topic_id = td.topic_id
                WHERE DATE(cd.call_date) >= :date_from
                  AND DATE(cd.call_date) <= :date_to
                  AND (
                      LOWER(td.topic_level1) LIKE :query_pattern
                      OR LOWER(td.topic_level2) LIKE :query_pattern
                      OR LOWER(td.topic_level3) LIKE :query_pattern
                      OR LOWER(td.topic_category) LIKE :query_pattern
                  )
            """, {
                "date_from": date_from,
                "date_to": date_to,
                "query_pattern": f"%{query_lower}%"
            })

            topic_call_ids = [row[0] for row in cursor.fetchall()]
            print(f"Found {len(topic_call_ids)} VIN topic-classified calls", file=sys.stderr)
            return topic_call_ids

def get_direct_vin_call_ids(vin_pattern, date_from, date_to):
    """Find calls with direct VIN matches from call_data"""
    print(f"Finding direct VIN matches for: '{vin_pattern}'", file=sys.stderr)

    with get_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(f"""
                SELECT DISTINCT call_id
                FROM {CALL_DATA}
                WHERE DATE(call_date) >= :date_from
                  AND DATE(call_date) <= :date_to
                  AND vin IS NOT NULL
                  AND vin LIKE :vin_pattern
            """, {
                "date_from": date_from,
                "date_to": date_to,
                "vin_pattern": f"%{vin_pattern}%"
            })

            direct_call_ids = [row[0] for row in cursor.fetchall()]
            print(f"Found {len(direct_call_ids)} direct VIN matches", file=sys.stderr)
            return direct_call_ids

def classify_lemon_status(call_count, avg_sentiment, escalation_indicators, days_span, parts_issues):
    """Advanced lemon law status classification using semantic understanding"""

    # Escalation score based on semantic indicators
    escalation_score = 0
    if 'buyback_requested' in escalation_indicators:
        escalation_score += 3
    if 'legal_mentions' in escalation_indicators:
        escalation_score += 2
    if 'safety_concerns' in escalation_indicators:
        escalation_score += 2
    if 'lemon_law_mentioned' in escalation_indicators:
        escalation_score += 3

    # Parts issue scoring
    parts_score = len(parts_issues) if parts_issues else 0

    # Combined assessment
    if call_count >= 5 and (escalation_score >= 3 or avg_sentiment < -0.65 or days_span < 60):
        return 'strong_candidate', 'high'
    elif call_count >= 4 and (escalation_score >= 1 or avg_sentiment < -0.50 or parts_score >= 2):
        return 'monitoring', 'medium'
    else:
        return 'normal', 'low'


def perform_comprehensive_vin_analysis(all_call_ids, args, vin_query=None):
    """Perform comprehensive multi-table VIN analysis using proven query pattern"""
    print(f"Performing comprehensive VIN analysis on {len(all_call_ids)} calls...", file=sys.stderr)

    # Convert call_ids to VALUES clause
    call_ids_values = ','.join([f"('{cid}')" for cid in all_call_ids[:args.limit]])

    # Build filters
    filters = ["1=1"]
    params = {}

    if args.vehicle:
        filters.append("(LOWER(COALESCE(m.ModelVehicleLine, cd.modelvehicleline)) LIKE LOWER(:vehicle))")
        params["vehicle"] = f"%{args.vehicle}%"

    where_clause = " AND ".join(filters)

    # === COMPREHENSIVE MULTI-TABLE VIN QUERY ===
    analysis_query = f"""
        WITH vin_matches AS (
            SELECT DISTINCT call_id FROM (VALUES {call_ids_values}) AS t(call_id)
        )
        SELECT
            -- === CALL & VIN IDENTIFICATION ===
            s.call_id,
            cd.casenumber,
            DATE(cd.call_date) AS call_date,
            cd.vin,
            CASE WHEN cd.vin IS NOT NULL
                 THEN CONCAT('xxx-xxxx-', RIGHT(cd.vin, 4))
                 ELSE 'xxx-xxxx-xxxx' END AS vin_masked,

            -- === CALL CONTENT ===
            cs.summary AS call_summary_preview,
            ct.transcript AS call_transcript,

            -- === VEHICLE INFORMATION ===
            COALESCE(m.ModelVehicleLine, cd.modelvehicleline, 'Unknown Vehicle') AS vehicle_model,
            COALESCE(CAST(m.Model_Year AS STRING), CAST(cd.modelyear AS STRING), 'Unknown Year') AS model_year,

            -- === AGENT & TEAM INFORMATION ===
            COALESCE(ct.agent_team, 'Unknown Team') AS agent_team,
            COALESCE(cd.program_name, 'Unknown Program') AS program_name,

            -- === CASE CLASSIFICATION ===
            COALESCE(cm.caseclassificationlevel1, 'No Case Data') AS case_level1,
            COALESCE(cm.caseclassificationlevel2, 'No Case Data') AS case_level2,
            COALESCE(cm.caseclassificationlevel3, 'No Case Data') AS case_level3,

            -- === 3-LEVEL TOPIC HIERARCHY ===
            COALESCE(td.topic_level1, 'No Topic Data') AS topic_broad,
            COALESCE(td.topic_level2, 'No Topic Data') AS topic_mid,
            COALESCE(td.topic_level3, 'No Topic Data') AS topic_specific,
            COALESCE(td.topic_category, 'No Topic Category') AS topic_category,

            -- === PARTS INFORMATION ===
            COALESCE(pf.parts_features, 'No Parts Data') AS parts_features,
            COALESCE(pf.parts_concern, 'No Parts Concern') AS parts_concern,

            -- === PRIMARY SENTIMENT SCORES ===
            ROUND(s.agent_sentiment, 4) AS agent_sentiment,
            ROUND(s.customer_sentiment, 4) AS customer_sentiment,
            ROUND(s.overall_sentiment, 4) AS overall_sentiment,
            ROUND(s.customer_sentiment - s.agent_sentiment, 4) AS sentiment_gap,

            -- === SENTIMENT JOURNEY (Beginning to End) ===
            ROUND(cd.agent_beg_sent, 4) AS agent_start_sentiment,
            ROUND(cd.agent_end_sent, 4) AS agent_end_sentiment,
            ROUND(cd.cust_beg_sent, 4) AS customer_start_sentiment,
            ROUND(cd.cust_end_sent, 4) AS customer_end_sentiment,

            -- === SENTIMENT CHANGES DURING CALL ===
            ROUND(cd.agent_end_sent - cd.agent_beg_sent, 4) AS agent_sentiment_change,
            ROUND(cd.cust_end_sent - cd.cust_beg_sent, 4) AS customer_sentiment_change,

            -- === CALL COMPLEXITY & OPERATIONS ===
            ROUND(cd.complexity, 4) AS complexity_score,
            cd.complexity_label,
            COALESCE(cd.number_of_transfers, 0) AS number_of_transfers,
            CASE
                WHEN cd.handle_time IS NOT NULL AND cd.handle_time > 0
                THEN ROUND(cd.handle_time / 60.0, 2)
                ELSE NULL
            END AS handle_time_minutes,

            -- === DETECTION METHOD ===
            CASE
                WHEN cd.vin IS NOT NULL AND cd.vin LIKE :vin_pattern THEN 'Direct VIN Match'
                WHEN td.topic_level1 IS NOT NULL OR td.topic_level2 IS NOT NULL OR td.topic_level3 IS NOT NULL
                THEN 'Topic Classification'
                ELSE 'Semantic Detection'
            END AS detection_method

        FROM {SENTIMENTS} s
        INNER JOIN vin_matches vm ON s.call_id = vm.call_id
        INNER JOIN {CALL_DATA} cd ON s.call_id = cd.call_id
        LEFT JOIN {EMBEDDING_TABLE} cs ON s.call_id = cs.call_id
        LEFT JOIN {CALL_TABLE} ct ON s.call_id = ct.call_id
        LEFT JOIN {MODELS} m ON s.call_id = m.call_id
        LEFT JOIN {CASE_METADATA} cm ON COALESCE(cd.casenumber, '') = COALESCE(cm.casenumber, '')
        LEFT JOIN {TOPIC_XWALK} tx ON s.call_id = tx.call_id
        LEFT JOIN {TOPIC_DETAIL} td ON tx.topic_id = td.topic_id
        LEFT JOIN {PARTS_UNFILTERED} pf ON s.call_id = pf.call_id

        WHERE {where_clause}

        ORDER BY
            cd.call_date ASC

        LIMIT {args.limit}
    """

    # Set VIN pattern for detection method classification
    params["vin_pattern"] = f"%{vin_query}%" if vin_query else "%"

    with get_connection() as conn:
        with conn.cursor() as cursor:
            print(f"Executing comprehensive VIN analysis query...", file=sys.stderr)
            cursor.execute(analysis_query, params)
            rows = cursor.fetchall()
            columns = [d[0] for d in cursor.description]

    # Process results
    examples = []
    sentiment_stats = []
    topic_stats = {}
    vehicle_stats = {}
    detection_methods = {}
    parts_issues = set()
    escalation_indicators = set()

    for row in rows:
        row_dict = dict(zip(columns, [serialize(val) for val in row]))
        examples.append(row_dict)

        # Collect statistics
        if row_dict.get('customer_sentiment') is not None:
            sentiment_stats.append(row_dict['customer_sentiment'])

        # Check for escalation indicators in call content
        summary = row_dict.get('call_summary_preview', '') or ''
        transcript = row_dict.get('call_transcript', '') or ''
        text = (summary + ' ' + transcript).lower()
        if 'buyback' in text or 'buy back' in text:
            escalation_indicators.add('buyback_requested')
        if any(kw in text for kw in ['lawyer', 'attorney', 'legal action']):
            escalation_indicators.add('legal_mentions')
        if any(kw in text for kw in ['unsafe', 'dangerous', 'safety']):
            escalation_indicators.add('safety_concerns')
        if 'lemon law' in text or 'lemon' in text:
            escalation_indicators.add('lemon_law_mentioned')

        # Collect parts issues
        if row_dict.get('parts_concern') != 'No Parts Concern':
            parts_issues.add(row_dict.get('parts_concern'))

        # Topic statistics
        topic_hierarchy = f"{row_dict.get('topic_broad', 'Unknown')} > {row_dict.get('topic_mid', 'Unknown')} > {row_dict.get('topic_specific', 'Unknown')}"
        topic_stats[topic_hierarchy] = topic_stats.get(topic_hierarchy, 0) + 1

        # Vehicle statistics
        vehicle = row_dict.get('vehicle_model', 'Unknown')
        vehicle_stats[vehicle] = vehicle_stats.get(vehicle, 0) + 1

        # Detection method statistics
        detection_method = row_dict.get('detection_method', 'Unknown')
        detection_methods[detection_method] = detection_methods.get(detection_method, 0) + 1

    return {
        "examples": examples,
        "sentiment_stats": sentiment_stats,
        "topic_stats": topic_stats,
        "vehicle_stats": vehicle_stats,
        "detection_methods": detection_methods,
        "escalation_indicators": list(escalation_indicators),
        "parts_issues": list(parts_issues)
    }

def main():
    parser = argparse.ArgumentParser(description="Enhanced VIN Intelligence with Semantic Detection")
    parser.add_argument("--vin", help="VIN to search (partial match supported)")
    parser.add_argument("--from", dest="date_from", required=True, help="Start date YYYY-MM-DD")
    parser.add_argument("--to", dest="date_to", required=True, help="End date YYYY-MM-DD")
    parser.add_argument("--vehicle", help="Filter to specific vehicle (partial match)")
    parser.add_argument("--min-calls", dest="min_calls", type=int, default=5, help="Minimum calls for lemon candidates")
    parser.add_argument("--similarity-threshold", type=float, default=0.4, help="Similarity threshold (0.0-1.0)")
    parser.add_argument("--limit", type=int, default=100, help="Number of examples to return (100 or 1000)")

    args = parser.parse_args()

    try:
        print(f"Starting VIN analysis for query: '{args.vin or 'lemon candidates'}'", file=sys.stderr)

        if args.vin:
            # === SPECIFIC VIN LOOKUP ===
            print(f"Performing specific VIN lookup for: '{args.vin}'", file=sys.stderr)

            # Method 1: Direct VIN matches from call_data
            direct_call_ids = get_direct_vin_call_ids(args.vin, args.date_from, args.date_to)

            # Method 2: Semantic embedding search for VIN-related content
            semantic_call_ids = get_semantic_call_ids(args.vin, args.similarity_threshold, 1000, args.date_from, args.date_to)

            # Method 3: 3-level topic classification
            topic_call_ids = get_topic_call_ids(args.vin, args.date_from, args.date_to)

            # Combine all methods (union for comprehensive coverage)
            all_call_ids = list(set(direct_call_ids + semantic_call_ids + topic_call_ids))

            if not all_call_ids:
                print(json.dumps({
                    "vin_query": args.vin,
                    "vin_masked": mask_vin(args.vin),
                    "total_matches": 0,
                    "direct_matches": 0,
                    "semantic_matches": 0,
                    "topic_matches": 0,
                    "message": "No matching calls found for the specified VIN"
                }))
                return

            print(f"Total VIN matches: {len(all_call_ids)} (direct: {len(direct_call_ids)}, semantic: {len(semantic_call_ids)}, topic: {len(topic_call_ids)})", file=sys.stderr)

            # Comprehensive analysis
            analysis_results = perform_comprehensive_vin_analysis(all_call_ids, args, args.vin)

            # Calculate metrics for specific VIN
            examples = analysis_results["examples"]
            if not examples:
                print(json.dumps({"error": "No analysis data available"}))
                return

            # VIN information from first match
            vin_info = examples[0]
            vehicle_model = vin_info.get('vehicle_model', 'Unknown')
            model_year = vin_info.get('model_year', 'Unknown')
            vin_masked = vin_info.get('vin_masked', mask_vin(args.vin))

            # Calculate timeline metrics
            call_dates = [ex.get('call_date') for ex in examples if ex.get('call_date')]
            first_call = min(call_dates) if call_dates else None
            last_call = max(call_dates) if call_dates else None

            days_span = 0
            if first_call and last_call and len(call_dates) > 1:
                try:
                    first_dt = pd.to_datetime(first_call) if isinstance(first_call, str) else first_call
                    last_dt = pd.to_datetime(last_call) if isinstance(last_call, str) else last_call
                    days_span = (last_dt - first_dt).days
                except:
                    days_span = 0

            # Sentiment analysis
            avg_sentiment = np.mean(analysis_results["sentiment_stats"]) if analysis_results["sentiment_stats"] else 0

            # Sentiment trajectory
            sentiments = analysis_results["sentiment_stats"]
            sentiment_trajectory = 'stable'
            if len(sentiments) >= 3:
                if sentiments[-1] < sentiments[0] - 0.2:
                    sentiment_trajectory = 'declining'
                elif sentiments[-1] > sentiments[0] + 0.2:
                    sentiment_trajectory = 'improving'

            # Lemon law assessment
            lemon_status, priority = classify_lemon_status(
                len(examples), avg_sentiment, analysis_results["escalation_indicators"],
                days_span, analysis_results["parts_issues"]
            )

            # Build timeline
            call_timeline = []
            for i, example in enumerate(examples, 1):
                call_timeline.append({
                    "call_number": i,
                    "call_date": example.get('call_date'),
                    "call_summary_preview": (example.get('call_summary_preview', '') or '')[:200],
                    "call_transcript": example.get('call_transcript', ''),
                    "vehicle_model": example.get('vehicle_model'),
                    "model_year": example.get('model_year'),
                    "agent_team": example.get('agent_team'),
                    "case_level1": example.get('case_level1'),
                    "topic_broad": example.get('topic_broad'),
                    "topic_mid": example.get('topic_mid'),
                    "topic_specific": example.get('topic_specific'),
                    "parts_concern": example.get('parts_concern'),
                    "customer_sentiment": example.get('customer_sentiment'),
                    "agent_sentiment": example.get('agent_sentiment'),
                    "sentiment_gap": example.get('sentiment_gap'),
                    "complexity_score": example.get('complexity_score'),
                    "number_of_transfers": example.get('number_of_transfers'),
                    "handle_time_minutes": example.get('handle_time_minutes'),
                    "detection_method": example.get('detection_method')
                })

            # Final response for specific VIN
            response = {
                "vin_query": args.vin,
                "vin_masked": vin_masked,
                "parameters": {
                    "search_method": "semantic_embeddings_plus_topics_plus_direct",
                    "embedding_model": "Qwen/Qwen3-Embedding-0.6B",
                    "similarity_threshold": args.similarity_threshold,
                    "topic_levels_analyzed": 3,
                    "date_range": {"from": args.date_from, "to": args.date_to},
                    "vehicle_filter": args.vehicle
                },
                "detection_summary": {
                    "total_matches": len(all_call_ids),
                    "direct_matches": len(direct_call_ids),
                    "semantic_matches": len(semantic_call_ids),
                    "topic_matches": len(topic_call_ids),
                    "analyzed_examples": len(examples),
                    "detection_methods": analysis_results["detection_methods"]
                },
                "vehicle_information": {
                    "vehicle_model": vehicle_model,
                    "model_year": model_year,
                    "vin_source": "call_data"
                },
                "call_summary": {
                    "total_calls": len(examples),
                    "first_call": first_call,
                    "last_call": last_call,
                    "days_span": days_span
                },
                "sentiment_analysis": {
                    "avg_customer_sentiment": round(avg_sentiment, 4),
                    "sentiment_trajectory": sentiment_trajectory,
                    "total_calls_analyzed": len(analysis_results["sentiment_stats"])
                },
                "lemon_law_assessment": {
                    "lemon_status": lemon_status,
                    "priority": priority,
                    "call_count": len(examples),
                    "escalation_indicators": analysis_results["escalation_indicators"],
                    "parts_issues": analysis_results["parts_issues"],
                    "recommendation": f"VIN analysis complete - {lemon_status} with {len(examples)} calls"
                },
                "call_timeline": call_timeline,
                "data_sources": [
                    "call_data (VIN source + core call information)",
                    "sentiments (customer/agent sentiment journey)",
                    "embedding_table (Qwen 0.6B semantic search)",
                    "call_table (transcripts and agent teams)",
                    "models (vehicle correlation)",
                    "parts_unfiltered (component analysis)",
                    "topic_detail (3-level topic hierarchy)",
                    "case_metadata (business classification)"
                ]
            }

        else:
            # === LEMON CANDIDATES ANALYSIS ===
            print(f"Finding lemon candidates with {args.min_calls}+ calls...", file=sys.stderr)

            # Query for vehicles with multiple calls
            with get_connection() as conn:
                with conn.cursor() as cursor:
                    base_params = {"date_from": args.date_from, "date_to": args.date_to}
                    base_filters = [
                        "DATE(cd.call_date) >= :date_from",
                        "DATE(cd.call_date) <= :date_to",
                        "cd.vin IS NOT NULL"
                    ]

                    if args.vehicle:
                        base_params["vehicle"] = f"%{args.vehicle}%"
                        base_filters.append("LOWER(cd.modelvehicleline) LIKE LOWER(:vehicle)")

                    base_where = " AND ".join(base_filters)

                    cursor.execute(f"""
                        SELECT cd.vin, COUNT(*) as call_count
                        FROM {CALL_DATA} cd
                        WHERE {base_where}
                        GROUP BY cd.vin
                        HAVING COUNT(*) >= {args.min_calls}
                        ORDER BY call_count DESC
                        LIMIT {args.limit}
                    """, base_params)

                    vin_candidates = cursor.fetchall()

            lemon_candidates = []

            for vin, call_count in vin_candidates:
                # Get all call IDs for this VIN
                with get_connection() as conn:
                    with conn.cursor() as cursor:
                        cursor.execute(f"""
                            SELECT call_id FROM {CALL_DATA}
                            WHERE vin = :vin
                              AND DATE(call_date) >= :date_from
                              AND DATE(call_date) <= :date_to
                        """, {"vin": vin, "date_from": args.date_from, "date_to": args.date_to})

                        vin_call_ids = [row[0] for row in cursor.fetchall()]

                # Analyze this VIN
                analysis_results = perform_comprehensive_vin_analysis(vin_call_ids, args)
                examples = analysis_results["examples"]

                if examples:
                    # Calculate VIN metrics
                    call_dates = [ex.get('call_date') for ex in examples if ex.get('call_date')]
                    first_call = min(call_dates) if call_dates else None
                    last_call = max(call_dates) if call_dates else None
                    days_span = 0
                    if first_call and last_call and len(call_dates) > 1:
                        try:
                            first_dt = pd.to_datetime(first_call) if isinstance(first_call, str) else first_call
                            last_dt = pd.to_datetime(last_call) if isinstance(last_call, str) else last_call
                            days_span = (last_dt - first_dt).days
                        except:
                            days_span = 0

                    avg_sentiment = np.mean(analysis_results["sentiment_stats"]) if analysis_results["sentiment_stats"] else 0

                    lemon_status, priority = classify_lemon_status(
                        len(examples), avg_sentiment, analysis_results["escalation_indicators"],
                        days_span, analysis_results["parts_issues"]
                    )

                    vehicle_info = examples[0]

                    lemon_candidates.append({
                        "vin_masked": mask_vin(vin),
                        "vehicle_model": vehicle_info.get('vehicle_model', 'Unknown'),
                        "model_year": vehicle_info.get('model_year', 'Unknown'),
                        "call_count": len(examples),
                        "first_call": first_call,
                        "last_call": last_call,
                        "days_span": days_span,
                        "avg_customer_sentiment": round(avg_sentiment, 4),
                        "escalation_indicators": analysis_results["escalation_indicators"],
                        "parts_issues": analysis_results["parts_issues"],
                        "lemon_status": lemon_status,
                        "priority": priority
                    })

            # Sort candidates by call count (highest first)
            lemon_candidates.sort(key=lambda x: x['call_count'], reverse=True)

            # Calculate insights
            strong_candidates = sum(1 for v in lemon_candidates if v['lemon_status'] == 'strong_candidate')
            monitoring_candidates = sum(1 for v in lemon_candidates if v['lemon_status'] == 'monitoring')
            avg_calls = sum(v['call_count'] for v in lemon_candidates) / len(lemon_candidates) if lemon_candidates else 0

            response = {
                "date_range": f"{args.date_from} to {args.date_to}",
                "vehicle_filter": args.vehicle or "all",
                "min_calls": args.min_calls,
                "parameters": {
                    "search_method": "multi_table_intelligence",
                    "lemon_assessment": "semantic_enhanced",
                    "topic_levels_analyzed": 3
                },
                "summary": {
                    "total_problem_vehicles": len(lemon_candidates),
                    "strong_candidates": strong_candidates,
                    "monitoring_candidates": monitoring_candidates,
                    "avg_calls_per_vehicle": round(avg_calls, 1)
                },
                "lemon_candidates": lemon_candidates,
                "insights": {
                    "highest_risk_vehicle": lemon_candidates[0]['vin_masked'] if lemon_candidates else 'none',
                    "vehicles_requiring_attention": strong_candidates
                }
            }

        print(json.dumps(response, indent=2))

    except Exception as e:
        print(json.dumps({
            "error": f"Enhanced VIN analysis failed: {str(e)}"
        }), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)
