---
name: transcript_export
display_name: Enhanced Semantic Transcript Export
description: Advanced bulk transcript export with semantic search (Qwen 0.6B embeddings), turn-by-turn analysis, and multi-table intelligence. Returns full transcripts with rich metadata including parts correlation, topic classification, pain points, emotion tracking, and toxicity detection. Optimized for compliance, quality assurance, and deep conversation analysis.
signals:
  # CSV EXPORT SIGNALS - Primary routing triggers
  - export CSV transcripts
  - download CSV transcripts
  - CSV transcript export
  - export to CSV
  - CSV format transcripts
  - bulk CSV export
  - downloadable CSV
  
  # TRANSCRIPT EXPORT SIGNALS
  - provide me with transcripts
  - export transcripts  
  - download calls
  - give me all conversations
  - provide all agent customer conversations
  - show me transcripts
  - bulk export
  - downloadable format
  
  # TURN-BY-TURN ANALYSIS SIGNALS
  - turn by turn analysis
  - turn-by-turn analysis
  - conversation breakdown
  - with turn analysis
  - including turn analysis
  - turn level analysis
  
  # SEMANTIC SEARCH SIGNALS
  - semantic transcript search
  - similar conversations
  - related customer calls
  - find transcript examples
  - semantically similar transcripts
requires:
  - at least one search criteria (query, keywords, or filters)
not_good_for: Single call summaries (use vehicle_examples), high-level counts (use keyword_search)
---

# Enhanced Semantic Transcript Export

## What this script does
**ENHANCED VERSION**: Uses Qwen 0.6B semantic embeddings to find contextually related conversations, then provides comprehensive transcript export with turn-by-turn analysis, multi-table intelligence (parts, topics, pain points), emotion tracking, and toxicity detection. Perfect for compliance reporting, quality assurance, and deep conversation analytics.

**Key Features:**
- **Semantic Discovery**: Finds related conversations beyond exact keyword matches
- **Turn-by-Turn Analysis**: Complete conversation flow with sentiment progression
- **Multi-Table Intelligence**: Parts, topic, and pain point correlation
- **Compliance Ready**: Toxicity and threat detection per turn
- **CSV Optimized**: Spreadsheet-ready format for analysis

## How to run it

**Enhanced Semantic Search (Recommended):**
```bash
python .claude/skills/transcript_export/scripts/transcript_export_enhanced.py --query "NHTSA safety complaints" --semantic --format csv --limit 100
```

**Traditional Keyword Search:**
```bash
python .claude/skills/transcript_export/scripts/transcript_export.py --keywords "NHTSA,VOQ,buyback" --format csv
```

## Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--query` | No |  | Semantic search query (e.g., "safety complaints") |
| `--keywords` | No |  | Traditional comma-separated keywords (OR logic) |
| `--semantic` | No | false | Enable semantic search via Qwen 0.6B embeddings |
| `--similarity-threshold` | No | 0.4 | Similarity threshold for semantic matching (0.0-1.0) |
| `--semantic-limit` | No | 1000 | Max semantic matches to analyze |
| `--vehicle` | No | all | Vehicle name filter (partial match) |
| `--sentiment` | No | all | Filter: `positive`, `neutral`, `negative` |
| `--from` | No | all time | Start date YYYY-MM-DD |
| `--to` | No | all time | End date YYYY-MM-DD |
| `--limit` | No | 100 | Max transcripts (1-500) |
| `--format` | No | json | Output format: `json` or `csv` |
| `--detail-level` | No | calls | Detail level: `calls` (summary) or `turns` (turn-by-turn) |
| `--sort` | No | negative | Sort: `negative`, `complexity`, `recent` |
| `--include-emotions` | No | false | Include emotion analysis in output |
| `--include-toxicity` | No | false | Include toxicity/threat scores |
| `--traditional` | No | false | Force traditional keyword search |

## Example calls

**Semantic Search Examples:**
```bash
# NHTSA/Compliance semantic discovery
python transcript_export_enhanced.py --query "NHTSA safety complaints" --semantic --format csv --limit 200 --include-toxicity

# Buyback/Lemon law conversations with emotion tracking
python transcript_export_enhanced.py --query "buyback lemon law customer frustration" --semantic --detail-level turns --include-emotions --format csv

# Turn-by-turn brake safety analysis
python transcript_export_enhanced.py --query "brake failure safety issues" --vehicle "F-150" --semantic --detail-level turns --format csv --limit 50

# Quality assurance - escalated calls with complexity sorting  
python transcript_export_enhanced.py --query "supervisor escalation angry customer" --semantic --sort complexity --format csv --include-emotions

# Cross-vehicle transmission issues
python transcript_export_enhanced.py --query "transmission problems shifting issues" --semantic --format csv --limit 300
```

**Traditional Keyword Examples:**
```bash
# Multi-keyword traditional search
python transcript_export_enhanced.py --keywords "NHTSA,VOQ,recall" --format csv --traditional

# Vehicle-specific keyword search
python transcript_export_enhanced.py --keywords "transmission" --vehicle "F-150" --sentiment negative --format csv --traditional
```

## Output formats

### Enhanced JSON (Semantic Search)
```json
{
  "search_method": "enhanced_semantic",
  "parameters": {
    "query": "brake safety issues",
    "semantic_enabled": true,
    "similarity_threshold": 0.4,
    "vehicle": "F-150",
    "detail_level": "calls"
  },
  "semantic_matches_found": 347,
  "total_transcripts_returned": 50,
  "negative_sentiment_pct": 76.0,
  "transcripts": [
    {
      "call_id": "abc123",
      "call_date": "2025-06-15", 
      "modelvehicleline": "F-150",
      "modelyear": "2024",
      "Agent_Team": "Truck Concern",
      "sentiment_label": "negative",
      "sentiment_score": -0.23,
      "complexity": 8.5,
      "aht_minutes": 12.3,
      "customer_turns": 24,
      "agent_turns": 23, 
      "total_turns": 47,
      "avg_customer_sentiment": -0.35,
      "worst_customer_sentiment": -0.78,
      "max_toxicity": 0.15,
      
      "parts_features": "Brake Components",
      "parts_concern": "Brake failure at highway speeds",
      "pain_point": "Safety Concerns", 
      "customer_feedback": "Extremely frustrated with brake performance",
      "considering_switching_brands": "yes",
      "topic_name": "Brake Safety Issues",
      "topic_level1": "Vehicle Safety",
      "topic_level2": "Brake System Failures", 
      "topic_level3": "Critical safety defects requiring immediate attention",
      
      "call_summary": "Customer called about brake failure...",
      "full_transcript": "Complete conversation text..."
    }
  ]
}
```

### Turn-by-Turn CSV (detail-level: turns)
```csv
call_id,text_order,speaker_role,turn_text,turn_sentiment,emotion,emotion_score,toxic_score,call_date,modelvehicleline,Agent_Team,parts_concern,topic_level1,pain_point,brand_risk,call_summary
abc123,1,agent,"Thank you for calling Ford...",0.75,neutral,0.68,0.01,2025-06-15,F-150,Truck Concern,Brake failure,Vehicle Safety,Critical,yes,"Customer called about brake issues..."
abc123,2,customer,"Hi I'm having serious brake problems...",0.45,frustrated,0.82,0.15,2025-06-15,F-150,Truck Concern,Brake failure,Vehicle Safety,Critical,yes,"Customer called about brake issues..."
abc123,3,agent,"I understand your concern about the brakes...",0.65,empathetic,0.71,0.02,2025-06-15,F-150,Truck Concern,Brake failure,Vehicle Safety,Critical,yes,"Customer called about brake issues..."
```

### Call-Level CSV (detail-level: calls)
```csv
call_id,call_date,modelvehicleline,modelyear,Agent_Team,sentiment_label,sentiment_score,complexity,aht_minutes,customer_turns,agent_turns,avg_customer_sentiment,max_toxicity,parts_concern,topic_level1,pain_point,considering_switching_brands,call_summary,full_transcript
abc123,2025-06-15,F-150,2024,Truck Concern,negative,-0.23,8.5,12.3,24,23,-0.35,0.15,Brake failure,Vehicle Safety,Critical,yes,"Customer called about brake issues...","Complete conversation..."
```

## Advanced Use Cases

### Compliance & Legal
```bash
# NHTSA complaint discovery with toxicity monitoring
python transcript_export_enhanced.py --query "NHTSA complaints safety defects" --semantic --include-toxicity --format csv --limit 500

# Buyback conversations with brand switching risk
python transcript_export_enhanced.py --query "buyback lemon law repurchase" --semantic --format csv --sort negative --limit 200
```

### Quality Assurance
```bash
# Turn-by-turn escalation analysis with emotions
python transcript_export_enhanced.py --query "supervisor escalation management" --semantic --detail-level turns --include-emotions --format csv

# High complexity call analysis
python transcript_export_enhanced.py --query "difficult customer service" --semantic --sort complexity --include-toxicity --format csv
```

### Product Development
```bash
# Vehicle-specific feature complaints
python transcript_export_enhanced.py --query "brake performance issues" --vehicle "F-150" --semantic --format csv --limit 300

# Cross-vehicle transmission analysis
python transcript_export_enhanced.py --query "transmission shifting problems" --semantic --format csv --sort recent --limit 400
```

## Enhanced Intelligence

### Multi-Table Enrichment
- **Parts Intelligence**: Automatic parts/features identification
- **Topic Classification**: Hierarchical topic taxonomy (3 levels)
- **Pain Point Analysis**: Customer satisfaction and brand loyalty insights
- **Turn-Level Analytics**: Sentiment progression and emotion tracking
- **Compliance Monitoring**: Toxicity, threat, and inappropriate content detection

### Semantic Capabilities
- **Contextual Discovery**: Find related issues beyond exact keywords
- **Qwen 0.6B Integration**: Same model as call_summary_qwen06b table
- **Similarity Tuning**: Adjustable similarity thresholds
- **Fallback Support**: Traditional keyword search when semantic fails

### Performance Features
- **Batch Processing**: Efficient handling of large datasets (up to 15K embeddings)
- **CSV Optimization**: Spreadsheet-ready formats for analysis
- **Sorting Intelligence**: Prioritize by importance (negative sentiment, complexity)
- **Memory Efficient**: Streaming processing for large exports

## Error handling
- Semantic search failures automatically fallback to traditional keyword search
- CSV export generates timestamped files: `transcript_export_enhanced_YYYYMMDD_HHMMSS.csv`
- JSON errors reported to stderr with detailed error messages
- Input validation for all parameters with helpful error messages

## Notes
- **Default sorting: `negative`** - Most important customer issues first (lowest sentiment = highest priority)
- **Semantic search** requires either `--query` or `--keywords` parameter
- **Turn-level analysis** provides conversation flow and sentiment progression
- **Multi-table joins** enrich transcripts with parts, topics, and pain point context
- **Large exports** (500+ calls) automatically optimized for performance