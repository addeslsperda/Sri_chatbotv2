"""
ENHANCED SEMANTIC TRANSCRIPT EXPORT - Production Version

Multi-table semantic intelligence using Qwen 0.6B embeddings for discovering
contextually related customer transcripts with rich turn-by-turn analysis,
parts correlation, topic classification, and pain point insights.

Features:
- Semantic discovery via Qwen 0.6B embeddings (same model as call_summary_qwen06b table)
- Turn-by-turn conversation analysis with sentiment, emotion, and toxicity tracking
- Multi-table intelligence (parts_accessories, topic hierarchy, pain points)
- CSV export optimized for spreadsheet analysis
- Compliance-ready toxicity and threat detection
- Agent performance and customer journey analytics

Usage:
    python transcript_export_enhanced.py --query "NHTSA safety complaints" --semantic --format csv --limit 100
    python transcript_export_enhanced.py --query "buyback lemon law" --semantic --detail-level turns --include-emotions
    python transcript_export_enhanced.py --vehicle "F-150" --query "brake problems" --semantic --format csv --turn-analysis
    python transcript_export_enhanced.py --keywords "transmission" --vehicle "F-150" --format csv --traditional
"""
import argparse
import csv
import json
import os
import sys
import numpy as np
from datetime import datetime
from decimal import Decimal
from pathlib import Path
from databricks import sql
# Import vector search with fallback
try:
    from databricks.vector_search.client import VectorSearchClient
    from databricks.sdk import WorkspaceClient
    VECTOR_SEARCH_AVAILABLE = True
except ImportError:
    VECTOR_SEARCH_AVAILABLE = False
import requests
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parents[5] / ".env", override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


def cosine_similarity(vec1, vec2):
    """Calculate cosine similarity between two vectors"""
    vec1 = np.array(vec1)
    vec2 = np.array(vec2)
    return np.dot(vec1, vec2) / (np.linalg.norm(vec1) * np.linalg.norm(vec2))


def _get_embedding(query_str: str) -> list[float]:
    """Get query embedding using EXACT SAME Qwen/Qwen3-Embedding-0.6B model"""

    # Method 1: Try Databricks Qwen endpoint (preferred - same model used for table embeddings)
    if VECTOR_SEARCH_AVAILABLE:
        try:
            w = WorkspaceClient(
                host=os.environ.get("DATABRICKS_HOST"),
                client_id=os.environ.get("DATABRICKS_CLIENT_ID"),
                client_secret=os.environ.get("DATABRICKS_CLIENT_SECRET")
            )
            response = w.serving_endpoints.query(
                name="qwen3-embedding-06b",
                instances=[query_str]
            )
            return response.predictions[0]
        except Exception as e:
            print(f"Databricks Qwen embedding failed: {e}", file=sys.stderr)

    # Method 2: Local Qwen 0.6B model (EXACT SAME MODEL)
    try:
        from sentence_transformers import SentenceTransformer

        print(f"Loading Qwen 0.6B model locally...", file=sys.stderr)
        model = SentenceTransformer(
            "Qwen/Qwen3-Embedding-0.6B",
            processor_kwargs={"padding_side": "left"}
        )
        embedding = model.encode([query_str])
        print(f"Query embedding generated successfully (dimension: {len(embedding[0])})", file=sys.stderr)
        return embedding[0].tolist()
    except Exception as e:
        print(f"Local Qwen 0.6B embedding failed: {e}", file=sys.stderr)
        return None


def get_semantic_call_ids(query_embedding, vehicle_filter=None, similarity_threshold=0.4, limit=1000, date_from="2020-01-01", date_to="2030-12-31"):
    """
    Find call_ids with embeddings similar to query_embedding using cosine similarity
    """
    semantic_call_ids = []

    with get_connection() as conn:
        with conn.cursor() as cursor:
            print(f"Finding semantically similar calls (threshold: {similarity_threshold})...", file=sys.stderr)

            # Build vehicle filter for embedding table query
            vehicle_where = ""
            params = {"date_from": date_from, "date_to": date_to}

            if vehicle_filter:
                # We need to join with call_data to filter by vehicle
                vehicle_where = """
                AND EXISTS (
                    SELECT 1 FROM {CALL_DATA} cd
                    WHERE cd.call_id = emb.call_id
                    AND LOWER(cd.modelvehicleline) LIKE LOWER(:vehicle)
                )
                """.format(CALL_DATA=CALL_DATA)
                params["vehicle"] = f"%{vehicle_filter}%"

            # Fetch embeddings in batches
            batch_size = 1000
            offset = 0
            max_batches = 15  # Process up to 15K embeddings
            batch_count = 0

            while len(semantic_call_ids) < limit and batch_count < max_batches:
                query = f"""
                    SELECT emb.call_id, emb.embeddings
                    FROM {EMBEDDING_TABLE} emb
                    WHERE emb.call_date >= :date_from
                      AND emb.call_date <= :date_to
                      {vehicle_where}
                    ORDER BY emb.call_date DESC
                    LIMIT {batch_size} OFFSET {offset}
                """

                cursor.execute(query, params)
                batch_results = cursor.fetchall()
                if not batch_results:
                    break

                batch_count += 1
                print(f"Processing batch {batch_count}: {len(batch_results)} embeddings", file=sys.stderr)

                # Calculate similarities for this batch
                batch_similarities = []
                for call_id, db_embedding in batch_results:
                    try:
                        if db_embedding:
                            import ast
                            try:
                                # Parse JSON array format
                                embedding_str = str(db_embedding)
                                if embedding_str.startswith('[') and embedding_str.endswith(']'):
                                    db_emb_list = ast.literal_eval(embedding_str)
                                    embedding_array = np.array(db_emb_list)
                                else:
                                    embedding_array = np.array(db_embedding)
                            except:
                                continue

                            if len(embedding_array) == len(query_embedding):
                                similarity = cosine_similarity(query_embedding, embedding_array)
                                if similarity >= similarity_threshold:
                                    batch_similarities.append((call_id, similarity))
                    except Exception:
                        continue

                # Sort by similarity and add to results
                batch_similarities.sort(key=lambda x: x[1], reverse=True)
                for call_id, similarity in batch_similarities:
                    if len(semantic_call_ids) < limit:
                        semantic_call_ids.append(call_id)

                print(f"Found {len(batch_similarities)} similar calls in this batch (total: {len(semantic_call_ids)})", file=sys.stderr)
                offset += batch_size

                if len(semantic_call_ids) >= limit or offset >= 150000:
                    break

    return semantic_call_ids


def get_enhanced_transcripts(call_ids, detail_level="calls", include_emotions=False, include_toxicity=False, sort_order="negative", limit=100):
    """
    Get enhanced transcript data with multi-table intelligence
    """
    if not call_ids:
        return []

    # Convert call_ids to SQL IN clause (limit for performance)
    limited_call_ids = call_ids[:limit*3]  # Get more than needed for filtering
    call_id_list = "'" + "', '".join(limited_call_ids) + "'"

    with get_connection() as conn:
        with conn.cursor() as cursor:
            if detail_level == "turns":
                # Turn-by-turn detailed analysis
                query = f"""
                    SELECT
                        tt.call_id,
                        tt.text_order,
                        tt.speaker_role,
                        tt.transcript as turn_text,
                        ROUND(tt.sentiment, 4) as turn_sentiment,
                        tt.sentiment_score as turn_sentiment_score,
                        tt.emotion,
                        tt.emotion_score,
                        ROUND(tt.toxic, 4) as toxic_score,
                        ROUND(tt.threat, 4) as threat_score,
                        ROUND(tt.insult, 4) as insult_score,
                        ROUND(tt.obscene, 4) as obscene_score,
                        DATE(tt.Date_of_Call) as call_date,
                        cd.modelvehicleline,
                        cd.modelyear,
                        tt.Agent_Team,
                        cd.sentiment_label as call_sentiment_label,
                        ROUND(cd.sentiment, 4) as call_sentiment_score,
                        ROUND(cd.complexity, 2) as call_complexity,
                        ROUND(cd.handle_time, 2) as aht_minutes,

                        -- Parts & Accessories Intelligence
                        pa.parts_features,
                        pa.parts_concern,

                        -- Model Intelligence
                        m.ModelVehicleLine as model_vehicle_line,
                        m.Model_Year as model_year,

                        -- Pain Points Intelligence
                        mpp.pain_point,
                        mpp.customer_feedback,
                        mpp.considering_switching_brands,

                        -- Topic Classification (proper linkage)
                        tx.topic_name,
                        td.topic_category,
                        td.topic_level1,
                        td.topic_level2,
                        td.topic_level3,

                        -- Call Context
                        ct.summary as call_summary,
                        ct.transcript as full_transcript

                    FROM {TURN_TABLE} tt
                    JOIN {CALL_DATA} cd ON tt.call_id = cd.call_id
                    JOIN {CALL_TABLE} ct ON tt.call_id = ct.call_id
                    LEFT JOIN {PARTS_ACCESSORIES} pa ON tt.call_id = pa.call_id
                    LEFT JOIN {MODELS} m ON tt.call_id = m.call_id
                    LEFT JOIN {MODEL_PAIN_POINTS} mpp ON tt.call_id = mpp.call_id
                    LEFT JOIN {TOPIC_XWALK} tx ON tt.call_id = tx.call_id
                    LEFT JOIN {TOPIC_DETAIL} td ON tx.topic_id = td.topic_id

                    WHERE tt.call_id IN ({call_id_list})
                      AND tt.transcript IS NOT NULL
                      AND LENGTH(tt.transcript) > 10
                """

                # Sort order for turns
                if sort_order == "negative":
                    query += " ORDER BY cd.sentiment ASC NULLS LAST, tt.call_id, tt.text_order"
                elif sort_order == "complexity":
                    query += " ORDER BY cd.complexity DESC NULLS LAST, tt.call_id, tt.text_order"
                else:  # recent
                    query += " ORDER BY tt.Date_of_Call DESC, tt.call_id, tt.text_order"

                query += f" LIMIT {limit * 50}"  # Allow up to 50 turns per call

            else:
                # Call-level summary analysis
                query = f"""
                    SELECT
                        cd.call_id,
                        DATE(cd.call_date) as call_date,
                        cd.modelvehicleline,
                        cd.modelyear,
                        ct.Agent_Team,
                        cd.sentiment_label,
                        ROUND(cd.sentiment, 4) as sentiment_score,
                        ROUND(cd.complexity, 2) as complexity,
                        ROUND(cd.handle_time, 2) as aht_minutes,

                        -- Turn Statistics
                        COUNT(CASE WHEN tt.speaker_role = 'customer' THEN 1 END) as customer_turns,
                        COUNT(CASE WHEN tt.speaker_role = 'agent' THEN 1 END) as agent_turns,
                        COUNT(tt.text_order) as total_turns,
                        ROUND(AVG(CASE WHEN tt.speaker_role = 'customer' THEN tt.sentiment END), 4) as avg_customer_sentiment,
                        ROUND(MIN(CASE WHEN tt.speaker_role = 'customer' THEN tt.sentiment END), 4) as worst_customer_sentiment,
                        ROUND(MAX(CASE WHEN tt.speaker_role = 'customer' THEN tt.toxic END), 4) as max_toxicity,

                        -- Parts & Accessories Intelligence
                        pa.parts_features,
                        pa.parts_concern,

                        -- Pain Points Intelligence
                        mpp.pain_point,
                        mpp.customer_feedback,
                        mpp.considering_switching_brands,

                        -- Topic Classification
                        tx.topic_name,
                        td.topic_level1,
                        td.topic_level2,
                        td.topic_level3,

                        -- Call Content
                        ct.summary as call_summary,
                        ct.transcript as full_transcript

                    FROM {CALL_DATA} cd
                    JOIN {CALL_TABLE} ct ON cd.call_id = ct.call_id
                    LEFT JOIN {TURN_TABLE} tt ON cd.call_id = tt.call_id
                    LEFT JOIN {PARTS_ACCESSORIES} pa ON cd.call_id = pa.call_id
                    LEFT JOIN {MODELS} m ON cd.call_id = m.call_id
                    LEFT JOIN {MODEL_PAIN_POINTS} mpp ON cd.call_id = mpp.call_id
                    LEFT JOIN {TOPIC_XWALK} tx ON cd.call_id = tx.call_id
                    LEFT JOIN {TOPIC_DETAIL} td ON tx.topic_id = td.topic_id

                    WHERE cd.call_id IN ({call_id_list})
                      AND ct.summary IS NOT NULL
                    GROUP BY cd.call_id, cd.call_date, cd.modelvehicleline, cd.modelyear,
                             ct.Agent_Team, cd.sentiment_label, cd.sentiment, cd.complexity,
                             cd.handle_time, pa.parts_features, pa.parts_concern,
                             mpp.pain_point, mpp.customer_feedback, mpp.considering_switching_brands,
                             tx.topic_name, td.topic_level1, td.topic_level2, td.topic_level3,
                             ct.summary, ct.transcript
                """

                # Sort order for calls
                if sort_order == "negative":
                    query += " ORDER BY cd.sentiment ASC NULLS LAST, cd.call_date DESC"
                elif sort_order == "complexity":
                    query += " ORDER BY cd.complexity DESC NULLS LAST, cd.sentiment ASC"
                else:  # recent
                    query += " ORDER BY cd.call_date DESC"

                query += f" LIMIT {limit}"

            cursor.execute(query)
            rows = cursor.fetchall()
            columns = [d[0] for d in cursor.description]

            # Serialize results
            transcripts = []
            for row in rows:
                transcript = {}
                for i, col in enumerate(columns):
                    value = row[i]
                    if isinstance(value, Decimal):
                        transcript[col] = float(value)
                    elif hasattr(value, "isoformat"):
                        transcript[col] = str(value)
                    else:
                        transcript[col] = value
                transcripts.append(transcript)

            return transcripts


def get_traditional_transcripts(keywords=None, vehicle=None, sentiment=None, date_from=None, date_to=None, sort_order="negative", limit=100):
    """
    Traditional keyword-based transcript search (fallback)
    """
    params = {}
    filters = []

    # Date filters
    if date_from:
        params["date_from"] = date_from
        filters.append("DATE(cd.call_date) >= :date_from")
    if date_to:
        params["date_to"] = date_to
        filters.append("DATE(cd.call_date) <= :date_to")

    # Vehicle filter
    if vehicle:
        params["vehicle"] = f"%{vehicle}%"
        filters.append("LOWER(cd.modelvehicleline) LIKE LOWER(:vehicle)")

    # Sentiment filter
    if sentiment:
        params["sentiment_label"] = sentiment.lower()
        filters.append("LOWER(cd.sentiment_label) = :sentiment_label")

    # Keyword filter (OR logic)
    if keywords:
        keyword_list = [k.strip() for k in keywords.split(",") if k.strip()]
        if keyword_list:
            keyword_conditions = []
            for i, kw in enumerate(keyword_list):
                params[f"kw{i}"] = f"%{kw}%"
                keyword_conditions.append(f"(LOWER(ct.summary) LIKE LOWER(:kw{i}) OR LOWER(ct.transcript) LIKE LOWER(:kw{i}))")
            filters.append(f"({' OR '.join(keyword_conditions)})")

    # Ensure we have transcript data
    filters.append("(ct.transcript IS NOT NULL OR ct.summary IS NOT NULL)")

    where_clause = " AND ".join(filters) if filters else "1=1"

    with get_connection() as conn:
        with conn.cursor() as cursor:
            # Determine sort order
            if sort_order == "negative":
                order_by = "cd.sentiment ASC NULLS LAST, cd.call_date DESC"
            elif sort_order == "complexity":
                order_by = "cd.complexity DESC NULLS LAST, cd.sentiment ASC"
            else:  # recent
                order_by = "cd.call_date DESC"

            query = f"""
                SELECT
                    cd.call_id,
                    DATE(cd.call_date) AS call_date,
                    cd.modelvehicleline,
                    cd.modelyear,
                    ct.Agent_Team,
                    cd.sentiment_label,
                    ROUND(cd.sentiment, 4) AS sentiment_score,
                    ROUND(cd.complexity, 2) AS complexity,
                    ROUND(cd.handle_time, 2) AS aht_minutes,
                    ct.summary,
                    ct.transcript
                FROM {CALL_DATA} cd
                JOIN {CALL_TABLE} ct ON cd.call_id = ct.call_id
                WHERE {where_clause}
                ORDER BY {order_by}
                LIMIT {limit}
            """

            cursor.execute(query, params)
            rows = cursor.fetchall()
            columns = [d[0] for d in cursor.description]
            return [dict(zip(columns, [serialize(val) for val in row])) for row in rows]


def serialize(v):
    if isinstance(v, Decimal): return float(v)
    if hasattr(v, "isoformat"): return str(v)
    return v


# Table configuration
CATALOG = os.environ.get("DATABRICKS_CATALOG", "text_analytics")
SCHEMA = os.environ.get("DATABRICKS_SCHEMA", "nlp_analytics")
CALL_DATA = f"{CATALOG}.{SCHEMA}.call_data"
CALL_TABLE = f"{CATALOG}.{SCHEMA}.call_table"
TURN_TABLE = f"{CATALOG}.{SCHEMA}.turn_table"
PARTS_ACCESSORIES = f"{CATALOG}.{SCHEMA}.parts_accessories"
MODELS = f"{CATALOG}.{SCHEMA}.models"
TOPIC_XWALK = f"{CATALOG}.{SCHEMA}.topic_xwalk"
TOPIC_DETAIL = f"{CATALOG}.nlp_configs.topic_detail"
MODEL_PAIN_POINTS = f"{CATALOG}.nlp_agent.model_pain_points"
EMBEDDING_TABLE = f"{CATALOG}.nlp_agent.call_summary_qwen06b"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--query", help="Semantic search query (e.g., 'NHTSA safety complaints')")
    parser.add_argument("--keywords", help="Traditional keyword search (comma-separated)")
    parser.add_argument("--semantic", action="store_true", help="Enable semantic search via Qwen 0.6B embeddings")
    parser.add_argument("--similarity-threshold", type=float, default=0.4, help="Similarity threshold for semantic search")
    parser.add_argument("--semantic-limit", type=int, default=1000, help="Max semantic matches to find")
    parser.add_argument("--vehicle", help="Vehicle filter (partial match)")
    parser.add_argument("--sentiment", choices=["positive", "neutral", "negative"], help="Sentiment filter")
    parser.add_argument("--from", dest="date_from", help="Start date YYYY-MM-DD")
    parser.add_argument("--to", dest="date_to", help="End date YYYY-MM-DD")
    parser.add_argument("--limit", type=int, default=500, help="Max transcripts (1-500)")
    parser.add_argument("--format", choices=["json", "csv"], default="json", help="Output format")
    parser.add_argument("--detail-level", choices=["calls", "turns"], default="calls", help="Call summary or turn-by-turn detail")
    parser.add_argument("--sort", choices=["recent", "negative", "complexity"], default="negative", help="Sort order")
    parser.add_argument("--include-emotions", action="store_true", help="Include emotion analysis")
    parser.add_argument("--include-toxicity", action="store_true", help="Include toxicity/threat scores")
    parser.add_argument("--traditional", action="store_true", help="Force traditional keyword search")
    args, _ = parser.parse_known_args()

    # Validate limit
    if args.limit < 1 or args.limit > 500:
        print(json.dumps({"error": "Limit must be between 1 and 500"}), file=sys.stderr)
        sys.exit(1)

    # Determine search method
    use_semantic = args.semantic and not args.traditional and (args.query or args.keywords)
    search_query = args.query or args.keywords or ""

    result = {
        "search_method": "enhanced_semantic" if use_semantic else "traditional_keyword",
        "parameters": {
            "query": search_query,
            "semantic_enabled": use_semantic,
            "similarity_threshold": args.similarity_threshold if use_semantic else None,
            "vehicle": args.vehicle or "all",
            "sentiment": args.sentiment or "all",
            "date_range": f"{args.date_from or 'all time'} to {args.date_to or 'all time'}",
            "limit": args.limit,
            "detail_level": args.detail_level,
            "sort_order": args.sort
        },
        "transcripts": []
    }

    try:
        if use_semantic and search_query:
            print(f"Generating query embedding using Qwen 0.6B model...", file=sys.stderr)

            # Generate embedding for search query
            query_embedding = _get_embedding(search_query)
            if not query_embedding:
                print("Semantic search failed, falling back to traditional search", file=sys.stderr)
                result["transcripts"] = get_traditional_transcripts(
                    args.keywords, args.vehicle, args.sentiment,
                    args.date_from, args.date_to, args.sort, args.limit
                )
                result["search_method"] = "fallback_traditional"
            else:
                # Semantic search
                semantic_call_ids = get_semantic_call_ids(
                    query_embedding,
                    vehicle_filter=args.vehicle,
                    similarity_threshold=args.similarity_threshold,
                    limit=args.semantic_limit,
                    date_from=args.date_from or "2020-01-01",
                    date_to=args.date_to or "2030-12-31"
                )

                print(f"Found {len(semantic_call_ids)} semantically similar calls", file=sys.stderr)
                result["semantic_matches_found"] = len(semantic_call_ids)

                # Get enhanced transcripts
                result["transcripts"] = get_enhanced_transcripts(
                    semantic_call_ids,
                    detail_level=args.detail_level,
                    include_emotions=args.include_emotions,
                    include_toxicity=args.include_toxicity,
                    sort_order=args.sort,
                    limit=args.limit
                )
        else:
            # Traditional keyword search
            result["transcripts"] = get_traditional_transcripts(
                args.keywords, args.vehicle, args.sentiment,
                args.date_from, args.date_to, args.sort, args.limit
            )

        # Add summary statistics
        result["total_transcripts_returned"] = len(result["transcripts"])
        if result["transcripts"]:
            if args.detail_level == "calls":
                negative_count = sum(1 for t in result["transcripts"] if t.get("sentiment_label") == "Negative")
                result["negative_sentiment_pct"] = round(negative_count / len(result["transcripts"]) * 100, 1)
            else:
                # Turn-level statistics
                customer_turns = [t for t in result["transcripts"] if t.get("speaker_role") == "customer"]
                if customer_turns:
                    avg_customer_sentiment = sum(t.get("turn_sentiment", 0) for t in customer_turns) / len(customer_turns)
                    result["avg_customer_sentiment"] = round(avg_customer_sentiment, 3)

        # Output based on format
        if args.format == "csv":
            # Generate CSV file
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"transcript_export_{timestamp}.csv"

            if result["transcripts"]:
                with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
                    fieldnames = result["transcripts"][0].keys()
                    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                    writer.writeheader()
                    writer.writerows(result["transcripts"])

                print(json.dumps({
                    "status": "success",
                    "format": "csv",
                    "filename": filename,
                    "search_method": result["search_method"],
                    "total_transcripts_exported": len(result["transcripts"]),
                    "parameters": result["parameters"]
                }, indent=2))
            else:
                print(json.dumps({
                    "status": "no_results",
                    "search_method": result["search_method"],
                    "parameters": result["parameters"]
                }, indent=2))
        else:
            # JSON output
            print(json.dumps(result, indent=2))

    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()