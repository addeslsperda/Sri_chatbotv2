---
name: data_discovery
display_name: Data Discovery
description: Checks what data is actually available  the earliest and latest call dates, total call count, and all vehicle names with their call counts. Always use this FIRST when the user's date range returns no results, or when unsure what vehicle names look like in the database.
signals:
  # DATA AVAILABILITY SIGNALS - Primary routing
  - what data is available
  - what data is available for
  - data available for
  - check data availability
  - available data for
  - what data exists
  - data exists for
  
  # COVERAGE & DISCOVERY SIGNALS  
  - what vehicles are available
  - check available vehicles
  - available vehicle data
  - vehicle data coverage
  - data coverage for
  - coverage analysis
  
  # DATE RANGE SIGNALS
  - what date range is available
  - available date range
  - earliest date
  - latest date
  - date coverage
  
  # DATA QUALITY SIGNALS
  - data quality for
  - data completeness
  - no results found
  - check why no results
requires: []
not_good_for: Actual analysis  use this only to discover what data exists before running other skills
---

# Data Discovery

## What this script does
Queries `call_data` to return the min/max call dates, total call count, and a ranked list of all vehicle names. Use this when a query returns no results to confirm the correct date range and vehicle name spelling.

## How to run it

```bash
python .claude/skills/data_discovery/scripts/data_discovery.py
```

## Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--check` | No | `all` | `all`, `dates`, or `vehicles` |

## Example calls

```bash
# Check everything
python .claude/skills/data_discovery/scripts/data_discovery.py

# Check only date range
python .claude/skills/data_discovery/scripts/data_discovery.py --check dates

# Check vehicle names
python .claude/skills/data_discovery/scripts/data_discovery.py --check vehicles
```

## Output format

```json
{
  "min_date": "2025-01-01",
  "max_date": "2025-12-31",
  "total_calls": 142831,
  "vehicles": [
    { "modelvehicleline": "F-150", "call_count": 48221 },
    { "modelvehicleline": "Mustang Mach-E", "call_count": 18432 }
  ]
}
```

## Error output
If something goes wrong, the script prints `{"error": "..."}` to stderr and exits with code 1.
