---
name: third_party_mentions
display_name: Third-Party Product & Service Analysis
description: Advanced semantic analysis of third-party product/service mentions using Qwen 0.6B embeddings with comprehensive multi-table intelligence. Tracks Amazon chargers, Tesla adapters, AT&T connectivity, SiriusXM, Alexa, and all external vendor interactions. Provides sentiment analysis, issue categorization, brand detection, and business intelligence.
signals:
  - amazon
  - at&t
  - att
  - tesla
  - sirius
  - siriusxm
  - alexa
  - third party
  - third-party
  - chargepoint
  - electrify america
  - evgo
  - google
  - apple
  - carplay
  - android auto
requires:
  - third-party entity name or category
  - date range
not_good_for: Ford-owned services (use other skills), general keyword search (use keyword_search)
---

# Third-Party Product & Service Analysis - PRODUCTION VERSION

## What this script does
Advanced semantic analysis using Qwen 0.6B embeddings to track and analyze third-party product/service mentions in customer calls. Provides comprehensive business intelligence including:

- **Semantic Discovery**: Finds mentions using AI embeddings (not just keyword matching)
- **Sentiment Analysis**: Customer/agent sentiment patterns for third-party experiences  
- **Ford Topic Taxonomy**: Uses Ford's official 3-level topic classification system
- **Parts Correlation**: Links to Ford's parts/features data for technical context
- **Customer Pain Points**: Real customer feedback from Ford's pain points system
- **Business Intelligence**: Volume trends, team analysis, complexity metrics
- **Multi-Table Integration**: Complete Ford data ecosystem integration

### **Supported Third-Party Categories:**
- **Charging**: Amazon chargers, Tesla adapters/superchargers, ChargePoint, Electrify America, EVgo, third-party adapters
- **Connectivity**: AT&T, Verizon, T-Mobile, cellular networks, WiFi hotspots
- **Entertainment**: SiriusXM, Alexa/Amazon Alexa Built-In, Spotify integration
- **Mobile Integration**: Apple CarPlay, Android Auto, Google Assistant
- **Other**: Third-party accessories, aftermarket parts, external services

## How to run it

```bash
python .claude/skills/third_party_mentions/scripts/third_party_mentions.py --entity "Amazon" --from 2026-01-01 --to 2026-01-31
```

## Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--entity` | Yes |  | Third-party entity name or keyword (e.g., "Amazon", "Tesla", "AT&T") |
| `--from` | Yes |  | Start date YYYY-MM-DD |
| `--to` | Yes |  | End date YYYY-MM-DD |
| `--vehicle` | No | all | Filter by vehicle model |
| `--category` | No | all | Category: `charging`, `connectivity`, `entertainment`, `mobile`, `accessories` |
| `--sentiment` | No | all | Filter: `positive`, `neutral`, `negative` |
| `--similarity-threshold` | No | `0.4` | Semantic similarity threshold (0.0-1.0) |
| `--semantic-limit` | No | `5000` | Max semantic matches to analyze |
| `--include-transcripts` | No | `false` | Include full transcript examples |
| `--include-pain-points` | No | `false` | Include customer pain point analysis |
| `--limit` | No | `20` | Max example calls to return |

## Example calls

```bash
# Amazon charger semantic analysis
python .claude/skills/third_party_mentions/scripts/third_party_mentions.py --entity "Amazon chargers" --from 2026-01-01 --to 2026-01-31 --include-pain-points

# Tesla adapter comprehensive analysis
python .claude/skills/third_party_mentions/scripts/third_party_mentions.py --entity "Tesla adapters NACS" --vehicle "Mach-E" --from 2026-01-01 --to 2026-01-31 --include-transcripts

# AT&T connectivity issues with sentiment analysis
python .claude/skills/third_party_mentions/scripts/third_party_mentions.py --entity "AT&T WiFi connectivity" --from 2026-01-01 --to 2026-01-31 --sentiment negative

# SiriusXM subscription problems
python .claude/skills/third_party_mentions/scripts/third_party_mentions.py --entity "SiriusXM subscription billing" --from 2026-01-01 --to 2026-01-31 --category entertainment

# Third-party adapter brand analysis
python .claude/skills/third_party_mentions/scripts/third_party_mentions.py --entity "third party adapters compatibility" --from 2026-01-01 --to 2026-01-31 --similarity-threshold 0.35

# Apple CarPlay integration issues
python .claude/skills/third_party_mentions/scripts/third_party_mentions.py --entity "Apple CarPlay connection problems" --from 2026-01-01 --to 2026-01-31 --category mobile
```

## Enhanced Output Format

```json
{
  "status": "success",
  "analysis_type": "semantic_third_party_analysis",
  "parameters": {
    "entity": "Amazon chargers",
    "search_method": "qwen_embeddings_cosine_similarity",
    "embedding_model": "Qwen/Qwen3-Embedding-0.6B",
    "similarity_threshold": 0.4,
    "semantic_limit": 5000,
    "date_range": {"from": "2026-01-01", "to": "2026-01-31"}
  },
  "results": {
    "total_semantic_matches": 1285,
    "pct_of_total_calls": 0.9,
    "semantic_classification": "THIRD_PARTY_HIGH_NEGATIVE",
    "priority_score": 78.5
  },
  "sentiment_analysis": {
    "avg_customer_sentiment": -0.25,
    "avg_agent_sentiment": 0.15,
    "sentiment_gap": -0.40,
    "sentiment_breakdown": {
      "positive": 285,
      "neutral": 520, 
      "negative": 480
    },
    "sentiment_journey": {
      "avg_start_sentiment": -0.15,
      "avg_end_sentiment": -0.25,
      "deterioration_pct": 65.2
    }
  },
  "ford_topic_analysis": {
    "top_topics": [
      {"topic_level1": "Vehicle", "topic_level2": "Electrical", "topic_level3": "Charging", "count": 567, "avg_sentiment": -0.35},
      {"topic_level1": "Customer Service", "topic_level2": "Order Management", "topic_level3": "Delivery", "count": 234, "avg_sentiment": -0.42}
    ]
  },
  "parts_correlation": {
    "top_parts": [
      {"parts_features": "Charging Port", "parts_concern": "Compatibility with third-party chargers", "count": 345, "avg_sentiment": -0.38},
      {"parts_features": "Charging Cable", "parts_concern": "Adapter connection issues", "count": 189, "avg_sentiment": -0.41}
    ]
  },
  "vehicle_breakdown": [
    {"vehicle": "MUSTANG MACH-E", "mentions": 685, "negative_pct": 42.1},
    {"vehicle": "F-150 LIGHTNING", "mentions": 245, "negative_pct": 38.8}
  ],
  "team_analysis": {
    "primary_teams": [
      {"team": "FMNA_US_CRC_EN_BEV", "calls": 456, "avg_handle_time": 18.5},
      {"team": "FMNA_US_CRC_EN_TRUCK", "calls": 234, "avg_handle_time": 16.2}
    ]
  },
  "business_metrics": {
    "avg_complexity": 8.2,
    "avg_handle_time_min": 17.3,
    "escalated_calls": 89,
    "escalation_rate_pct": 6.9
  },
  "topic_analysis": {
    "top_topics": [
      {"topic": "Charging Equipment", "level1": "Vehicle", "level2": "Electrical", "level3": "Charging", "count": 567},
      {"topic": "Delivery Issues", "level1": "Customer Service", "level2": "Order Management", "level3": "Delivery", "count": 234}
    ]
  },
  "pain_points": [
    {
      "pain_point": "Third-party charger compatibility issues",
      "call_count": 123,
      "customer_feedback": "Charger from Amazon doesn't work with my Mach-E, very frustrated...",
      "avg_sentiment": -0.67
    }
  ],
  "examples": [
    {
      "call_id": "abc123",
      "call_date": "2026-01-15",
      "vehicle": "MUSTANG MACH-E",
      "sentiment": -0.45,
      "topic_level1": "Vehicle",
      "topic_level2": "Electrical", 
      "topic_level3": "Charging",
      "parts_features": "Charging Port",
      "parts_concern": "Third-party charger compatibility",
      "summary": "Customer ordered home charger from Amazon but received wrong model...",
      "pain_point": "Third-party ordering confusion",
      "customer_feedback": "This is my third call about this charger issue...",
      "team": "FMNA_US_CRC_EN_BEV",
      "complexity": 7.2,
      "handle_time_min": 22.1
    }
  ],
  "insights": {
    "summary": {
      "classification": "THIRD_PARTY_HIGH_NEGATIVE", 
      "primary_issues": ["delivery_problems", "compatibility_issues"],
      "most_affected_vehicle": "MUSTANG MACH-E",
      "trend": "increasing_negative_sentiment"
    },
    "recommendations": [
      {
        "action": "Partner with Amazon on Ford-certified charger program",
        "priority": "high",
        "estimated_impact": "Reduce compatibility issues by 60%"
      }
    ]
  }
}
```

## Enhanced Features

### **Semantic Intelligence**
- **True Cosine Similarity**: Uses Qwen 0.6B embeddings for precise semantic matching
- **Context Aware**: Distinguishes "Tesla adapter problems" from "Tesla vehicle discussions"
- **Natural Language**: Finds mentions even when customers don't use exact brand names

### **Multi-Dimensional Analysis**
- **Sentiment Journey**: Tracks how sentiment changes during third-party discussions
- **Ford Topic Taxonomy**: Uses Ford's official topic classification hierarchy (3 levels)
- **Parts Integration**: Links to Ford's parts/features database for hardware context
- **Pain Point Analysis**: Incorporates Ford's customer pain point system

### **Business Intelligence**
- **Team Impact**: Which Ford teams handle third-party issues most
- **Complexity Analysis**: How third-party issues affect call complexity
- **Vehicle Correlation**: Which vehicles have most third-party issues
- **Trend Analysis**: Emerging patterns in third-party mentions

### **Integration Depth**
- **Pain Points**: Customer feedback about third-party experiences
- **Topic Classification**: Full 3-level topic hierarchy for third-party issues  
- **Case Analysis**: Links to case management data for resolution tracking
- **Transcript Access**: Full conversation details when requested

## Ford's Third-Party Integrations Reference

### **Ford Services with Third-Party Components:**
- **ford_bluecruise** - Ford BlueCruise: Hands-free highway driving technology developed by Ford Motor Company
- **ford_security_package** - Ford Security Package: Optional upgrade available on select Ford vehicles  
- **ford_connectivity_package** - Ford Connectivity Package: Subscription service that enhances Ford vehicle technology
- **mustang_mache_performance_upgrade** - Mustang Mach-E Performance Upgrade: Optional performance enhancement
- **ford_premium_connectivity** - Ford Premium Connectivity: Standalone service for enhanced vehicle connectivity
- **ford_connected_navigation** - Ford Connected Navigation: Cloud-connected, in-vehicle navigation system via SYNC 4/4A
- **ford_blue_oval_charge_network** - Ford Blue Oval Charge Network (BOCN): Unified network allowing Ford all-electric vehicle access
- **alexa** - Ford Alexa Built-In: Amazon Alexa Built-in voice assistant integrated into Ford SYNC 4/4A systems
- **sirius_xm** - Sirius XM in Ford Vehicles: SiriusXM satellite radio service across Ford vehicle lineup
- **att_wifi_hotspot** - AT&T WiFi Hotspot in Ford Vehicles: FordPass Connect includes embedded AT&T-powered 4G LTE

*Use this skill to analyze customer experiences with these Ford-integrated third-party services and external vendor products.*

## Error handling
If something goes wrong, the script prints `{"error": "..."}` to stderr and exits with code 1.

## Notes
- **Semantic Search**: Finds relevant calls even with indirect mentions
- **Data-Driven Thresholds**: Uses Ford's actual sentiment baselines for classification
- **Multi-Table Intelligence**: Enriches with pain points, topics, parts, teams, and case data
- **Brand Agnostic**: Automatically detects any third-party brand mentioned
- **Scalable**: Handles large volume analysis with configurable limits
- **Business Focused**: Provides actionable insights for partner relationship management