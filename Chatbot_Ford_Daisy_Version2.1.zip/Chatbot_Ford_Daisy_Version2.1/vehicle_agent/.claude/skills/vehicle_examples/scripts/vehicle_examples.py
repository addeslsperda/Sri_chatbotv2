"""
ENHANCED SEMANTIC VEHICLE EXAMPLES - Production Version

Multi-table semantic intelligence using Qwen 0.6B embeddings for discovering
contextually related customer verbatims with rich parts, model, and topic correlation.

Features:
- Semantic discovery via Qwen 0.6B embeddings (same model as call_summary_qwen06b table)
- Multi-table intelligence (parts_accessories, models, topic_detail, model_pain_points)
- Exact verbatim extraction from transcripts
- Follow-up analysis pipeline on matching call_ids
- Fallback to traditional keyword search

Usage:
    python vehicle_examples_enhanced.py --vehicle "F-150" --topic "transmission" --semantic
    python vehicle_examples_enhanced.py --vehicle "Bronco" --topic "doors" --semantic --limit 10
    python vehicle_examples_enhanced.py --vehicle "Mach-E" --topic "charging" --deep-analysis
    python vehicle_examples_enhanced.py --vehicle "Explorer" --topic "brake noise" --semantic --similarity-threshold 0.3
"""
import argparse
import json
import os
import sys
import numpy as np
from decimal import Decimal
from pathlib import Path
from databricks import sql
# Import vector search with fallback
try:
    from databricks.vector_search.client import VectorSearchClient
    from databricks.sdk import WorkspaceClient
    VECTOR_SEARCH_AVAILABLE = True
except ImportError:
    VECTOR_SEARCH_AVAILABLE = False
import requests
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parents[4] / ".env", override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


def cosine_similarity(vec1, vec2):
    """Calculate cosine similarity between two vectors"""
    vec1 = np.array(vec1)
    vec2 = np.array(vec2)
    return np.dot(vec1, vec2) / (np.linalg.norm(vec1) * np.linalg.norm(vec2))


def _get_embedding(query_str: str) -> list[float]:
    """Get query embedding using EXACT SAME Qwen/Qwen3-Embedding-0.6B model"""

    # Method 1: Try Databricks Qwen endpoint (preferred - same model used for table embeddings)
    if VECTOR_SEARCH_AVAILABLE:
        try:
            w = WorkspaceClient(
                host=os.environ.get("DATABRICKS_HOST"),
                client_id=os.environ.get("DATABRICKS_CLIENT_ID"),
                client_secret=os.environ.get("DATABRICKS_CLIENT_SECRET")
            )
            response = w.serving_endpoints.query(
                name="qwen3-embedding-06b",
                instances=[query_str]
            )
            return response.predictions[0]
        except Exception as e:
            print(f"Databricks Qwen embedding failed: {e}", file=sys.stderr)

    # Method 2: Local Qwen 0.6B model (EXACT SAME MODEL)
    try:
        from sentence_transformers import SentenceTransformer

        print(f"Loading Qwen 0.6B model locally...", file=sys.stderr)
        model = SentenceTransformer(
            "Qwen/Qwen3-Embedding-0.6B",
            processor_kwargs={"padding_side": "left"}
        )
        embedding = model.encode([query_str])
        print(f"Query embedding generated successfully (dimension: {len(embedding[0])})", file=sys.stderr)
        return embedding[0].tolist()
    except Exception as e:
        print(f"Local Qwen 0.6B embedding failed: {e}", file=sys.stderr)
        return None


def get_semantic_call_ids(query_embedding, vehicle_filter=None, similarity_threshold=0.25, limit=500, date_from="2024-01-01", date_to="2030-12-31"):
    """
    Find call_ids with embeddings similar to query_embedding using cosine similarity
    """
    semantic_call_ids = []

    with get_connection() as conn:
        with conn.cursor() as cursor:
            print(f"Finding semantically similar calls (threshold: {similarity_threshold})...", file=sys.stderr)

            # Build vehicle filter for embedding table query
            vehicle_where = ""
            params = {"date_from": date_from, "date_to": date_to}

            if vehicle_filter:
                # We need to join with call_data to filter by vehicle
                vehicle_where = """
                AND EXISTS (
                    SELECT 1 FROM {CALL_DATA} cd
                    WHERE cd.call_id = emb.call_id
                    AND LOWER(cd.modelvehicleline) LIKE LOWER(:vehicle)
                )
                """.format(CALL_DATA=CALL_DATA)
                params["vehicle"] = f"%{vehicle_filter}%"

            # Fetch embeddings in batches (INCREASED COVERAGE)
            batch_size = 2000
            offset = 0
            max_batches = 25  # Increased from 10 to 25
            batch_count = 0

            while len(semantic_call_ids) < limit and batch_count < max_batches:
                query = f"""
                    SELECT emb.call_id, emb.embeddings
                    FROM {EMBEDDING_TABLE} emb
                    WHERE emb.call_date >= :date_from
                      AND emb.call_date <= :date_to
                      {vehicle_where}
                    ORDER BY emb.call_date DESC
                    LIMIT {batch_size} OFFSET {offset}
                """

                cursor.execute(query, params)
                batch_results = cursor.fetchall()
                if not batch_results:
                    break

                batch_count += 1
                print(f"Processing batch {batch_count}: {len(batch_results)} embeddings", file=sys.stderr)

                # Calculate similarities for this batch
                batch_similarities = []
                for call_id, db_embedding in batch_results:
                    try:
                        if db_embedding:
                            import ast
                            try:
                                # Parse JSON array format
                                embedding_str = str(db_embedding)
                                if embedding_str.startswith('[') and embedding_str.endswith(']'):
                                    db_emb_list = ast.literal_eval(embedding_str)
                                    embedding_array = np.array(db_emb_list)
                                else:
                                    embedding_array = np.array(db_embedding)
                            except:
                                continue

                            if len(embedding_array) == len(query_embedding):
                                similarity = cosine_similarity(query_embedding, embedding_array)
                                if similarity >= similarity_threshold:
                                    batch_similarities.append((call_id, similarity))
                    except Exception:
                        continue

                # Sort by similarity and add to results
                batch_similarities.sort(key=lambda x: x[1], reverse=True)
                for call_id, similarity in batch_similarities:
                    if len(semantic_call_ids) < limit:
                        semantic_call_ids.append(call_id)

                print(f"Found {len(batch_similarities)} similar calls in this batch (total: {len(semantic_call_ids)})", file=sys.stderr)
                offset += batch_size

                if len(semantic_call_ids) >= limit or offset >= 200000:  # Increased search range
                    break

    return semantic_call_ids


def get_multi_table_verbatims(call_ids, vehicle_filter=None, limit=50):
    """
    Get enriched customer verbatims with multi-table intelligence
    """
    if not call_ids:
        return []

    # Convert call_ids to SQL IN clause (BALANCED SAMPLING)
    call_id_list = "'" + "', '".join(call_ids[:limit*4]) + "'"  # Get even more for diverse sampling

    with get_connection() as conn:
        with conn.cursor() as cursor:
            # Multi-table enriched query
            query = f"""
                SELECT
                    cd.call_id,
                    DATE(cd.call_date) AS call_date,
                    cd.modelvehicleline,
                    cd.modelyear,
                    ct.summary,
                    cd.sentiment_label,
                    ROUND(cd.sentiment, 4) AS sentiment_score,

                    -- Parts & Accessories Intelligence
                    pa.parts_features,
                    pa.parts_concern,

                    -- Model Intelligence
                    m.ModelVehicleLine as model_vehicle_line,
                    m.Model_Year as model_year,

                    -- Pain Points Intelligence
                    mpp.pain_point,
                    mpp.customer_feedback,
                    mpp.considering_switching_brands,
                    mpp.reason_for_considering_switching_brands,

                    -- Topic Classification (proper linkage via topic_xwalk)
                    tx.topic_name,
                    tx.topic_category as topic_category_xwalk,
                    td.topic_category as topic_category_detail,
                    td.topic_level1,
                    td.topic_level2,
                    td.topic_level3,
                    td.topic_joiner

                FROM {CALL_DATA} cd
                JOIN {CALL_TABLE} ct ON cd.call_id = ct.call_id
                LEFT JOIN {PARTS_ACCESSORIES} pa ON cd.call_id = pa.call_id
                LEFT JOIN {MODELS} m ON cd.call_id = m.call_id
                LEFT JOIN {MODEL_PAIN_POINTS} mpp ON cd.call_id = mpp.call_id
                LEFT JOIN {TOPIC_XWALK} tx ON cd.call_id = tx.call_id
                LEFT JOIN {TOPIC_DETAIL} td ON tx.topic_id = td.topic_id

                WHERE cd.call_id IN ({call_id_list})
                  AND ct.summary IS NOT NULL
                  AND LENGTH(ct.summary) > 50
            """

            # Add vehicle filter if specified (SECURE PARAMETER BINDING)
            if vehicle_filter:
                query += " AND LOWER(cd.modelvehicleline) LIKE LOWER(:vehicle_filter)"
                # Note: params will be passed to cursor.execute()

            # Get diverse sentiment sample - mix negative, neutral, and positive
            query += f"""
                ORDER BY
                  CASE
                    WHEN cd.sentiment < -0.1 THEN 1  -- Negative first (but not all)
                    WHEN cd.sentiment BETWEEN -0.1 AND 0.1 THEN 2  -- Neutral second
                    ELSE 3  -- Positive last
                  END,
                  RAND(),  -- Random within each sentiment group (Databricks compatible)
                  cd.call_date DESC
                LIMIT {limit}
            """

            # SECURE: Pass vehicle_filter as parameter to prevent SQL injection
            params = {}
            if vehicle_filter:
                params["vehicle_filter"] = f"%{vehicle_filter}%"

            cursor.execute(query, params)
            rows = cursor.fetchall()
            columns = [d[0] for d in cursor.description]

            # Serialize results
            verbatims = []
            for row in rows:
                verbatim = {}
                for i, col in enumerate(columns):
                    value = row[i]
                    if isinstance(value, Decimal):
                        verbatim[col] = float(value)
                    elif hasattr(value, "isoformat"):
                        verbatim[col] = str(value)
                    else:
                        verbatim[col] = value
                verbatims.append(verbatim)

            return verbatims


def get_follow_up_analytics(call_ids):
    """
    Generate follow-up analysis insights on matching call_ids
    """
    if not call_ids:
        return {}

    call_id_list = "'" + "', '".join(call_ids) + "'"

    with get_connection() as conn:
        with conn.cursor() as cursor:
            # Parts correlation analysis (using actual schema)
            cursor.execute(f"""
                SELECT
                    pa.parts_concern as concern_category,
                    pa.parts_features as feature_category,
                    COUNT(*) as call_count,
                    ROUND(AVG(cd.sentiment), 3) as avg_sentiment
                FROM {CALL_DATA} cd
                JOIN {PARTS_ACCESSORIES} pa ON cd.call_id = pa.call_id
                WHERE cd.call_id IN ({call_id_list})
                  AND (pa.parts_concern IS NOT NULL OR pa.parts_features IS NOT NULL)
                GROUP BY pa.parts_concern, pa.parts_features
                ORDER BY call_count DESC
                LIMIT 15
            """)
            parts_analysis = [dict(zip([d[0] for d in cursor.description], row)) for row in cursor.fetchall()]

            # Cross-vehicle analysis
            cursor.execute(f"""
                SELECT
                    cd.modelvehicleline,
                    COUNT(*) as call_count,
                    ROUND(AVG(cd.sentiment), 3) as avg_sentiment,
                    COUNT(CASE WHEN cd.sentiment_label = 'Negative' THEN 1 END) as negative_calls
                FROM {CALL_DATA} cd
                WHERE cd.call_id IN ({call_id_list})
                  AND cd.modelvehicleline IS NOT NULL
                GROUP BY cd.modelvehicleline
                ORDER BY call_count DESC
                LIMIT 15
            """)
            vehicle_analysis = [dict(zip([d[0] for d in cursor.description], row)) for row in cursor.fetchall()]

            # Topic correlation (using proper linkage via topic_xwalk)
            cursor.execute(f"""
                SELECT
                    tx.topic_name,
                    td.topic_category,
                    td.topic_level1,
                    td.topic_level2,
                    COUNT(*) as call_count,
                    ROUND(AVG(cd.sentiment), 3) as avg_sentiment
                FROM {CALL_DATA} cd
                LEFT JOIN {TOPIC_XWALK} tx ON cd.call_id = tx.call_id
                LEFT JOIN {TOPIC_DETAIL} td ON tx.topic_id = td.topic_id
                WHERE cd.call_id IN ({call_id_list})
                  AND (tx.topic_name IS NOT NULL OR td.topic_category IS NOT NULL)
                GROUP BY tx.topic_name, td.topic_category, td.topic_level1, td.topic_level2
                ORDER BY call_count DESC
                LIMIT 15
            """)
            topic_analysis = [dict(zip([d[0] for d in cursor.description], row)) for row in cursor.fetchall()]

            return {
                "parts_correlation": parts_analysis,
                "cross_vehicle_analysis": vehicle_analysis,
                "topic_correlation": topic_analysis,
                "total_analyzed_calls": len(call_ids)
            }


def get_traditional_verbatims(vehicle, topic, date_from=None, date_to=None, limit=50):
    """
    Fallback traditional keyword search
    """
    base_params = {}
    date_filters = []

    if date_from:
        base_params["date_from"] = date_from
        date_filters.append("DATE(cd.call_date) >= :date_from")
    if date_to:
        base_params["date_to"] = date_to
        date_filters.append("DATE(cd.call_date) <= :date_to")

    base_filters = date_filters.copy()
    if vehicle:
        base_params["vehicle"] = f"%{vehicle}%"
        base_filters.insert(0, "LOWER(cd.modelvehicleline) LIKE LOWER(:vehicle)")

    topic_params = dict(base_params)
    topic_params["topic"] = f"%{topic}%"
    topic_filter = "(LOWER(ct.summary) LIKE LOWER(:topic) OR LOWER(ct.transcript) LIKE LOWER(:topic))"
    topic_filters = base_filters + [topic_filter, "ct.summary IS NOT NULL", "LENGTH(ct.summary) > 50"]

    topic_where = " AND ".join(topic_filters) if topic_filters else "1=1"

    with get_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(f"""
                SELECT
                    cd.call_id,
                    DATE(cd.call_date) AS call_date,
                    cd.modelvehicleline,
                    cd.modelyear,
                    ct.summary,
                    cd.sentiment_label,
                    ROUND(cd.sentiment, 4) AS sentiment_score
                FROM {CALL_DATA} cd
                JOIN {CALL_TABLE} ct ON cd.call_id = ct.call_id
                WHERE {topic_where}
                ORDER BY cd.sentiment ASC NULLS LAST, cd.call_date DESC
                LIMIT {limit}
            """, topic_params)

            rows = cursor.fetchall()
            columns = [d[0] for d in cursor.description]
            return [dict(zip(columns, [serialize(val) for val in row])) for row in rows]


def serialize(v):
    if isinstance(v, Decimal): return float(v)
    if hasattr(v, "isoformat"): return str(v)
    return v


# Table configuration
CATALOG = os.environ.get("DATABRICKS_CATALOG", "text_analytics")
SCHEMA = os.environ.get("DATABRICKS_SCHEMA", "nlp_analytics")
CALL_DATA = f"{CATALOG}.{SCHEMA}.call_data"
CALL_TABLE = f"{CATALOG}.{SCHEMA}.call_table"
PARTS_ACCESSORIES = f"{CATALOG}.{SCHEMA}.parts_accessories"
MODELS = f"{CATALOG}.{SCHEMA}.models"
TOPIC_XWALK = f"{CATALOG}.{SCHEMA}.topic_xwalk"
TOPIC_DETAIL = f"{CATALOG}.nlp_configs.topic_detail"
MODEL_PAIN_POINTS = f"{CATALOG}.nlp_agent.model_pain_points"
EMBEDDING_TABLE = f"{CATALOG}.nlp_agent.call_summary_qwen06b"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--vehicle", required=False, default=None)
    parser.add_argument("--topic", required=False, default=None)
    parser.add_argument("--keyword", required=False, default=None)  # Alias for --topic
    parser.add_argument("--from", dest="date_from", default=None)
    parser.add_argument("--to", dest="date_to", default=None)
    parser.add_argument("--limit", type=int, default=50)  # Increased from 20 to 50
    parser.add_argument("--semantic", action="store_true",
                       help="Use semantic search via Qwen 0.6B embeddings")
    parser.add_argument("--similarity-threshold", type=float, default=0.25,  # Lowered from 0.4 to 0.25
                       help="Minimum similarity for semantic matching (0.0-1.0)")
    parser.add_argument("--semantic-limit", type=int, default=5000,  # Increased from 2000 to 5000
                       help="Max semantic matches to find before filtering")
    parser.add_argument("--deep-analysis", action="store_true",
                       help="Include follow-up analysis (parts, topics, cross-vehicle)")
    args, _ = parser.parse_known_args()

    # Support --keyword as alias for --topic
    topic = args.topic or args.keyword or "general"
    vehicle = args.vehicle or ""

    # Build search query
    search_query = f"{vehicle} {topic}".strip()

    result = {
        "search_method": "enhanced_semantic" if args.semantic else "traditional_keyword",
        "parameters": {
            "vehicle": vehicle or "all",
            "topic": topic,
            "search_query": search_query,
            "semantic_enabled": args.semantic,
            "similarity_threshold": args.similarity_threshold if args.semantic else None,
            "deep_analysis": args.deep_analysis
        },
        "verbatims": [],
        "follow_up_analysis": {}
    }

    try:
        if args.semantic:
            print(f"Generating query embedding using Qwen 0.6B model...", file=sys.stderr)

            # Generate embedding for search query
            query_embedding = _get_embedding(search_query)
            if not query_embedding:
                print("Semantic search failed, falling back to traditional search", file=sys.stderr)
                result["verbatims"] = get_traditional_verbatims(vehicle, topic, args.date_from, args.date_to, args.limit)
                result["search_method"] = "fallback_traditional"
            else:
                # Semantic search
                semantic_call_ids = get_semantic_call_ids(
                    query_embedding,
                    vehicle_filter=vehicle if vehicle else None,
                    similarity_threshold=args.similarity_threshold,
                    limit=args.semantic_limit,
                    date_from=args.date_from or "2020-01-01",
                    date_to=args.date_to or "2030-12-31"
                )

                print(f"Found {len(semantic_call_ids)} semantically similar calls", file=sys.stderr)
                result["semantic_matches_found"] = len(semantic_call_ids)

                # Get enriched verbatims
                result["verbatims"] = get_multi_table_verbatims(
                    semantic_call_ids,
                    vehicle_filter=vehicle if vehicle else None,
                    limit=args.limit
                )

                # Deep analysis if requested
                if args.deep_analysis and semantic_call_ids:
                    print(f"Generating follow-up analysis...", file=sys.stderr)
                    result["follow_up_analysis"] = get_follow_up_analytics(semantic_call_ids[:200])  # Analyze top 200
        else:
            # Traditional keyword search
            result["verbatims"] = get_traditional_verbatims(vehicle, topic, args.date_from, args.date_to, args.limit)

        # Add summary statistics
        result["total_verbatims_returned"] = len(result["verbatims"])
        if result["verbatims"]:
            negative_count = sum(1 for v in result["verbatims"] if v.get("sentiment_label") == "Negative")
            result["negative_sentiment_pct"] = round(negative_count / len(result["verbatims"]) * 100, 1)

        print(json.dumps(result, indent=2))

    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()