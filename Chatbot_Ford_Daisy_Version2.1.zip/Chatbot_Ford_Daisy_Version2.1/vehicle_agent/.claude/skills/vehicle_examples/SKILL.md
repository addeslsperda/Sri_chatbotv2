---
name: vehicle_examples
display_name: Enhanced Semantic Vehicle Verbatims
description: Returns real customer verbatims using Qwen 0.6B semantic search with multi-table intelligence. Finds exact customer quotes, complaints, stories, and examples about specific vehicle issues. Best for discovering what customers actually said in their own words.
signals:
  # PRIMARY SIGNALS - Customer verbatim requests
  - what are customers saying
  - show me examples
  - customer verbatim
  - customer examples
  - what do customers say
  - in their own words
  - exact customer feedback
  - customer quotes
  - real customer comments
  - actual customer complaints
  - customer stories
  - verbatim examples
  
  # SEMANTIC DISCOVERY SIGNALS - Finding related issues
  - similar issues
  - related problems
  - find examples of
  - show me calls about
  - semantic search for
  - semantically similar
  - contextually related
  - find related customer feedback
  
  # SPECIFIC ISSUE SIGNALS - Technical problems
  - transmission problems examples
  - battery issues customer feedback
  - brake complaints verbatim
  - engine problems what customers say
  - charging issues examples
  - door problems customer stories
  - electrical issues verbatim
  - suspension complaints examples
  
  # MULTI-TABLE INTELLIGENCE SIGNALS - Rich analysis
  - with parts analysis
  - including sentiment analysis
  - with topic correlation
  - enriched customer examples
  - comprehensive verbatim analysis
  - multi-dimensional customer feedback
  
requires:
  - a topic/issue to search for (e.g., "transmission", "battery", "doors")
  - optionally a vehicle name for focused search

not_good_for: 
  - Pain point category counts (use vehicle_pain_points)
  - Call volume over time (use vehicle_volume) 
  - Agent performance metrics (use operations_agent)
  - Sentiment trend analysis (use sentiment_agent)
  - Brand switching statistics (use issue_breakdown)
  - Topic trending analysis (use topic_trends)
---

# Enhanced Semantic Vehicle Verbatims

## What this skill does
**PRODUCTION-READY SEMANTIC SEARCH**: Uses Qwen 0.6B embeddings (same model as your database) to find contextually related customer calls, then enriches with multi-table Ford intelligence. Returns exact customer verbatims with rich business context.

**Key Capabilities:**
- *** Semantic Discovery**: Finds related issues beyond exact keyword matches using Qwen 0.6B
- *** Multi-Table Intelligence**: Correlates parts, models, topics, and pain points
- *** Exact Verbatims**: Real customer language from call transcripts  
- *** Follow-up Analysis**: Deep dive into call patterns and correlations
- *** Production Fallbacks**: Traditional keyword search if semantic fails
- *** Optimized Performance**: Processes up to 50,000 embeddings for comprehensive coverage

## When to use this skill

### YES **PERFECT FOR:**
```
"Show me F-150 transmission examples"
"What are customers saying about Bronco doors?"
"Find battery complaints from Mach-E owners"
"Customer verbatims about BlueCruise issues"
"Semantic search for charging problems"
"Real customer feedback about brake noise"
"Examples of engine stalling complaints"
"Customer stories about warranty issues"
"What do customers actually say about recalls?"
"Find similar transmission problems across models"
```

### NO **NOT GOOD FOR:**
```
"How many transmission calls this month?"  use vehicle_volume
"Top pain point categories"  use vehicle_pain_points  
"Sentiment trends over time"  use sentiment_agent
"Agent performance metrics"  use operations_agent
"Call volume by hour"  use operations_agent
"Brand switching statistics"  use issue_breakdown
```

## How to run it

**ENHANCED Enhanced Semantic Search (Recommended):**
```bash
# Basic semantic search with optimized parameters
python .claude/skills/vehicle_examples/scripts/vehicle_examples.py --vehicle "F-150" --topic "transmission" --semantic

# Advanced search with more results and lower threshold
python .claude/skills/vehicle_examples/scripts/vehicle_examples.py --vehicle "Bronco" --topic "doors" --semantic --limit 25 --similarity-threshold 0.25

# Cross-vehicle semantic discovery
python .claude/skills/vehicle_examples/scripts/vehicle_examples.py --topic "charging issues" --semantic --limit 30

# Deep analysis with parts/topic correlation
python .claude/skills/vehicle_examples/scripts/vehicle_examples.py --vehicle "Mach-E" --topic "battery" --semantic --deep-analysis
```

**BASIC Traditional Keyword Search (Fallback):**
```bash
python .claude/skills/vehicle_examples/scripts/vehicle_examples.py --vehicle "Explorer" --topic "brake noise" --limit 15
```

## Arguments (PRODUCTION OPTIMIZED)

| Argument | Required | Default | Description |
|---|---|---|---|
| `--vehicle` | No | all | Vehicle name (partial match, optional for semantic search) |
| `--topic` | Yes |  | Issue/topic to search for (e.g., "transmission", "battery") |
| `--keyword` | No |  | Alias for --topic |
| `--semantic` | No | true | Enable semantic search via Qwen 0.6B embeddings |
| `--similarity-threshold` | No | 0.25 | Semantic similarity threshold (0.2-0.4 recommended) |
| `--semantic-limit` | No | 5000 | Max semantic matches to analyze (increased for coverage) |
| `--deep-analysis` | No | false | Include parts/topic/cross-vehicle correlation analysis |
| `--from` | No | 2024-01-01 | Start date YYYY-MM-DD (recent data focus) |
| `--to` | No | current | End date YYYY-MM-DD |
| `--limit` | No | 50 | Number of verbatim examples (increased from 20) |

## Production example calls

### **TARGET Business Intelligence Examples:**
```bash
# Transmission issues with parts analysis
python .claude/skills/vehicle_examples/scripts/vehicle_examples.py --vehicle "F-150" --topic "transmission slipping" --semantic --deep-analysis --limit 20

# Multi-model battery problems
python .claude/skills/vehicle_examples/scripts/vehicle_examples.py --topic "battery dead won't start" --semantic --similarity-threshold 0.3 --limit 30

# Recall-related customer feedback
python .claude/skills/vehicle_examples/scripts/vehicle_examples.py --topic "recall repair problems" --semantic --deep-analysis

# BlueCruise customer experiences
python .claude/skills/vehicle_examples/scripts/vehicle_examples.py --topic "BlueCruise not working hands-free" --semantic --limit 25
```

### *** Semantic Discovery Examples:**
```bash
# Find all charging-related issues (not just exact "charging" mentions)
python .claude/skills/vehicle_examples/scripts/vehicle_examples.py --topic "won't charge slow charging" --semantic --similarity-threshold 0.25

# Discover door/seal related problems semantically
python .claude/skills/vehicle_examples/scripts/vehicle_examples.py --vehicle "Bronco" --topic "door seal wind noise water leak" --semantic

# Engine performance issues across models
python .claude/skills/vehicle_examples/scripts/vehicle_examples.py --topic "engine stalling rough idle power loss" --semantic --deep-analysis
```

## Output format (ENHANCED)

**ENHANCED Enhanced Semantic Output:**
```json
{
  "search_method": "enhanced_semantic",
  "parameters": {
    "vehicle": "F-150",
    "topic": "transmission",
    "search_query": "F-150 transmission",
    "semantic_enabled": true,
    "similarity_threshold": 0.25,
    "semantic_matches_found": 1328,
    "deep_analysis": true
  },
  "verbatims": [
    {
      "call_id": "2026080615444118908069126043403101",
      "call_date": "2026-08-06",
      "modelvehicleline": "F-150",
      "modelyear": "2025",
      "summary": "Customer reports transmission issues with multiple shop visits...",
      "sentiment_label": "Negative",
      "sentiment_score": -0.1295,
      "parts_features": "Transmission",
      "parts_concern": "Multiple issues, including engine problems that keep recurring", 
      "pain_point": "Powertrain",
      "topic_level1": "Vehicle Maintenance and Support",
      "topic_level2": "Customer Service Issues",
      "topic_level3": "Customers experiencing and resolving issues with Ford vehicles"
    }
  ],
  "follow_up_analysis": {
    "total_semantic_matches": 1328,
    "sentiment_distribution": {
      "negative": 65.2, "neutral": 24.8, "positive": 10.0
    },
    "parts_correlation": [
      {"parts_concern": "Transmission failure", "call_count": 245, "avg_sentiment": -0.32},
      {"parts_concern": "Engine problems", "call_count": 123, "avg_sentiment": -0.28}
    ],
    "vehicle_breakdown": [
      {"modelvehicleline": "F-150", "call_count": 890, "negative_pct": 67.2},
      {"modelvehicleline": "F-Series", "call_count": 438, "negative_pct": 71.8}
    ]
  }
}
```

## Routing Intelligence

### **TARGET When Daisy should route here:**
- **Customer verbatim requests**: "What do customers say...", "Show me examples...", "Customer complaints about..."
- **Semantic discovery**: "Find similar issues", "Related problems to...", "Semantically search for..."
- **Specific issue examples**: "Battery problems examples", "Transmission complaints", "Door issues verbatims"
- **Multi-table enrichment**: "With parts analysis", "Including sentiment", "Comprehensive feedback"

### ** When Daisy should route elsewhere:**
- **Counts/volumes**  vehicle_volume, vehicle_pain_points
- **Trends over time**  trend_analysis, sentiment_agent  
- **Agent metrics**  operations_agent
- **Brand switching stats**  issue_breakdown
- **Topic popularity**  topic_trends

## Error handling
- **Semantic search failures**: Automatic fallback to traditional keyword search
- **No matches found**: Returns empty verbatims array with explanation
- **Database errors**: Graceful error messages with retry suggestions
- **Invalid parameters**: Clear validation error messages

## Performance optimizations
- **Batch processing**: 2000 embeddings per batch, up to 25 batches
- **Smart caching**: Recent embeddings processed first
- **Balanced sampling**: Diverse sentiment representation
- **Connection pooling**: Efficient database resource usage