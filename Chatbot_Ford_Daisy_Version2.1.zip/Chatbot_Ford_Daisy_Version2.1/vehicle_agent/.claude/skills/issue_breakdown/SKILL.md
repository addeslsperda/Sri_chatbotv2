---
name: issue_breakdown
display_name: Enhanced Semantic Issue Breakdown  
description: Advanced hierarchical issue drill-down using semantic search (Qwen 0.6B embeddings) with multi-table intelligence. Breaks down vehicle issues by REAL parts features/concerns, topic hierarchy, and pain points. Use for "break down F-150 engine problems", "drill into brake issues by parts", "what specific BlueCruise problems", "analyze transmission issues by components".
signals:
  # PAIN POINT BREAKDOWN SIGNALS - Primary routing
  - break down pain points
  - breakdown pain points
  - pain point breakdown
  - pain points breakdown
  - break down battery pain points
  - breakdown battery issues
  - pain point analysis
  - customer pain points
  - break down issues
  
  # ISSUE ANALYSIS SIGNALS
  - break down
  - drill down
  - drill into
  - specific issues
  - what issues with
  - breakdown by
  - sub-categories
  - hierarchical
  - more detail on
  - elaborate on
  
  # PARTS & COMPONENTS SIGNALS  
  - parts breakdown
  - component analysis
  - issue analysis
  - sample concerns
  - related parts concerns
  - parts correlation
  - component issues
requires:
  - search query or topic keyword
not_good_for: High-level pain points (use vehicle_pain_points), simple keyword counts (use keyword_search), individual verbatims (use vehicle_examples)
---

# Enhanced Semantic Issue Breakdown

## What this script does
**ENHANCED VERSION**: Uses Qwen 0.6B semantic embeddings to discover contextually related issues, then breaks them down using REAL multi-table data:

- **Parts Breakdown**: Real parts_features  parts_concern analysis from parts_accessories table
- **Topic Hierarchy**: 3-level classification from topic_xwalk + topic_detail tables  
- **Pain Point Analysis**: Customer feedback and brand switching risk from model_pain_points table
- **Dynamic Discovery**: No hardcoded patterns - uses actual data relationships

**Key Features:**
- **Semantic Discovery**: Find related issues beyond exact keyword matches
- **Multi-Table Intelligence**: Real parts, topics, and pain point data
- **Dynamic Categorization**: Auto-discover emerging issues from data
- **Hierarchical Analysis**: True topic taxonomy (Level1 > Level2 > Level3)

## How to run it

**Enhanced Semantic Analysis (Recommended):**
```bash
python .claude/skills/issue_breakdown/scripts/issue_breakdown_enhanced.py --query "F-150 engine problems" --semantic --parts-breakdown --vehicle "F-150"
```

**Traditional Keyword Analysis:**
```bash
python .claude/skills/issue_breakdown/scripts/issue_breakdown.py --topic "engine" --vehicle "F-150" --from 2026-01-01 --to 2026-01-31
```

## Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--query` | No |  | Semantic search query (e.g., "brake safety issues") |
| `--topic` | No |  | Traditional keyword for fallback search |
| `--semantic` | No | false | Enable semantic search via Qwen 0.6B embeddings |
| `--similarity-threshold` | No | 0.4 | Similarity threshold for semantic matching (0.0-1.0) |
| `--semantic-limit` | No | 2000 | Max semantic matches to analyze |
| `--vehicle` | No | all | Vehicle filter (partial match) |
| `--from` | No | all time | Start date YYYY-MM-DD |
| `--to` | No | all time | End date YYYY-MM-DD |
| `--min-mentions` | No | 5 | Min mentions to include in breakdown |
| `--limit` | No | 20 | Max items per breakdown category |
| `--parts-breakdown` | No | false | Include parts feature/concern analysis |
| `--topic-hierarchy` | No | false | Include topic hierarchy breakdown |
| `--pain-point-analysis` | No | false | Include pain point & brand risk analysis |
| `--traditional` | No | false | Force traditional keyword search |

## Example calls

**Semantic Parts Breakdown:**
```bash
# F-150 engine issues with parts analysis
python issue_breakdown_enhanced.py --query "F-150 engine problems" --semantic --parts-breakdown --vehicle "F-150"

# BlueCruise issues breakdown  
python issue_breakdown_enhanced.py --query "BlueCruise hands-free driving problems" --semantic --parts-breakdown

# Brake system analysis across all vehicles
python issue_breakdown_enhanced.py --query "brake safety issues" --semantic --parts-breakdown --topic-hierarchy
```

**Multi-Dimensional Analysis:**
```bash
# Complete breakdown with all dimensions
python issue_breakdown_enhanced.py --query "transmission shifting problems" --semantic --parts-breakdown --topic-hierarchy --pain-point-analysis --vehicle "F-150"

# Topic hierarchy focus
python issue_breakdown_enhanced.py --query "software update issues" --semantic --topic-hierarchy --limit 15

# Pain point analysis for brand switching risk
python issue_breakdown_enhanced.py --query "customer service problems" --semantic --pain-point-analysis --limit 10
```

**Traditional Fallback:**
```bash
# Traditional keyword breakdown
python issue_breakdown_enhanced.py --topic "charging" --vehicle "Mach-E" --parts-breakdown --traditional --from 2026-01-01 --to 2026-06-30
```

## Enhanced Output Format

### Semantic Multi-Dimensional Breakdown
```json
{
  "search_method": "enhanced_semantic",
  "parameters": {
    "query": "F-150 engine problems", 
    "semantic_enabled": true,
    "similarity_threshold": 0.4,
    "vehicle": "F-150",
    "breakdowns_requested": {
      "parts": true,
      "topics": true,
      "pain_points": false
    }
  },
  "semantic_matches_found": 1247,
  "issue_breakdown": {
    "parts_breakdown": [
      {
        "parts_features": "Turbocharger",
        "parts_concern": "Turbo failure at highway speeds",
        "call_count": 89,
        "avg_sentiment": -0.45,
        "avg_complexity": 8.2,
        "avg_aht": 15.3
      },
      {
        "parts_features": "Oil System",
        "parts_concern": "Oil consumption between changes",  
        "call_count": 67,
        "avg_sentiment": -0.38,
        "avg_complexity": 6.8,
        "avg_aht": 12.1
      },
      {
        "parts_features": "Check Engine System",
        "parts_concern": "Engine light with diagnostic codes",
        "call_count": 54,
        "avg_sentiment": -0.31,
        "avg_complexity": 7.5,
        "avg_aht": 13.8
      }
    ],
    "topic_breakdown": [
      {
        "topic_level1": "Vehicle Maintenance and Support",
        "topic_level2": "Troubleshooting Assistance", 
        "topic_level3": "Customers asking for advice on diagnosing vehicle problems",
        "topic_name": "Engine Performance Issues",
        "call_count": 156,
        "avg_sentiment": -0.42,
        "avg_complexity": 8.1
      },
      {
        "topic_level1": "Vehicle Support Query",
        "topic_level2": "Effective Communication in Automotive Business",
        "topic_level3": "Customers contacting Ford dealerships for service inquiries",
        "topic_name": "Engine Service Requests", 
        "call_count": 98,
        "avg_sentiment": -0.28,
        "avg_complexity": 6.4
      }
    ]
  }
}
```

### Pain Point Analysis Format
```json
{
  "pain_point_breakdown": [
    {
      "pain_point": "Engine Reliability",
      "customer_feedback": "Repeated engine failures affecting confidence",
      "call_count": 45,
      "avg_sentiment": -0.67,
      "brand_switching_risk_count": 12,
      "brand_switching_risk_pct": 26.7
    },
    {
      "pain_point": "Service Experience", 
      "customer_feedback": "Multiple dealer visits for same engine issue",
      "call_count": 34,
      "avg_sentiment": -0.52,
      "brand_switching_risk_count": 8,
      "brand_switching_risk_pct": 23.5
    }
  ]
}
```

## Real Data Breakdown Categories

### Parts Features  Concerns (from parts_accessories table)
**Most Common Real Breakdown Categories:**
- **Airbags**  Recall (1579 calls)
- **BlueCruise**  Not working, Hands-free driving issues (3000+ calls)  
- **Tires**  Slow tire leak (1089 calls)
- **FordPass**  Unable to authorize, Remote start issues (1400+ calls)
- **Software/Modem/Technology**  Not responding, Updates, Reprogramming (2000+ calls)
- **Battery**  Dead battery, Health monitoring (1100+ calls)
- **Navigation System**  Not working (854 calls)
- **Air Conditioning**  Compressor not working (668 calls)
- **Infotainment**  Bluetooth pairing issues (519 calls)
- **Rearview Camera**  Not working (516 calls)

### Topic Hierarchy Levels (from topic_detail table)
**Example Real Classifications:**
- **L1: Vehicle Maintenance and Support** > **L2: Troubleshooting Assistance** > **L3: Customers asking for advice on diagnosing problems**
- **L1: Customer Support and Rewards** > **L2: Dealer Communication Breakdown** > **L3: Difficulty contacting dealers for assistance**
- **L1: Vehicle Support Query** > **L2: Effective Communication** > **L3: Customers contacting dealerships for service inquiries**
- **L1: Connectivity Subscription Issues** > **L2: Billing Confusion** > **L3: Seeking clarification on subscription charges**

### Pain Points (from model_pain_points table)
**Real Pain Point Categories:**
- Engine Reliability & Performance Issues
- Service Experience & Dealer Communication  
- Software/Technology Integration Problems
- Safety Concerns & Recall Issues
- Charging Infrastructure (EV-specific)
- Subscription & Connectivity Problems

## Enhanced Intelligence Features

### Semantic Discovery Capabilities
- **Contextual Matching**: "engine problems" finds turbo failures, oil consumption, check engine lights
- **Cross-Part Analysis**: Discovers related component failures in same issue
- **Emerging Issue Detection**: Auto-identifies new problems not in hardcoded patterns
- **Multi-Vehicle Intelligence**: Cross-vehicle issue pattern analysis

### Multi-Table Enrichment
- **Real Parts Data**: Actual parts_features and parts_concern from service data
- **True Topic Hierarchy**: 3-level classification from topic taxonomy
- **Pain Point Correlation**: Customer satisfaction and brand loyalty insights
- **Business Intelligence**: Sentiment, complexity, AHT, and switching risk metrics

### Dynamic Categorization  
- **No Hardcoded Patterns**: Uses actual data relationships instead of fixed keywords
- **Data-Driven Discovery**: Automatically finds issue categories from parts/topic tables
- **Flexible Analysis**: Supports any vehicle, part, or issue type
- **Real-Time Insights**: Based on current data, not outdated pattern lists

## Advanced Use Cases

### Product Development
```bash
# Discover F-150 powertrain issues with parts breakdown
python issue_breakdown_enhanced.py --query "F-150 powertrain problems" --semantic --parts-breakdown --vehicle "F-150"

# Cross-vehicle transmission analysis  
python issue_breakdown_enhanced.py --query "transmission shifting issues" --semantic --parts-breakdown --topic-hierarchy
```

### Quality Assurance
```bash
# BlueCruise issue analysis with pain point assessment
python issue_breakdown_enhanced.py --query "BlueCruise reliability problems" --semantic --parts-breakdown --pain-point-analysis

# Service experience breakdown with brand risk
python issue_breakdown_enhanced.py --query "dealer service problems" --semantic --pain-point-analysis --topic-hierarchy
```

### Compliance & Safety
```bash
# Safety-related issue breakdown
python issue_breakdown_enhanced.py --query "safety defects recalls" --semantic --parts-breakdown --topic-hierarchy --limit 30

# Airbag recall analysis with topics
python issue_breakdown_enhanced.py --query "airbag recall issues" --semantic --parts-breakdown --topic-hierarchy
```

## Performance Notes
- **Semantic Processing**: Up to 15K embeddings analyzed for comprehensive discovery
- **Multi-Table Joins**: Efficiently processes 5000 call limit for breakdown analysis  
- **Dynamic Thresholds**: Configurable min-mentions filter (default: 5 calls)
- **Batch Processing**: Optimized for large-scale issue analysis
- **Fallback Support**: Traditional keyword search when semantic fails

## Error Handling
- Semantic search failures automatically fallback to traditional keyword matching
- Multi-table joins handle missing data gracefully with LEFT JOINs
- Configurable similarity thresholds for precision vs. recall optimization
- Input validation for all parameters with helpful error messages