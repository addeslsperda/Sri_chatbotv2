"""
DIRECT DATA-DRIVEN ISSUE BREAKDOWN - Production Version

Multi-table intelligence without embeddings - uses direct data relationships from:
- v_pain_points2: Pain points and customer feedback
- parts_accessories: Parts features and concerns
- topic hierarchy: Topic classification
- call_data: Sentiment, complexity, AHT metrics

Approach: Start with pain points  find related parts concerns  enrich with topics
Much faster than embedding search, uses real data relationships directly.

Features:
- Pain point discovery from v_pain_points2 table
- Related parts analysis from parts_accessories table
- Topic hierarchy classification
- Brand switching analysis (is_switch, why_switch, new_brand)
- Multi-dimensional breakdown without semantic overhead

Usage:
    python issue_breakdown.py --vehicle "F-150" --pain-point "Engine" --parts-analysis
    python issue_breakdown.py --pain-point "Battery" --topic-analysis --brand-switching
    python issue_breakdown.py --vehicle "Bronco" --parts-feature "BlueCruise" --comprehensive
"""
import argparse
import json
import os
import sys
from decimal import Decimal
from pathlib import Path
from databricks import sql
import requests
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parents[5] / ".env", override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


def get_pain_point_breakdown(vehicle=None, pain_point=None, date_from=None, date_to=None, min_mentions=3, limit=20):
    """
    Direct pain point analysis from v_pain_points2 table
    """
    params = {}
    filters = []

    # Date filters
    if date_from:
        params["date_from"] = date_from
        filters.append("DATE(cd.call_date) >= :date_from")
    if date_to:
        params["date_to"] = date_to
        filters.append("DATE(cd.call_date) <= :date_to")

    # Vehicle filter
    if vehicle:
        params["vehicle"] = f"%{vehicle}%"
        filters.append("LOWER(vpp.model_vehicle_line) LIKE LOWER(:vehicle)")

    # Pain point filter (optional)
    if pain_point:
        params["pain_point"] = f"%{pain_point}%"
        filters.append("LOWER(vpp.pain_point) LIKE LOWER(:pain_point)")

    # Base filters
    filters.extend([
        "vpp.pain_point IS NOT NULL",
        "vpp.pain_point != 'Miscellaneous'",
        "vpp.customer_feedback IS NOT NULL"
    ])

    where_clause = " AND ".join(filters)

    with get_connection() as conn:
        with conn.cursor() as cursor:
            query = f"""
                SELECT
                    vpp.pain_point,
                    vpp.problem_mentioned,
                    COUNT(DISTINCT vpp.call_id) as call_count,
                    ROUND(AVG(cd.sentiment), 4) as avg_sentiment,
                    ROUND(AVG(cd.complexity), 2) as avg_complexity,
                    ROUND(AVG(cd.handle_time), 2) as avg_aht,

                    -- Brand switching analysis
                    COUNT(CASE WHEN vpp.is_switch = 'yes' THEN 1 END) as switching_count,
                    ROUND(COUNT(CASE WHEN vpp.is_switch = 'yes' THEN 1 END) * 100.0 / COUNT(DISTINCT vpp.call_id), 1) as switching_pct,

                    -- Competitor analysis
                    STRING_AGG(DISTINCT vpp.new_brand, ', ') as competitor_brands,
                    STRING_AGG(DISTINCT vpp.why_switch, ' | ') as switching_reasons,

                    -- Sample feedback
                    MAX(vpp.customer_feedback) as sample_feedback,

                    -- Vehicle impact
                    COUNT(DISTINCT vpp.model_vehicle_line) as vehicles_affected,
                    STRING_AGG(DISTINCT vpp.model_vehicle_line, ', ') as affected_vehicles

                FROM {V_PAIN_POINTS2} vpp
                JOIN {CALL_DATA} cd ON vpp.call_id = cd.call_id
                WHERE {where_clause}
                GROUP BY vpp.pain_point, vpp.problem_mentioned
                HAVING COUNT(DISTINCT vpp.call_id) >= {min_mentions}
                ORDER BY call_count DESC
                LIMIT {limit}
            """

            cursor.execute(query, params)
            rows = cursor.fetchall()
            columns = [d[0] for d in cursor.description]

            breakdown = []
            for row in rows:
                item = {}
                for i, col in enumerate(columns):
                    value = row[i]
                    if isinstance(value, Decimal):
                        item[col] = float(value)
                    else:
                        item[col] = value
                breakdown.append(item)

            return breakdown


def get_parts_for_pain_points(call_ids_from_pain_points, min_mentions=3, limit=15):
    """
    Get related parts concerns for calls with specific pain points
    """
    if not call_ids_from_pain_points:
        return []

    # Get call_ids from pain point analysis
    pain_point_call_ids = []
    with get_connection() as conn:
        with conn.cursor() as cursor:
            # Build call_ids list from pain point breakdown
            for pain_point_data in call_ids_from_pain_points:
                # We need to get the actual call_ids for this pain point
                params = {"pain_point": pain_point_data["pain_point"]}

                cursor.execute(f"""
                    SELECT DISTINCT call_id
                    FROM {V_PAIN_POINTS2}
                    WHERE pain_point = :pain_point
                    LIMIT 1000
                """, params)

                call_ids = [row[0] for row in cursor.fetchall()]
                pain_point_call_ids.extend(call_ids)

    if not pain_point_call_ids:
        return []

    # Limit for performance
    call_id_list = "'" + "', '".join(pain_point_call_ids[:3000]) + "'"

    with get_connection() as conn:
        with conn.cursor() as cursor:
            query = f"""
                SELECT
                    pa.parts_features,
                    pa.parts_concern,
                    COUNT(DISTINCT pa.call_id) as call_count,
                    ROUND(AVG(cd.sentiment), 4) as avg_sentiment,
                    ROUND(AVG(cd.complexity), 2) as avg_complexity
                FROM {PARTS_ACCESSORIES} pa
                JOIN {CALL_DATA} cd ON pa.call_id = cd.call_id
                WHERE pa.call_id IN ({call_id_list})
                  AND pa.parts_features NOT IN ('No Parts Mentioned', 'Other/Unknown', 'Miscellaneous')
                  AND pa.parts_concern NOT IN ('No parts concern', 'Vehicle model', 'No parts')
                  AND pa.parts_concern IS NOT NULL
                  AND pa.parts_features IS NOT NULL
                GROUP BY pa.parts_features, pa.parts_concern
                HAVING COUNT(DISTINCT pa.call_id) >= {min_mentions}
                ORDER BY call_count DESC
                LIMIT {limit}
            """

            cursor.execute(query)
            rows = cursor.fetchall()
            columns = [d[0] for d in cursor.description]

            parts_breakdown = []
            for row in rows:
                item = {}
                for i, col in enumerate(columns):
                    value = row[i]
                    if isinstance(value, Decimal):
                        item[col] = float(value)
                    else:
                        item[col] = value
                parts_breakdown.append(item)

            return parts_breakdown


def get_topic_analysis_for_pain_points(call_ids_from_pain_points, min_mentions=3, limit=10):
    """
    Get topic analysis for calls with specific pain points
    """
    if not call_ids_from_pain_points:
        return []

    # Get call_ids from pain point analysis
    pain_point_call_ids = []
    with get_connection() as conn:
        with conn.cursor() as cursor:
            for pain_point_data in call_ids_from_pain_points:
                params = {"pain_point": pain_point_data["pain_point"]}

                cursor.execute(f"""
                    SELECT DISTINCT call_id
                    FROM {V_PAIN_POINTS2}
                    WHERE pain_point = :pain_point
                    LIMIT 1000
                """, params)

                call_ids = [row[0] for row in cursor.fetchall()]
                pain_point_call_ids.extend(call_ids)

    if not pain_point_call_ids:
        return []

    call_id_list = "'" + "', '".join(pain_point_call_ids[:3000]) + "'"

    with get_connection() as conn:
        with conn.cursor() as cursor:
            query = f"""
                SELECT
                    td.topic_level1,
                    td.topic_level2,
                    td.topic_level3,
                    tx.topic_name,
                    COUNT(DISTINCT tx.call_id) as call_count,
                    ROUND(AVG(cd.sentiment), 4) as avg_sentiment
                FROM {TOPIC_XWALK} tx
                JOIN {TOPIC_DETAIL} td ON tx.topic_id = td.topic_id
                JOIN {CALL_DATA} cd ON tx.call_id = cd.call_id
                WHERE tx.call_id IN ({call_id_list})
                  AND td.topic_level1 IS NOT NULL
                  AND td.topic_level2 IS NOT NULL
                GROUP BY td.topic_level1, td.topic_level2, td.topic_level3, tx.topic_name
                HAVING COUNT(DISTINCT tx.call_id) >= {min_mentions}
                ORDER BY call_count DESC
                LIMIT {limit}
            """

            cursor.execute(query)
            rows = cursor.fetchall()
            columns = [d[0] for d in cursor.description]

            topic_breakdown = []
            for row in rows:
                item = {}
                for i, col in enumerate(columns):
                    value = row[i]
                    if isinstance(value, Decimal):
                        item[col] = float(value)
                    else:
                        item[col] = value
                topic_breakdown.append(item)

            return topic_breakdown


def serialize(v):
    if isinstance(v, Decimal): return float(v)
    if hasattr(v, "isoformat"): return str(v)
    return v


# Table configuration
CATALOG = os.environ.get("DATABRICKS_CATALOG", "text_analytics")
SCHEMA = os.environ.get("DATABRICKS_SCHEMA", "nlp_analytics")
CALL_DATA = f"{CATALOG}.{SCHEMA}.call_data"
PARTS_ACCESSORIES = f"{CATALOG}.{SCHEMA}.parts_accessories"
TOPIC_XWALK = f"{CATALOG}.{SCHEMA}.topic_xwalk"
TOPIC_DETAIL = f"{CATALOG}.nlp_configs.topic_detail"
V_PAIN_POINTS2 = f"{CATALOG}.restensl.v_pain_points2"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--vehicle", help="Vehicle filter (partial match)")
    parser.add_argument("--pain-point", help="Pain point filter (partial match)")
    parser.add_argument("--parts-feature", help="Parts feature filter")
    parser.add_argument("--from", dest="date_from", help="Start date YYYY-MM-DD")
    parser.add_argument("--to", dest="date_to", help="End date YYYY-MM-DD")
    parser.add_argument("--min-mentions", type=int, default=1, help="Min mentions to include")
    parser.add_argument("--limit", type=int, default=500, help="Max items per category")
    parser.add_argument("--parts-analysis", action="store_true", help="Include parts analysis for pain points")
    parser.add_argument("--topic-analysis", action="store_true", help="Include topic analysis")
    parser.add_argument("--brand-switching", action="store_true", help="Focus on brand switching analysis")
    parser.add_argument("--comprehensive", action="store_true", help="Include all analysis types")
    args, _ = parser.parse_known_args()

    result = {
        "analysis_method": "direct_data_driven",
        "parameters": {
            "vehicle": args.vehicle or "all",
            "pain_point_filter": args.pain_point or "all",
            "parts_feature_filter": args.parts_feature or "all",
            "date_range": f"{args.date_from or 'all time'} to {args.date_to or 'all time'}",
            "min_mentions": args.min_mentions,
            "analysis_types": {
                "parts": args.parts_analysis or args.comprehensive,
                "topics": args.topic_analysis or args.comprehensive,
                "brand_switching": args.brand_switching or args.comprehensive
            }
        }
    }

    try:
        print(f"Analyzing pain points from v_pain_points2 table...", file=sys.stderr)

        # Step 1: Get pain point breakdown (always included)
        pain_point_breakdown = get_pain_point_breakdown(
            vehicle=args.vehicle,
            pain_point=args.pain_point,
            date_from=args.date_from,
            date_to=args.date_to,
            min_mentions=args.min_mentions,
            limit=args.limit
        )

        result["pain_point_breakdown"] = pain_point_breakdown
        result["total_pain_points_found"] = len(pain_point_breakdown)

        # Step 2: Get related parts analysis (if requested)
        if args.parts_analysis or args.comprehensive:
            if pain_point_breakdown:
                print(f"Analyzing related parts for pain points...", file=sys.stderr)
                parts_breakdown = get_parts_for_pain_points(
                    pain_point_breakdown, args.min_mentions, args.limit
                )
                result["related_parts_breakdown"] = parts_breakdown
                result["total_related_parts"] = len(parts_breakdown)

        # Step 3: Get topic analysis (if requested)
        if args.topic_analysis or args.comprehensive:
            if pain_point_breakdown:
                print(f"Analyzing topics for pain points...", file=sys.stderr)
                topic_breakdown = get_topic_analysis_for_pain_points(
                    pain_point_breakdown, args.min_mentions, args.limit
                )
                result["topic_breakdown"] = topic_breakdown
                result["total_topics"] = len(topic_breakdown)

        # Add summary statistics
        if pain_point_breakdown:
            total_calls = sum(item["call_count"] for item in pain_point_breakdown)
            total_switching = sum(item["switching_count"] for item in pain_point_breakdown)
            avg_switching_rate = (total_switching / total_calls * 100) if total_calls > 0 else 0

            result["summary"] = {
                "total_calls_analyzed": total_calls,
                "total_brand_switching_cases": total_switching,
                "overall_switching_rate_pct": round(avg_switching_rate, 1),
                "unique_pain_points": len(pain_point_breakdown)
            }

        print(json.dumps(result, indent=2))

    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()