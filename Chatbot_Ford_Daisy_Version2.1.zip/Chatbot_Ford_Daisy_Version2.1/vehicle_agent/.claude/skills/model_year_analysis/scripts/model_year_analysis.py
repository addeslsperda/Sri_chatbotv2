"""
Enhanced Model Year Analysis with Complete Data Sources & Statistical Validation

Revolutionary improvements:
- Uses 100% complete vehicle data (models table) vs 18.2% incomplete (call_data.modelvehicleline)
- Integrates 99.3% complete sentiment data vs 22.9% incomplete (call_data.sentiment)
- Structured pain point analysis from v_pain_points2 table (100% coverage)
- Statistical validation with HAVING filters for reliable results
- Time-based performance tracking (month/year trends)

Sample Questions Answered:
- "What issues affect 2022 F-150s?"
- "Which Explorer year has the highest AHT?"
- "What are the main pain points for 2023 Broncos?"
- "How many calls did we get for 2025 Mach-E?"
- "Which model year has the worst sentiment?"
- "Are 2024 F-Series calls more complex than 2023?"

Usage:
    python model_year_analysis_enhanced.py --vehicle "Explorer"
    python model_year_analysis_enhanced.py --vehicle "F-150" --year 2023 --from 2026-01-01 --to 2026-12-31
    python model_year_analysis_enhanced.py --vehicle "Bronco" --time-analysis month --min-calls 30
"""
import argparse
import json
import os
import sys
from decimal import Decimal
from pathlib import Path
from datetime import datetime, date
from databricks import sql
import requests
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parents[4] / ".env", override=True)


def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )


# Enhanced table definitions with complete data sources
CATALOG = os.environ.get("DATABRICKS_CATALOG", "text_analytics")
SCHEMA = os.environ.get("DATABRICKS_SCHEMA", "nlp_analytics")
RESTENSL_SCHEMA = os.environ.get("DATABRICKS_RESTENSL_SCHEMA", "restensl")

CALL_DATA = f"{CATALOG}.{SCHEMA}.call_data"
MODELS = f"{CATALOG}.{SCHEMA}.models"
SENTIMENTS = f"{CATALOG}.{SCHEMA}.sentiments"
CALL_TABLE = f"{CATALOG}.{SCHEMA}.call_table"
V_PAIN_POINTS2 = f"{CATALOG}.{RESTENSL_SCHEMA}.v_pain_points2"


def serialize(v):
    """Bulletproof serialization - handles ALL Databricks types."""
    if v is None:
        return None
    if isinstance(v, Decimal):
        return float(v)
    if hasattr(v, "isoformat"):  # datetime objects
        return str(v)
    if isinstance(v, float):
        # Handle NaN and infinity
        if str(v) in ['nan', 'inf', '-inf']:
            return None
        return float(v)
    if isinstance(v, int):
        return int(v)
    # Convert everything else to string as fallback
    try:
        return str(v)
    except Exception:
        return None


def validate_statistical_reliability(call_count, min_calls=20):
    """Validate if sample size is sufficient for reliable statistics"""
    if call_count < min_calls:
        return {
            "sufficient": False,
            "confidence": "low",
            "warning": f"Sample size too small ({call_count} < {min_calls})"
        }
    elif call_count < min_calls * 3:
        return {
            "sufficient": True,
            "confidence": "medium",
            "note": f"Moderate sample size ({call_count} calls)"
        }
    else:
        return {
            "sufficient": True,
            "confidence": "high",
            "note": f"Large sample size ({call_count} calls)"
        }


def get_data_quality_stats(conn, date_from, date_to, vehicle_filter):
    """Validate data quality and coverage for the analysis period - INTELLIGENT MERGE."""

    # NORMALIZE the vehicle filter (remove spaces, hyphens, convert to upper)
    normalized_filter = vehicle_filter.replace("-", "").replace(" ", "").replace("_", "").upper()

    quality_query = f"""
    WITH base_calls AS (
        SELECT cd.call_id
        FROM {CALL_DATA} cd
        LEFT JOIN {MODELS} m ON cd.call_id = m.call_id
        WHERE UPPER(REPLACE(REPLACE(REPLACE(COALESCE(m.ModelVehicleLine, cd.modelvehicleline), '-', ''), ' ', ''), '_', '')) LIKE :normalized_filter
          AND (:date_from IS NULL OR DATE(cd.call_date) >= :date_from)
          AND (:date_to IS NULL OR DATE(cd.call_date) <= :date_to)
    ),
    coverage_stats AS (
        SELECT
            COUNT(bc.call_id) as total_calls,
            COUNT(CASE WHEN COALESCE(m.ModelVehicleLine, cd.modelvehicleline) IS NOT NULL
                            AND COALESCE(m.ModelVehicleLine, cd.modelvehicleline) != ''
                            AND COALESCE(m.ModelVehicleLine, cd.modelvehicleline) NOT IN ('No Match Found', 'No Vehicle', 'Unknown')
                       THEN 1 END) as calls_with_vehicle,
            COUNT(COALESCE(s.overall_sentiment, cd.sentiment)) as calls_with_sentiment,
            COUNT(vpp.pain_point) as calls_with_pain_points
        FROM base_calls bc
        LEFT JOIN {CALL_DATA} cd ON bc.call_id = cd.call_id
        LEFT JOIN {MODELS} m ON bc.call_id = m.call_id
        LEFT JOIN {SENTIMENTS} s ON bc.call_id = s.call_id
        LEFT JOIN {V_PAIN_POINTS2} vpp ON bc.call_id = vpp.call_id
    )
    SELECT
        total_calls,
        calls_with_vehicle,
        calls_with_sentiment,
        calls_with_pain_points,
        ROUND(CASE WHEN total_calls > 0 THEN calls_with_vehicle * 100.0 / total_calls ELSE 0 END, 1) as vehicle_coverage_pct,
        ROUND(CASE WHEN total_calls > 0 THEN calls_with_sentiment * 100.0 / total_calls ELSE 0 END, 1) as sentiment_coverage_pct,
        ROUND(CASE WHEN total_calls > 0 THEN calls_with_pain_points * 100.0 / total_calls ELSE 0 END, 1) as pain_point_coverage_pct
    FROM coverage_stats
    """

    params = {
        "normalized_filter": f"%{normalized_filter}%",
        "date_from": date_from,
        "date_to": date_to
    }

    with conn.cursor() as cursor:
        cursor.execute(quality_query, params)
        row = cursor.fetchone()
        return {
            "total_calls": serialize(row[0]),
            "vehicle_coverage_pct": serialize(row[4]),
            "sentiment_coverage_pct": serialize(row[5]),
            "pain_point_coverage_pct": serialize(row[6]),
            "data_quality": "excellent" if float(row[5] or 0) > 95 else "good" if float(row[5] or 0) > 80 else "fair"
        }


def get_model_year_breakdown(conn, date_from, date_to, vehicle_filter, min_calls=20, specific_year=None):
    """Enhanced model year breakdown with INTELLIGENT MERGE - Pure normalized matching."""

    # NORMALIZE the vehicle filter (remove spaces, hyphens, convert to upper)
    normalized_filter = vehicle_filter.replace("-", "").replace(" ", "").replace("_", "").upper()

    params = {
        "min_calls": min_calls,
        "normalized_filter": f"%{normalized_filter}%"
    }

    # INTELLIGENT MERGE WHERE clause with pure normalization
    where_conditions = [
        """UPPER(REPLACE(REPLACE(REPLACE(COALESCE(m.ModelVehicleLine, cd.modelvehicleline), '-', ''), ' ', ''), '_', ''))
           LIKE :normalized_filter"""
    ]

    # CRITICAL FIX: Filter by specific year or year range if requested
    if specific_year:
        if isinstance(specific_year, tuple):
            # Handle year range (start_year, end_year)
            start_year, end_year = specific_year
            where_conditions.append("COALESCE(m.Model_Year, cd.modelyear) BETWEEN :start_year AND :end_year")
            params["start_year"] = str(start_year)
            params["end_year"] = str(end_year)
        else:
            # Handle single year
            where_conditions.append("COALESCE(m.Model_Year, cd.modelyear) = :specific_year")
            params["specific_year"] = str(specific_year)

    # Date filtering
    if date_from:
        where_conditions.append("DATE(cd.call_date) >= :date_from")
        params["date_from"] = date_from
    if date_to:
        where_conditions.append("DATE(cd.call_date) <= :date_to")
        params["date_to"] = date_to

    where_clause = " AND ".join(where_conditions)

    query = f"""
    SELECT
        -- Smart model year selection (prioritizes models table but falls back to call_data)
        COALESCE(m.Model_Year, cd.modelyear, 'Unknown') as model_year,

        -- Data source quality tracking
        CASE
            WHEN m.ModelVehicleLine IS NOT NULL
                 AND m.ModelVehicleLine != ''
                 AND m.ModelVehicleLine NOT IN ('No Match Found', 'No Vehicle')
                 AND m.Model_Year IS NOT NULL
                 AND m.Model_Year != ''
                 AND m.Model_Year NOT IN ('No Vehicle', 'No Match Found', 'Unknown')
            THEN 'models_verified'
            WHEN m.ModelVehicleLine IS NOT NULL
                 AND m.ModelVehicleLine != ''
                 AND m.ModelVehicleLine NOT IN ('No Match Found', 'No Vehicle')
            THEN 'models_partial'
            WHEN cd.modelvehicleline IS NOT NULL
                 AND cd.modelvehicleline != ''
                 AND cd.modelvehicleline NOT IN ('No Match Found', 'No Vehicle')
            THEN 'call_data_fallback'
            ELSE 'no_vehicle_data'
        END as data_source_quality,

        COUNT(*) AS call_count,
        ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER(), 1) AS pct_of_vehicle_calls,
        ROUND(AVG(cd.handle_time)/60, 2) AS avg_aht_minutes,
        ROUND(AVG(cd.complexity), 3) AS avg_complexity,
        ROUND(AVG(COALESCE(s.overall_sentiment, cd.sentiment)), 3) AS avg_overall_sentiment,
        COUNT(cd.handle_time) * 100.0 / COUNT(*) AS aht_coverage_pct,
        COUNT(s.overall_sentiment) * 100.0 / COUNT(*) AS sentiment_coverage_pct

    FROM {CALL_DATA} cd
    LEFT JOIN {MODELS} m ON cd.call_id = m.call_id
    LEFT JOIN {SENTIMENTS} s ON cd.call_id = s.call_id

    WHERE {where_clause}

    GROUP BY
        COALESCE(m.Model_Year, cd.modelyear, 'Unknown'),
        CASE
            WHEN m.ModelVehicleLine IS NOT NULL
                 AND m.ModelVehicleLine != ''
                 AND m.ModelVehicleLine NOT IN ('No Match Found', 'No Vehicle')
                 AND m.Model_Year IS NOT NULL
                 AND m.Model_Year != ''
                 AND m.Model_Year NOT IN ('No Vehicle', 'No Match Found', 'Unknown')
            THEN 'models_verified'
            WHEN m.ModelVehicleLine IS NOT NULL
                 AND m.ModelVehicleLine != ''
                 AND m.ModelVehicleLine NOT IN ('No Match Found', 'No Vehicle')
            THEN 'models_partial'
            WHEN cd.modelvehicleline IS NOT NULL
                 AND cd.modelvehicleline != ''
                 AND cd.modelvehicleline NOT IN ('No Match Found', 'No Vehicle')
            THEN 'call_data_fallback'
            ELSE 'no_vehicle_data'
        END
    HAVING COUNT(*) >= :min_calls
    ORDER BY call_count DESC
    LIMIT 500
    """

    with conn.cursor() as cursor:
        cursor.execute(query, params)
        rows = cursor.fetchall()
        columns = [d[0] for d in cursor.description]

    # Process results with intelligence
    year_breakdown = []
    for row in rows:
        year_data = dict(zip(columns, [serialize(v) for v in row]))

        # Add statistical reliability assessment
        reliability = validate_statistical_reliability(year_data["call_count"], min_calls)
        year_data["statistical_reliability"] = reliability

        year_breakdown.append(year_data)

    return year_breakdown


def get_structured_pain_points(conn, date_from, date_to, vehicle_filter, specific_year):
    """Get enhanced structured pain points with INTELLIGENT MERGE - Pure normalized matching."""

    # NORMALIZE the vehicle filter (remove spaces, hyphens, convert to upper)
    normalized_filter = vehicle_filter.replace("-", "").replace(" ", "").replace("_", "").upper()

    params = {
        "normalized_filter": f"%{normalized_filter}%",
        "specific_year": str(specific_year)
    }

    # INTELLIGENT MERGE WHERE clause with pure normalization
    where_conditions = [
        """UPPER(REPLACE(REPLACE(REPLACE(COALESCE(m.ModelVehicleLine, cd.modelvehicleline), '-', ''), ' ', ''), '_', ''))
           LIKE :normalized_filter""",
        "COALESCE(m.Model_Year, cd.modelyear) = :specific_year",
        "vpp.pain_point IS NOT NULL",
        "vpp.pain_point != ''"
    ]

    if date_from:
        where_conditions.append("DATE(cd.call_date) >= :date_from")
        params["date_from"] = date_from
    if date_to:
        where_conditions.append("DATE(cd.call_date) <= :date_to")
        params["date_to"] = date_to

    where_clause = " AND ".join(where_conditions)

    # Get total calls for this year first - INTELLIGENT MERGE
    total_query = f"""
    SELECT COUNT(*)
    FROM {CALL_DATA} cd
    LEFT JOIN {MODELS} m ON cd.call_id = m.call_id
    WHERE UPPER(REPLACE(REPLACE(REPLACE(COALESCE(m.ModelVehicleLine, cd.modelvehicleline), '-', ''), ' ', ''), '_', '')) LIKE :normalized_filter
      AND COALESCE(m.Model_Year, cd.modelyear) = :specific_year
      {' AND DATE(cd.call_date) >= :date_from' if date_from else ''}
      {' AND DATE(cd.call_date) <= :date_to' if date_to else ''}
    """

    with conn.cursor() as cursor:
        cursor.execute(total_query, params)
        year_total = cursor.fetchone()[0]

    # Enhanced pain points breakdown with INTELLIGENT MERGE
    pain_query = f"""
    SELECT
        vpp.pain_point,
        COUNT(*) AS call_count,
        ROUND(COUNT(*) * 100.0 / {year_total}, 1) AS pct_of_year_calls,
        ROUND(AVG(cd.handle_time)/60, 2) AS avg_aht_minutes,
        ROUND(AVG(cd.complexity), 3) AS avg_complexity,
        ROUND(AVG(COALESCE(s.overall_sentiment, cd.sentiment)), 3) AS avg_overall_sentiment,
        COUNT(cd.handle_time) * 100.0 / COUNT(*) AS aht_coverage_pct,
        COUNT(s.overall_sentiment) * 100.0 / COUNT(*) AS sentiment_coverage_pct

    FROM {CALL_DATA} cd
    LEFT JOIN {MODELS} m ON cd.call_id = m.call_id
    INNER JOIN {V_PAIN_POINTS2} vpp ON cd.call_id = vpp.call_id
    LEFT JOIN {SENTIMENTS} s ON cd.call_id = s.call_id

    WHERE {where_clause}

    GROUP BY vpp.pain_point
    HAVING COUNT(*) >= 5
    ORDER BY call_count DESC
    LIMIT 500
    """

    with conn.cursor() as cursor:
        cursor.execute(pain_query, params)
        rows = cursor.fetchall()
        columns = [d[0] for d in cursor.description]

    pain_points = []
    for row in rows:
        pain_data = dict(zip(columns, [serialize(v) for v in row]))

        # Add statistical reliability for pain points
        reliability = validate_statistical_reliability(pain_data["call_count"], 5)
        pain_data["statistical_reliability"] = reliability

        pain_points.append(pain_data)

    return {
        "year": specific_year,
        "total_calls": year_total,
        "structured_pain_points": pain_points
    }


def get_monthly_pain_points_analysis(conn, date_from, date_to, vehicle_filter, specific_year, min_calls=5):
    """Get pain points breakdown by month for specific model year - INTELLIGENT MERGE."""

    # NORMALIZE the vehicle filter (remove spaces, hyphens, convert to upper)
    normalized_filter = vehicle_filter.replace("-", "").replace(" ", "").replace("_", "").upper()

    where_conditions = [
        """UPPER(REPLACE(REPLACE(REPLACE(COALESCE(m.ModelVehicleLine, cd.modelvehicleline), '-', ''), ' ', ''), '_', ''))
           LIKE :normalized_filter""",
        "COALESCE(m.Model_Year, cd.modelyear) = :specific_year",
        "vpp.pain_point IS NOT NULL",
        "vpp.pain_point != ''"
    ]

    params = {
        "normalized_filter": f"%{normalized_filter}%",
        "specific_year": str(specific_year),
        "min_calls": min_calls
    }

    if date_from:
        where_conditions.append("DATE(cd.call_date) >= :date_from")
        params["date_from"] = date_from
    if date_to:
        where_conditions.append("DATE(cd.call_date) <= :date_to")
        params["date_to"] = date_to

    where_clause = " AND ".join(where_conditions)

    query = f"""
    SELECT
        DATE_TRUNC('month', cd.call_date) as analysis_month,
        vpp.pain_point,
        COUNT(*) AS call_count,
        ROUND(AVG(cd.handle_time)/60, 2) AS avg_aht_minutes,
        ROUND(AVG(cd.complexity), 3) AS avg_complexity,
        ROUND(AVG(COALESCE(s.overall_sentiment, cd.sentiment)), 3) AS avg_overall_sentiment

    FROM {CALL_DATA} cd
    LEFT JOIN {MODELS} m ON cd.call_id = m.call_id
    INNER JOIN {V_PAIN_POINTS2} vpp ON cd.call_id = vpp.call_id
    LEFT JOIN {SENTIMENTS} s ON cd.call_id = s.call_id

    WHERE {where_clause}

    GROUP BY DATE_TRUNC('month', cd.call_date), vpp.pain_point
    HAVING COUNT(*) >= :min_calls
    ORDER BY analysis_month DESC, call_count DESC
    LIMIT 500
    """

    with conn.cursor() as cursor:
        cursor.execute(query, params)
        rows = cursor.fetchall()
        columns = [d[0] for d in cursor.description]

    monthly_analysis = []
    for row in rows:
        month_data = dict(zip(columns, [serialize(v) for v in row]))

        # Add statistical reliability
        reliability = validate_statistical_reliability(month_data["call_count"], min_calls)
        month_data["statistical_reliability"] = reliability

        monthly_analysis.append(month_data)

    return monthly_analysis


def get_sample_customer_feedback(conn, date_from, date_to, vehicle_filter, specific_year, pain_point, limit=3):
    """Get sample customer feedback for a specific pain point - INTELLIGENT MERGE."""

    # NORMALIZE the vehicle filter (remove spaces, hyphens, convert to upper)
    normalized_filter = vehicle_filter.replace("-", "").replace(" ", "").replace("_", "").upper()

    where_conditions = [
        """UPPER(REPLACE(REPLACE(REPLACE(COALESCE(m.ModelVehicleLine, cd.modelvehicleline), '-', ''), ' ', ''), '_', ''))
           LIKE :normalized_filter""",
        "COALESCE(m.Model_Year, cd.modelyear) = :specific_year",
        "vpp.pain_point = :pain_point",
        "vpp.customer_feedback IS NOT NULL",
        "vpp.customer_feedback != ''"
    ]

    params = {
        "normalized_filter": f"%{normalized_filter}%",
        "specific_year": str(specific_year),
        "pain_point": pain_point
    }

    if date_from:
        where_conditions.append("DATE(cd.call_date) >= :date_from")
        params["date_from"] = date_from
    if date_to:
        where_conditions.append("DATE(cd.call_date) <= :date_to")
        params["date_to"] = date_to

    where_clause = " AND ".join(where_conditions)

    query = f"""
    SELECT
        vpp.customer_feedback,
        cd.call_date

    FROM {CALL_DATA} cd
    LEFT JOIN {MODELS} m ON cd.call_id = m.call_id
    INNER JOIN {V_PAIN_POINTS2} vpp ON cd.call_id = vpp.call_id

    WHERE {where_clause}

    ORDER BY cd.call_date DESC
    LIMIT {limit}
    """

    with conn.cursor() as cursor:
        cursor.execute(query, params)
        rows = cursor.fetchall()

    return [serialize(row[0]) for row in rows]


def get_time_based_analysis(conn, date_from, date_to, vehicle_filter, specific_year, time_grouping="month", min_calls=10):
    """Get time-based performance tracking (month/year analysis) - INTELLIGENT MERGE."""

    # NORMALIZE the vehicle filter (remove spaces, hyphens, convert to upper)
    normalized_filter = vehicle_filter.replace("-", "").replace(" ", "").replace("_", "").upper()

    # Determine time truncation
    if time_grouping == "year":
        time_trunc = "DATE_TRUNC('year', cd.call_date)"
        min_calls = 50  # Higher threshold for yearly data
    else:  # month
        time_trunc = "DATE_TRUNC('month', cd.call_date)"

    where_conditions = [
        """UPPER(REPLACE(REPLACE(REPLACE(COALESCE(m.ModelVehicleLine, cd.modelvehicleline), '-', ''), ' ', ''), '_', ''))
           LIKE :normalized_filter""",
        "COALESCE(m.Model_Year, cd.modelyear) = :specific_year"
    ]

    params = {
        "normalized_filter": f"%{normalized_filter}%",
        "specific_year": str(specific_year),
        "min_calls": min_calls
    }

    if date_from:
        where_conditions.append("DATE(cd.call_date) >= :date_from")
        params["date_from"] = date_from
    if date_to:
        where_conditions.append("DATE(cd.call_date) <= :date_to")
        params["date_to"] = date_to

    where_clause = " AND ".join(where_conditions)

    query = f"""
    SELECT
        {time_trunc} as analysis_period,
        COUNT(*) AS call_count,
        ROUND(AVG(cd.handle_time)/60, 2) AS avg_aht_minutes,
        ROUND(AVG(cd.complexity), 3) AS avg_complexity,
        ROUND(AVG(COALESCE(s.overall_sentiment, cd.sentiment)), 3) AS avg_overall_sentiment,
        COUNT(DISTINCT DATE(cd.call_date)) as days_with_calls,
        ROUND(COUNT(*) * 1.0 / COUNT(DISTINCT DATE(cd.call_date)), 1) as avg_calls_per_active_day

    FROM {CALL_DATA} cd
    LEFT JOIN {MODELS} m ON cd.call_id = m.call_id
    LEFT JOIN {SENTIMENTS} s ON cd.call_id = s.call_id

    WHERE {where_clause}

    GROUP BY {time_trunc}
    HAVING COUNT(*) >= :min_calls
    ORDER BY analysis_period DESC
    LIMIT 500
    """

    with conn.cursor() as cursor:
        cursor.execute(query, params)
        rows = cursor.fetchall()
        columns = [d[0] for d in cursor.description]

    time_analysis = []
    for row in rows:
        period_data = dict(zip(columns, [serialize(v) for v in row]))

        # Add statistical reliability
        reliability = validate_statistical_reliability(period_data["call_count"], min_calls)
        period_data["statistical_reliability"] = reliability

        time_analysis.append(period_data)

    return time_analysis


def parse_year_range(year_input):
    """Parse year input - handles single year (2024), range (2020-2024), or comma-separated (2020,2021,2022,2023,2024)"""
    if not year_input:
        return None, None, None

    year_str = str(year_input).strip()

    # Handle comma-separated years like "2020,2021,2022,2023,2024"
    if "," in year_str:
        try:
            years = [int(y.strip()) for y in year_str.split(",") if y.strip()]
            if not years:
                raise ValueError(f"No valid years found in '{year_input}'")
            return min(years), max(years), "range"
        except ValueError as e:
            if "No valid" in str(e):
                raise
            raise ValueError(f"Invalid comma-separated years: '{year_input}'. Use format like '2020,2022,2024'")

    # Handle range like "2020-2024"
    if "-" in year_str:
        try:
            start_year, end_year = year_str.split("-")
            return int(start_year.strip()), int(end_year.strip()), "range"
        except ValueError:
            raise ValueError(f"Invalid year range format: '{year_input}'. Use format like '2020-2024'")

    # Handle single year
    try:
        single_year = int(year_str)
        return single_year, single_year, "single"
    except ValueError:
        raise ValueError(f"Invalid year format: '{year_input}'. Use single year (2024), range (2020-2024), or comma-separated (2020,2022,2024)")


def main():
    parser = argparse.ArgumentParser(description="Enhanced Model Year Analytics with Complete Data & Intelligence")
    parser.add_argument("--vehicle", required=True, help="Vehicle name (partial match)")
    parser.add_argument("--year", "--model-year", dest="year", default=None, type=str,
                        help="Model year(s) for analysis - single year (2024) or range (2020-2024)")
    parser.add_argument("--from", dest="date_from", default=None, help="Start date (YYYY-MM-DD)")
    parser.add_argument("--to", dest="date_to", default=None, help="End date (YYYY-MM-DD)")
    parser.add_argument("--min-calls", dest="min_calls", type=int, default=20,
                        help="Minimum calls per model year for statistical reliability")
    parser.add_argument("--time-analysis", dest="time_analysis", choices=["month", "year"], default=None,
                        help="Include time-based performance analysis")
    parser.add_argument("--monthly-pain-points", dest="monthly_pain_points", action="store_true",
                        help="Include monthly pain point analysis for specific year")
    parser.add_argument("--sample-feedback", dest="sample_feedback", action="store_true",
                        help="Include sample customer feedback for pain points")

    args, _ = parser.parse_known_args()

    # Parse year input (handles both single years and ranges)
    try:
        start_year, end_year, year_type = parse_year_range(args.year)
    except ValueError as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)

    try:
        with get_connection() as conn:

            # Data quality validation
            quality_stats = get_data_quality_stats(conn, args.date_from, args.date_to, args.vehicle)

            result = {
                "metadata": {
                    "vehicle_filter": args.vehicle,
                    "analysis_period": {
                        "from": args.date_from or "all_time",
                        "to": args.date_to or "all_time"
                    },
                    "min_calls_threshold": args.min_calls,
                    "data_completeness": {
                        "vehicle_coverage": f"{quality_stats['vehicle_coverage_pct']}%",
                        "sentiment_coverage": f"{quality_stats['sentiment_coverage_pct']}%",
                        "pain_point_coverage": f"{quality_stats['pain_point_coverage_pct']}%"
                    },
                    "enhancements_enabled": {
                        "complete_vehicle_data": True,
                        "enhanced_sentiment_analysis": True,
                        "structured_pain_points": True,
                        "statistical_validation": True
                    }
                },
                "data_quality": quality_stats
            }

            # Get model year breakdown - CRITICAL FIX: Pass year range or single year if requested
            year_filter = (start_year, end_year) if year_type == "range" and start_year else start_year if start_year else None
            year_breakdown = get_model_year_breakdown(
                conn, args.date_from, args.date_to, args.vehicle, args.min_calls, year_filter
            )
            result["year_breakdown"] = year_breakdown

            # Flat 'results' key for chart renderer (no nested objects, string model_year)
            result["results"] = [
                {
                    "model_year": str(y.get("model_year", "Unknown")),
                    "call_count": y.get("call_count"),
                    "avg_aht_minutes": y.get("avg_aht_minutes"),
                    "avg_complexity": y.get("avg_complexity"),
                    "avg_overall_sentiment": y.get("avg_overall_sentiment"),
                }
                for y in year_breakdown
            ]

            # Add summary statistics
            if year_breakdown:
                total_calls = sum(year["call_count"] for year in year_breakdown)
                result["summary"] = {
                    "total_model_years_analyzed": len(year_breakdown),
                    "total_calls_in_breakdown": total_calls,
                    "avg_aht_across_years": round(
                        sum(year["avg_aht_minutes"] * year["call_count"] for year in year_breakdown) / total_calls, 2
                    ) if total_calls > 0 else None,
                    "best_sentiment_year": max(year_breakdown, key=lambda x: x["avg_overall_sentiment"] or -1)["model_year"],
                    "worst_sentiment_year": min(year_breakdown, key=lambda x: x["avg_overall_sentiment"] or 1)["model_year"]
                }

            # Specific year analysis (only for single years, not ranges)
            if start_year and year_type == "single":
                # Get structured pain points
                pain_point_detail = get_structured_pain_points(
                    conn, args.date_from, args.date_to, args.vehicle, start_year
                )

                # Add sample feedback if requested
                if args.sample_feedback and pain_point_detail["structured_pain_points"]:
                    for pain_point in pain_point_detail["structured_pain_points"][:5]:  # Top 5 pain points
                        feedback = get_sample_customer_feedback(
                            conn, args.date_from, args.date_to, args.vehicle,
                            start_year, pain_point["pain_point"]
                        )
                        pain_point["sample_feedback"] = feedback

                result["model_year_detail"] = pain_point_detail

            # Monthly pain points analysis (only for single years)
            if args.monthly_pain_points and start_year and year_type == "single":
                monthly_pain_analysis = get_monthly_pain_points_analysis(
                    conn, args.date_from, args.date_to, args.vehicle, start_year
                )
                result["monthly_pain_points_analysis"] = monthly_pain_analysis

            # Time-based analysis (performance trends) - only for single years
            if args.time_analysis and start_year and year_type == "single":
                time_analysis = get_time_based_analysis(
                    conn, args.date_from, args.date_to, args.vehicle,
                    start_year, args.time_analysis
                )
                result["time_based_analysis"] = {
                    "grouping": args.time_analysis,
                    "periods": time_analysis
                }

            # Data completeness warnings
            warnings = []
            if quality_stats["vehicle_coverage_pct"] < 95:
                warnings.append(f"Vehicle data coverage is {quality_stats['vehicle_coverage_pct']}% - some calls may lack vehicle information")
            if quality_stats["sentiment_coverage_pct"] < 90:
                warnings.append(f"Sentiment data coverage is {quality_stats['sentiment_coverage_pct']}% - some calls may lack sentiment analysis")
            if not year_breakdown:
                warnings.append(f"No model years found with sufficient data ({args.min_calls}+ calls) - try wider date range or lower --min-calls")

            if warnings:
                result["warnings"] = warnings

            print(json.dumps(result, indent=2))

    except Exception as e:
        error_response = {
            "error": str(e),
            "error_type": type(e).__name__,
            "suggestion": "Check vehicle name spelling, date format (YYYY-MM-DD), and database connectivity"
        }
        print(json.dumps(error_response), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()