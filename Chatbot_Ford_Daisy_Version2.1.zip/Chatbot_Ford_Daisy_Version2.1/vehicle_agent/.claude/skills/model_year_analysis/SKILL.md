---
name: model_year_analysis
display_name: Enhanced Model Year Intelligence 
description: Production-grade model year analysis with complete vehicle data coverage (100% vs 18.2% incomplete), advanced statistical validation, and comprehensive pain point analysis. Handles both single years (2024) and year ranges (2020-2024) for business intelligence across Ford model lifecycles.
signals:
  # MODEL YEAR ANALYSIS SIGNALS - Primary routing
  - model year analysis
  - analyze by model year
  - model year breakdown
  - issues by model year
  - breakdown by model year
  - model year intelligence
  - model year comparison
  
  # SPECIFIC YEAR SIGNALS - Single year focus
  - 2024 Explorer issues
  - 2023 F-150 problems  
  - 2022 Bronco analysis
  - 2021 Mach-E breakdown
  - which model year has most calls
  - which year has worst sentiment
  - specific model year issues
  
  # YEAR RANGE SIGNALS - Multi-year analysis  
  - 2020-2024 analysis
  - 2022 to 2024 comparison
  - model years 2020-2024
  - across model years 2020-2024
  - Explorer 2020-2024 issues
  - F-150 2021-2024 breakdown
  
  # YEAR COMPARISON SIGNALS - Business intelligence
  - compare model years
  - model year trends
  - year over year analysis
  - which year is better
  - model year performance
  - yearly comparison analysis
requires:
  - a vehicle name (Explorer, F-150, Bronco, etc.)
  - optionally a model year (2024) or year range (2020-2024)
  
capabilities:
  - COMPLETE VEHICLE DATA: Uses 100% complete models table vs 18.2% incomplete call_data  
  - ENHANCED SENTIMENT: Integrates 99.3% complete sentiment vs 22.9% incomplete call_data
  - YEAR RANGE SUPPORT: Handles both single years (2024) and ranges (2020-2024)
  - STATISTICAL VALIDATION: HAVING filters ensure reliable results with confidence scoring
  - STRUCTURED PAIN POINTS: Complete pain point analysis from v_pain_points2 table
  - TIME ANALYSIS: Monthly/yearly performance tracking and trend analysis
  
not_good_for: 
  - Simple call counts without year breakdown (use vehicle_volume)  
  - Keyword-based analysis (use keyword_search)
  - Customer verbatim examples (use vehicle_examples) 
  - Overall pain points without year context (use vehicle_pain_points)
  - Brand switching analysis (use issue_breakdown)
---

# Enhanced Model Year Intelligence

## What this skill does
**PRODUCTION-READY MODEL YEAR ANALYSIS** with complete vehicle data coverage and advanced business intelligence. Uses authoritative models table (100% coverage) vs incomplete call_data (18.2%), providing reliable model year analysis for strategic decision making.

**Key Capabilities:**
- Complete Year Breakdown: Call volume, sentiment, AHT, complexity by model year
- Single Year Deep-Dive: Detailed pain point analysis for specific years  
- Year Range Analysis: Multi-year comparison (2020-2024) for trend analysis
- Statistical Validation: Confidence scoring and reliability metrics
- Business Intelligence: Identifies best/worst performing model years

## When to use this skill

### YES PERFECT FOR:
```
"Analyze Explorer by model year"
"Explorer 2020-2024 breakdown"  
"2024 F-150 specific issues"
"Which Explorer model year has most calls?"
"Compare Bronco 2021 vs 2022 vs 2023"
"Model year analysis for Mach-E 2022-2024"
"F-150 yearly performance trends"
"Which year model has worst sentiment?"
"2023 Explorer pain point breakdown"
"Model years with highest AHT"
```

### NO NOT GOOD FOR:
```
"F-150 transmission issues"  use vehicle_examples or keyword_search
"Overall Explorer pain points"  use vehicle_pain_points  
"Call volume trends over time"  use vehicle_volume
"Customer verbatim about recalls"  use vehicle_examples
"Brand switching analysis"  use issue_breakdown
```

## How to run it

ENHANCED Production Examples:
```bash
# All model years breakdown for business planning
python .claude/skills/model_year_analysis/scripts/model_year_analysis.py --vehicle "Explorer"

# Year range analysis for strategic insights  
python .claude/skills/model_year_analysis/scripts/model_year_analysis.py --vehicle "F-150" --year "2020-2024"

# Single year deep-dive with pain points
python .claude/skills/model_year_analysis/scripts/model_year_analysis.py --vehicle "Bronco" --year "2023" --sample-feedback

# Time-based performance analysis
python .claude/skills/model_year_analysis/scripts/model_year_analysis.py --vehicle "Mach-E" --year "2022" --time-analysis month --monthly-pain-points
```

## Arguments (PRODUCTION ENHANCED)

| Argument | Required | Default | Description |
|---|---|---|---|
| `--vehicle` | Yes |  | Vehicle name (Explorer, F-150, Bronco, Mach-E, etc.) |
| `--year` | No | all years | **NEW**: Model year analysis - single (2024) or range (2020-2024) |
| `--from` | No | all time | Start call date YYYY-MM-DD for time filtering |
| `--to` | No | all time | End call date YYYY-MM-DD for time filtering |
| `--min-calls` | No | 20 | Min calls per model year for statistical reliability |
| `--time-analysis` | No | none | Include monthly/yearly performance trends |
| `--monthly-pain-points` | No | false | Monthly pain point breakdown (single years only) |
| `--sample-feedback` | No | false | Include sample customer feedback for pain points |

### YEAR RANGE EXAMPLES:
- `--year 2024`  Single year deep-dive analysis
- `--year "2020-2024"`  Multi-year comparison across 5-year span  
- `--year "2022-2024"`  Recent 3-year trend analysis

## Output format

```json
{
  "vehicle": "Explorer",
  "total_calls_in_breakdown": 49000,
  "year_breakdown": [
    { "modelyear": "2025", "call_count": 12277, "pct_of_vehicle_calls": 25.1,
      "avg_sentiment": 0.09, "avg_handle_time_min": 12.4, "avg_complexity": 18.2 },
    { "modelyear": "2020", "call_count": 7195, ... }
  ],
  "model_year_detail": {
    "year": "2017",
    "total_calls": 2963,
    "phrase_pain_points": [
      { "topic": "Software/Technical Issues", "call_count": 2100, "pct_of_year_calls": 70.9 }
    ],
    "flag_pain_points": [
      { "topic": "Warranty Issues", "call_count": 450, "pct_of_year_calls": 15.2 }
    ],
    "flags_note": "Flag pain points only populated for 20232024 data."
  }
}
```

## Routing Intelligence

### When Daisy should route here:
- Model Year Focus: Questions about specific model years or year ranges
- Year Comparison: "Which year is better?", "Compare 2022 vs 2023"  
- Year Breakdown: "Analyze by model year", "Model year analysis"
- Performance by Year: "Which year has worst sentiment?", "Best model year for reliability"
- Multi-Year Trends: "2020-2024 analysis", "Across model years"

### When Daisy should route elsewhere:
- Keyword Analysis  keyword_search (for semantic/business intelligence)
- Customer Examples  vehicle_examples (for verbatim quotes/stories)
- Simple Volumes  vehicle_volume (for basic call counts over time)
- Pain Points Overall  vehicle_pain_points (without year context)
- Parts Analysis  issue_breakdown (for parts/brand switching focus)

### Routing Decision Matrix:
```
Contains "model year" OR "by year" OR "2020-2024" OR "which year"?
     YES: model_year_analysis 
     NO: Check other signals 

Contains specific years like "2024 Explorer" OR "2023 issues"?  
     YES: model_year_analysis 
     NO: Route to appropriate skill 
```

## Error handling
- **Year Format Validation**: Clear error messages for invalid year formats  
- **Range Validation**: Ensures year ranges are logical (start  end)
- **Data Availability**: Reports when insufficient data for reliable analysis
- **Statistical Confidence**: Flags results with low statistical reliability

## Performance optimizations
- **Complete Data Sources**: Uses 100% complete models table for authoritative results
- **Statistical Filtering**: HAVING clauses ensure reliable sample sizes
- **Efficient Joins**: Optimized multi-table joins with proper indexing
- **Intelligent Caching**: Leverages database query optimization for large datasets
