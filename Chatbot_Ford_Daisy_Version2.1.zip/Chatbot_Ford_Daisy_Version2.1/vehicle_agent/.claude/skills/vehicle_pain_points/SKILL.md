---
name: vehicle_pain_points
display_name: Comprehensive Vehicle Pain Points Intelligence
description: Production-grade pain point analysis using v_pain_points2 (main table) combined with models + call_data + sentiments for comprehensive multi-table intelligence. Returns real customer pain points with customer feedback, brand switching analysis, and business impact metrics.
signals:
  # PAIN POINT ANALYSIS SIGNALS - Primary routing
  - pain points
  - top pain points
  - pain point analysis
  - pain points for vehicle
  - vehicle pain points
  - biggest pain points
  - main pain points
  
  # VEHICLE ISSUE SIGNALS - Customer problems
  - top issues for
  - biggest problems  
  - main issues
  - primary issues
  - key issues
  - critical issues
  - major problems
  
  # CUSTOMER COMPLAINT SIGNALS - Customer voice
  - what are customers complaining about
  - customer complaints
  - customer issues
  - customer problems
  - customer concerns
  - what customers say
  
  # BUSINESS INTELLIGENCE SIGNALS - Analysis focus
  - issues with the
  - problems with
  - concerns about
  - top concerns for
  - pain point breakdown
  - issue analysis
  
requires:
  - a vehicle name (Explorer, F-150, Bronco Sport, etc.)
  - optionally date range for temporal analysis
  
capabilities:
  - COMPREHENSIVE MULTI-TABLE INTELLIGENCE: Uses v_pain_points2 (main) + models + call_data + sentiments + parts_unfiltered
  - REAL PAIN POINTS: Actual pain_point field from v_pain_points2 table with customer feedback
  - CUSTOMER FEEDBACK DRILL-DOWN: Sample customer_feedback for context, full feedback with --customer-feedback flag
  - BRAND SWITCHING INTELLIGENCE: Tracks is_switch, why_switch, new_brand for competitive analysis  
  - BUSINESS IMPACT METRICS: Sentiment correlation, performance metrics, switching risk assessment
  - AUTHORITATIVE VEHICLE ID: Uses models table for accurate vehicle identification across model years
  
not_good_for: 
  - Real customer verbatim examples (use vehicle_examples for stories/quotes)
  - Call volume trends over time (use vehicle_volume for trending) 
  - Model year specific analysis (use model_year_analysis for year breakdown)
  - Keyword semantic search (use keyword_search for keyword intelligence)
  - Topic hierarchy analysis (use topic_trends for Level1/Level2/Level3)
---

# Comprehensive Vehicle Pain Points Intelligence

## What this skill does
**PRODUCTION-READY PAIN POINT ANALYSIS** using Ford's v_pain_points2 table as the primary source, combined with comprehensive multi-table intelligence. Provides real customer pain points with business context, sentiment analysis, and competitive intelligence.

**Key Capabilities:**
- Real Pain Points: Uses actual pain_point field from v_pain_points2 (not derived/calculated)
- Customer Feedback: Includes customer_feedback for actionable insights and drill-down capability
- Multi-Table Intelligence: Combines 4+ data sources for comprehensive business intelligence
- Brand Switching Analysis: Tracks customer switching behavior and competitor preferences
- Performance Correlation: Links pain points to AHT, complexity, and sentiment metrics

## When to use this skill

### YES PERFECT FOR:
```
"What are the top pain points for Explorer?"
"Pain point analysis for F-150 this year" 
"Biggest problems with Bronco Sport"
"Customer complaints about Mach-E"
"Main issues affecting Explorer customers"
"Pain points driving F-150 calls"
"Critical issues for Lightning owners"
"Customer concerns about Ranger"
"Pain point breakdown for Transit"
"Top customer problems with Edge"
```

### NO NOT GOOD FOR:
```
"Customer examples about brakes" → use vehicle_examples (for verbatim quotes)
"Call volume trends for Explorer" → use vehicle_volume (for trending)  
"2024 F-150 specific issues" → use model_year_analysis (for model year focus)
"Semantic search for transmission" → use keyword_search (for semantic analysis)
"Topic Level1 Level2 breakdown" → use topic_trends (for topic hierarchy)
```

## How to run it

**COMPREHENSIVE Pain Point Examples:**
```bash
# Current year pain points for specific vehicle
python .claude/skills/vehicle_pain_points/scripts/vehicle_pain_points.py --vehicle "Explorer" --from 2026-01-01 --to 2026-12-31

# All-time pain points with customer feedback drill-down
python .claude/skills/vehicle_pain_points/scripts/vehicle_pain_points.py --vehicle "F-150" --customer-feedback --limit 10

# Recent pain point analysis
python .claude/skills/vehicle_pain_points/scripts/vehicle_pain_points.py --vehicle "Bronco Sport" --from 2026-08-01 --to 2026-09-18

# Comprehensive analysis with date filtering
python .claude/skills/vehicle_pain_points/scripts/vehicle_pain_points.py --vehicle "Mach-E" --from 2026-06-01 --to 2026-09-18 --limit 8
```

## Arguments (PRODUCTION ENHANCED)

| Argument | Required | Default | Description |
|---|---|---|---|
| `--vehicle` | Yes | — | Vehicle name (Explorer, F-150, Bronco Sport, Mach-E, etc.) |
| `--from` | No | all time | Start date YYYY-MM-DD for temporal filtering |
| `--to` | No | all time | End date YYYY-MM-DD for temporal filtering |
| `--limit` | No | 10 | Max pain points to return (ranked by call volume) |
| `--customer-feedback` | No | false | Include comprehensive customer feedback for drill-down analysis |

## Enhanced Output Format

**COMPREHENSIVE PAIN POINT INTELLIGENCE:**
```json
{
  "vehicle": "Explorer", 
  "total_calls": 44240,
  "analysis_method": "comprehensive_v_pain_points2",
  "data_sources": ["v_pain_points2", "call_data", "models", "sentiments"],
  "pain_points": [
    {
      "pain_point": "Transmission",
      "call_count": 1390,
      "pct_of_calls": 5.7,
      "sentiment_metrics": {
        "avg_sentiment": -0.004,
        "negative_calls": 392,
        "negative_pct": 28.1
      },
      "performance_metrics": {
        "avg_complexity": 25.16,
        "avg_handle_time": 1032.73
      },
      "business_intelligence": {
        "switching_customers": 0,
        "switching_pct": 0.0,
        "competitor_brands": "Lincoln, Ram, Chevrolet, Toyota",
        "vehicles_affected": 1,
        "model_years_affected": 27
      },
      "customer_context": {
        "sample_customer_feedback": "went out, throwing up error codes",
        "sample_problem_mentioned": "Warranty issue with third party company",
        "affected_vehicles": "EXPLORER"
      }
    }
  ],
  "metadata": {
    "date_range": "2026-01-01 to 2026-12-31",
    "customer_feedback_included": false,
    "analysis_completeness": "comprehensive_multi_table"
  }
}
```

## Routing Intelligence

### When Daisy should route here:
- Pain Point Focus: "pain points", "top pain points", "pain point analysis"
- Customer Issues: "biggest problems", "main issues", "customer complaints"  
- Vehicle Problems: "issues with Explorer", "problems with F-150"
- Business Intelligence: "customer concerns", "top concerns for vehicle"

### When Daisy should route elsewhere:
- Customer Stories → vehicle_examples (for verbatim quotes and examples)
- Volume Trends → vehicle_volume (for call volume over time)
- Model Year Analysis → model_year_analysis (for year-specific breakdown)
- Keyword Analysis → keyword_search (for semantic/keyword intelligence)
- Topic Structure → topic_trends (for Ford topic hierarchy)

## Multi-Table Architecture

### PRIMARY TABLE: v_pain_points2
- **pain_point**: Real customer pain point categories (Transmission, Engine, etc.)
- **customer_feedback**: Actual customer descriptions of problems
- **is_switch/why_switch/new_brand**: Brand switching intelligence
- **problem_mentioned**: Specific problem descriptions

### ENRICHMENT TABLES:
- **models**: Authoritative vehicle identification and model year data
- **call_data**: Core metrics (sentiment, complexity, handle_time, call_date)  
- **sentiments**: Enhanced sentiment analysis (overall_sentiment, customer_sentiment)
- **parts_unfiltered**: Available for parts correlation analysis (future enhancement)

## Business Intelligence Features
- **Sentiment Correlation**: Links pain points to customer satisfaction metrics
- **Performance Impact**: Shows AHT and complexity correlation with specific pain points  
- **Brand Switching Risk**: Identifies pain points driving customers to competitors
- **Temporal Analysis**: Date filtering for recent vs. historical pain point trends
- **Customer Voice**: Real customer feedback provides actionable context for each pain point
- **Cross-Vehicle Impact**: Tracks pain points affecting multiple model years

## Data Quality & Coverage
- **44,240 total calls analyzed** (example: Explorer 2026)
- **Real pain point categories** from Ford's v_pain_points2 classification
- **Multi-year coverage** spanning 20+ model years per vehicle
- **Comprehensive sentiment analysis** with negative call tracking
- **Competitive intelligence** tracking 10+ competitor brands per pain point
