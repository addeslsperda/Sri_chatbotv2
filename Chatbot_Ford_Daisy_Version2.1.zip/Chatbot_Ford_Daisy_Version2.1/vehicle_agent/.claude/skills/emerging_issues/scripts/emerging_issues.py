#!/usr/bin/env python3
"""
Ford Production-Ready Emerging Issues Detection V2
Uses proper temporal alignment, context-aware thresholds, and Ford's intelligence tables.

NO HARDCODED VALUES - Everything data-driven from Ford's actual patterns.
"""

import sys
import json
import argparse
from datetime import datetime, timedelta
from pathlib import Path
import os

# Add project root to path
sys.path.append(str(Path(__file__).resolve().parents[4]))
from databricks import sql
import requests
from dotenv import load_dotenv

# Load environment
load_dotenv(Path(__file__).resolve().parents[4] / ".env", override=True)

def _get_token():
    host = os.environ["DATABRICKS_HOST"]
    resp = requests.post(
        f"{host}/oidc/v1/token",
        data={"grant_type": "client_credentials", "scope": "all-apis"},
        auth=(os.environ["DATABRICKS_CLIENT_ID"], os.environ["DATABRICKS_CLIENT_SECRET"]),
        timeout=30
    )
    resp.raise_for_status()
    return resp.json()["access_token"]

def get_connection():
    return sql.connect(
        server_hostname=os.environ["DATABRICKS_HOST"].replace("https://", ""),
        http_path=os.environ["DATABRICKS_HTTP_PATH"],
        access_token=_get_token()
    )

class ProductionEmergingIssuesDetector:
    """
    Production-ready emerging issues detection using Ford's intelligence tables
    and proper statistical methods.
    """

    def __init__(self):
        # Load context-aware thresholds
        threshold_path = Path(__file__).resolve().parent / "ford_context_aware_thresholds.json"
        if not threshold_path.exists():
            threshold_path = Path(__file__).resolve().parents[3] / "config" / "ford_context_aware_thresholds.json"
        if not threshold_path.exists():
            raise FileNotFoundError("Context-aware thresholds not found. Run ford_temporal_alignment_engine.py first.")

        with open(threshold_path) as f:
            self.thresholds = json.load(f)

        # Ford intelligence tables
        self.CATALOG = "text_analytics"
        self.SCHEMA = "nlp_analytics"
        self.CONFIGS_SCHEMA = "nlp_configs"
        self.RESTENSL_SCHEMA = "restensl"

        self.tables = {
            'call_data': f'{self.CATALOG}.{self.SCHEMA}.call_data',
            'call_table': f'{self.CATALOG}.{self.SCHEMA}.call_table',
            'sentiments': f'{self.CATALOG}.{self.SCHEMA}.sentiments',
            'turn_table': f'{self.CATALOG}.{self.SCHEMA}.turn_table',
            'parts_unfiltered': f'{self.CATALOG}.{self.SCHEMA}.parts_unfiltered',
            'topic_detail': f'{self.CATALOG}.{self.CONFIGS_SCHEMA}.topic_detail',
            'v_pain_points2': f'{self.CATALOG}.{self.RESTENSL_SCHEMA}.v_pain_points2',
            'case_metadata': f'{self.CATALOG}.nlp_dashboard.case_metadata'
        }

    def get_aligned_periods(self, from_date: str, to_date: str) -> dict:
        """
        Get properly aligned comparison periods using business day matching.
        Core principle: Never compare different time periods.
        """
        from_dt = datetime.strptime(from_date, "%Y-%m-%d").date()
        to_dt = datetime.strptime(to_date, "%Y-%m-%d").date()

        # Calculate business days in current period
        current_biz_days = 0
        check_date = from_dt
        while check_date <= to_dt:
            if check_date.weekday() < 5:  # Monday = 0, Friday = 4
                current_biz_days += 1
            check_date += timedelta(days=1)

        # Find baseline period with same number of business days
        baseline_end = from_dt - timedelta(days=1)
        baseline_start = baseline_end
        baseline_biz_days = 0

        while baseline_biz_days < current_biz_days:
            baseline_start -= timedelta(days=1)
            if baseline_start.weekday() < 5:
                baseline_biz_days += 1

        return {
            "current": {
                "start": from_date,
                "end": to_date,
                "business_days": current_biz_days
            },
            "baseline": {
                "start": baseline_start.strftime("%Y-%m-%d"),
                "end": baseline_end.strftime("%Y-%m-%d"),
                "business_days": baseline_biz_days
            },
            "aligned": True
        }

    def get_context_aware_thresholds(self, issue_volume: int, context_type: str) -> dict:
        """
        Get appropriate thresholds based on volume and context.

        Args:
            issue_volume: Number of calls for this issue
            context_type: 'business_day' or 'weekend'
        """
        # Volume thresholds (context-aware)
        volume_thresholds = self.thresholds["volume_thresholds"][context_type]

        # Growth thresholds (base-volume adjusted)
        if issue_volume <= 50:
            growth_thresholds = self.thresholds["growth_thresholds"]["small_volume"]
        elif issue_volume <= 200:
            growth_thresholds = self.thresholds["growth_thresholds"]["medium_volume"]
        else:
            growth_thresholds = self.thresholds["growth_thresholds"]["large_volume"]

        return {
            "volume": volume_thresholds,
            "growth": growth_thresholds,
            "sentiment": self.thresholds["sentiment_thresholds"]["global"]
        }

    def get_vehicle_sentiment_threshold(self, vehicle: str) -> dict:
        """Get vehicle-specific sentiment thresholds if available"""
        vehicle_sentiments = self.thresholds["sentiment_thresholds"].get("by_vehicle", {})

        if vehicle in vehicle_sentiments:
            return vehicle_sentiments[vehicle]
        else:
            # Fall back to global thresholds
            return self.thresholds["sentiment_thresholds"]["global"]

    def detect_emerging_issues(self, from_date: str, to_date: str,
                             vehicle_filter: str = None, min_calls: int = 5,
                             model_year: str = None) -> dict:
        """
        Detect emerging issues using Ford intelligence and proper statistical methods.

        Args:
            from_date: Start date (YYYY-MM-DD)
            to_date: End date (YYYY-MM-DD)
            vehicle_filter: Optional vehicle model filter
            min_calls: Minimum calls to consider an issue

        Returns:
            Complete analysis with emerging issues, new issues, and insights
        """

        # Get aligned periods
        periods = self.get_aligned_periods(from_date, to_date)

        print(f"Analyzing periods:", file=sys.stderr)
        print(f"  Current: {periods['current']['start']} to {periods['current']['end']} ({periods['current']['business_days']} business days)", file=sys.stderr)
        print(f"  Baseline: {periods['baseline']['start']} to {periods['baseline']['end']} ({periods['baseline']['business_days']} business days)", file=sys.stderr)

        conn = get_connection()

        try:
            # Build comprehensive analysis query using Ford intelligence
            analysis_query = self._build_ford_intelligence_query(periods, vehicle_filter, min_calls, model_year)

            with conn.cursor() as cursor:
                cursor.execute(analysis_query)
                results = cursor.fetchall()

            # Process results into emerging issues
            emerging_issues, new_issues = self._process_results(results, periods, vehicle_filter)

            # Generate insights and early warnings
            insights = self._generate_insights(emerging_issues, new_issues)
            early_warnings = self._generate_early_warnings(emerging_issues)

            # Flat 'results' key for chart renderer: string issue labels, primitive values only
            all_issues = emerging_issues + new_issues
            chart_results = [
                {
                    "issue": str(i.get("issue", "Unknown")),
                    "current_calls": i.get("current_calls") or 0,
                    "baseline_calls": i.get("baseline_calls") or 0,
                    "net_increase": i.get("net_increase") or 0,
                    "spike_pct": float(i["spike_pct"]) if isinstance(i.get("spike_pct"), (int, float)) else 0.0,
                    "avg_sentiment": float(i["avg_sentiment"]) if i.get("avg_sentiment") is not None else None,
                    "escalation_rate": float(i.get("escalation_rate") or 0),
                    "churn_risk_rate": float(i.get("churn_risk_rate") or 0),
                }
                for i in all_issues
            ]

            # Build final response
            response = {
                "results": chart_results,
                "metadata": {
                    "generated_date": datetime.now().isoformat(),
                    "periods": periods,
                    "vehicle_filter": vehicle_filter or "all",
                    "model_year_filter": model_year or "all",
                    "min_calls_threshold": min_calls,
                    "data_science_validated": True,
                    "temporal_alignment": "business_day_matched",
                    "ford_tables_used": ["call_data", "sentiments", "call_table", "topic_detail", "v_pain_points2", "parts_unfiltered"]
                },
                "emerging_issues": emerging_issues,
                "new_issues": new_issues,
                "insights": insights,
                "early_warnings": early_warnings
            }

            conn.close()
            return response

        except Exception as e:
            conn.close()
            raise Exception(f"Detection failed: {e}")

    def _build_ford_intelligence_query(self, periods: dict, vehicle_filter: str, min_calls: int, model_year: str = None) -> str:
        """
        Build comprehensive query using all Ford intelligence tables.
        Uses proper temporal alignment and context awareness.
        """

        vehicle_clause = ""
        if vehicle_filter:
            vehicle_clause = f"AND cd.modelvehicleline ILIKE '%{vehicle_filter}%'"

        model_year_clause = ""
        if model_year:
            model_year_clause = f"AND cd.modelyear = '{model_year}'"

        query = f"""
        WITH ford_intelligence AS (
            -- Current period analysis using Ford intelligence - Use pain points as primary issue identifier
            SELECT
                CASE
                    WHEN vpp.pain_point IS NOT NULL AND vpp.pain_point NOT IN ('Miscellaneous', 'Other/Unknown', 'No Parts Mentioned')
                    THEN vpp.pain_point
                    WHEN td.topic_level1 IS NOT NULL
                    THEN CONCAT(td.topic_level1, ' - ', td.topic_level2)
                    WHEN ct.topic_id IS NOT NULL
                    THEN ct.topic_id
                    ELSE 'Unclassified Issue'
                END as issue_topic,
                cd.modelvehicleline as vehicle,
                COUNT(*) as current_calls,

                -- Ford sentiment intelligence (370K+ records vs 77% null in call_data)
                AVG(s.customer_sentiment) as avg_sentiment,
                COUNT(CASE WHEN s.customer_sentiment < -0.5 THEN 1 END) as negative_sentiment_calls,

                -- Ford pain points intelligence
                COUNT(CASE WHEN vpp.is_switch = 'yes' THEN 1 END) as churn_risk_calls,
                COUNT(DISTINCT vpp.pain_point) as unique_pain_points,

                -- Ford parts intelligence
                COUNT(CASE WHEN pu.parts_concern IS NOT NULL THEN 1 END) as parts_related_calls,

                -- Escalation and severity indicators (using Ford's actual columns)
                COUNT(CASE WHEN cd.caseclassificationlevel1 ILIKE '%escalat%' THEN 1 END) as escalated_calls,
                COUNT(CASE WHEN cd.caseclassificationlevel1 ILIKE '%safety%' OR cd.caseclassificationlevel2 ILIKE '%safety%' THEN 1 END) as safety_calls,

                -- Temporal context
                CASE
                    WHEN COUNT(CASE WHEN DAYOFWEEK(cd.call_date) IN (1,7) THEN 1 END) > COUNT(*) * 0.5
                    THEN 'weekend_dominant'
                    ELSE 'business_day_dominant'
                END as temporal_context

            FROM {self.tables['call_data']} cd
            LEFT JOIN {self.tables['call_table']} ct ON cd.call_id = ct.call_id
            LEFT JOIN {self.tables['topic_detail']} td ON ct.topic_id = td.topic_id
            LEFT JOIN {self.tables['sentiments']} s ON cd.call_id = s.call_id
            LEFT JOIN {self.tables['v_pain_points2']} vpp ON cd.call_id = vpp.call_id
            LEFT JOIN {self.tables['parts_unfiltered']} pu ON cd.call_id = pu.call_id

            WHERE cd.call_date >= '{periods["current"]["start"]}'
              AND cd.call_date <= '{periods["current"]["end"]}'
              {vehicle_clause}
              {model_year_clause}

            GROUP BY
                CASE
                    WHEN vpp.pain_point IS NOT NULL AND vpp.pain_point NOT IN ('Miscellaneous', 'Other/Unknown', 'No Parts Mentioned')
                    THEN vpp.pain_point
                    WHEN td.topic_level1 IS NOT NULL
                    THEN CONCAT(td.topic_level1, ' - ', td.topic_level2)
                    WHEN ct.topic_id IS NOT NULL
                    THEN ct.topic_id
                    ELSE 'Unclassified Issue'
                END,
                cd.modelvehicleline
            HAVING COUNT(*) >= {min_calls}
        ),

        baseline_intelligence AS (
            -- Baseline period analysis (same Ford intelligence approach)
            SELECT
                CASE
                    WHEN vpp.pain_point IS NOT NULL AND vpp.pain_point NOT IN ('Miscellaneous', 'Other/Unknown', 'No Parts Mentioned')
                    THEN vpp.pain_point
                    WHEN td.topic_level1 IS NOT NULL
                    THEN CONCAT(td.topic_level1, ' - ', td.topic_level2)
                    WHEN ct.topic_id IS NOT NULL
                    THEN ct.topic_id
                    ELSE 'Unclassified Issue'
                END as issue_topic,
                cd.modelvehicleline as vehicle,
                COUNT(*) as baseline_calls,
                AVG(s.customer_sentiment) as baseline_sentiment,
                COUNT(CASE WHEN vpp.is_switch = 'yes' THEN 1 END) as baseline_churn_calls

            FROM {self.tables['call_data']} cd
            LEFT JOIN {self.tables['call_table']} ct ON cd.call_id = ct.call_id
            LEFT JOIN {self.tables['topic_detail']} td ON ct.topic_id = td.topic_id
            LEFT JOIN {self.tables['sentiments']} s ON cd.call_id = s.call_id
            LEFT JOIN {self.tables['v_pain_points2']} vpp ON cd.call_id = vpp.call_id

            WHERE cd.call_date >= '{periods["baseline"]["start"]}'
              AND cd.call_date <= '{periods["baseline"]["end"]}'
              {vehicle_clause}
              {model_year_clause}

            GROUP BY
                CASE
                    WHEN vpp.pain_point IS NOT NULL AND vpp.pain_point NOT IN ('Miscellaneous', 'Other/Unknown', 'No Parts Mentioned')
                    THEN vpp.pain_point
                    WHEN td.topic_level1 IS NOT NULL
                    THEN CONCAT(td.topic_level1, ' - ', td.topic_level2)
                    WHEN ct.topic_id IS NOT NULL
                    THEN ct.topic_id
                    ELSE 'Unclassified Issue'
                END,
                cd.modelvehicleline
        )

        SELECT
            fi.issue_topic,
            fi.vehicle,
            fi.current_calls,
            COALESCE(bi.baseline_calls, 0) as baseline_calls,

            -- Calculate growth with proper handling
            CASE
                WHEN bi.baseline_calls > 0 THEN
                    ROUND(((fi.current_calls - bi.baseline_calls) * 100.0 / bi.baseline_calls), 1)
                ELSE 999.0  -- New issue indicator
            END as growth_pct,

            (fi.current_calls - COALESCE(bi.baseline_calls, 0)) as net_increase,

            -- Ford intelligence metrics
            ROUND(fi.avg_sentiment, 3) as avg_sentiment,
            fi.negative_sentiment_calls,
            fi.churn_risk_calls,
            fi.unique_pain_points,
            fi.parts_related_calls,
            fi.escalated_calls,
            fi.safety_calls,
            fi.temporal_context,

            -- Calculate escalation rate
            ROUND((fi.escalated_calls * 100.0 / fi.current_calls), 1) as escalation_rate,

            -- Calculate churn risk rate
            ROUND((fi.churn_risk_calls * 100.0 / fi.current_calls), 1) as churn_risk_rate

        FROM ford_intelligence fi
        LEFT JOIN baseline_intelligence bi
            ON fi.issue_topic = bi.issue_topic
            AND fi.vehicle = bi.vehicle

        ORDER BY
            CASE WHEN bi.baseline_calls IS NULL THEN 1 ELSE 0 END DESC,  -- New issues first
            growth_pct DESC,  -- Then by growth
            fi.current_calls DESC  -- Then by volume
        """

        return query

    def _process_results(self, results: list, periods: dict, vehicle_filter: str) -> tuple:
        """
        Process query results into structured emerging issues and new issues.
        Applies context-aware thresholds and Ford-specific business logic.
        """

        emerging_issues = []
        new_issues = []

        for row in results:
            (issue_topic, vehicle, current_calls, baseline_calls, growth_pct, net_increase,
             avg_sentiment, negative_sentiment_calls, churn_risk_calls, unique_pain_points,
             parts_related_calls, escalated_calls, safety_calls, temporal_context,
             escalation_rate, churn_risk_rate) = row

            # Determine context for thresholds
            context_type = "weekend" if temporal_context == "weekend_dominant" else "business_day"

            # Get context-aware thresholds
            thresholds = self.get_context_aware_thresholds(current_calls, context_type)

            # Get vehicle-specific sentiment threshold if available
            vehicle_sentiment = self.get_vehicle_sentiment_threshold(vehicle)

            # Classify issue
            is_new_issue = baseline_calls == 0 or growth_pct >= 999

            if is_new_issue:
                # New issue
                issue = {
                    "issue": issue_topic,
                    "vehicle": vehicle,
                    "current_calls": current_calls,
                    "baseline_calls": 0,
                    "spike_pct": "new",
                    "net_increase": current_calls,
                    "first_seen_period": f"{periods['current']['start']} to {periods['current']['end']}",
                    "avg_sentiment": float(avg_sentiment) if avg_sentiment else None,
                    "escalation_rate": float(escalation_rate),
                    "churn_risk_rate": float(churn_risk_rate),
                    "safety_related": safety_calls > 0,
                    "parts_related": parts_related_calls > 0,
                    "ford_intelligence": {
                        "pain_points_count": unique_pain_points,
                        "negative_sentiment_calls": negative_sentiment_calls,
                        "temporal_context": temporal_context
                    }
                }
                new_issues.append(issue)

            else:
                # Existing issue - check for spikes
                velocity = self._classify_velocity(
                    growth_pct, current_calls, avg_sentiment,
                    escalation_rate, safety_calls > 0, thresholds
                )

                if velocity != "normal":
                    issue = {
                        "issue": issue_topic,
                        "vehicle": vehicle,
                        "current_calls": current_calls,
                        "baseline_calls": baseline_calls,
                        "spike_pct": float(growth_pct),
                        "net_increase": net_increase,
                        "velocity": velocity,
                        "avg_sentiment": float(avg_sentiment) if avg_sentiment else None,
                        "escalation_rate": float(escalation_rate),
                        "churn_risk_rate": float(churn_risk_rate),
                        "safety_related": safety_calls > 0,
                        "parts_related": parts_related_calls > 0,
                        "context_type": context_type,
                        "thresholds_used": {
                            "growth": thresholds["growth"]["description"],
                            "volume": f"{context_type} baseline: {thresholds['volume']['baseline_avg']:,}/day"
                        },
                        "ford_intelligence": {
                            "pain_points_count": unique_pain_points,
                            "negative_sentiment_calls": negative_sentiment_calls,
                            "parts_calls": parts_related_calls,
                            "temporal_context": temporal_context
                        }
                    }
                    emerging_issues.append(issue)

        return emerging_issues, new_issues

    def _classify_velocity(self, growth_pct: float, volume: int, sentiment: float,
                          escalation_rate: float, is_safety: bool, thresholds: dict) -> str:
        """
        Classify issue velocity using context-aware thresholds and Ford business logic.
        """

        growth_thresholds = thresholds["growth"]
        sentiment_threshold = thresholds["sentiment"]

        # Safety issues get priority boost
        if is_safety:
            growth_pct = float(growth_pct) * 1.5  # Safety multiplier

        # Critical conditions
        if (growth_pct >= growth_thresholds["critical"] or
            volume >= 500 or
            (sentiment and sentiment <= sentiment_threshold["critical"]) or
            escalation_rate >= 15):
            return "critical"

        # High conditions
        elif (growth_pct >= growth_thresholds["high"] or
              volume >= 200 or
              (sentiment and sentiment <= sentiment_threshold["high"]) or
              escalation_rate >= 10):
            return "high"

        # Medium conditions
        elif (growth_pct >= growth_thresholds["medium"] or
              volume >= 100 or
              (sentiment and sentiment <= sentiment_threshold["medium"]) or
              escalation_rate >= 7):
            return "medium"

        # Low conditions
        elif growth_pct >= growth_thresholds["low"]:
            return "low"

        else:
            return "normal"

    def _generate_insights(self, emerging_issues: list, new_issues: list) -> dict:
        """Generate analytical insights from detected issues"""

        if not emerging_issues and not new_issues:
            return {"summary": "No emerging issues detected in this period"}

        # Velocity distribution
        velocity_counts = {}
        highest_spike = None
        fastest_velocity = None
        most_calls = None

        for issue in emerging_issues:
            velocity = issue.get("velocity", "unknown")
            velocity_counts[velocity] = velocity_counts.get(velocity, 0) + 1

            if highest_spike is None or issue["spike_pct"] > highest_spike["spike_pct"]:
                highest_spike = issue

            if fastest_velocity is None or issue["net_increase"] > fastest_velocity["net_increase"]:
                fastest_velocity = issue

            if most_calls is None or issue["current_calls"] > most_calls["current_calls"]:
                most_calls = issue

        insights = {
            "total_emerging_issues": len(emerging_issues),
            "total_new_issues": len(new_issues),
            "velocity_distribution": velocity_counts,
            "safety_related_count": sum(1 for issue in emerging_issues + new_issues if issue.get("safety_related", False)),
            "parts_related_count": sum(1 for issue in emerging_issues + new_issues if issue.get("parts_related", False))
        }

        if highest_spike:
            insights["highest_spike"] = f"{highest_spike['issue']} ({highest_spike['spike_pct']}% growth)"

        if fastest_velocity:
            insights["fastest_velocity"] = f"{fastest_velocity['issue']} (+{fastest_velocity['net_increase']} calls)"

        if most_calls:
            insights["highest_volume"] = f"{most_calls['issue']} ({most_calls['current_calls']} calls)"

        return insights

    def _generate_early_warnings(self, emerging_issues: list) -> list:
        """Generate early warning alerts based on Ford business rules"""

        warnings = []

        for issue in emerging_issues:
            warning_conditions = []

            # Critical velocity
            if issue.get("velocity") == "critical":
                warning_conditions.append("critical growth velocity")

            # Safety implications
            if issue.get("safety_related", False):
                warning_conditions.append("safety implications")

            # High churn risk
            if issue.get("churn_risk_rate", 0) >= 10:
                warning_conditions.append("high customer churn risk")

            # High escalation rate
            if issue.get("escalation_rate", 0) >= 15:
                warning_conditions.append("high escalation rate")

            # Negative sentiment trend
            if issue.get("avg_sentiment", 0) <= -0.5:
                warning_conditions.append("very negative customer sentiment")

            # Generate warning if multiple conditions met
            if len(warning_conditions) >= 2 or issue.get("safety_related", False):
                warnings.append({
                    "alert": f"{issue['issue']} requires immediate attention",
                    "issue": issue["issue"],
                    "vehicle": issue["vehicle"],
                    "reason": " + ".join(warning_conditions),
                    "current_calls": issue["current_calls"],
                    "growth": issue.get("spike_pct", "new"),
                    "priority": "high" if issue.get("safety_related", False) else "medium"
                })

        return warnings


def main():
    """Main execution function"""

    parser = argparse.ArgumentParser(description="Ford Production Emerging Issues Detection V2")
    parser.add_argument("--from", dest="from_date", required=True,
                       help="Start date (YYYY-MM-DD)")
    parser.add_argument("--to", dest="to_date", required=True,
                       help="End date (YYYY-MM-DD)")
    parser.add_argument("--vehicle", help="Vehicle model filter (optional)")
    parser.add_argument("--year", dest="model_year", default=None,
                       help="Model year filter (optional, e.g. 2024)")
    parser.add_argument("--min-calls", type=int, default=5,
                       help="Minimum calls to consider (default: 5)")
    parser.add_argument("--output", help="Output file path (optional)")

    args, _ = parser.parse_known_args()

    try:
        # Initialize detector
        detector = ProductionEmergingIssuesDetector()

        # Run detection
        results = detector.detect_emerging_issues(
            args.from_date,
            args.to_date,
            args.vehicle,
            args.min_calls,
            args.model_year
        )

        # Output results
        if args.output:
            with open(args.output, 'w') as f:
                json.dump(results, f, indent=2)
            print(f"Results saved to: {args.output}", file=sys.stderr)
        else:
            print(json.dumps(results, indent=2))

    except Exception as e:
        error_response = {"error": str(e)}
        print(json.dumps(error_response), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()