---
name: emerging_issues
display_name: Emerging Issues & Anomaly Detection
description: Detects new issues appearing suddenly, volume spikes, and trending problems before they become critical. Use for "what's trending up", "new issues this week", "any spikes", "what's emerging", "unusual patterns", "early warning", "what changed recently".
signals:
  - emerging
  - trending up
  - new issues
  - volume spike
  - unusual
  - anomaly
  - what's new
  - what changed
  - early warning
  - sudden increase
requires:
  - date range (minimum 2 weeks for comparison)
not_good_for: Long-term trends (use trend_analysis), period comparison (use temporal_comparison)
---

# Emerging Issues & Anomaly Detection

## What this script does
Automatically detects issues that are spiking or appearing for the first time:
- **Volume spikes**: Issues with sudden increases (week-over-week)
- **New issues**: Problems not seen in prior period
- **Trending topics**: Issues growing rapidly
- **Anomaly detection**: Unusual patterns requiring attention
- **Early warning system**: Catch problems before they hit social media/NHTSA
- **Velocity tracking**: How fast issues are accelerating

Returns issues sorted by spike magnitude (highest growth = priority).

## How to run it

```bash
python .claude/skills/emerging_issues/scripts/emerging_issues.py --from 2026-01-15 --to 2026-01-31
```

## Arguments

| Argument | Required | Default | Description |
|---|---|---|---|
| `--from` | Yes |  | Start date YYYY-MM-DD (recent period) |
| `--to` | Yes |  | End date YYYY-MM-DD |
| `--vehicle` | No | all | Filter by vehicle model |
| `--min-spike` | No | `50` | Minimum % increase to flag (50 = 50% increase) |
| `--min-occurrences` | No | `10` | Minimum calls in current period |
| `--lookback-days` | No | `14` | Days to look back for baseline comparison |
| `--sort` | No | `spike` | Sort: `spike` (highest growth), `volume` (most calls), `velocity` |
| `--limit` | No | `20` | Max issues to return |

## Example calls

```bash
# Detect emerging issues (last 2 weeks vs prior 2 weeks)
python .claude/skills/emerging_issues/scripts/emerging_issues.py --from 2026-01-15 --to 2026-01-31

# Only major spikes (100%+ increase)
python .claude/skills/emerging_issues/scripts/emerging_issues.py --from 2026-01-15 --to 2026-01-31 --min-spike 100

# F-150 emerging issues
python .claude/skills/emerging_issues/scripts/emerging_issues.py --from 2026-01-15 --to 2026-01-31 --vehicle "F-150"

# Mach-E new problems (last week vs prior week)
python .claude/skills/emerging_issues/scripts/emerging_issues.py --from 2026-01-24 --to 2026-01-31 --vehicle "Mach-E" --lookback-days 7

# Highest velocity issues (fastest growing)
python .claude/skills/emerging_issues/scripts/emerging_issues.py --from 2026-01-15 --to 2026-01-31 --sort velocity
```

## Output format

```json
{
  "date_range": "2026-01-15 to 2026-01-31",
  "comparison_period": "2026-01-01 to 2026-01-14",
  "vehicle_filter": "all",
  "min_spike_threshold": 50,
  "total_current_calls": 8500,
  "total_baseline_calls": 7200,
  "overall_growth": 18.1,
  "emerging_issues": [
    {
      "issue": "Phone as a Key intermittent failure",
      "current_calls": 285,
      "baseline_calls": 95,
      "spike_pct": 200.0,
      "net_increase": 190,
      "velocity": "critical",
      "current_pct_of_calls": 3.4,
      "baseline_pct_of_calls": 1.3,
      "avg_sentiment": -0.72,
      "sentiment_trend": "declining",
      "vehicles_affected": ["Mach-E", "F-150 Lightning", "Explorer"],
      "top_vehicle": "Mach-E (185 calls)",
      "escalation_rate": 8.5,
      "keywords": ["phone as a key", "paak", "won't unlock", "intermittent"],
      "examples": [
        {
          "date": "2026-01-28",
          "vehicle": "Mach-E",
          "summary": "Phone as a Key stops working randomly, customer stranded in parking lot"
        }
      ]
    },
    {
      "issue": "BlueCruise hands-free disengages unexpectedly",
      "current_calls": 120,
      "baseline_calls": 45,
      "spike_pct": 166.7,
      "net_increase": 75,
      "velocity": "high",
      "current_pct_of_calls": 1.4,
      "baseline_pct_of_calls": 0.6,
      "avg_sentiment": -0.58,
      "vehicles_affected": ["F-150", "Mustang Mach-E"]
    }
  ],
  "new_issues": [
    {
      "issue": "Software update 3.8.5 causing infotainment freeze",
      "current_calls": 45,
      "baseline_calls": 0,
      "spike_pct": "new",
      "first_seen": "2026-01-18",
      "vehicles_affected": ["Explorer", "Bronco Sport"]
    }
  ],
  "insights": {
    "highest_spike": "Phone as a Key (200% increase)",
    "fastest_velocity": "Phone as a Key (190 new calls in 2 weeks)",
    "most_vehicles_affected": "Phone as a Key (3 models)",
    "critical_issues": 1,
    "high_issues": 4,
    "new_issues_count": 2
  },
  "early_warnings": [
    {
      "alert": "Phone as a Key issue accelerating rapidly - potential NHTSA complaint risk",
      "issue": "Phone as a Key",
      "reason": "200% spike + negative sentiment + safety implications"
    }
  ]
}
```

## Velocity Classification

**Critical** (Immediate action):
- Spike > 150%
- Or net increase > 100 calls
- Or negative sentiment < -0.6
- Safety-related keywords

**High** (Monitor closely):
- Spike 100-150%
- Or net increase 50-100 calls
- Or escalation rate > 10%

**Medium** (Watch):
- Spike 50-100%
- Or net increase 20-50 calls

**Low** (Normal variation):
- Spike < 50%

## Sorting Options

**`--sort spike`** (DEFAULT):
- Highest % increase first
- Use for: "What's spiking most?"

**`--sort volume`**:
- Most calls in current period
- Use for: "What's the biggest new problem?"

**`--sort velocity`**:
- Fastest acceleration (net increase)
- Use for: "What's growing fastest?"

## Error output
If something goes wrong, the script prints `{"error": "..."}` to stderr and exits with code 1.

## Notes
- **Use cases**: 
  - Early warning system (catch issues before they explode)
  - Quality control (detect manufacturing defects early)
  - Software update monitoring (did new update break something?)
  - Recall prediction (identify potential safety issues)
  - Social media prevention (fix before customers tweet)
  - NHTSA prevention (address before formal complaints)
- **Default lookback**: 14 days (2 weeks for baseline comparison)
- Requires minimum 2-week date range for meaningful comparison
- **Smart sorting**: Default = spike % (highest growth = priority)
- Combines volume, sentiment, and escalation signals
- Use with recall_analysis to track safety-related spikes
- Combine with sentiment_deep_dive to understand emotional impact
- Cross-reference with temporal_comparison for detailed period analysis
