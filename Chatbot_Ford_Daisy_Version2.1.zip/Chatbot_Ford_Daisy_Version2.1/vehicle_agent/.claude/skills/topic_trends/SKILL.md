---
name: topic_trends
display_name: Comprehensive Topic Intelligence
description: Production-grade topic analysis using Ford's official topic hierarchy (Level1→Level2→Level3) with comprehensive multi-table intelligence. Analyzes trending topics from topic_xwalk, topic_detail, and enriches with call_data, models, sentiments, and call summaries for complete business intelligence.
signals:
  # TOPIC ANALYSIS SIGNALS - Primary routing for topic hierarchy
  - trending topics
  - topic trends  
  - top topics
  - what are the trending topics
  - topic analysis
  - topics by volume
  - most common topics
  
  # TOPIC HIERARCHY SIGNALS - Ford's structured topics
  - topic level1
  - topic level2  
  - topic level3
  - topic hierarchy
  - topic breakdown
  - topic categories
  - topic classification
  
  # BUSINESS INTELLIGENCE SIGNALS - Topic insights
  - what are customers calling about
  - top call drivers
  - main issues
  - primary concerns
  - call topics
  - customer topics
  - issue topics
  
  # TIME-BASED TOPIC SIGNALS - Trending analysis
  - topics this week
  - topics this month
  - trending issues  
  - emerging topics
  - topic uptick
  - topic increase
  - topic surge
  
  # VEHICLE-SPECIFIC TOPIC SIGNALS - Vehicle + topics
  - F-150 topics
  - Bronco topics
  - Mach-E topics
  - Explorer topics
  - topics for vehicle
  
requires:
  - a date range (from/to) for trend analysis
  - optionally a vehicle name for vehicle-specific topic trends
  
capabilities:
  - COMPREHENSIVE MULTI-TABLE INTELLIGENCE: Uses 6 core tables (topic_xwalk + topic_detail + call_data + models + call_table + sentiments)
  - FORD TOPIC HIERARCHY: Official Level1→Level2→Level3 topic structure from topic_detail table
  - BUSINESS IMPACT SCORING: Data-driven impact assessment with Ford-specific thresholds
  - SENTIMENT CORRELATION: Topic sentiment analysis with negative sentiment percentages
  - SAMPLE CONTEXT: Real call summaries for actionable insights
  - VEHICLE INTEGRATION: Authoritative vehicle identification using models table
  
not_good_for: 
  - Simple call counts (use vehicle_volume)
  - Customer verbatim examples (use vehicle_examples) 
  - Model year analysis (use model_year_analysis)
  - Keyword semantic search (use keyword_search)
  - Parts breakdown analysis (use issue_breakdown)
---

# Comprehensive Topic Intelligence

## What this skill does
**PRODUCTION-READY TOPIC ANALYSIS** using Ford's official topic hierarchy with comprehensive multi-table intelligence. Provides structured topic insights from Level1 (broad categories) to Level3 (specific issues) with business impact scoring and sentiment analysis.

**Key Capabilities:**
- Topic Hierarchy Analysis: Complete Level1→Level2→Level3 breakdown from Ford's topic_detail table
- Multi-Table Intelligence: Integrates 6 core tables for comprehensive topic insights
- Business Impact Scoring: Data-driven priority assessment with Ford-specific thresholds  
- Sentiment Correlation: Topic sentiment analysis with actionable insights
- Real Context: Actual call summaries with specific customer issues

## When to use this skill

### YES PERFECT FOR:
```
"What are the trending topics for Bronco Sport?"
"Topic analysis for F-150 calls this month"
"Top customer topics by call volume"
"Trending issues for Mach-E"
"Topic hierarchy breakdown"
"What are customers calling about?"
"Main topics driving calls"
"Topic trends with sentiment analysis"
"Level1 Level2 Level3 topic breakdown"
"Business intelligence on call topics"
```

### NO NOT GOOD FOR:
```
"How many calls for F-150?" → use vehicle_volume
"Customer examples about brakes" → use vehicle_examples  
"2024 Explorer model year issues" → use model_year_analysis
"Semantic search for keywords" → use keyword_search
"Parts breakdown analysis" → use issue_breakdown
```

## How to run it

**COMPREHENSIVE Topic Analysis Examples:**
```bash
# Trending topics for specific vehicle
python .claude/skills/topic_trends/scripts/topic_trends.py --from 2026-08-01 --to 2026-08-31 --vehicle "Bronco Sport"

# All vehicle topic trends with business intelligence
python .claude/skills/topic_trends/scripts/topic_trends.py --from 2026-08-01 --to 2026-08-31 --limit 15

# Recent topic analysis (last 30 days)
python .claude/skills/topic_trends/scripts/topic_trends.py --from 2026-08-01 --to 2026-08-31 --vehicle "F-150" --limit 10
```

## Arguments (PRODUCTION ENHANCED)

| Argument | Required | Default | Description |
|---|---|---|---|
| `--from` | Yes | — | Start date YYYY-MM-DD for topic trend analysis |
| `--to` | Yes | — | End date YYYY-MM-DD for topic trend analysis |
| `--vehicle` | No | all vehicles | Filter to specific vehicle (Bronco Sport, F-150, etc.) |
| `--limit` | No | 15 | Max topics per category (critical/high/trending) |

## Enhanced Output Format

**COMPREHENSIVE TOPIC INTELLIGENCE:**
```json
{
  "critical_topics": [
    {
      "topic_hierarchy": {
        "level1": "Vehicle Maintenance and Support",
        "level2": "Customer Service Issues", 
        "level3": "Customers experiencing and resolving issues with Ford vehicles"
      },
      "call_count": 1247,
      "pct_of_calls": 18.5,
      "business_impact_score": 85,
      "impact_level": "CRITICAL",
      "metrics": {
        "avg_sentiment": -0.125,
        "negative_calls": 445,
        "negative_pct": 35.7,
        "avg_complexity": 28.4,
        "avg_aht_minutes": 15.2,
        "vehicles_affected": 12
      },
      "sample_data": {
        "sample_summary": "Customer reports transmission failure...",
        "affected_vehicles": "F-150, Bronco, Explorer"
      }
    }
  ],
  "high_impact_topics": [...],
  "trending_topics": [...],
  "summary_stats": {
    "total_calls_analyzed": 7834,
    "unique_topics_found": 25,
    "analysis_method": "comprehensive_multi_table"
  },
  "ford_intelligence": {
    "data_sources": [
      "topic_xwalk", "topic_detail", "call_data", 
      "models", "call_table", "sentiments"
    ],
    "thresholds_applied": {
      "sentiment_negative": -0.235,
      "minimum_calls": 5
    }
  }
}
```

## Routing Intelligence

### When Daisy should route here:
- Topic Analysis: "trending topics", "topic trends", "topic analysis"
- Topic Hierarchy: "topic level1/2/3", "topic breakdown", "topic categories"  
- Customer Intelligence: "what are customers calling about", "main topics"
- Business Intelligence: "top call drivers", "trending issues", "topic insights"
- Vehicle + Topics: "F-150 topics", "Bronco trending topics"

### When Daisy should route elsewhere:
- Call Volume → vehicle_volume (for simple counts without topic context)
- Customer Stories → vehicle_examples (for verbatim quotes/examples)
- Model Year Focus → model_year_analysis (for year-specific analysis)
- Keyword Search → keyword_search (for semantic/keyword intelligence)
- Parts Analysis → issue_breakdown (for parts/brand switching focus)

### Topic Hierarchy Structure:
- **Level1**: Broad categories (Vehicle Maintenance, Customer Support, etc.)
- **Level2**: Specific areas (Customer Service Issues, App Login Issues, etc.)  
- **Level3**: Detailed descriptions (actual customer problems and scenarios)

## Multi-Table Intelligence
- **topic_xwalk**: Core topic assignments linking calls to topic_ids
- **topic_detail**: Official Ford topic hierarchy (Level1→Level2→Level3)  
- **call_data**: Core call metrics (sentiment, complexity, AHT)
- **models**: Authoritative vehicle identification and model details
- **call_table**: Call summaries and metadata for context
- **sentiments**: Multi-dimensional sentiment analysis

## Performance & Quality
- **Execution Time**: 3-7 seconds for comprehensive analysis of 3K+ calls
- **Data Quality**: 100% authoritative topic hierarchy from Ford configurations
- **Business Intelligence**: Ford-specific thresholds and impact scoring
- **Real Context**: Actual call summaries for actionable business insights
