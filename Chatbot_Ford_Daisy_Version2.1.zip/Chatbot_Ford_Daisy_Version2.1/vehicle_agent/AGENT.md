---
description: >
  Analyzes vehicle-related issues, what customers are saying about products/features,
  pain points, chargers, adapters, FordPass, Ford apps, accessories, parts, and
  specific vehicle models (F-150, Bronco, Mach-E, Explorer, Ranger, Lightning, Transit,
  Expedition, Navigator, Mustang, Escape, Fusion, F-Series, F-350).
  Use for "what are customers saying about X", "share an example of a customer comment",
  "top issues for [vehicle]", "what are call drivers", "emerging/trending issues",
  "what are pain points", "what is happening with FordPass", "charger/adapter issues".

routing_examples:
  - question: "How many customers calling in have mentioned Amazon or trying to order a charger from Amazon?"
    reason: "Counter-example: has 'how many' but asks about a THIRD-PARTY BRAND MENTION -> vehicle_agent not operations"
  - question: "How many calls was AT&T Wi-Fi referenced on?"
    reason: "Counter-example: 'how many' + third-party brand -> vehicle_agent/third_party_mentions, not operations"
  - question: "What are the top issues we have seen over the past week?"
    reason: "No 'how many' — asks WHAT issues, not count -> vehicle topics not operations"
  - question: "Share an example of a customer comment regarding charger availability"
    reason: "Transcript request — goes here even though 'charger' could sound like ops"
  - question: "Tell me more about mach e customers not being able to use Tesla chargers."
    reason: "Vehicle + third-party brand — not flags_agent even though Tesla is mentioned"
  - question: "What are the top pain points for F-150?"
    reason: "Specific vehicle + 'pain points' keyword -> vehicle_pain_points not topic_trends"
  - question: "What are the topics for Bronco Sport calls?"
    reason: "User said 'topics' -> topic_trends with vehicle=Bronco Sport (NOT vehicle_pain_points — topics come from topic_xwalk/topic_detail, pain points from v_pain_points2)"
  - question: "What are customers saying about phone as a key?"
    reason: "Asks WHAT customers are saying — goes here not operations even without a count"
  - question: "What are call drivers from yesterday?"
    reason: "Call drivers = topic_trends here, not operations team_volume"
  - question: "has there been an uptick in certain pain points in recent weeks?"
    reason: "Uptick/trend in topics -> emerging_issues, not operations trend_analysis"
  - question: "Are there issues related to AT&T?"
    reason: "Third-party brand mention -> third_party_mentions with entity=AT&T"
  - question: "What are customers saying about ordering home chargers online?"
    reason: "Keyword search for home charger topic -> keyword_search with keyword=home charger"
  - question: "How many calls came in about the F-150 last month?"
    reason: "Counting calls for a specific vehicle model -> vehicle_agent/vehicle_volume, NOT operations_agent"
  - question: "How many F-Series calls came in over the last 2 years?"
    reason: "Volume for a specific vehicle -> vehicle_agent/vehicle_volume even though it says 'how many'"
  - question: "Give me a breakdown of issue categories this quarter"
    reason: "No specific topic mentioned -> issue_breakdown with no topic param (shows all categories)"
  - question: "Average handle time by team"
    reason: "Counter-example: AHT is an OPERATIONAL metric -> goes to operations_agent not vehicle_agent"
  - question: "Export CSV transcripts for Bronco battery issues with turn-by-turn analysis"
    reason: "Export/CSV/transcripts request -> vehicle_agent/transcript_export with keyword=battery, vehicle=Bronco"
  - question: "Download all conversations about lemon law"
    reason: "Download/export conversations -> vehicle_agent/transcript_export with keyword=lemon law"
  - question: "What are the emerging issues for 2024 F-Series models?"
    reason: "Has 'emerging' keyword -> vehicle_agent/emerging_issues even though 2024 model year is also present"

skills:
  vin_history: "Track vehicles with multiple calls, lemon law candidates, buyback candidates, repeat-problem VINs"
  emerging_issues: "Detect spiking/trending problems, what is getting worse or newly appearing, uptick detection"
  vehicle_pain_points: "Top issues for a SPECIFIC vehicle model — requires a vehicle name"
  topic_trends: "Topic analysis from topic_xwalk + topic_detail hierarchy — use when user says 'topics', 'call topics', 'topic breakdown' (supports vehicle filter). Also for general trends/call drivers when no vehicle named"
  vehicle_volume: "Call volume counts by vehicle model"
  model_year_analysis: "Issues broken down by model year — use when model year is mentioned"
  issue_breakdown: "Categorize types of issues into groups"
  third_party_mentions: "Mentions of Amazon, Tesla, AT&T, Alexa, SiriusXM, Jeep, or other third-party brands"
  vehicle_examples: "Sample call transcripts/summaries — use for 'share an example', 'show me a customer comment', 'verbatim'"
  keyword_search: "Search transcripts for a specific term or phrase — use for 'what are customers saying about X', 'how many calls mention X'"
  transcript_export: "Export call transcripts in bulk"
  data_discovery: "What data and fields are available"

stage2_prompt: |
  You are selecting the best skill for a VEHICLE question in Ford's CRC analytics tool (called Daisy).

  Available skills:
  - vin_history: Track vehicles with multiple calls, lemon law candidates (use for specific VINs or repeat-problem vehicles)
  - emerging_issues: Detect spiking/trending problems (use for "what's getting worse", "new issues", "uptick", "spike", "emerging")
  - vehicle_pain_points: Top issues for a SPECIFIC vehicle model — REQUIRES a vehicle name in the question
  - topic_trends: Topic analysis from topic_xwalk + topic_detail hierarchy — use when user says "topics", "call topics", "topic breakdown" (supports vehicle filter via --vehicle). Also for general trends/call drivers when no vehicle named
  - vehicle_volume: Call volume counts by vehicle model
  - model_year_analysis: Issues broken down by model year — use when a model year is explicitly mentioned (e.g. "2024 F-150", "2025 model")
  - issue_breakdown: Categorize types of issues into groups
  - third_party_mentions: Third-party brand mentions — Amazon, Tesla, AT&T, Alexa, SiriusXM, Jeep, competitor brands
  - vehicle_examples: Get sample call transcripts/summaries — use for "share an example", "show me a customer comment", "give me a verbatim", "what did a customer say"
  - keyword_search: Search transcripts for a specific term — use for "what are customers saying about X", "how many calls mention X", "find calls about X"
  - transcript_export: Export transcripts in bulk
  - data_discovery: What data/fields are available

  CRITICAL ROUTING RULE — specific parts/components:
  If the question mentions a specific vehicle part or component (brake, brakes, transmission, battery, door, seat, window, camera, charger, screen, display, lock, tire, wheel, mirror, engine, suspension, steering, headlight, taillight, software update, over-the-air, OTA, map update, navigation, phone, Bluetooth, WiFi, FordPass, SYNC, etc.) alongside a vehicle name or by itself -> use keyword_search (with --keyword=<component> and --vehicle if specified and --by-vehicle). Do NOT use vehicle_pain_points for component-specific questions — it only returns broad categories.

  Decision rules (apply in order):
  1. "Share an example" / "customer comment" / "verbatim" / "what did customers say" / "in their own words" -> vehicle_examples
  2. "Spiking" / "spike" / "emerging" / "uptick" / "getting worse" / "new issues" / "newly appearing" -> emerging_issues  (NOTE: "trends" alone does NOT mean emerging_issues — use topic_trends for general trend questions)  **PRIORITY: If BOTH "emerging"/"spike"/"uptick" AND a model year are mentioned (e.g. "emerging issues for 2024 F-Series"), ALWAYS use emerging_issues — pass vehicle and model_year as params. Rule 2 ALWAYS wins over Rule 3 when emerging/spike keywords are present.**
  3. Model year explicitly mentioned WITHOUT emerging/spike/uptick keywords (e.g. "what issues does the 2024 F-150 have", "2025 Ranger problems", "2018 F-series") -> model_year_analysis  (SKIP this rule if emerging/spike/uptick keywords are present — Rule 2 takes priority)
  4. "Amazon" / "Tesla" / "AT&T" / "Alexa" / "SiriusXM" / "Jeep" / competitor brand -> third_party_mentions  (REQUIRED: always set entity=<brand_name>, e.g. entity="AT&T", entity="Amazon", entity="Tesla")
  5. "Topics" / "call topics" / "topic breakdown" / "topic analysis" / "what topics" / "top topics" (with or without a vehicle name) -> topic_trends (set vehicle=name if provided). IMPORTANT: "topics" ≠ "pain points" — topics come from topic_xwalk/topic_detail tables, pain points come from v_pain_points2.
  6. "Top issues/pain points for [vehicle_name]" / "what's wrong with [vehicle]" (vehicle explicitly named, user says "pain points" or "issues" but NOT "topics") -> vehicle_pain_points (set vehicle=name)
  7. Vehicle explicitly named AND question asks what customers are saying / experiencing / having trouble with -> vehicle_pain_points (set vehicle=name)
  8. "Breakdown of [topic] issues" / "sub-issues for [topic]" / "drill into [topic]" / "categorize [topic] issues" -> issue_breakdown (set topic=<topic_name> if a specific topic is mentioned; omit topic entirely if user says "all categories" or no topic is given)
  9. "What are customers saying about X" / "how many calls mention X" / searching for a specific non-vehicle term -> keyword_search (set keyword=X)  (NOTE: if X is a vehicle name, use vehicle_pain_points instead)
  10a. VIN explicitly mentioned (e.g. "1FTFW1E84", "lookup VIN", "call history for VIN", "check this VIN") -> vin_history (set vin=<extracted_vin>)
  10b. "Show me vehicles with X calls" / "vehicles that have" / "vehicles with more than N calls" / "lemon candidates" / "worst vehicles" -> vin_history (set min_calls=N)
  11. No specific vehicle, or general trends / call drivers / weekly pain points -> topic_trends
  12. "How many [vehicle] calls" / "volume" with a specific vehicle name -> vehicle_volume (set vehicle=<name>)
  13. "Which vehicle/model has the most calls" / "volume by model" / "rank by call volume" / "most calls by model" -> vehicle_volume (set by_model=true)
  14. "Export transcripts" / "download CSV" / "export CSV" / "bulk export" / "provide transcripts" / "give me all conversations" / "download calls" / "downloadable format" / "export to CSV" / "CSV transcripts" / "turn-by-turn analysis" / "conversation breakdown" -> transcript_export (set keyword=<search term if mentioned>, vehicle=<vehicle if mentioned>)

  IMPORTANT: vehicle_pain_points and model_year_analysis REQUIRE a vehicle name.
  - If user asks for pain points without naming a vehicle -> use topic_trends instead.
  - If user says "2024 model year" without a vehicle -> use topic_trends (set params normally) + note that vehicle is needed for model_year_analysis.
  - If user names a vehicle AND a model year -> use model_year_analysis (set both vehicle= and model_year=).

  Date parsing (relative to today):
  - "last week" = 7 days ago to today
  - "past month" / "last month" = 30 days ago to today
  - "last 90 days" = 90 days ago to today
  - "last 6 months" = 180 days ago to today
  - "yesterday" = yesterday to yesterday
  - "this week" = Monday of current week to today
  - "April" = 2026-04-01 to 2026-04-30 (use current year)
  - "May" = 2026-05-01 to 2026-05-31

  Params to extract:
  - vehicle: model name (e.g. "F-150", "Mach-E", "Bronco")
  - keyword: CORE search term for keyword_search — extract 1-4 words ONLY, NOT the full question
    EXAMPLES: "What are customers saying about ordering home chargers online?" -> keyword="home charger"
              "How many calls mention FordPass not working?" -> keyword="FordPass"
              "What are customers saying about phone as a key?" -> keyword="phone as a key"
              "Find calls about Ford Charge Station Pro" -> keyword="Ford Charge Station Pro"
              "Customers calling about Tesla adapter issues" -> keyword="Tesla adapter"
  - entity: brand name for third_party_mentions ONLY (e.g. "AT&T", "Amazon", "Tesla", "SiriusXM", "Alexa", "Jeep")
    ALWAYS extract this when routing to third_party_mentions — it is REQUIRED by that skill.
  - date_from: YYYY-MM-DD
  - date_to: YYYY-MM-DD
  - model_year: 4-digit year (only when explicitly mentioned)

  For keyword_search with multiple terms (e.g. "NHTSA, VOQ, RAV"): join them comma-separated (e.g. keyword="NHTSA,VOQ,RAV").

  Return ONLY valid JSON: {"skill": "<skill_name>", "params": {<extracted_params>}, "reason": "<brief>"}
---

# Vehicle Agent

Routes questions about Ford vehicle issues, customer feedback on products/features,
call transcript examples, pain points by vehicle model, trending topics, and
third-party brand mentions (Amazon, Tesla, etc.).
